import { GoogleGenAI, Modality } from "@google/genai";
import { TtsRequestParams, VoiceStyle } from "../types";

const STYLE_DESCRIPTIONS: Record<VoiceStyle, string> = {
  'Vocal Smile': 'The "Vocal Smile": The soft palate is raised to keep the tone bright, sunny, and explicitly inviting.',
  'Newscaster': 'Professional, authoritative, clear articulation with standard broadcast cadence.',
  'Whisper': 'Intimate, breathy, close-to-mic proximity effect.',
  'Empathetic': 'Warm, understanding, soft tone with gentle inflections.',
  'Promo/Hype': 'High energy, punchy consonants, elongated vowels on excitement words.',
  'Deadpan': 'Flat affect, minimal pitch variation, dry delivery.'
};

const getClient = () => {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing. Please ensure process.env.GEMINI_API_KEY is available.");
  }
  return new GoogleGenAI({ apiKey });
};

// Convert raw PCM Base64 to WAV Base64 so it can be played in browser
function pcmBase64ToWavBase64(pcmBase64: string, sampleRate = 24000): string {
  const binaryString = atob(pcmBase64);
  const pcmData = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    pcmData[i] = binaryString.charCodeAt(i);
  }

  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmData.length;
  const chunkSize = 36 + dataSize;
  const wavHeader = new ArrayBuffer(44);
  const view = new DataView(wavHeader);

  const writeString = (view: DataView, offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  writeString(view, 0, 'RIFF');
  view.setUint32(4, chunkSize, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);
  writeString(view, 36, 'data');
  view.setUint32(40, dataSize, true);

  const wavData = new Uint8Array(44 + dataSize);
  wavData.set(new Uint8Array(wavHeader), 0);
  wavData.set(pcmData, 44);

  // Convert resulting WAV byte array back to base64
  let wavBase64 = '';
  // process in chunks to avoid call stack size exceeded
  const chunkSizeForBtoa = 0x8000;
  for (let i = 0; i < wavData.length; i += chunkSizeForBtoa) {
    wavBase64 += String.fromCharCode.apply(null, Array.from(wavData.subarray(i, i + chunkSizeForBtoa)));
  }
  return btoa(wavBase64);
}

export const generateVoiceover = async (params: TtsRequestParams): Promise<string> => {
  const ai = getClient();
  
  // Construct a prompt that leverages the "director" instructions.
  // We use this prompt to guide how the speech should be delivered.
  const promptText = `[DIRECTOR'S NOTES]
Scene Location & Atmosphere: ${params.scene}
Speaker Context/Physical State: ${params.sampleContext}
Performance Style: ${params.style} (${STYLE_DESCRIPTIONS[params.style]})
Pacing Instruction: Please speak at approximately ${params.pace}x normal pace.

[SCRIPT TO PERFORM]
${params.speakerText}
`;

  try {
    const response = await ai.models.generateContent({
      // We specifically use flash-tts-preview as per the instructions
      model: 'gemini-3.1-flash-tts-preview',
      contents: [{ parts: [{ text: promptText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: params.voiceName },
          },
        },
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio data received from Gemini.");
    }

    // Convert raw PCM (24000hz, 16bit, mono) into WAV
    const wavBase64 = pcmBase64ToWavBase64(base64Audio, 24000);
    return `data:audio/wav;base64,${wavBase64}`;
  } catch (error) {
    console.error("Gemini TTS API Error:", error);
    throw error;
  }
};

export const reformatTextForStress = async (text: string): Promise<string> => {
  const ai = getClient();
  
  const instruction = `You are a professional Voiceover Director and linguist. 
Your task is to reformat the following text for a Text-to-Speech (TTS) engine.
The TTS engine places phonetic stress on a syllable when its vowel is capitalized (e.g., "МожлИво", "зОкрема", "дЕрево").

Rules:
1. ONLY modify vowels in words of two or more syllables.
2. Put the stressed vowel in UPPERCASE. Convert all other letters to lowercase unless it's a proper noun.
3. Be highly accurate, especially for Ukrainian or Russian words where stress is ambiguous.
4. Do not change the meaning, add words, or remove words. Keep all punctuation exactly intact.
5. If the text is naturally in English, you can leave it as is, or apply stress logic if helpful.

Text to reformat:
${text}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [{ parts: [{ text: instruction }] }],
    });

    return response.text || text;
  } catch (error) {
    console.error("Gemini Auto-Stress API Error:", error);
    throw error;
  }
};

