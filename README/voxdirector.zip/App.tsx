
import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { EditorStatus, VoiceTemplate, VoiceName, VoiceStyle, TtsRequestParams } from './types';
import { generateVoiceover, reformatTextForStress } from './services/geminiService';
import { Mic, Zap, Moon, Sun, Play, Download, Loader2, Volume2, Wand2, Info, FileText, X, Upload, Save, Clock, Captions } from 'lucide-react';

const PRESETS: Record<VoiceTemplate, { scene: string; sampleContext: string }> = {
  youtube_intro: {
    scene: 'A bright, colorful YouTube studio with a fun and engaging atmosphere.',
    sampleContext: 'The speaker is excited, looking directly at the camera, and speaks with high energy to hook the viewer immediately.'
  },
  podcast_dialogue: {
    scene: 'A cozy, soundproofed podcast recording studio. Dim lighting, relaxed mood.',
    sampleContext: 'The speaker is relaxed, conversational, sitting close to the microphone, speaking clearly with a thoughtful tone.'
  },
  emotional_storytelling: {
    scene: 'A quiet room at night, rain slightly tapping on the window.',
    sampleContext: 'The speaker is reflective, speaking softly and slowly, with a touch of vulnerability and deep emotion.'
  },
  corporate_presentation: {
    scene: 'A modern, well-lit executive boardroom during a quarterly review.',
    sampleContext: 'The speaker is confident, authoritative, and speaks at a measured, professional pace to convey clarity and trust.'
  }
};

const App: React.FC = () => {
  const [template, setTemplate] = useState<VoiceTemplate>('youtube_intro');
  const [scene, setScene] = useState(PRESETS['youtube_intro'].scene);
  const [sampleContext, setSampleContext] = useState(PRESETS['youtube_intro'].sampleContext);
  const [speakerText, setSpeakerText] = useState('Good morning!  London is the capital of Great Britain.');
  
  const [voiceName, setVoiceName] = useState<VoiceName>('Puck');
  const [style, setStyle] = useState<VoiceStyle>('Empathetic');
  const [pace, setPace] = useState<number>(1.0);
  
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [srtUrl, setSrtUrl] = useState<string | null>(null);
  const [status, setStatus] = useState<EditorStatus>(EditorStatus.IDLE);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isReformatting, setIsReformatting] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const recognitionRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  const handleInsertTag = (tag: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;

    const newText = speakerText.substring(0, start) + tag + speakerText.substring(end);
    setSpeakerText(newText);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + tag.length, start + tag.length);
    }, 0);
  };

  useEffect(() => {
    return () => {
      if (srtUrl) URL.revokeObjectURL(srtUrl);
    };
  }, [srtUrl]);

  const handleReformatText = async () => {
    if (!speakerText.trim()) return;
    setIsReformatting(true);
    try {
      const formattedText = await reformatTextForStress(speakerText);
      setSpeakerText(formattedText);
    } catch (e) {
      console.error(e);
      alert("Failed to Auto-Stress the text. See console for details.");
    } finally {
      setIsReformatting(false);
    }
  };

  const estimatedSeconds = useMemo(() => {
    if (!speakerText.trim()) return 0;
    const words = speakerText.trim().split(/\s+/).filter(w => w.length > 0).length;
    // Base 140 WPM ~ 2.33 words per second at 1.0x pace
    let baseSeconds = words / 2.33;
    
    // Add extra time for explicit pauses
    const numEllipsis = (speakerText.match(/\.\.\./g) || []).length;
    const numDashes = (speakerText.match(/—/g) || []).length;
    
    baseSeconds += (numEllipsis * 1.5);
    baseSeconds += (numDashes * 0.5);
    
    return Math.max(1, Math.round(baseSeconds / pace));
  }, [speakerText, pace]);

  const formatTime = (secs: number) => {
    if (secs < 60) return `${secs}s`;
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s}s`;
  };

  const initRecognition = () => {
    if (recognitionRef.current) return true;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Your browser does not support Speech Recognition. Please try Chrome or Edge.");
      return false;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = navigator.language || 'en-US';

    recognition.onresult = (event: any) => {
      let currentTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
           setSpeakerText(prev => prev + (prev.length > 0 && !prev.endsWith(' ') ? ' ' : '') + event.results[i][0].transcript);
        }
      }
    };

    recognition.onend = () => {
      setIsRecording(false);
    };
    
    recognition.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      setIsRecording(false);
    };

    recognitionRef.current = recognition;
    return true;
  };

  const toggleRecording = () => {
    if (!initRecognition()) return;

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (e) {
        console.error("Error starting speech recognition:", e);
      }
    }
  };

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const data = {
      scene,
      sampleContext,
      speakerText,
      voiceName,
      style,
      pace
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'voxdirector-project.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.scene !== undefined) setScene(json.scene);
        if (json.sampleContext !== undefined) setSampleContext(json.sampleContext);
        if (json.speakerText !== undefined) setSpeakerText(json.speakerText);
        if (json.voiceName !== undefined) setVoiceName(json.voiceName);
        if (json.style !== undefined) setStyle(json.style);
        if (json.pace !== undefined) setPace(json.pace);
        // Reset template to "custom" or let it stay, but actually there is no "custom" template string.
      } catch (error) {
        console.error("Invalid JSON file", error);
        alert("Failed to parse the project file.");
      }
    };
    reader.onloadend = () => {
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const handleTemplateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const nextTemplate = e.target.value as VoiceTemplate;
    setTemplate(nextTemplate);
    setScene(PRESETS[nextTemplate].scene);
    setSampleContext(PRESETS[nextTemplate].sampleContext);
  };

  const handleGenerate = useCallback(async () => {
    if (!speakerText.trim() || !scene.trim() || !sampleContext.trim()) return;

    setStatus(EditorStatus.LOADING);
    setAudioUrl(null);
    if (srtUrl) URL.revokeObjectURL(srtUrl);
    setSrtUrl(null);

    try {
      const params: TtsRequestParams = {
        scene,
        sampleContext,
        speakerText,
        voiceName,
        style,
        pace
      };
      
      const url = await generateVoiceover(params);
      setAudioUrl(url);

      // --- Synthetic SRT Generation ---
      const segments = speakerText.replace(/([.!?\n]+)/g, "$1|").split("|").map(s => s.trim()).filter(s => s.length > 0);
      let currentSeconds = 0;
      let srtOutput = '';
      
      const formatSrtTime = (totalSeconds: number) => {
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = Math.floor(totalSeconds % 60);
        const milliseconds = Math.floor((totalSeconds % 1) * 1000);
        
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')},${String(milliseconds).padStart(3, '0')}`;
      };

      segments.forEach((sentence, index) => {
        const words = sentence.split(/\s+/).filter(w => w.length > 0).length;
        if (words === 0) return;
        let baseSeconds = words / 2.33;
        const numEllipsis = (sentence.match(/\.\.\./g) || []).length;
        const numDashes = (sentence.match(/—/g) || []).length;
        baseSeconds += (numEllipsis * 1.5);
        baseSeconds += (numDashes * 0.5);
        
        const duration = baseSeconds / pace;
        const startTime = currentSeconds;
        const endTime = currentSeconds + duration;
        
        srtOutput += `${index + 1}\n`;
        srtOutput += `${formatSrtTime(startTime)} --> ${formatSrtTime(endTime)}\n`;
        srtOutput += `${sentence}\n\n`;
        
        currentSeconds = endTime;
      });

      const srtBlob = new Blob([srtOutput], { type: 'text/srt' });
      setSrtUrl(URL.createObjectURL(srtBlob));
      
      setStatus(EditorStatus.SUCCESS);
    } catch (error) {
      console.error(error);
      setStatus(EditorStatus.ERROR);
    }
  }, [speakerText, scene, sampleContext, voiceName, style, pace, srtUrl]);

  const handleDownloadBundle = () => {
    const timestamp = Date.now();
    let delay = 0;

    if (audioUrl) {
      const a = document.createElement('a');
      a.href = audioUrl;
      a.download = `voxdirector-${timestamp}.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      delay += 300;
    }

    if (srtUrl) {
      setTimeout(() => {
        const a = document.createElement('a');
        a.href = srtUrl;
        a.download = `voxdirector-${timestamp}.srt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }, delay);
    }
  };

  return (
    <>
      <div className={`min-h-screen ${isDarkMode ? 'dark' : ''} bg-slate-50 dark:bg-slate-950 flex flex-col transition-colors duration-300 font-sans text-slate-900 dark:text-slate-100`}>
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-violet-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-violet-200 dark:shadow-none">
                <Mic className="w-5 h-5" />
            </div>
            <div>
                <h1 className="text-xl font-bold tracking-tight leading-none">Vox<span className="text-violet-600 dark:text-violet-400">Director</span></h1>
                <p className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">AI Voiceover Studio</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <div className="hidden sm:flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700">
                <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>Gemini Flash TTS</span>
             </div>
             
             {/* Divider */}
             <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-1 hidden sm:block"></div>

             {/* Export/Import Controls */}
             <div className="flex items-center">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleImport} 
                  accept=".json" 
                  className="hidden" 
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Import Project"
                >
                  <Upload className="w-5 h-5" />
                </button>
                <button
                  onClick={handleExport}
                  className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Export Project"
                >
                  <Save className="w-5 h-5" />
                </button>
             </div>

             <button
               onClick={() => setIsHelpOpen(true)}
               className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
               aria-label="Audio Tags Guide"
               title="Audio Tags Guide"
             >
               <Info className="w-5 h-5" />
             </button>

             <button
               onClick={() => setIsDarkMode(!isDarkMode)}
               className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
               title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
             >
               {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
             </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Context & Script */}
            <section className="lg:col-span-8 flex flex-col gap-6">
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold flex items-center gap-2">
                       <Wand2 className="w-5 h-5 text-violet-500" />
                       Director's Setup
                    </h2>
                    <select 
                      value={template} 
                      onChange={handleTemplateChange}
                      className="text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 focus:ring-2 focus:ring-violet-500 focus:border-violet-500 dark:text-slate-200"
                    >
                      <option value="youtube_intro">🎬 YouTube Intro</option>
                      <option value="podcast_dialogue">🎙️ Podcast Dialogue</option>
                      <option value="emotional_storytelling">📖 Emotional Storytelling</option>
                      <option value="corporate_presentation">💼 Corporate Presentation</option>
                    </select>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Scene (Location/Atmosphere)</label>
                      <textarea 
                        rows={2}
                        value={scene}
                        onChange={(e) => setScene(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500 resize-none transition-all dark:text-slate-200"
                        placeholder="Describe where the scene takes place..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Sample Context (Speaker's State)</label>
                      <textarea 
                        rows={3}
                        value={sampleContext}
                        onChange={(e) => setSampleContext(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500 resize-none transition-all dark:text-slate-200"
                        placeholder="Describe the speaker's emotional and physical state..."
                      />
                    </div>
                  </div>
                </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 flex flex-col relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <h2 className="text-lg font-semibold flex items-center gap-2">
                         <Mic className="w-5 h-5 text-violet-500" />
                         Speaker #1 Text
                      </h2>
                      {estimatedSeconds > 0 && (
                        <span 
                          className="text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-2 py-1 rounded-md flex items-center gap-1.5 border border-slate-200 dark:border-slate-700"
                          title="Estimated generated audio length"
                        >
                          <Clock className="w-3.5 h-3.5" />
                          ~{formatTime(estimatedSeconds)}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleReformatText}
                        disabled={isReformatting || !speakerText.trim()}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all bg-violet-100 text-violet-700 hover:bg-violet-200 dark:bg-violet-900/30 dark:text-violet-300 dark:hover:bg-violet-900/50 disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Automatically place phonetic stress on vowels for better pronunciation"
                      >
                        {isReformatting ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Wand2 className="w-3.5 h-3.5" />
                        )}
                        Auto-Stress
                      </button>

                      <button
                        onClick={toggleRecording}
                        title={isRecording ? "Stop listening" : "Dictate script with your voice"}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                          isRecording 
                            ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400 animate-pulse'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                        }`}
                      >
                        <Mic className="w-3.5 h-3.5" />
                        {isRecording ? 'Listening...' : 'Dictate'}
                      </button>
                    </div>
                  </div>
                  <textarea 
                    ref={textareaRef}
                    value={speakerText}
                    onChange={(e) => setSpeakerText(e.target.value)}
                    className="w-full min-h-[160px] bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-base focus:ring-2 focus:ring-violet-500 focus:border-violet-500 resize-none transition-all dark:text-slate-200"
                    placeholder="Enter the actual script to be voiced here, click Auto-Stress to fix pronunciation, or Dictate to use your voice..."
                  />
                  <div className="mt-3 flex flex-wrap gap-2">
                    {['[laughs]', '[whispers]', '[sighs]', '[crying]', '[enthusiasm]', '[neutral]', '[pause]', '[silence]'].map(tag => (
                      <button
                        key={tag}
                        onClick={() => handleInsertTag(tag)}
                        className="text-xs bg-slate-100 font-mono hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 py-1.5 px-3 rounded-lg transition-colors border border-slate-200 dark:border-slate-700 shadow-sm shrink-0"
                        title={`Insert ${tag} tag`}
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
            </section>

            {/* Right Column: Controls & Output */}
            <section className="lg:col-span-4 flex flex-col gap-6">
                {/* Voice Controls */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6">
                  <h2 className="text-lg font-semibold mb-5 flex items-center gap-2">
                    <Volume2 className="w-5 h-5 text-violet-500" />
                    Speaker Controls
                  </h2>
                  
                  <div className="space-y-5">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Voice Selection</label>
                      <select 
                        value={voiceName}
                        onChange={(e) => setVoiceName(e.target.value as VoiceName)}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500 dark:text-slate-200"
                      >
                        <option value="Aoede">Aoede (Female)</option>
                        <option value="Charon">Charon (Male)</option>
                        <option value="Fenrir">Fenrir (Male)</option>
                        <option value="Kore">Kore (Female)</option>
                        <option value="Puck">Puck (Male)</option>
                        <option value="Zephyr">Zephyr (Male)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Style</label>
                      <select 
                        value={style}
                        onChange={(e) => setStyle(e.target.value as VoiceStyle)}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500 dark:text-slate-200"
                      >
                        <option value="Vocal Smile">Vocal Smile</option>
                        <option value="Newscaster">Newscaster</option>
                        <option value="Whisper">Whisper</option>
                        <option value="Empathetic">Empathetic</option>
                        <option value="Promo/Hype">Promo/Hype</option>
                        <option value="Deadpan">Deadpan</option>
                      </select>
                    </div>

                    <div>
                       <div className="flex justify-between items-center mb-2">
                           <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Pace</label>
                           <span className="text-xs font-medium text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-900/30 px-2 py-0.5 rounded-md">{pace.toFixed(1)}x</span>
                       </div>
                       <input 
                         type="range" 
                         min="0.5" 
                         max="2.0" 
                         step="0.1" 
                         value={pace}
                         onChange={(e) => setPace(parseFloat(e.target.value))}
                         className="w-full accent-violet-600"
                       />
                       <div className="flex justify-between mt-1 text-[10px] text-slate-400 font-medium">
                         <span>0.5x</span>
                         <span>Norm</span>
                         <span>2.0x</span>
                       </div>
                    </div>
                  </div>

                  <button 
                    onClick={handleGenerate}
                    disabled={status === EditorStatus.LOADING || !speakerText.trim()}
                    title={status === EditorStatus.LOADING ? "Generating..." : "Synthesize audio from text"}
                    className="mt-8 w-full bg-violet-600 hover:bg-violet-700 text-white font-medium py-3 px-4 rounded-xl shadow-md shadow-violet-200 dark:shadow-none transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {status === EditorStatus.LOADING ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Generating Audio...
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 fill-white" />
                        Generate Voiceover
                      </>
                    )}
                  </button>
                  {status === EditorStatus.ERROR && (
                    <p className="mt-3 text-sm text-red-500 text-center font-medium">Failed to generate audio. Check console.</p>
                  )}
                </div>

                {/* Output Section */}
                <div className={`bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 transition-all duration-500 ${audioUrl ? 'opacity-100 translate-y-0' : 'opacity-50 pointer-events-none'}`}>
                  <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Download className="w-5 h-5 text-violet-500" />
                    Output
                  </h2>
                  
                  {audioUrl ? (
                    <div className="flex flex-col gap-4 animate-in fade-in duration-500">
                       <audio 
                         ref={audioRef}
                         controls 
                         src={audioUrl} 
                         className="w-full rounded-xl bg-slate-50 dark:bg-slate-950" 
                       />
                       <button
                         onClick={handleDownloadBundle}
                         title="Save Audio (WAV) and Subtitles (SRT) to your device"
                         className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-medium py-2.5 px-4 rounded-xl transition-colors text-sm"
                       >
                         <Download className="w-4 h-4" />
                         <span>Download Audio {srtUrl && '& SRT'}</span>
                       </button>
                    </div>
                  ) : (
                    <div className="h-24 flex items-center justify-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl px-4 text-center text-sm text-slate-400">
                       Audio player will appear here after generation
                    </div>
                  )}
                </div>
            </section>
        </div>
      </main>

    </div>
    
    {/* Audio Tags Guide Modal */}
    {isHelpOpen && (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm" onClick={() => setIsHelpOpen(false)}>
        <div 
          className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200" 
          onClick={e => e.stopPropagation()}
        >
          <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
             <h2 className="text-xl font-semibold flex items-center gap-2">
                <Info className="w-5 h-5 text-violet-500" />
                Audio Tags & Formatting Guide
             </h2>
             <button 
               onClick={() => setIsHelpOpen(false)} 
               title="Close guide"
               className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-800"
             >
               <X className="w-5 h-5" />
             </button>
          </div>
          <div className="p-6">
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-5 leading-relaxed">
              Gemini Flash TTS supports inline audio tags. Insert them directly into your text to shape the delivery dynamically mid-sentence.
            </p>
            <div className="flex flex-wrap gap-2 text-xs font-mono mb-6">
              <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm shrink-0">[laughs]</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm shrink-0">[whispers]</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm shrink-0">[sighs]</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm shrink-0">[crying]</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm shrink-0">[enthusiasm]</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shadow-sm shrink-0">[neutral]</span>
            </div>

            <div className="mb-6">
              <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200 mb-2">
                Punctuation Sensitivity
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mb-3 leading-relaxed">
                Gemini Flash TTS is highly sensitive to punctuation. Use these to control pacing and inflection:
              </p>
              <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/30 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
                <li className="flex items-start gap-3">
                   <span className="font-mono font-bold text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-900/30 px-1.5 py-0.5 rounded">...</span>
                   <span className="mt-0.5"><strong>Ellipsis:</strong> Creates a natural pause for a breath or dramatic effect.</span>
                </li>
                <li className="flex items-start gap-3">
                   <span className="font-mono font-bold text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-900/30 px-1.5 py-0.5 rounded">—</span>
                   <span className="mt-0.5"><strong>Dash:</strong> Forces the model to place a logical accent/stress on the next word.</span>
                </li>
                <li className="flex items-start gap-3">
                   <span className="font-mono font-bold text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-900/30 px-1.5 py-0.5 rounded">!</span>
                   <span className="mt-0.5"><strong>Exclamation:</strong> Raises the pitch of the voice at the end of the sentence.</span>
                </li>
                <li className="flex items-start gap-3">
                   <span className="font-mono font-bold text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-900/30 px-1.5 py-0.5 rounded">A E I</span>
                   <span className="mt-0.5"><strong>Syllable Stress:</strong> Capitalize a vowel to force the stress mark on that specific syllable (e.g., <i>МожлИво</i>).</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-5 border border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between mb-4">
                 <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Example Usage</span>
                 <button
                   onClick={() => {
                     setSpeakerText("Welcome to the Vox Director! [laughs] I can't believe we are finally here. [whispers] It's been a secret for so long... [sighs] But the wait is over. [enthusiasm] Let's get started right now! [neutral] And now, the weather is fine.");
                     setIsHelpOpen(false);
                   }}
                   title="Replace current text with this example"
                   className="text-xs flex items-center gap-1.5 text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300 font-medium transition-colors bg-violet-100 hover:bg-violet-200 dark:bg-violet-900/30 dark:hover:bg-violet-900/50 px-3 py-1.5 rounded-md"
                >
                  <FileText className="w-3.5 h-3.5" /> Use This For Speaker #1
                </button>
              </div>
              <p className="text-sm italic text-slate-700 dark:text-slate-300 leading-relaxed font-serif bg-white dark:bg-slate-900 p-4 rounded-lg border border-slate-100 dark:border-slate-800">
                "Welcome to the show! <span className="text-violet-600 dark:text-violet-400 font-mono text-xs not-italic font-bold">[laughs]</span> I can't believe we are finally here. <span className="text-violet-600 dark:text-violet-400 font-mono text-xs not-italic font-bold">[whispers]</span> It's been a secret for so long... <span className="text-violet-600 dark:text-violet-400 font-mono text-xs not-italic font-bold">[sighs]</span> But the wait is over. <span className="text-violet-600 dark:text-violet-400 font-mono text-xs not-italic font-bold">[enthusiasm]</span> Let's get started right now! <span className="text-violet-600 dark:text-violet-400 font-mono text-xs not-italic font-bold">[neutral]</span> And now, the weather."
              </p>
            </div>
          </div>
        </div>
      </div>
    )}
    </>
  );
};

export default App;

