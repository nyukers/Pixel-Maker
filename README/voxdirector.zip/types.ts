export enum EditorStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export type VoiceTemplate = 'youtube_intro' | 'podcast_dialogue' | 'emotional_storytelling' | 'corporate_presentation';

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export type VoiceName = 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' | 'Aoede';

export type VoiceStyle = 'Vocal Smile' | 'Newscaster' | 'Whisper' | 'Empathetic' | 'Promo/Hype' | 'Deadpan';

export interface TtsRequestParams {
  scene: string;
  sampleContext: string;
  speakerText: string;
  voiceName: VoiceName;
  style: VoiceStyle;
  pace: number;
}
