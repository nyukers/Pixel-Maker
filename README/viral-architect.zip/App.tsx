
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Editor } from './components/Editor';
import { Preview } from './components/Preview';
import { ChatInterface, ChatInterfaceHandle } from './components/ChatInterface';
import { generateMasterPrompt } from './services/geminiService';
import { EditorStatus } from './types';
import { Bot, Zap, Moon, Sun, ArrowDown, RefreshCw, Info, X, Download } from 'lucide-react';

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [outputHtml, setOutputHtml] = useState('');
  const [status, setStatus] = useState<EditorStatus>(EditorStatus.IDLE);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [showInfo, setShowInfo] = useState(true);
  const chatInterfaceRef = useRef<ChatInterfaceHandle>(null);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleGenerate = useCallback(async () => {
    if (!inputText.trim()) return;

    setStatus(EditorStatus.LOADING);
    setShowChat(false); // Reset chat when regenerating
    try {
      const generatedHtml = await generateMasterPrompt(inputText);
      setOutputHtml(generatedHtml);
      setStatus(EditorStatus.SUCCESS);
    } catch (error) {
      console.error(error);
      setStatus(EditorStatus.ERROR);
    }
  }, [inputText]);

  const handleStartInterview = () => {
    setShowChat(true);
    // Scroll to chat
    setTimeout(() => {
      document.getElementById('chat-section')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleNewIdea = () => {
    setInputText('');
    setOutputHtml('');
    setStatus(EditorStatus.IDLE);
    setShowChat(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGlobalExport = () => {
    // If chat is active and has content, export chat result
    if (showChat && chatInterfaceRef.current) {
        chatInterfaceRef.current.exportResult();
        return;
    }

    // Otherwise, if we have a generated master prompt, export that
    if (outputHtml) {
        const blob = new Blob([outputHtml], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'master-prompt.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex flex-col transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-300 dark:border-slate-800 sticky top-0 z-30 transition-colors duration-300 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-md shadow-indigo-200 dark:shadow-none">
                <Bot className="w-5 h-5" />
            </div>
            <div>
                <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight leading-none">Viral<span className="text-indigo-600 dark:text-indigo-400">Architect</span></h1>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider">AI Prompt Engineering Tool</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="hidden sm:flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-full border border-slate-300 dark:border-slate-700 shadow-sm dark:shadow-none">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Powered by Gemini 3+</span>
             </div>

             {/* Global Export Button */}
             {(outputHtml || showChat) && (
                 <button
                    onClick={handleGlobalExport}
                    className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg text-sm font-medium shadow-sm transition-all"
                    title={showChat ? "Export Session Result" : "Export Master Prompt"}
                 >
                    <Download className="w-4 h-4" />
                    <span className="hidden sm:inline">Export</span>
                 </button>
             )}

             <button
               onClick={() => setShowInfo(true)}
               className="p-2 rounded-lg text-slate-500 dark:text-slate-400 bg-white dark:bg-transparent border border-slate-300 dark:border-transparent hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm dark:shadow-none font-bold"
               aria-label="Info"
             >
               <Info className="w-5 h-5" />
             </button>
             
             <button
               onClick={() => setIsDarkMode(!isDarkMode)}
               className="p-2 rounded-lg text-slate-500 dark:text-slate-400 bg-white dark:bg-transparent border border-slate-300 dark:border-transparent hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm dark:shadow-none"
               aria-label="Toggle theme"
             >
               {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
             </button>
          </div>
        </div>
      </header>

      {/* Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 dark:border-slate-800 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  <Info className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  How it Works
                </h3>
                <button 
                  onClick={() => setShowInfo(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300">
                <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                  <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-1 flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs">1</div>
                    Generate Master Prompt
                  </h4>
                  <p>Enter a topic (e.g., "Cyberpunk Car Build") to generate a specialized "Master Prompt" that acts as a Viral Video Director.</p>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                  <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-1 flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs">2</div>
                    Select Concept
                  </h4>
                  <p>Execute the prompt. The AI will generate 15 unique concepts. Simply type a number (e.g., "3") to select one.</p>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                  <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-1 flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs">3</div>
                    Auto-Execute
                  </h4>
                  <p>The AI automatically generates a 3-stage image sequence (Before → Progress → After) and video transition prompts for Runway/Kling.</p>
                </div>
              </div>

              <button 
                onClick={() => setShowInfo(false)}
                className="w-full mt-6 bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-xl font-medium transition-colors"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
        
        {/* Step 1: Input */}
        <section className="min-h-[300px]">
            <div className="flex items-center gap-2 mb-4">
                <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">1</div>
                <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Define Topic</h2>
            </div>
            <Editor 
                value={inputText} 
                onChange={setInputText} 
                onGenerate={handleGenerate}
                status={status}
            />
        </section>

        {/* Step 2: Preview & Master Prompt */}
        {(status === EditorStatus.SUCCESS || status === EditorStatus.LOADING) && (
            <section className="min-h-[400px] animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-2 mb-4">
                    <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">2</div>
                    <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Generated Master Prompt</h2>
                </div>
                <Preview 
                    htmlContent={outputHtml}
                    status={status}
                    onChange={setOutputHtml}
                />
                
                {status === EditorStatus.SUCCESS && !showChat && (
                    <div className="flex justify-center mt-6">
                        <button 
                            onClick={handleStartInterview}
                            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all active:scale-95"
                        >
                            <ArrowDown className="w-5 h-5" />
                            Start Viral Session
                        </button>
                    </div>
                )}
            </section>
        )}

        {/* Step 3: Chat Interface */}
        {showChat && (
            <section id="chat-section" className="min-h-[600px] animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
                <div className="flex items-center gap-2 mb-4">
                    <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">3</div>
                    <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Execute Prompt</h2>
                </div>
                <ChatInterface 
                    ref={chatInterfaceRef}
                    systemPrompt={outputHtml} 
                />

                <div className="flex justify-center mt-8">
                    <button 
                        onClick={handleNewIdea}
                        className="flex items-center gap-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 px-6 py-3 rounded-xl font-semibold transition-all active:scale-95"
                    >
                        <RefreshCw className="w-5 h-5" />
                        New Idea
                    </button>
                </div>
            </section>
        )}

      </main>
    </div>
  );
};

export default App;
