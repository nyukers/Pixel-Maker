import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { generatePanorama, inpaintImage } from './services/geminiService';
import { InputImage, GenerationResult, HistoryEntry, StoredInputImage, UserPreset } from './types';
import { UploadIcon } from './components/UploadIcon';

// --- Preset Prompts ---
const promptPresets = [
    { name: 'Abstract', prompt: 'Reimagine this image as an abstract panoramic. Use bold colors, geometric shapes, and surreal elements to create a unique artistic interpretation.' },
    { name: '*Loop ChatGPT', prompt: `Expand the provided image horizontally only to create a seamless circular panoramic view suitable for a horizontal 360° loop.
The left and right edges must align perfectly without any visible seam or discontinuity when the image is tiled horizontally.
Keep the original vertical composition and horizon intact - do not extend the image upward or downward.
Maintain consistent lighting, texture, and perspective across the full width.
Preserve the integrity of any central or key subjects, ensuring they appear only once and are not duplicated or distorted.
Avoid introducing unrelated focal elements.` },
    { name: '*Loop Gemini', prompt: `Expand the provided image horizontally to create a panoramic view that forms a seamless loop. 
The generated content on the far left should be designed to naturally and continuously connect with the content on 
the far right, making the overall image capable of being tiled horizontally without visible seams. 
Maintain the integrity and proportions of any central or prominent subjects within the original image, 
ensuring they appear only once in the resulting seamless panorama.` },
    {
        name: '*Loop Gemini json',
        prompt: `{
  "Task": "Create a seamless horizontal panoramic loop from an image.",
  "constraints": {
    "no_distortion": true,
    "maintain_subject_integrity": true
  },
  "steps": [
    {
      "step_id": 1,
      "name": "Horizontal Expansion",
      "instructions": "Take the input image and expand it horizontally by approximately 2.5 times its original width. The generated content should naturally extend the background elements (like sky, landscape, etc.) without distorting the main subject. Output this as 'expanded_panorama'."
    },
    {
      "step_id": 2,
      "name": "Seamless Loop Adjustment",
      "instructions": "Take the 'expanded_panorama' image. Adjust the leftmost and rightmost sections of this image to ensure they seamlessly connect, creating a continuous horizontal loop without visible seams. Focus changes primarily on the edges to achieve the loop effect, preserving the central content as much as possible. Output this as 'final_seamless_loop'."
    }
  ],
  "Deliverables": {
    "final_seamless_loop_image": "final_seamless_loop"
  }
}`
    },
    { name: 'Cinematic', prompt: 'Extend this image into a seamless ultra-wide panoramic in a cinematic style. Make it a FullHD 16:9 aspect ratio with dramatic lighting.' },
    { name: 'Cyberpunk', prompt: 'Create a cyberpunk panoramic version of this image. Infuse it with neon-drenched streets, futuristic megastructures, cybernetic enhancements, and a gritty, dystopian atmosphere.' },
    { name: 'Dreamy', prompt: 'Transform this image into a dreamy, ethereal panoramic landscape. Use soft focus, pastel colors, and a magical atmosphere.' },
    { name: 'Fantasy', prompt: 'Transform this image into a high-fantasy panoramic scene. Add mythical creatures, enchanted forests, towering castles, and a sense of epic adventure.' },
    { name: 'Realistic', prompt: 'Create a photorealistic panoramic extension of this image. Match the lighting, textures, and details perfectly for a seamless, believable result.' },
    { name: 'Sci-Fi', prompt: 'Extend this image into a futuristic, science-fiction panoramic. Incorporate sleek technology, alien landscapes, or advanced cityscapes with neon lights and a high-tech feel.' },
    { name: 'Surreal', prompt: 'Extend this image into a surreal, dreamlike panoramic. Blend reality with fantasy, using illogical scenes, strange juxtapositions, and a mysterious, subconscious quality.' },
    { name: 'Watercolor', prompt: 'Recreate this image as a beautiful watercolor panoramic painting. Use soft, blended colors, delicate brushstrokes, and a light, airy feel.' },
];

// --- Helper & Icon Components ---
const SparklesIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456Z" />
    </svg>
);

const DownloadIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

const ArrowLeftCircleIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 9l-3 3m0 0l3 3m-3-3h7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const ArrowRightCircleIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 15l3-3m0 0l-3-3m3 3h-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const ArrowUpCircleIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 11.25l-3-3m0 0l-3 3m3-3v7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const HistoryIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

const TrashIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.033-2.134H8.71c-1.123 0-2.033.954-2.033 2.134v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
    </svg>
);

const CloseIcon = ({ className = 'w-6 h-6' }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
  </svg>
);

const PlusCircleIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

const PencilIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
    </svg>
);

const FileTextIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
    </svg>
);


const getImageDimensions = (dataUrl: string): Promise<{ width: number; height: number }> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            resolve({ width: img.naturalWidth, height: img.naturalHeight });
        };
        img.onerror = (err) => {
            console.error("Failed to load image for dimension check", err);
            reject(new Error("Could not load image to get dimensions."));
        };
        img.src = dataUrl;
    });
};

// --- UI Components ---
interface HeaderProps {
    onOutpaint: (direction: 'left' | 'right') => void;
    onUpscale: (factor: 'x2' | '4k') => void;
    onToggleHistory: () => void;
    isModificationDisabled: boolean;
}
const Header: React.FC<HeaderProps> = ({ onOutpaint, onUpscale, onToggleHistory, isModificationDisabled }) => (
    <header className="py-2 px-8 border-b border-gray-700/50 flex items-center justify-between bg-gray-900/50 backdrop-blur-sm sticky top-0 z-20">
        <div className="flex items-center gap-3">
            <SparklesIcon className="w-8 h-8 text-yellow-400 flex-shrink-0" />
            <div>
                <h1 className="text-xl md:text-2xl font-bold text-yellow-400 leading-tight">
                    Pixel Panorama Pro
                </h1>
                <p className="text-xs text-gray-500">Nyukers (C)opyright, 2025</p>
            </div>
        </div>
        <div className="flex items-center gap-2">
            <button
                onClick={() => onOutpaint('left')}
                disabled={isModificationDisabled}
                className="flex items-center gap-2 px-3 py-2 bg-gray-800/50 text-white rounded-lg backdrop-blur-sm hover:bg-purple-600 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors duration-300"
                aria-label="Outpaint to the left"
                title="Extend the panorama to the left"
            >
                <ArrowLeftCircleIcon className="w-5 h-5" />
                <span className="hidden sm:inline">Left</span>
            </button>
            <button
                onClick={() => onOutpaint('right')}
                disabled={isModificationDisabled}
                className="flex items-center gap-2 px-3 py-2 bg-gray-800/50 text-white rounded-lg backdrop-blur-sm hover:bg-purple-600 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors duration-300"
                aria-label="Outpaint to the right"
                title="Extend the panorama to the right"
            >
                <ArrowRightCircleIcon className="w-5 h-5" />
                <span className="hidden sm:inline">Right</span>
            </button>
            <button
                onClick={() => onUpscale('x2')}
                disabled={isModificationDisabled}
                className="flex items-center gap-2 px-3 py-2 bg-gray-800/50 text-white rounded-lg backdrop-blur-sm hover:bg-purple-600 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors duration-300"
                aria-label="Upscale image by a factor of 2"
                title="Upscale image resolution x2"
            >
                <ArrowUpCircleIcon className="w-5 h-5" />
                <span className="hidden sm:inline">Up x2</span>
            </button>
            <button
                onClick={() => onUpscale('4k')}
                disabled={isModificationDisabled}
                className="flex items-center gap-2 px-3 py-2 bg-gray-800/50 text-white rounded-lg backdrop-blur-sm hover:bg-purple-600 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors duration-300"
                aria-label="Upscale image to 4K"
                title="Upscale image resolution to 4K"
            >
                <ArrowUpCircleIcon className="w-5 h-5" />
                <span className="hidden sm:inline">Up 4K</span>
            </button>
            <button
                onClick={onToggleHistory}
                className="flex items-center gap-2 px-3 py-2 bg-gray-800/50 text-white rounded-lg backdrop-blur-sm hover:bg-purple-600 transition-colors duration-300"
                aria-label="Toggle History Panel"
                title="View history of generated images"
            >
                <HistoryIcon className="w-5 h-5" />
                <span className="hidden sm:inline">History</span>
            </button>
        </div>
    </header>
);


interface ImageUploaderProps {
    onImageUpload: (image: InputImage) => void;
    inputImage: InputImage | null;
}
const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, inputImage }) => {
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = async () => {
                const dataUrl = reader.result as string;
                const base64String = dataUrl.split(',')[1];
                 try {
                    const { width, height } = await getImageDimensions(dataUrl);
                    onImageUpload({
                        base64: base64String,
                        mimeType: file.type,
                        name: file.name,
                        previewUrl: dataUrl,
                        width,
                        height,
                    });
                } catch (error) {
                    console.error("Error getting image dimensions:", error);
                    // Fallback: upload without dimensions
                    onImageUpload({
                        base64: base64String,
                        mimeType: file.type,
                        name: file.name,
                        previewUrl: dataUrl,
                    });
                }
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 h-full flex flex-col justify-between">
            <div>
                <h2 className="text-lg font-semibold text-gray-200 mb-4">1. Upload Base Image</h2>
                <label htmlFor="file-upload" title="Click to upload a base image" className="relative cursor-pointer flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-gray-600 rounded-lg hover:border-purple-400 transition-colors duration-300 bg-gray-800 hover:bg-gray-700/50">
                    {inputImage ? (
                        <img src={inputImage.previewUrl} alt="Preview" className="w-full h-full object-contain rounded-lg" />
                    ) : (
                        <>
                            <UploadIcon className="w-8 h-8 text-gray-500 mb-2" />
                            <span className="text-gray-400">Click to upload</span>
                            <span className="text-xs text-gray-500">PNG, JPG, WEBP</span>
                        </>
                    )}
                </label>
                <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/png, image/jpeg, image/webp" onChange={handleFileChange} />
            </div>
            {inputImage && (
                <div className="mt-4 text-sm text-gray-400 animate-fade-in">
                    <div className="truncate">
                        <span className="font-medium text-gray-300">File:</span> {inputImage.name}
                    </div>
                    {inputImage.width && inputImage.height && (
                        <div className="text-xs">
                            <span className="font-medium text-gray-400">Size:</span> {inputImage.width} &times; {inputImage.height} px
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

interface PromptInputProps {
    prompt: string;
    setPrompt: (prompt: string) => void;
    isDisabled: boolean;
    userPresets: UserPreset[];
    onLoadPreset: (preset: UserPreset) => void;
    onDeletePreset: (id: number) => void;
    onSavePreset: () => void;
}
const PromptInput: React.FC<PromptInputProps> = ({ prompt, setPrompt, isDisabled, userPresets, onLoadPreset, onDeletePreset, onSavePreset }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const selectedPresetPromptValue = useMemo(() => {
        return promptPresets.find(p => p.prompt === prompt)?.prompt || "";
    }, [prompt]);

    const handlePresetChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        setPrompt(event.target.value);
    };

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        if (file.type !== 'text/plain') {
            console.error("Invalid file type. Please upload a .txt file.");
            if(event.target) event.target.value = ''; // Reset input
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result;
            if (typeof text === 'string') {
                setPrompt(text);
            }
        };
        reader.onerror = (e) => {
            console.error("Failed to read file:", e);
        };
        reader.readAsText(file);

        if(event.target) event.target.value = ''; // Reset input to allow re-uploading the same file
    };

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 h-full flex flex-col">
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".txt,text/plain"
                className="hidden"
            />
            <div className="flex justify-between items-center mb-4">
                 <h2 className="text-lg font-semibold text-gray-200">2. Describe Your Panorama</h2>
                 <div className="flex items-center gap-1">
                    <button
                        onClick={handleUploadClick}
                        disabled={isDisabled}
                        className="p-2 text-gray-400 rounded-full hover:bg-gray-700 hover:text-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Load prompt from a text file (.txt)"
                        aria-label="Load prompt from a text file"
                    >
                        <FileTextIcon className="w-5 h-5" />
                    </button>
                     <button
                        onClick={onSavePreset}
                        disabled={isDisabled || !prompt.trim()}
                        className="p-2 text-gray-400 rounded-full hover:bg-gray-700 hover:text-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Save current prompt and quality settings as a new preset"
                        aria-label="Save as new preset"
                    >
                        <PlusCircleIcon className="w-5 h-5" />
                    </button>
                 </div>
            </div>
            <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={isDisabled}
                placeholder="Type your custom prompt here, or choose a preset below..."
                className="flex-grow w-full p-3 bg-gray-900/80 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-300 text-gray-200 disabled:opacity-50 mb-4"
                title="Describe the panorama you want to create"
            />
            <div>
                <label htmlFor="prompt-presets" className="block text-sm font-medium text-gray-400 mb-2">
                    Choose preset
                </label>
                <select
                    id="prompt-presets"
                    value={selectedPresetPromptValue}
                    onChange={handlePresetChange}
                    disabled={isDisabled}
                    className="w-full p-3 bg-gray-900/80 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-300 text-gray-200 disabled:opacity-50"
                    aria-label="Select a prompt style preset"
                    title="Choose a pre-made style for your prompt"
                >
                    <option value="" disabled>None</option>
                    {promptPresets.map((preset) => (
                        <option key={preset.name} value={preset.prompt}>
                            {preset.name}
                        </option>
                    ))}
                </select>
            </div>
            {userPresets.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-700/50">
                    <h3 className="text-sm font-medium text-gray-400 mb-2">My Presets</h3>
                    <div className="space-y-2 max-h-32 overflow-y-auto pr-2">
                        {userPresets.map(preset => (
                            <div key={preset.id} className="flex items-center justify-between bg-gray-900/50 p-2 rounded-md group">
                                <span className="text-sm text-gray-300 truncate pr-2">{preset.name}</span>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => onLoadPreset(preset)} className="text-xs text-purple-400 hover:text-purple-300" title={`Load '${preset.name}' preset`}>Load</button>
                                    <button onClick={() => onDeletePreset(preset.id)} className="text-gray-500 hover:text-red-400" title={`Delete '${preset.name}' preset`}>
                                        <TrashIcon className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

interface QualitySelectorProps {
    quality: string;
    setQuality: (quality: string) => void;
    isDisabled: boolean;
}

const qualityOptions = [
    { value: 'standard', label: '1080p - Standard' },
    { value: 'high', label: '1440p - High' },
    { value: 'ultra', label: '2160p - Ultra 4K' },
];

const QualitySelector: React.FC<QualitySelectorProps> = ({ quality, setQuality, isDisabled }) => (
    <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700">
        <h2 className="text-lg font-semibold text-gray-200 mb-4">3. Output Quality</h2>
        <select
            value={quality}
            onChange={(e) => setQuality(e.target.value)}
            disabled={isDisabled}
            className="w-full p-3 bg-gray-900/80 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-300 text-gray-200 disabled:opacity-50"
            aria-label="Select output image quality"
            title="Select the quality of the final image"
        >
            {qualityOptions.map((option) => (
                <option key={option.value} value={option.value}>
                    {option.label}
                </option>
            ))}
        </select>
    </div>
);

const loadingMessages = [
    "Stretching the canvas...",
    "Painting a wider world...",
    "Brewing panoramic pixels...",
    "Expanding the horizon...",
    "Assembling the masterpiece...",
    "Performing AI magic...",
    "Adding finishing touches...",
];

const Loader: React.FC = () => {
    const [message, setMessage] = useState(loadingMessages[0]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            setMessage(prev => {
                const currentIndex = loadingMessages.indexOf(prev);
                const nextIndex = (currentIndex + 1) % loadingMessages.length;
                return loadingMessages[nextIndex];
            });
        }, 3000);
        return () => clearInterval(intervalId);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <div className="w-16 h-16 border-4 border-t-purple-400 border-r-purple-400 border-b-transparent border-l-transparent rounded-full animate-spin mb-6"></div>
            <p className="text-lg font-semibold text-gray-200">{message}</p>
            <p className="text-sm text-gray-400 mt-2">This can take a moment, please be patient.</p>
        </div>
    );
};

const ErrorMessage: React.FC<{ message: string }> = ({ message }) => (
    <div className="flex flex-col items-center justify-center h-full text-center bg-red-900/20 border border-red-500/50 rounded-lg p-4 animate-fade-in">
        <h3 className="text-lg font-bold text-red-400 mb-2">Generation Failed</h3>
        <p className="text-sm text-red-300">{message}</p>
    </div>
);

// --- History Panel Component ---
interface HistoryPanelProps {
    isVisible: boolean;
    history: HistoryEntry[];
    onClose: () => void;
    onLoad: (entry: HistoryEntry) => void;
    onDelete: (id: number) => void;
    onClear: () => void;
}
const HistoryPanel: React.FC<HistoryPanelProps> = ({ isVisible, history, onClose, onLoad, onDelete, onClear }) => {
    const handleDownload = (e: React.MouseEvent, imageUrl: string | null) => {
        e.stopPropagation(); // Prevent loading the history item
        if (!imageUrl) return;
        const link = document.createElement('a');
        link.href = imageUrl;
        const mimeType = imageUrl.split(';')[0].split(':')[1] || 'image/png';
        const extension = mimeType.split('/')[1] || 'png';
        link.download = `panorama-history-${Date.now()}.${extension}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    
    return (
        <>
            <div
                className={`fixed inset-0 bg-black/60 z-30 transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={onClose}
                aria-hidden="true"
            ></div>
            <aside className={`fixed top-0 right-0 h-full w-full max-w-md bg-gray-800/95 backdrop-blur-lg shadow-2xl z-40 transform transition-transform duration-300 ease-in-out ${isVisible ? 'translate-x-0' : 'translate-x-full'}`}>
                <div className="flex flex-col h-full">
                    {/* Panel Header */}
                    <div className="flex items-center justify-between p-4 border-b border-gray-700">
                        <h2 className="text-xl font-semibold flex items-center gap-2">
                            <HistoryIcon className="w-6 h-6" /> Generation History
                        </h2>
                        <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700 transition-colors" aria-label="Close history panel" title="Close the history panel">
                           <CloseIcon />
                        </button>
                    </div>

                    {/* History List */}
                    <div className="flex-grow overflow-y-auto p-4 space-y-4">
                        {history.length === 0 ? (
                            <div className="text-center text-gray-500 pt-10 flex flex-col items-center">
                                <HistoryIcon className="w-12 h-12 mb-4" />
                                <p className="font-semibold">No history yet.</p>
                                <p className="text-sm">Your generated panoramas will appear here.</p>
                            </div>
                        ) : (
                            history.map(entry => (
                                <div key={entry.id} className="bg-gray-900/50 p-3 rounded-lg flex gap-4 animate-fade-in group relative cursor-pointer hover:bg-gray-900 transition-colors" onClick={() => onLoad(entry)} title="Click to load this state (image, prompt, settings)">
                                    <img src={entry.result.image || ''} alt="Generated thumbnail" className="w-24 h-16 object-cover rounded-md flex-shrink-0 border border-gray-700" />
                                    <div className="flex-grow overflow-hidden">
                                        <p className="text-sm font-medium truncate text-gray-200">{entry.prompt}</p>
                                        <p className="text-xs text-gray-400">{new Date(entry.timestamp).toLocaleString()}</p>
                                        <div className="mt-2 flex items-center gap-2 flex-wrap">
                                            <span className="text-xs px-2 py-1 bg-purple-600/50 text-purple-200 rounded">{entry.quality}</span>
                                        </div>
                                    </div>
                                    <div className="absolute top-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all">
                                        <button
                                            onClick={(e) => { e.stopPropagation(); onDelete(entry.id); }}
                                            className="p-1.5 rounded-full bg-gray-700 text-gray-400 hover:bg-red-500 hover:text-white transition-colors"
                                            aria-label="Delete history item"
                                            title="Delete this entry from history"
                                        >
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                        {entry.result.image && (
                                            <button
                                                onClick={(e) => handleDownload(e, entry.result.image)}
                                                className="p-1.5 rounded-full bg-gray-700 text-gray-400 hover:bg-purple-600 hover:text-white transition-colors"
                                                aria-label="Download image from history"
                                                title="Download this image from history"
                                            >
                                                <DownloadIcon className="w-4 h-4" />
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>

                    {/* Panel Footer */}
                    {history.length > 0 && (
                        <div className="p-4 border-t border-gray-700">
                            <button
                                onClick={onClear}
                                className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-red-600/80 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors duration-300"
                                title="Delete all generation history"
                            >
                                <TrashIcon /> Clear All History
                            </button>
                        </div>
                    )}
                </div>
            </aside>
        </>
    );
};

// --- In-painting Modal Component ---
interface InpaintModalProps {
    isOpen: boolean;
    onClose: () => void;
    imageSrc: string | null;
    onGenerate: (baseImage: string, mask: string, prompt: string) => void;
    isGenerating: boolean;
}
const InpaintModal: React.FC<InpaintModalProps> = ({ isOpen, onClose, imageSrc, onGenerate, isGenerating }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const isDrawing = useRef(false);
    const [brushSize, setBrushSize] = useState(40);
    const [inpaintPrompt, setInpaintPrompt] = useState("");

    const drawOnCanvas = useCallback((x: number, y: number) => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!ctx) return;

        ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
        ctx.beginPath();
        ctx.arc(x, y, brushSize / 2, 0, 2 * Math.PI);
        ctx.fill();
    }, [brushSize]);

    const handleMouseEvent = (e: React.MouseEvent) => {
        if (!isDrawing.current || !canvasRef.current) return;
        const rect = canvasRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        drawOnCanvas(x, y);
    };

    const handleTouchEvent = (e: React.TouchEvent) => {
        if (!isDrawing.current || !canvasRef.current) return;
        const rect = canvasRef.current.getBoundingClientRect();
        const touch = e.touches[0];
        const x = touch.clientX - rect.left;
        const y = touch.clientY - rect.top;
        drawOnCanvas(x, y);
    };

    useEffect(() => {
        if (!isOpen || !imageSrc) return;

        const canvas = canvasRef.current;
        const container = containerRef.current;
        const ctx = canvas?.getContext('2d');
        if (!canvas || !ctx || !container) return;

        const image = new Image();
        image.crossOrigin = "anonymous";
        image.onload = () => {
            const containerWidth = container.clientWidth;
            const containerHeight = container.clientHeight;
            const imageAspectRatio = image.naturalWidth / image.naturalHeight;
            const containerAspectRatio = containerWidth / containerHeight;

            let renderWidth, renderHeight;

            if (imageAspectRatio > containerAspectRatio) {
                renderWidth = containerWidth;
                renderHeight = containerWidth / imageAspectRatio;
            } else {
                renderHeight = containerHeight;
                renderWidth = containerHeight * imageAspectRatio;
            }

            canvas.width = renderWidth;
            canvas.height = renderHeight;

            // Clear before drawing
            ctx.clearRect(0, 0, canvas.width, canvas.height); 
            ctx.globalAlpha = 0; // Prepare to draw mask only on a separate canvas
            
            // This is the mask canvas logic, let's simplify.
            // We draw image on a background div, and canvas on top is only for the mask
            canvas.style.backgroundImage = `url(${imageSrc})`;
            canvas.style.backgroundSize = 'contain';
            canvas.style.backgroundRepeat = 'no-repeat';
            canvas.style.backgroundPosition = 'center';
            
            // Clear the drawing context itself.
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        };
        image.src = imageSrc;

    }, [isOpen, imageSrc]);

    const handleClearMask = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (ctx) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    };
    
    const handleGenerateClick = () => {
        if (!imageSrc || !inpaintPrompt.trim() || !canvasRef.current) return;

        // Create a separate mask canvas that is pure black and white (or black and transparent)
        const maskCanvas = document.createElement('canvas');
        const originalCanvas = canvasRef.current;
        maskCanvas.width = originalCanvas.width;
        maskCanvas.height = originalCanvas.height;
        const maskCtx = maskCanvas.getContext('2d');
        if(!maskCtx) return;
        
        const originalCtx = originalCanvas.getContext('2d');
        if(!originalCtx) return;

        // We get the drawn red mask, and convert it to a solid mask for the service
        const imageData = originalCtx.getImageData(0, 0, originalCanvas.width, originalCanvas.height);
        for (let i = 0; i < imageData.data.length; i += 4) {
            // If the pixel has any red (from our brush), make it solid black on the mask
            if (imageData.data[i] > 0) {
                imageData.data[i] = 0;   // R
                imageData.data[i+1] = 0; // G
                imageData.data[i+2] = 0; // B
                imageData.data[i+3] = 255; // Alpha
            }
        }
        maskCtx.putImageData(imageData, 0, 0);

        onGenerate(imageSrc, maskCanvas.toDataURL(), inpaintPrompt);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/80 z-50 flex flex-col items-center justify-center p-4 animate-fade-in" role="dialog" aria-modal="true">
            <div className="absolute top-4 right-4">
                <button onClick={onClose} className="p-2 rounded-full bg-gray-800/50 hover:bg-gray-700 text-white" aria-label="Close in-painting editor" title="Close in-painting editor">
                    <CloseIcon />
                </button>
            </div>

            <div ref={containerRef} className="w-full h-[60vh] relative mb-4 flex items-center justify-center">
                 <canvas
                    ref={canvasRef}
                    className="cursor-crosshair absolute"
                    onMouseDown={() => isDrawing.current = true}
                    onMouseUp={() => isDrawing.current = false}
                    onMouseLeave={() => isDrawing.current = false}
                    onMouseMove={handleMouseEvent}
                    onTouchStart={() => isDrawing.current = true}
                    onTouchEnd={() => isDrawing.current = false}
                    onTouchMove={handleTouchEvent}
                />
            </div>
            
            <div className="bg-gray-900/50 p-4 rounded-xl border border-gray-700 w-full max-w-4xl flex flex-col sm:flex-row items-center gap-4">
                <div className="flex-grow w-full">
                    <label htmlFor="inpaint-prompt" className="sr-only">In-painting prompt</label>
                    <input
                        id="inpaint-prompt"
                        type="text"
                        value={inpaintPrompt}
                        onChange={e => setInpaintPrompt(e.target.value)}
                        placeholder="What should be in the masked area? (e.g., 'a majestic dragon')"
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 transition-colors"
                        disabled={isGenerating}
                    />
                </div>
                <div className="flex items-center gap-4 w-full sm:w-auto">
                    <div className="flex items-center gap-2">
                        <label htmlFor="brush-size" className="text-sm text-gray-300 whitespace-nowrap">Brush Size</label>
                        <input
                            id="brush-size"
                            type="range"
                            min="10"
                            max="200"
                            value={brushSize}
                            onChange={e => setBrushSize(Number(e.target.value))}
                            className="w-24"
                            disabled={isGenerating}
                        />
                    </div>
                     <button onClick={handleClearMask} className="p-2 bg-gray-700 rounded-lg hover:bg-yellow-600 transition-colors" title="Clear mask" disabled={isGenerating}><TrashIcon /></button>
                    <button onClick={handleGenerateClick} className="flex items-center justify-center gap-2 py-3 px-6 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 disabled:bg-gray-600 w-full sm:w-auto" disabled={isGenerating || !inpaintPrompt.trim()} title="Generate the in-painted image">
                        <SparklesIcon />
                        {isGenerating ? 'Editing...' : 'Generate'}
                    </button>
                </div>
            </div>
        </div>
    );
};


// --- Main App Component ---

const dataUrlToInputImage = async (dataUrl: string): Promise<InputImage> => {
    const [header, base64] = dataUrl.split(',');
    if (!header || !base64) {
        throw new Error("Invalid data URL format");
    }
    const mimeTypeMatch = header.match(/:(.*?);/);
    const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';
    
    const { width, height } = await getImageDimensions(dataUrl);

    return {
        base64,
        mimeType,
        name: `generated-image-${Date.now()}.${mimeType.split('/')[1] || 'png'}`,
        previewUrl: dataUrl,
        width,
        height,
    };
};

/**
 * Crops a data URL image to a target aspect ratio if it's currently square.
 * This removes the blurred padding often added by the generative model.
 * @param dataUrl The base64 data URL of the image to crop.
 * @param aspectRatioString The target aspect ratio, e.g., "16:9".
 * @returns A Promise that resolves to the cropped image data URL.
 */
const cropToPanorama = (dataUrl: string, aspectRatioString: string): Promise<string> => {
    return new Promise((resolve, reject) => {
        const [targetW, targetH] = aspectRatioString.split(':').map(Number);
        if (!targetW || !targetH) {
            return reject(new Error("Invalid aspect ratio format"));
        }
        const targetRatio = targetW / targetH;

        const img = new Image();
        img.onload = () => {
            const sourceWidth = img.naturalWidth;
            const sourceHeight = img.naturalHeight;

            // Only crop if the image is nearly square (aspect ratio between ~0.9 and ~1.1).
            const sourceRatio = sourceWidth / sourceHeight;
            if (sourceRatio > 0.9 && sourceRatio < 1.1) {
                const targetWidth = sourceWidth;
                const targetHeight = Math.round(sourceWidth / targetRatio);
                const sy = (sourceHeight - targetHeight) / 2;

                if (sy < 0) {
                    resolve(dataUrl); // Failsafe if calculations are off
                    return;
                }

                const canvas = document.createElement('canvas');
                canvas.width = targetWidth;
                canvas.height = targetHeight;
                const ctx = canvas.getContext('2d');

                if (!ctx) {
                    return reject(new Error("Failed to get canvas context"));
                }

                ctx.drawImage(img, 0, sy, sourceWidth, targetHeight, 0, 0, targetWidth, targetHeight);
                
                const mimeTypeMatch = dataUrl.match(/^data:(image\/.*?);/);
                const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : 'image/png';

                resolve(canvas.toDataURL(mimeType));
            } else {
                // Image is already panoramic or has a different non-square aspect ratio, no need to crop.
                resolve(dataUrl);
            }
        };
        img.onerror = (err) => {
            console.error("Failed to load image for cropping", err);
            reject(new Error("Could not load image to crop."));
        };
        img.src = dataUrl;
    });
};


const App: React.FC = () => {
    const [prompt, setPrompt] = useState<string>("");
    const [inputImage, setInputImage] = useState<InputImage | null>(null);
    const [quality, setQuality] = useState<string>('standard');
    const [result, setResult] = useState<GenerationResult | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [history, setHistory] = useState<HistoryEntry[]>([]);
    const [isHistoryPanelVisible, setIsHistoryPanelVisible] = useState<boolean>(false);
    const [userPresets, setUserPresets] = useState<UserPreset[]>([]);
    const [isInpaintModalOpen, setIsInpaintModalOpen] = useState<boolean>(false);
    const [imageToEdit, setImageToEdit] = useState<string | null>(null);


    const PANORAMA_ASPECT_RATIO = '16:9';

    // Load history from localStorage on initial render
    useEffect(() => {
        try {
            const storedHistory = localStorage.getItem('panoramaHistory');
            if (storedHistory) {
                setHistory(JSON.parse(storedHistory));
            }
        } catch (e) {
            console.error("Failed to load history from localStorage", e);
            localStorage.removeItem('panoramaHistory');
        }
    }, []);

    // Save history to localStorage whenever it changes
    useEffect(() => {
        try {
            localStorage.setItem('panoramaHistory', JSON.stringify(history));
        } catch (e) {
            console.error("Failed to save history to localStorage", e);
        }
    }, [history]);

    // Load user presets from localStorage on initial render
    useEffect(() => {
        try {
            const storedPresets = localStorage.getItem('panoramaUserPresets');
            if (storedPresets) {
                setUserPresets(JSON.parse(storedPresets));
            }
        } catch (e) {
            console.error("Failed to load user presets from localStorage", e);
            localStorage.removeItem('panoramaUserPresets');
        }
    }, []);

    // Save user presets to localStorage whenever they change
    useEffect(() => {
        try {
            localStorage.setItem('panoramaUserPresets', JSON.stringify(userPresets));
        } catch (e) {
            console.error("Failed to save user presets to localStorage", e);
        }
    }, [userPresets]);
    
    const addHistoryEntry = (newEntryData: Omit<HistoryEntry, 'id' | 'timestamp'>) => {
        const newEntry: HistoryEntry = {
            ...newEntryData,
            id: Date.now(),
            timestamp: new Date().toISOString(),
        };

        setHistory(prevHistory => {
            const updatedHistory = [newEntry, ...prevHistory];
            // Limit history size to prevent excessive localStorage usage
            return updatedHistory.length > 50 ? updatedHistory.slice(0, 50) : updatedHistory;
        });
    };

    const handleGenerate = useCallback(async () => {
        if (!inputImage || !prompt) {
            setError("Please upload an image and provide a prompt.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);

        const panoramaPrompt = `Create a panoramic extension of this image. Extend the image horizontally by adding new content to the left and right sides. The new content must seamlessly match the original image's style, lighting, and details. The subject of the panorama is: "${prompt}"`;

        try {
            const generatedResult = await generatePanorama(inputImage, panoramaPrompt, quality);
            if (generatedResult.image) {
                generatedResult.image = await cropToPanorama(generatedResult.image, PANORAMA_ASPECT_RATIO);
            }
            setResult(generatedResult);
            // Optimization: Don't store the large base64 string of the input image in history.
            const { base64, previewUrl, ...storedImageMetadata } = inputImage;
            addHistoryEntry({ inputImage: storedImageMetadata, prompt, quality, result: generatedResult });
        } catch (e) {
            if (e instanceof Error) {
                setError(e.message);
            } else {
                setError("An unknown error occurred.");
            }
        } finally {
            setIsLoading(false);
        }
    }, [inputImage, prompt, quality]);

    const handleImageModification = useCallback(async (actionPrompt: string) => {
        if (!result?.image) {
            setError("No generated image to modify.");
            return;
        }
        if (!prompt) {
            setError("Cannot modify the image without the original creative prompt for context.");
            return;
        }

        setIsLoading(true);
        setError(null);

        const baseCreativePrompt = `The overall creative theme is: "${prompt}"`;
        const finalActionPrompt = `${actionPrompt}. ${baseCreativePrompt}`;

        try {
            const currentImage = await dataUrlToInputImage(result.image);
            const generatedResult = await generatePanorama(currentImage, finalActionPrompt, quality);
            if (generatedResult.image) {
                generatedResult.image = await cropToPanorama(generatedResult.image, PANORAMA_ASPECT_RATIO);
            }
            setResult(generatedResult);
            
            // Optimization: Don't store the large base64 string of the input image in history.
            const { base64, previewUrl, ...storedImageMetadata } = currentImage;
             // Save the main creative prompt to history, not the modification action prompt.
            addHistoryEntry({ inputImage: storedImageMetadata, prompt: prompt, quality, result: generatedResult });
        } catch (e) {
            if (e instanceof Error) {
                setError(e.message);
            } else {
                setError("An unknown error occurred during image modification.");
            }
        } finally {
            setIsLoading(false);
        }
    }, [result, quality, prompt]);

    const handleOutpaint = useCallback((direction: 'left' | 'right') => {
        handleImageModification(`Seamlessly extend this image to the ${direction}, maintaining the existing style, lighting, and content. Create a wider, coherent scene.`);
    }, [handleImageModification]);

    const handleUpscale = useCallback((factor: 'x2' | '4k') => {
        let upscalePrompt = '';
        if (factor === 'x2') {
            upscalePrompt = `Upscale this image to double its current resolution. Enhance details and clarity while preserving the original style and composition. Do not add new content or change the aspect ratio.`;
        } else { // '4k'
            upscalePrompt = `Upscale this image to a high-quality 4K resolution (approximately 3840 pixels wide). Sharpen details, improve textures, and ensure the result is crisp and clear, without altering the content or aspect ratio.`;
        }
        handleImageModification(upscalePrompt);
    }, [handleImageModification]);

    const handleImageUpload = (image: InputImage) => {
        setInputImage(image);
        setError(null);
    }
    
    const handleLoadFromHistory = async (entry: HistoryEntry) => {
        if (!entry.result.image) {
            setError("This history entry does not contain a valid image to load.");
            return;
        }
        try {
            // When loading from history, the generated result becomes the new input image.
            const loadedImage = await dataUrlToInputImage(entry.result.image);
            setInputImage(loadedImage);
            setPrompt(entry.prompt);
            setQuality(entry.quality);
            setResult(entry.result);
            setError(null);
            setIsHistoryPanelVisible(false); // Close panel after loading
        } catch (e) {
            console.error("Failed to load and process image from history:", e);
            setError("Could not load the image from this history entry. It might be corrupted.");
        }
    };

    const handleDeleteFromHistory = (idToDelete: number) => {
        setHistory(prev => prev.filter(entry => entry.id !== idToDelete));
    };

    const handleClearHistory = () => {
        if (window.confirm("Are you sure you want to clear all generation history? This cannot be undone.")) {
            setHistory([]);
        }
    };

    const handleSavePreset = () => {
        const name = window.prompt("Enter a name for this preset:", "My Custom Style");
        if (name && name.trim()) {
            const newPreset: UserPreset = {
                id: Date.now(),
                name: name.trim(),
                prompt: prompt,
                quality: quality,
            };
            setUserPresets(prevPresets => [newPreset, ...prevPresets]);
        }
    };

    const handleLoadPreset = (preset: UserPreset) => {
        setPrompt(preset.prompt);
        setQuality(preset.quality);
    };

    const handleDeletePreset = (idToDelete: number) => {
        if (window.confirm("Are you sure you want to delete this preset?")) {
            setUserPresets(prev => prev.filter(preset => preset.id !== idToDelete));
        }
    };
    
    const handleEditClick = () => {
        if (result?.image) {
            setImageToEdit(result.image);
            setIsInpaintModalOpen(true);
        }
    };

    const handleInpaintGenerate = useCallback(async (baseImage: string, mask: string, inpaintPrompt: string) => {
        setIsLoading(true);
        setError(null);
        setIsInpaintModalOpen(false);

        try {
            const generatedResult = await inpaintImage(baseImage, mask, inpaintPrompt);
            // The result of inpainting might not need cropping, but we can check.
            if (generatedResult.image) {
                generatedResult.image = await cropToPanorama(generatedResult.image, PANORAMA_ASPECT_RATIO);
            }
            setResult(generatedResult);

            const currentImage = await dataUrlToInputImage(baseImage);
            const { base64, previewUrl, ...storedImageMetadata } = currentImage;
            // The prompt stored is the main creative prompt, not the inpainting action.
            addHistoryEntry({ inputImage: storedImageMetadata, prompt, quality, result: generatedResult });
        } catch (e) {
            if (e instanceof Error) {
                setError(e.message);
            } else {
                setError("An unknown error occurred during in-painting.");
            }
        } finally {
            setIsLoading(false);
            setImageToEdit(null);
        }
    }, [prompt, quality]);


    const isButtonDisabled = isLoading || !inputImage || !prompt;
    const isModificationDisabled = !result?.image || isLoading;

    return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col">
            <HistoryPanel
                isVisible={isHistoryPanelVisible}
                history={history}
                onClose={() => setIsHistoryPanelVisible(false)}
                onLoad={handleLoadFromHistory}
                onDelete={handleDeleteFromHistory}
                onClear={handleClearHistory}
            />
             <InpaintModal
                isOpen={isInpaintModalOpen}
                onClose={() => setIsInpaintModalOpen(false)}
                imageSrc={imageToEdit}
                onGenerate={handleInpaintGenerate}
                isGenerating={isLoading}
            />
            <Header 
                onOutpaint={handleOutpaint}
                onUpscale={handleUpscale}
                onToggleHistory={() => setIsHistoryPanelVisible(true)}
                isModificationDisabled={isModificationDisabled}
            />
            <main className="flex-grow p-4 sm:p-6 md:p-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                    
                    {/* --- Left Column: Controls --- */}
                    <div className="flex flex-col gap-6">
                        <ImageUploader onImageUpload={handleImageUpload} inputImage={inputImage} />
                        <PromptInput
                            prompt={prompt}
                            setPrompt={setPrompt}
                            isDisabled={isLoading}
                            userPresets={userPresets}
                            onLoadPreset={handleLoadPreset}
                            onDeletePreset={handleDeletePreset}
                            onSavePreset={handleSavePreset}
                        />
                        <QualitySelector quality={quality} setQuality={setQuality} isDisabled={isLoading} />
                        <button
                            onClick={handleGenerate}
                            disabled={isButtonDisabled}
                            className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-purple-600 text-white font-semibold rounded-lg shadow-lg hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100"
                            title="Create a panorama based on your image and prompt"
                        >
                            <SparklesIcon />
                            {isLoading ? 'Creating...' : 'Create'}
                        </button>
                    </div>

                    {/* --- Right Column: Result --- */}
                    <ResultDisplay 
                        isLoading={isLoading} 
                        result={result} 
                        error={error}
                        onEdit={handleEditClick}
                        isEditDisabled={isModificationDisabled}
                    />
                </div>
            </main>
        </div>
    );
};

interface ResultDisplayProps {
    isLoading: boolean;
    result: GenerationResult | null;
    error: string | null;
    onEdit: () => void;
    isEditDisabled: boolean;
}
const ResultDisplay: React.FC<ResultDisplayProps> = ({ isLoading, result, error, onEdit, isEditDisabled }) => {
    const [imageDimensions, setImageDimensions] = useState<{width: number; height: number} | null>(null);

     useEffect(() => {
        if (result?.image) {
            const img = new Image();
            img.onload = () => {
                setImageDimensions({ width: img.naturalWidth, height: img.naturalHeight });
            };
            img.src = result.image;
        } else {
            setImageDimensions(null);
        }
     }, [result?.image]);

     const handleDownload = useCallback(() => {
        if (!result?.image) return;
        const link = document.createElement('a');
        link.href = result.image;
        const mimeType = result.image.split(';')[0].split(':')[1] || 'image/png';
        const extension = mimeType.split('/')[1] || 'png';
        link.download = `panorama-${Date.now()}.${extension}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }, [result]);

    const content = useMemo(() => {
        if (isLoading) return <Loader />;
        if (error) return <ErrorMessage message={error} />;
        if (result?.image) {
            return (
                <div className="w-full h-full animate-fade-in relative group">
                    <img src={result.image} alt="Generated Panorama" className="w-full h-full object-contain" />
                    
                    <div className="absolute top-4 right-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        {imageDimensions && (
                            <span className="text-sm bg-gray-900/50 text-white py-1.5 px-3 rounded-full backdrop-blur-sm select-none">
                                {imageDimensions.width} &times; {imageDimensions.height}
                            </span>
                        )}
                         <button
                            onClick={onEdit}
                            disabled={isEditDisabled}
                            className="bg-gray-900/50 text-white p-2 rounded-full backdrop-blur-sm hover:bg-purple-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-gray-900 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed"
                            aria-label="Edit Image"
                            title="Edit this image with in-painting"
                        >
                            <PencilIcon className="w-6 h-6" />
                        </button>
                        <button
                            onClick={handleDownload}
                            className="bg-gray-900/50 text-white p-2 rounded-full backdrop-blur-sm hover:bg-purple-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-gray-900"
                            aria-label="Download Image"
                            title="Download the generated image"
                        >
                            <DownloadIcon className="w-6 h-6" />
                        </button>
                    </div>

                    {result.text && <p className="absolute bottom-0 left-0 right-0 text-sm text-gray-300 italic bg-black/60 p-2 text-center backdrop-blur-sm">{result.text}</p>}
                </div>
            );
        }
        return (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
                <SparklesIcon className="w-16 h-16 mb-4 text-yellow-400 opacity-40" />
                <h3 className="text-xl font-semibold text-gray-300">Your panorama will appear here</h3>
                <p>Upload an image and provide a prompt to begin.</p>
            </div>
        );
    }, [isLoading, result, error, handleDownload, imageDimensions, onEdit, isEditDisabled]);

    return (
        <div className="col-span-1 lg:col-span-2 bg-black/30 rounded-2xl border border-gray-700/50 w-full aspect-[16/9] flex items-center justify-center p-2 relative overflow-hidden">
           {content}
        </div>
    );
};


export default App;
