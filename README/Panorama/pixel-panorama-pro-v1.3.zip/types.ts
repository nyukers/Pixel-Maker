export interface InputImage {
  base64: string;
  mimeType: string;
  name: string;
  previewUrl: string;
  width?: number;
  height?: number;
}

export interface GenerationResult {
    image: string | null;
    text: string | null;
}

export interface StoredInputImage {
  base64?: string; // Made optional to reduce history size
  mimeType: string;
  name: string;
  width?: number;
  height?: number;
}

export interface HistoryEntry {
  id: number;
  inputImage: StoredInputImage;
  prompt: string;
  quality: string;
  result: GenerationResult;
  timestamp: string;
}

export interface UserPreset {
  id: number;
  name: string;
  prompt: string;
  quality: string;
}
