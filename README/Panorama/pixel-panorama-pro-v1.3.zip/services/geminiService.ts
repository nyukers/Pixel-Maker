import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";
import { InputImage, GenerationResult } from '../types';

if (!process.env.API_KEY) {
    // In a real app, you'd want to handle this more gracefully,
    // but for this context, throwing an error is clear.
    console.error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || " " });

export const generatePanorama = async (
    inputImage: InputImage,
    prompt: string,
    quality: string = 'standard' // Note: quality is not used in the prompt but kept for signature consistency
): Promise<GenerationResult> => {
    try {
        const imagePart = {
            inlineData: {
                data: inputImage.base64,
                mimeType: inputImage.mimeType,
            },
        };

        const textPart = {
            text: prompt, // The prompt is now passed directly from the app component
        };
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [imagePart, textPart],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const result: GenerationResult = { image: null, text: null };

        if (response.candidates && response.candidates.length > 0) {
            const parts = response.candidates[0].content.parts;
            for (const part of parts) {
                if (part.inlineData) {
                    result.image = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                } else if (part.text) {
                    result.text = part.text;
                }
            }
        }
        
        if (!result.image) {
            const safetyFeedback = response.candidates?.[0]?.safetyRatings;
            let errorMessage = "API did not return an image.";
            if (safetyFeedback) {
                 errorMessage += ` This might be due to safety policies. Blocked reason: ${JSON.stringify(safetyFeedback)}`;
            }
            throw new Error(errorMessage);
        }

        return result;

    } catch (error) {
        console.error("Error generating panorama:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate panorama: ${error.message}`);
        }
        throw new Error("An unknown error occurred during image generation.");
    }
};

/**
 * Creates a new image with a transparent area based on a mask.
 * @param baseImageSrc - The source image data URL.
 * @param maskImageSrc - The mask data URL (where content is drawn, the rest is transparent).
 * @returns A promise that resolves to a data URL of the image with a transparent cutout.
 */
const applyMask = (baseImageSrc: string, maskImageSrc: string): Promise<string> => {
    return new Promise((resolve, reject) => {
        const baseImg = new Image();
        const maskImg = new Image();
        let loadedCount = 0;

        const onImageLoad = () => {
            loadedCount++;
            if (loadedCount < 2) return;

            const canvas = document.createElement('canvas');
            canvas.width = baseImg.naturalWidth;
            canvas.height = baseImg.naturalHeight;
            const ctx = canvas.getContext('2d');
            if (!ctx) return reject('Could not get canvas context');

            // Draw the base image
            ctx.drawImage(baseImg, 0, 0);

            // Use 'destination-out' to erase parts of the base image where the mask is drawn.
            ctx.globalCompositeOperation = 'destination-out';
            ctx.drawImage(maskImg, 0, 0);

            // The result is an image with a transparent hole, which must be PNG.
            resolve(canvas.toDataURL('image/png'));
        };

        const onError = (e: string | Event) => reject(e);

        baseImg.onload = onImageLoad;
        maskImg.onload = onImageLoad;
        baseImg.onerror = onError;
        maskImg.onerror = onError;
        
        // Set crossOrigin to anonymous for Tainted Canvas error prevention if images were from external sources
        baseImg.crossOrigin = "anonymous";
        maskImg.crossOrigin = "anonymous";

        baseImg.src = baseImageSrc;
        maskImg.src = maskImageSrc;
    });
};


export const inpaintImage = async (
    baseImage: string, // data url
    maskImage: string, // data url of the mask
    prompt: string
): Promise<GenerationResult> => {
    try {
        const imageWithTransparency = await applyMask(baseImage, maskImage);
        
        const base64 = imageWithTransparency.split(',')[1];
        
        const imagePart = {
            inlineData: {
                data: base64,
                mimeType: 'image/png', // Must be PNG to support transparency
            },
        };

        const textPart = {
            text: `Fill in the transparent area of this image based on the following instruction: "${prompt}". Ensure the filled area seamlessly blends with the surrounding image in style, lighting, and texture. Do not alter the rest of the image.`,
        };
        
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const result: GenerationResult = { image: null, text: null };
        if (response.candidates && response.candidates.length > 0) {
            const parts = response.candidates[0].content.parts;
            for (const part of parts) {
                if (part.inlineData) {
                    result.image = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                } else if (part.text) {
                    result.text = part.text;
                }
            }
        }
        
        if (!result.image) {
            const safetyFeedback = response.candidates?.[0]?.safetyRatings;
            let errorMessage = "API did not return an in-painted image.";
            if (safetyFeedback) {
                 errorMessage += ` This might be due to safety policies. Blocked reason: ${JSON.stringify(safetyFeedback)}`;
            }
            throw new Error(errorMessage);
        }

        return result;

    } catch (error) {
        console.error("Error in-painting image:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to in-paint image: ${error.message}`);
        }
        throw new Error("An unknown error occurred during image in-painting.");
    }
};
