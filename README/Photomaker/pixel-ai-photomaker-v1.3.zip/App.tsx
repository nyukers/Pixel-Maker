import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import StyleSelector from './components/StyleSelector';
import Spinner from './components/Spinner';
import ImageEditor from './components/ImageEditor';
import { generateHeadshot, editImage, type GenerationResult } from './services/geminiService';
import { ASPECT_RATIOS } from './constants';
import type { StyleOption, AspectRatio } from './types';

interface UploadedImage {
  dataUrl: string;
  mimeType: string;
}

type View = 'uploader' | 'style-selector' | 'editor' | 'loading' | 'error';

function App() {
  const [originalImages, setOriginalImages] = useState<UploadedImage[]>([]);
  const [history, setHistory] = useState<GenerationResult[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [editPrompt, setEditPrompt] = useState<string>('');
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>(ASPECT_RATIOS[0]);
  const [cameraFocusPoint, setCameraFocusPoint] = useState({ x: 0.5, y: 0.5 });
  const [blurLevel, setBlurLevel] = useState<number>(0);
  const [customStyles, setCustomStyles] = useState<StyleOption[]>([]);
  const [selectedStyleId, setSelectedStyleId] = useState<string>('');


  const currentHistoryItem = history[historyIndex];
  const generatedImage = currentHistoryItem?.imageUrl ?? null;

  useEffect(() => {
    // Sync the edit prompt with the full prompt of the current history item
    const currentPrompt = currentHistoryItem?.fullPrompt ?? '';
    setEditPrompt(currentPrompt);
  }, [currentHistoryItem]);


  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
    });

  const handleImageUpload = useCallback(async (files: File[]) => {
    if (files.length > 5) {
        setError("You can upload a maximum of 5 photos.");
        return;
    }
    setIsLoading(true);
    setError(null);
    setHistory([]);
    setHistoryIndex(-1);
    try {
      const dataUrlPromises = files.map(file => fileToBase64(file));
      const dataUrls = await Promise.all(dataUrlPromises);
      const newImages = dataUrls.map((dataUrl, index) => ({
        dataUrl,
        mimeType: files[index].type,
      }));
      setOriginalImages(newImages);
    } catch (e) {
      setError('Failed to read the image files. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const getFocusPointPrompt = useCallback((point: { x: number; y: number }): string => {
    const prompts = [];
    
    // Vertical Angle Description
    if (point.y < 0.33) {
      prompts.push('a high-angle view, looking down on the subject');
    } else if (point.y > 0.66) {
      prompts.push('a low-angle hero view, looking up at the subject');
    } else {
      prompts.push('an eye-level view');
    }

    // Horizontal Position / Framing Description
    if (point.x < 0.4) {
      prompts.push('with the subject framed towards the left');
    } else if (point.x > 0.6) {
      prompts.push('with the subject framed towards the right');
    } else {
      prompts.push('with the subject centered in the frame');
    }

    // Rule of Thirds-ish description
    const isOffCenterY = point.y < 0.4 || point.y > 0.6;
    const isOffCenterX = point.x < 0.4 || point.x > 0.6;
    if (isOffCenterX || isOffCenterY) {
        prompts.push('creating a dynamic and engaging composition');
    }

    return `The camera composition should be ${prompts.join(', ')}.`;
  }, []);

  const handleGenerateHeadshot = useCallback(async (style: StyleOption) => {
    if (originalImages.length === 0) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);
    try {
      const imagesPayload = originalImages.map(img => ({
          data: img.dataUrl.split(',')[1],
          mimeType: img.mimeType,
      }));
      const cameraAnglePrompt = getFocusPointPrompt(cameraFocusPoint);
      const result = await generateHeadshot(
          imagesPayload, 
          style.prompt, 
          selectedAspectRatio.prompt, 
          cameraAnglePrompt
      );
      setHistory([result]);
      setHistoryIndex(0);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred during image generation.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [originalImages, selectedAspectRatio, cameraFocusPoint, getFocusPointPrompt]);

  const handleEditImage = useCallback(async () => {
    if (!generatedImage || !editPrompt) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);
    try {
      const base64Data = generatedImage.split(',')[1];
      const result = await editImage(base64Data, 'image/png', editPrompt);
      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, result]);
      setHistoryIndex(newHistory.length);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred during image editing.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [generatedImage, editPrompt, history, historyIndex]);

  const handleApplyEffect = useCallback(async (effectPrompt: string) => {
    if (!generatedImage) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);
    try {
      const base64Data = generatedImage.split(',')[1];
      const result = await editImage(base64Data, 'image/png', effectPrompt);
      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, result]);
      setHistoryIndex(newHistory.length);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred while applying the effect.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [generatedImage, history, historyIndex]);

  const handleBlurChange = useCallback(async (level: number) => {
    if (!generatedImage) return;
    setBlurLevel(level);

    setIsLoading(true);
    setError(null);

    let blurPrompt = "Remove any background blur.";
    if (level === 25) {
        blurPrompt = "Apply a subtle, light blur to the background.";
    } else if (level === 50) {
        blurPrompt = "Apply a medium blur to the background to make the subject stand out.";
    } else if (level === 75) {
        blurPrompt = "Apply a strong blur to the background.";
    } else if (level === 100) {
        blurPrompt = "Apply a maximum, heavy blur to the background for a strong bokeh effect.";
    }

    try {
        const base64Data = generatedImage.split(',')[1];
        const result = await editImage(base64Data, 'image/png', blurPrompt);
        const newHistory = history.slice(0, historyIndex + 1);
        setHistory([...newHistory, result]);
        setHistoryIndex(newHistory.length);
    } catch (e: any) {
        setError(e.message || 'An unknown error occurred while applying blur.');
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  }, [generatedImage, history, historyIndex]);

  const handleStartOver = useCallback(() => {
    setHistory([]);
    setHistoryIndex(-1);
    setError(null);
    setIsLoading(false);
    setBlurLevel(0);
  }, []);
  
  const handleReset = useCallback(() => {
    setOriginalImages([]);
    setHistory([]);
    setHistoryIndex(-1);
    setError(null);
    setIsLoading(false);
    setBlurLevel(0);
    setCustomStyles([]);
    setSelectedStyleId('');
  }, []);

  const handleDownload = useCallback(() => {
    if (!generatedImage) return;
    
    const currentPrompt = currentHistoryItem?.fullPrompt ?? '';
    const modelName = currentHistoryItem?.modelName ?? 'unknown';
  
    const image = new Image();
    image.onerror = () => {
      // Fallback for cross-origin issues or other errors: download original format
      const link = document.createElement('a');
      link.href = generatedImage;
      link.download = 'ai-headshot.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    image.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = image.width;
      canvas.height = image.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
  
      ctx.drawImage(image, 0, 0);
      const jpegDataUrl = canvas.toDataURL('image/jpeg', 0.9);
  
      if (!currentPrompt) {
        // No prompt available, download JPEG without metadata
        const link = document.createElement('a');
        link.href = jpegDataUrl;
        link.download = 'ai-headshot.jpeg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        return;
      }
  
      // Embed prompt into JPEG metadata (COM segment)
      try {
        const base64Jpeg = jpegDataUrl.split(',')[1];
        const binaryStr = atob(base64Jpeg);
        const len = binaryStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryStr.charCodeAt(i);
        }
  
        if (bytes[0] !== 0xFF || bytes[1] !== 0xD8) {
          throw new Error("Not a valid JPEG file");
        }
  
        const comment = `Powered by Pixel AI Photomaker, Nyukers ©, 2026.\nModel: ${modelName}\nFull AI Prompt: ${currentPrompt}`;
        const commentBytes = new TextEncoder().encode(comment);
        const commentSegmentLength = commentBytes.length + 2;
        const commentSegment = new Uint8Array(4 + commentBytes.length);
  
        commentSegment[0] = 0xFF;
        commentSegment[1] = 0xFE; // COM marker
        commentSegment[2] = commentSegmentLength >> 8;
        commentSegment[3] = commentSegmentLength & 0xFF;
        commentSegment.set(commentBytes, 4);
  
        const newJpegBytes = new Uint8Array(bytes.length + commentSegment.length);
        newJpegBytes.set(bytes.subarray(0, 2), 0); // SOI
        newJpegBytes.set(commentSegment, 2); // COM segment
        newJpegBytes.set(bytes.subarray(2), 2 + commentSegment.length); // Rest of file
  
        let newBinary = '';
        for (let i = 0; i < newJpegBytes.byteLength; i++) {
          newBinary += String.fromCharCode(newJpegBytes[i]);
        }
        const newBase64 = btoa(newBinary);
        const finalDataUrl = `data:image/jpeg;base64,${newBase64}`;
  
        const link = document.createElement('a');
        link.href = finalDataUrl;
        link.download = 'ai-headshot.jpeg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (e) {
        console.error("Failed to embed metadata, downloading JPEG without it.", e);
        // Fallback to downloading JPEG without metadata on error
        const link = document.createElement('a');
        link.href = jpegDataUrl;
        link.download = 'ai-headshot.jpeg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    };
    image.src = generatedImage;
  }, [generatedImage, currentHistoryItem]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setBlurLevel(0);
    }
  }, [historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setBlurLevel(0);
    }
  }, [historyIndex, history.length]);

  const handleCustomStylesUpload = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
        const text = event.target?.result as string;
        if (!text) {
            setError('The CSV file is empty.');
            return;
        }

        try {
            const lines = text.trim().split(/\r\n|\n/);
            const headerLine = lines.shift()?.trim();
            if (!headerLine) throw new Error('CSV is empty or has no header.');

            const header = headerLine.toLowerCase().split(',').map(h => h.trim().replace(/"/g, ''));
            const nameIndex = header.indexOf('name');
            const promptIndex = header.indexOf('prompt');

            if (nameIndex === -1 || promptIndex === -1) {
                throw new Error('Invalid CSV header. Must contain "name" and "prompt" columns.');
            }
            
            const newStyles: StyleOption[] = lines.map((line, index) => {
                if (!line.trim()) return null;
                const columns = line.split(',');
                const name = columns[nameIndex]?.trim().replace(/^"|"$/g, '');
                const prompt = columns[promptIndex]?.trim().replace(/^"|"$/g, '');

                if (!name || !prompt) {
                    console.warn(`Skipping malformed CSV line ${index + 2}: ${line}`);
                    return null;
                }

                return {
                    id: `custom-${Date.now()}-${index}`,
                    name,
                    prompt,
                };
            }).filter((style): style is StyleOption => style !== null);

            if (newStyles.length === 0) {
                throw new Error("No valid styles found in the CSV file.");
            }

            setCustomStyles(prevStyles => [...prevStyles, ...newStyles]);
            setError(null); // Clear previous errors
        } catch (e: any) {
            setError(e.message || 'Failed to parse CSV file.');
            console.error(e);
        }
    };
    reader.onerror = () => {
        setError('Failed to read the file.');
    };
    reader.readAsText(file);
}, []);


  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  const getCurrentView = (): View => {
    if (isLoading && !generatedImage) return 'loading';
    if (error) return 'error';
    if (generatedImage) return 'editor';
    if (originalImages.length > 0) return 'style-selector';
    return 'uploader';
  };

  const currentView = getCurrentView();

  const renderContent = () => {
    switch (currentView) {
      case 'loading':
        return <div className="flex-grow flex justify-center items-center"><Spinner /></div>;
      case 'error':
        return (
            <div className="flex-grow flex flex-col justify-center items-center text-center p-4">
                <p className="text-red-400 text-lg mb-4">{error}</p>
                <button onClick={handleReset} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">
                    Try Again
                </button>
            </div>
        );
      case 'editor':
        return (
          <ImageEditor
            imageSrc={generatedImage!}
            editPrompt={editPrompt}
            onEditPromptChange={setEditPrompt}
            onEditSubmit={handleEditImage}
            onReset={handleStartOver}
            isLoading={isLoading}
            onDownload={handleDownload}
            onApplyEffect={handleApplyEffect}
            onUndo={handleUndo}
            onRedo={handleRedo}
            canUndo={canUndo}
            canRedo={canRedo}
            blurLevel={blurLevel}
            onBlurChange={handleBlurChange}
          />
        );
      case 'style-selector':
        return (
          <StyleSelector 
              originalImages={originalImages.map(img => img.dataUrl)} 
              onStyleSelect={handleGenerateHeadshot} 
              selectedAspectRatio={selectedAspectRatio}
              onAspectRatioSelect={setSelectedAspectRatio}
              cameraFocusPoint={cameraFocusPoint}
              onFocusPointChange={setCameraFocusPoint}
              onReset={handleReset}
              onCustomStylesUpload={handleCustomStylesUpload}
              customStyleOptions={customStyles}
              selectedStyleId={selectedStyleId}
              onSelectedStyleIdChange={setSelectedStyleId}
          />
        );
      case 'uploader':
      default:
        return <ImageUploader onImageUpload={handleImageUpload} isLoading={isLoading} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col">
      <Header />
      <main className="flex-grow flex flex-col justify-center items-center p-4">
        <div key={currentView} className="fade-in w-full flex flex-col justify-center items-center flex-grow">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;