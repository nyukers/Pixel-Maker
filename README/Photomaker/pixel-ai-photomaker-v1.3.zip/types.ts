export interface StyleOption {
  id: string;
  name: string;
  prompt: string;
}

export interface PhotoEffect {
  id: string;
  name: string;
  prompt: string;
}

export interface AspectRatio {
  id: string;
  name: string;
  prompt: string;
}
