import React, { useRef } from 'react';

interface ImageUploaderProps {
  onImageUpload: (files: File[]) => void;
  isLoading: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, isLoading }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      onImageUpload(Array.from(files));
    }
  };

  const handleClick = () => {
    inputRef.current?.click();
  };

  return (
    <div className="w-full max-w-lg mx-auto text-center p-8">
      <h2 className="text-2xl font-semibold mb-4 text-gray-100">Step 1: Upload Your Selfie</h2>
      <p className="text-gray-400 mb-6">Choose one or more clear, front-facing photos for the best results. We'll take care of the rest.</p>
      <input
        type="file"
        ref={inputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
        disabled={isLoading}
        multiple
      />
      <button
        onClick={handleClick}
        disabled={isLoading}
        className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-transform transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Processing...' : 'Select Photo(s)'}
      </button>
    </div>
  );
};

export default ImageUploader;