import React, { useRef } from 'react';
import { STYLE_OPTIONS, ASPECT_RATIOS } from '../constants';
import type { StyleOption, AspectRatio } from '../types';
import CameraAngleController from './CameraAngleController';

interface StyleSelectorProps {
  onStyleSelect: (style: StyleOption) => void;
  originalImages: string[];
  onAspectRatioSelect: (ratio: AspectRatio) => void;
  selectedAspectRatio: AspectRatio;
  onFocusPointChange: (point: { x: number; y: number }) => void;
  cameraFocusPoint: { x: number; y: number };
  onReset: () => void;
  onCustomStylesUpload: (file: File) => void;
  customStyleOptions: StyleOption[];
  selectedStyleId: string;
  onSelectedStyleIdChange: (id: string) => void;
}

const Icon = ({ id, ...props }: { id: string } & React.SVGProps<SVGSVGElement>) => {
    const commonProps = {
      "aria-hidden": "true",
      width: "1.2em",
      height: "1.2em",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      ...props,
    };
  
    switch (id) {
      // Aspect Ratios
      case 'square':
        return <svg {...commonProps}><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>;
      case 'portrait':
        return <svg {...commonProps}><rect x="6" y="3" width="12" height="18" rx="2" ry="2"></rect></svg>;
      case 'landscape':
        return <svg {...commonProps}><rect x="3" y="6" width="18" height="12" rx="2" ry="2"></rect></svg>;
      default:
        return null;
    }
};

const StyleSelector: React.FC<StyleSelectorProps> = ({ 
    onStyleSelect, 
    originalImages,
    onAspectRatioSelect,
    selectedAspectRatio,
    onFocusPointChange,
    cameraFocusPoint,
    onReset,
    onCustomStylesUpload,
    customStyleOptions,
    selectedStyleId,
    onSelectedStyleIdChange
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const selectedCustomStyleId = customStyleOptions.some(s => s.id === selectedStyleId) ? selectedStyleId : '';
  const selectedBuiltInStyleId = STYLE_OPTIONS.some(s => s.id === selectedStyleId) ? selectedStyleId : '';


  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onCustomStylesUpload(file);
    }
    // Reset file input to allow uploading the same file again
    if (event.target) {
        event.target.value = '';
    }
  };

  const handleDownloadTemplate = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "name,prompt\n"
      + '"My Custom Style","A headshot with a dramatic, cinematic feel, deep shadows, and a single key light."';
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "custom_styles_template.csv");
    document.body.appendChild(link); // Required for FF
    link.click();
    document.body.removeChild(link);
  };
  
  const handleGenerateClick = () => {
    const styleId = selectedStyleId;
    if (!styleId) return;

    const allStyles = [...customStyleOptions, ...STYLE_OPTIONS];
    const selectedStyle = allStyles.find(style => style.id === styleId);
    if (selectedStyle) {
        onStyleSelect(selectedStyle);
    }
  };


  return (
    <div className="w-full max-w-4xl mx-auto text-center p-8">
        <h2 className="text-2xl font-semibold mb-4 text-gray-100">Step 2: Customize Your Headshot</h2>
        <p className="text-gray-400 mb-6">First, select your desired aspect ratio and camera angles for the final image.</p>
        
        <div className="bg-gray-800/50 p-6 rounded-lg mb-8 border border-gray-700">
            <h3 className="text-lg font-semibold text-gray-200 mb-4">Composition</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-1 items-center">
                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Aspect Ratio</label>
                    <div className="flex flex-col items-center justify-center flex-wrap gap-2">
                        {ASPECT_RATIOS.map((ratio) => (
                            <button
                                key={ratio.id}
                                onClick={() => onAspectRatioSelect(ratio)}
                                className={`px-4 py-2 text-sm rounded-md font-semibold transition-colors w-48 flex items-center justify-center gap-2 ${
                                    selectedAspectRatio.id === ratio.id 
                                    ? 'bg-blue-600 text-white' 
                                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                                }`}
                            >
                                <Icon id={ratio.id} />
                                {ratio.name}
                            </button>
                        ))}
                    </div>
                </div>
                <div className="flex flex-col items-center w-full">
                    <label className="block text-sm font-medium text-gray-400 mb-2">Camera Angel</label>
                    <div className="w-full max-w-[200px]">
                        <CameraAngleController
                            focusPoint={cameraFocusPoint}
                            onFocusPointChange={onFocusPointChange}
                            aspectRatioId={selectedAspectRatio.id}
                        />
                    </div>
                </div>
            </div>
        </div>
        
        <p className="text-gray-400 mb-6">Now, select a style below to generate your professional headshot.</p>

        <div className="mb-8 flex flex-col sm:flex-row justify-center items-center gap-4">
          <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept=".csv"
          />
          <button
              onClick={handleUploadClick}
              className="bg-gray-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 transition-transform transform hover:scale-105"
          >
              Upload Custom Styles (CSV)
          </button>
          <button
              onClick={handleDownloadTemplate}
              className="text-sm text-blue-400 hover:underline focus:outline-none focus:ring-2 focus:ring-blue-500 rounded"
          >
              Download Template
          </button>
        </div>
        
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            <div className="flex-shrink-0 text-center w-48">
                 <div className="grid grid-cols-2 gap-2 mb-2">
                    {originalImages.map((src, index) => (
                        <img 
                            key={index} 
                            src={src} 
                            alt={`Your selfie ${index + 1}`} 
                            className="rounded-lg object-cover w-full h-20 border-2 border-gray-600 shadow-lg"
                        />
                    ))}
                 </div>
                 <p className="text-sm text-gray-400 mt-2">Original Photos</p>
                 <button 
                   onClick={onReset}
                   className="text-sm text-blue-400 hover:underline mt-1"
                 >
                   Use different photos
                 </button>
            </div>
            <div className="w-full">
              <div className="space-y-4 text-left">
                  {customStyleOptions.length > 0 && (
                      <div className="mb-4">
                          <label htmlFor="custom-style-select" className="block text-sm font-medium text-gray-300 mb-2">
                              Your Custom Styles
                          </label>
                          <select
                              id="custom-style-select"
                              value={selectedCustomStyleId}
                              onChange={(e) => onSelectedStyleIdChange(e.target.value)}
                              className="w-full bg-gray-700 border border-gray-600 text-white rounded-md p-3 focus:ring-blue-500 focus:border-blue-500 appearance-none"
                          >
                              <option value="">-- Select a custom style --</option>
                              {customStyleOptions.map(style => (
                                  <option key={style.id} value={style.id}>{style.name}</option>
                              ))}
                          </select>
                      </div>
                  )}

                  <div>
                      <label htmlFor="style-select" className="block text-sm font-medium text-gray-300 mb-2">
                          Built-in Styles
                      </label>
                      <select
                          id="style-select"
                          value={selectedBuiltInStyleId}
                          onChange={(e) => onSelectedStyleIdChange(e.target.value)}
                          className="w-full bg-gray-700 border border-gray-600 text-white rounded-md p-3 focus:ring-blue-500 focus:border-blue-500 appearance-none"
                      >
                          <option value="">-- Select a built-in style --</option>
                          {STYLE_OPTIONS.map(style => (
                              <option key={style.id} value={style.id}>{style.name}</option>
                          ))}
                      </select>
                  </div>
                  <button
                      onClick={handleGenerateClick}
                      disabled={!selectedStyleId}
                      className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-transform transform hover:scale-105 disabled:bg-gray-500 disabled:cursor-not-allowed"
                  >
                      Generate Headshot
                  </button>
              </div>
            </div>
        </div>
    </div>
  );
};

export default StyleSelector;