import React, { useRef, useEffect } from 'react';
import { PHOTO_EFFECTS } from '../constants';

interface ImageEditorProps {
  imageSrc: string;
  editPrompt: string;
  onEditPromptChange: (value: string) => void;
  onEditSubmit: () => void;
  onReset: () => void;
  isLoading: boolean;
  onDownload: () => void;
  onApplyEffect: (prompt: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  blurLevel: number;
  onBlurChange: (level: number) => void;
}

const ImageEditor: React.FC<ImageEditorProps> = ({
  imageSrc,
  editPrompt,
  onEditPromptChange,
  onEditSubmit,
  onReset,
  isLoading,
  onDownload,
  onApplyEffect,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  blurLevel,
  onBlurChange,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto'; // Reset height to recalculate
      textarea.style.height = `${textarea.scrollHeight}px`; // Set to content height
    }
  }, [editPrompt]);

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-8">
      <h2 className="text-3xl font-semibold mb-8 text-gray-100 text-center">Step 3: Your AI Headshot</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
        {/* Left Column: Image */}
        <div className="flex justify-center items-start">
          <div className="relative w-full max-w-md lg:max-w-none">
            <img src={imageSrc} alt="Generated AI headshot" className="rounded-xl shadow-2xl border-2 border-gray-700 w-full" />
            {isLoading && (
                <div className="absolute inset-0 bg-black bg-opacity-60 flex justify-center items-center rounded-xl">
                     <div className="flex flex-col justify-center items-center">
                        <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <p className="text-white mt-2">Refining...</p>
                     </div>
                </div>
            )}
          </div>
        </div>

        {/* Right Column: Controls */}
        <div className="flex flex-col gap-6">
          <div>
            <label htmlFor="edit-prompt" className="block text-sm font-medium text-gray-300 mb-2">
                This is the final prompt. You can improve your result by writing here INSTEAD, for example, “add a retro filter,” “change the background to a library,” and pressing the Go button.
            </label>
            <div className="flex gap-2 items-start">
                <textarea
                    ref={textareaRef}
                    id="edit-prompt"
                    value={editPrompt}
                    onChange={(e) => onEditPromptChange(e.target.value)}
                    placeholder="Describe your change..."
                    className="flex-grow bg-gray-700 border border-gray-600 text-white rounded-md p-3 focus:ring-blue-500 focus:border-blue-500 resize-none overflow-hidden min-h-[50px]"
                    disabled={isLoading}
                />
                <button
                    onClick={onEditSubmit}
                    disabled={isLoading || !editPrompt}
                    className="bg-purple-600 text-white font-bold py-3 px-5 rounded-md hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                >
                    Go
                </button>
            </div>
          </div>

          <div>
            <label htmlFor="blur-slider" className="block text-sm font-medium text-gray-300 mb-2">
              Background Blur Intensity
            </label>
            <input
              id="blur-slider"
              type="range"
              min="0"
              max="100"
              step="25"
              value={blurLevel}
              onChange={(e) => onBlurChange(Number(e.target.value))}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
              disabled={isLoading}
            />
            <div className="flex justify-between text-xs text-gray-400 px-1 mt-1">
              <span>None</span>
              <span>Subtle</span>
              <span>Medium</span>
              <span>Strong</span>
              <span>Max</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Or apply a quick effect:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PHOTO_EFFECTS.map((effect) => (
                <button
                  key={effect.id}
                  onClick={() => onApplyEffect(effect.prompt)}
                  disabled={isLoading}
                  className="bg-gray-700 text-white text-sm font-semibold py-2 px-3 rounded-md hover:bg-gray-600 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                >
                  {effect.name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center flex-wrap justify-center gap-3 mt-4 border-t border-gray-700 pt-6">
            <button
              onClick={onUndo}
              disabled={!canUndo || isLoading}
              className="bg-gray-700 text-white font-semibold py-2 px-4 rounded-md hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors"
              aria-label="Undo last action"
            >
              Undo
            </button>
            <button
              onClick={onRedo}
              disabled={!canRedo || isLoading}
              className="bg-gray-700 text-white font-semibold py-2 px-4 rounded-md hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors"
              aria-label="Redo last action"
            >
              Redo
            </button>
            <button
              onClick={onDownload}
              disabled={isLoading}
              className="bg-green-600 text-white font-bold py-2 px-5 rounded-md hover:bg-green-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
            >
              Download
            </button>
            <button
              onClick={onReset}
              className="bg-red-600 text-white font-bold py-2 px-5 rounded-md hover:bg-red-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
              disabled={isLoading}
            >
              Start Over
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageEditor;