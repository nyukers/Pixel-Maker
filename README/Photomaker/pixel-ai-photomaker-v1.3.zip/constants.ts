import type { StyleOption, PhotoEffect, AspectRatio } from './types';

export const STYLE_OPTIONS: StyleOption[] = [
  {
    id: 'no_style',
    name: 'No Style',
    prompt: 'A simple, clean, photorealistic headshot with neutral lighting and a plain background, focusing on the specified composition.'
  },
  { 
    id: 'corporate', 
    name: 'Corporate Grey', 
    prompt: 'Professional corporate headshot, clean studio grey backdrop, sharp focus, studio lighting, looking confident and approachable.' 
  },
  { 
    id: 'tech', 
    name: 'Modern Tech Office', 
    prompt: 'Professional headshot in a modern tech office, blurred background with subtle elements like computer screens and green plants, bright, natural window lighting.' 
  },
  { 
    id: 'outdoor', 
    name: 'Outdoor Natural', 
    prompt: 'Friendly headshot outdoors with beautiful natural light, soft focus on a blurred park or nature background, warm and inviting expression.' 
  },
  { 
    id: 'creative', 
    name: 'Creative Studio', 
    prompt: 'Artistic and creative headshot in a studio, interesting textures or a solid dark color in the background, dramatic side lighting to highlight features.' 
  },
  {
    id: 'vintage',
    name: 'Vintage Film',
    prompt: 'Headshot with a vintage film look, warm tones, subtle grain, and a classic, timeless feel, reminiscent of 35mm film photography.'
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    prompt: 'Cyberpunk style headshot, moody, with dramatic neon lighting from the side, futuristic and edgy vibe, dark, rain-slicked city background.'
  },
  {
    id: 'bw',
    name: 'Elegant Black & White',
    prompt: 'Classic and elegant black and white headshot, high contrast, dramatic shadows, capturing a sophisticated and timeless look, against a simple dark backdrop.'
  },
  {
    id: 'pop-art',
    name: 'Pop Art',
    prompt: 'Pop Art style headshot inspired by Andy Warhol, with vibrant, saturated colors, bold outlines, and a graphic, screen-printed look.'
  },
  {
    id: 'golden-hour',
    name: 'Golden Hour Glow',
    prompt: 'Headshot taken during the golden hour, with warm, soft, and glowing sunlight. The background should be a beautiful, slightly blurred outdoor scene, creating a dreamy and serene atmosphere.'
  },
  {
    id: 'academic',
    name: 'Academic Scholar',
    prompt: 'Professional headshot in a classic library or study setting. The background features bookshelves, warm wooden tones, and soft, focused lighting to create an intellectual and sophisticated mood.'
  },
  {
    id: 'urban',
    name: 'Urban Streetwear',
    prompt: 'Stylish headshot in a dynamic urban city environment. The background is a blurred street scene with graffiti or interesting architecture. The lighting is natural but edgy, capturing a cool, confident vibe.'
  },
  {
    id: 'gamer',
    name: 'Gamer/Streamer',
    prompt: 'Modern headshot for a gamer or streamer. The subject is in front of a high-tech gaming setup with RGB neon lights, a high-end microphone, and blurred monitor screens in the background. The mood is energetic and futuristic.'
  }
];

export const PHOTO_EFFECTS: PhotoEffect[] = [
  { id: 'sepia', name: 'Sepia', prompt: 'Apply a warm, brownish sepia tone to the image.' },
  { id: 'vintage', name: 'Vintage', prompt: 'Give the image a faded, vintage look with muted colors.' },
  { id: 'bw', name: 'B & W', prompt: 'Convert the image to a dramatic, high-contrast black and white.' },
  { id: 'vibrant', name: 'Vibrant', prompt: 'Enhance the colors to make them more vibrant and saturated.' },
];

export const PLACEHOLDER_IMAGES: string[] = [
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=1000&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1000&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1000&auto=format&fit=crop',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1000&auto=format&fit=crop',
];

export const ASPECT_RATIOS: AspectRatio[] = [
  { id: 'square', name: 'Square (1:1)', prompt: 'The final image MUST have a square 1:1 aspect ratio.' },
  { id: 'portrait', name: 'Portrait (3:4)', prompt: 'The final image MUST have a portrait 3:4 aspect ratio.' },
  { id: 'landscape', name: 'Landscape (4:3)', prompt: 'The final image MUST have a landscape 4:3 aspect ratio.' },
];
