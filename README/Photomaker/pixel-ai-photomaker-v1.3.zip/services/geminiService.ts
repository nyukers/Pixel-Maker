import { GoogleGenAI, Modality } from "@google/genai";

// Assume process.env.API_KEY is available
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const fileToGenerativePart = (base64: string, mimeType: string) => {
  return {
    inlineData: {
      data: base64,
      mimeType,
    },
  };
};

interface Base64Image {
    data: string;
    mimeType: string;
}

export interface GenerationResult {
    imageUrl: string;
    fullPrompt: string;
    modelName: string;
}

export async function generateHeadshot(base64Images: Base64Image[], stylePrompt: string, aspectRatioPrompt: string, cameraAnglePrompt: string): Promise<GenerationResult> {
    const model = 'gemini-2.5-flash-image';
    const imageParts = base64Images.map(image => fileToGenerativePart(image.data, image.mimeType));
    
    const fullPrompt = `Generate a photorealistic, professional headshot. Use all of the provided images as a reference to create a single, consistent representation of the person. ${aspectRatioPrompt} ${cameraAnglePrompt} The headshot should be based on the person in the provided images. Apply the following style: "${stylePrompt}". Do not copy the aspect ratio or camera angle from the input images. IMPORTANT: The person's face and facial features in the generated image MUST be an exact match to the original photos, combining their features accurately. Do not alter their likeness in any way. Only change the background, lighting, and clothing to match the requested style. The final output must be a single, high-quality photograph.`;
    const textPart = { text: fullPrompt };

    const response = await ai.models.generateContent({
        model,
        contents: { parts: [...imageParts, textPart] },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    const firstPart = response.candidates?.[0]?.content?.parts[0];
    if (firstPart && firstPart.inlineData) {
        const base64Result = firstPart.inlineData.data;
        return {
            imageUrl: `data:${firstPart.inlineData.mimeType};base64,${base64Result}`,
            fullPrompt,
            modelName: model,
        };
    } else {
        throw new Error("Failed to generate image. The AI did not return image data. Please try a different photo or style.");
    }
}

export async function editImage(base64Image: string, mimeType: string, editPrompt: string): Promise<GenerationResult> {
    const model = 'gemini-2.5-flash-image';
    const imagePart = fileToGenerativePart(base64Image, mimeType);
    const fullPrompt = `Apply the following edit to the image: "${editPrompt}". It is absolutely crucial to maintain the person's exact likeness and facial features from the original image. Only apply the requested changes.`;
    const textPart = { text: fullPrompt };

    const response = await ai.models.generateContent({
        model,
        contents: { parts: [imagePart, textPart] },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    const firstPart = response.candidates?.[0]?.content?.parts[0];
    if (firstPart && firstPart.inlineData) {
        const base64Result = firstPart.inlineData.data;
        return {
            imageUrl: `data:${firstPart.inlineData.mimeType};base64,${base64Result}`,
            fullPrompt,
            modelName: model,
        };
    } else {
        throw new Error("Failed to edit image. The AI did not return image data. Please try a different prompt.");
    }
}
