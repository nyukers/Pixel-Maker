
import { useCallback, useRef, useEffect } from 'react';
import { useSettings } from '../contexts/SettingsContext';

type SoundType = 'draw' | 'flip' | 'reveal' | 'click';

export const useSound = () => {
  const { soundEnabled } = useSettings();
  const audioContextRef = useRef<AudioContext | null>(null);

  // Initialize AudioContext lazily
  useEffect(() => {
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const getContext = () => {
    if (!audioContextRef.current) {
        // Create context only when needed
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        audioContextRef.current = new AudioContextClass();
    }
    return audioContextRef.current;
  };

  const playSound = useCallback((type: SoundType) => {
    if (!soundEnabled) return;

    try {
      const ctx = getContext();
      // Resume context if it was suspended (browser autoplay policy)
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const t = ctx.currentTime;
      const gain = ctx.createGain();
      gain.connect(ctx.destination);

      if (type === 'click') {
        // Simple high blip
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, t);
        osc.frequency.exponentialRampToValueAtTime(400, t + 0.1);
        
        gain.gain.setValueAtTime(0.1, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
        
        osc.connect(gain);
        osc.start(t);
        osc.stop(t + 0.1);

      } else if (type === 'reveal') {
        // Magical chime (Major chord)
        const freqs = [523.25, 659.25, 783.99, 1046.50]; // C Major
        freqs.forEach((f, i) => {
            const osc = ctx.createOscillator();
            osc.type = 'sine';
            osc.frequency.value = f;
            
            const localGain = ctx.createGain();
            localGain.gain.setValueAtTime(0, t);
            localGain.gain.linearRampToValueAtTime(0.05, t + 0.1 + (i * 0.05));
            localGain.gain.exponentialRampToValueAtTime(0.001, t + 2.5);
            
            osc.connect(localGain);
            localGain.connect(ctx.destination); // Connect directly or to master gain
            osc.start(t);
            osc.stop(t + 2.5);
        });

      } else if (type === 'draw' || type === 'flip') {
        // White noise "swoosh" for paper sound
        const bufferSize = ctx.sampleRate * 0.3; // 300ms
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = ctx.createBufferSource();
        noise.buffer = buffer;

        // Filter to make it sound like paper
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1200, t);

        gain.gain.setValueAtTime(0.15, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

        noise.connect(filter);
        filter.connect(gain);
        noise.start(t);
      }

    } catch (error) {
      console.warn("Synth playback failed", error);
    }
  }, [soundEnabled]);

  return { playSound };
};
