
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

type DeckType = 'classic' | 'fantasy';
export type LanguageType = 'en' | 'uk';

interface SettingsContextType {
  soundEnabled: boolean;
  toggleSound: () => void;
  selectedDeck: DeckType;
  changeDeck: (deckId: DeckType) => void;
  language: LanguageType;
  setLanguage: (lang: LanguageType) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [soundEnabled, setSoundEnabled] = useState<boolean>(false);
  const [selectedDeck, setSelectedDeck] = useState<DeckType>('fantasy');
  const [language, setLanguageState] = useState<LanguageType>('en');

  useEffect(() => {
    // Load sound preference
    const savedSound = localStorage.getItem('tarot_sound_enabled');
    if (savedSound !== null) {
      setSoundEnabled(JSON.parse(savedSound));
    }

    // Load deck preference
    const savedDeck = localStorage.getItem('tarot_selected_deck');
    if (savedDeck === 'classic' || savedDeck === 'fantasy') {
        setSelectedDeck(savedDeck as DeckType);
    }

    // Load language preference
    const savedLang = localStorage.getItem('tarot_language');
    if (savedLang === 'en' || savedLang === 'uk') {
        setLanguageState(savedLang as LanguageType);
    }
  }, []);

  const toggleSound = () => {
    setSoundEnabled(prev => {
      const newValue = !prev;
      localStorage.setItem('tarot_sound_enabled', JSON.stringify(newValue));
      return newValue;
    });
  };

  const changeDeck = (deckId: DeckType) => {
      setSelectedDeck(deckId);
      localStorage.setItem('tarot_selected_deck', deckId);
  };

  const setLanguage = (lang: LanguageType) => {
      setLanguageState(lang);
      localStorage.setItem('tarot_language', lang);
  }

  return (
    <SettingsContext.Provider value={{ soundEnabled, toggleSound, selectedDeck, changeDeck, language, setLanguage }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
