
import { GoogleGenAI, Modality } from "@google/genai";
import { DrawnCard } from '../types';
import { LanguageType } from '../contexts/SettingsContext';

const getTarotReading = async (question: string, drawnCards: DrawnCard[], language: LanguageType = 'en'): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const cardDescriptions = drawnCards.map((c, index) => 
    `${index + 1}. Card for '${['Past', 'Present', 'Future'][index]}': ${c.card.name} (${c.isReversed ? 'Reversed' : 'Upright'}) - Meaning: ${c.card.meaning}`
  ).join('\n');

  const langInstruction = language === 'uk' 
    ? "Write the response in Ukrainian. The structure must be: 'Минуле: [text]', 'Теперішнє: [text]', 'Майбутнє: [text]'. Ensure the tone is mystical, poetic, and respectful."
    : "Write the response in English. The structure must be: 'Past: [text]', 'Present: [text]', 'Future: [text]'.";

  const prompt = `
    You are a mystical and wise tarot reader with deep knowledge of ancient symbolism. A person seeks your guidance.
    
    Their question is: "${question}"

    They have drawn three cards in a Past, Present, and Future spread:
    ${cardDescriptions}

    Your task is to weave these cards into a single, coherent, and insightful narrative, structured into distinct sections.
    - Begin with a mystical greeting in its own paragraph.
    - Create a new paragraph for the 'Past' interpretation.
    - Create a new paragraph for the 'Present' interpretation.
    - Create a new paragraph for the 'Future' interpretation.
    - Conclude with a final paragraph that synthesizes the reading and offers a thoughtful piece of advice.
    
    ${langInstruction}
    
    Your tone should be empathetic, profound, and enchanting. Relate the interpretation directly to their question and synthesize the card meanings into a flowing story. Do not use markdown. Separate each section with a single newline character.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const text = response.text;
    if (!text || text.trim() === '') {
        console.warn("Received an empty response from the tarot reading API.");
        return language === 'uk' 
            ? "Небесні течії сьогодні тихі. Я не бачу повідомлення в картах. Спробуйте запитати інакше."
            : "The celestial currents are unusually quiet. I could not discern a message in the cards. Please try asking in a different way or rephrasing your question.";
    }
    return text;
    
  } catch (error) {
    console.error("Error generating tarot reading:", error);
    return language === 'uk'
        ? "Космос зараз закритий вуаллю. Спробуйте пізніше, коли зірки стануть прихильнішими."
        : "The cosmos seems to be veiled at this moment. Please try again later when the stars are aligned.";
  }
};

const translateToEnglish = async (text: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Translate the following text to English. Do not add any explanation, just return the translated text. If it is already English, fix any grammar issues. Text: \n\n${text}`,
    });

    return response.text?.trim() || text;
  } catch (error) {
    console.error("Translation error:", error);
    return text;
  }
};

/**
 * Helper to decode base64 string to byte array
 */
function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

/**
 * Helper to decode PCM data into an AudioBuffer
 */
async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

const generateSpeech = async (text: string, audioContext: AudioContext): Promise<AudioBuffer | null> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' }, // 'Kore' implies a calm, feminine voice, good for tarot.
            },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    
    if (!base64Audio) {
        throw new Error("No audio data received");
    }

    const audioBuffer = await decodeAudioData(
        decode(base64Audio),
        audioContext,
        24000, // Gemini TTS sample rate
        1,
    );
    
    return audioBuffer;

  } catch (error) {
      console.error("Speech generation error:", error);
      return null;
  }
};

export { getTarotReading, translateToEnglish, generateSpeech };
