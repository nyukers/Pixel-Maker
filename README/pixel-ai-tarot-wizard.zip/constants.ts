
import { TarotCardData } from './types';

export const TRANSLATIONS = {
  en: {
    title: "AI Tarot Wizard",
    subtitle: "Gaze into the digital ether and find your answers.",
    focusTitle: "Focus your mind...",
    focusDesc: "What guidance do you seek from the cards today?",
    placeholder: "e.g., What should I focus on in my career?",
    defaultQuestion: "What do I need to know about my current path?",
    translateBtn: "Translate to English",
    drawBtn: "Draw Three Cards",
    drawingBtn: "Consulting the Cosmos...",
    asked: "You asked:",
    cardsWhispering: "The cards are whispering their secrets...",
    saveTxt: "Save as Text",
    printPdf: "Print / Save PDF",
    speakBtn: "Listen to Prophecy",
    speakingBtn: "Conjuring Voice (~ 20 sec)...",
    stopBtn: "Silence Voice",
    askAgain: "Ask Another Question",
    footer: "This tarot reading is for entertainment purposes only!",
    past: "Past",
    present: "Present",
    future: "Future",
    reversed: "Reversed",
    upright: "Upright",
    clickDetails: "Click for details",
    uprightMeaning: "Upright Meaning",
    reversedMeaning: "Reversed Meaning",
    settings: "Settings",
    soundEffects: "Sound Effects",
    chooseDeck: "Choose Deck Style",
    chooseLang: "Language",
    errorEmpty: "Please enter a question to begin your reading.",
    errorGeneric: "An error occurred while connecting to the spiritual plane. Please try again.",
    cardPositionNames: ['Past', 'Present', 'Future'],
    about: "About",
    aboutTitle: "About AI Tarot Wizard",
    aboutPurpose: "This application merges ancient symbolism with modern artificial intelligence. Powered by Google's Gemini API, it interprets card spreads to offer unique, reflective narratives tailored to your specific questions.",
    aboutArt: "The 'Fantasy' deck features the classic Rider-Waite imagery, a cornerstone of tarot history. The 'Classic' deck features the 'Nyukers' pixel art style, offering a retro-digital aesthetic.",
    aboutDisclaimer: "Please remember that this tool is for entertainment and self-reflection purposes only. It does not predict the future with certainty and should not replace professional medical, legal, or financial advice.",
    geminiLink: "Powered by (C) Nyukers, 2026"
  },
  uk: {
    title: "AI Tarot Wizard",
    subtitle: "Поглянь у цифровий ефір та знайди відповіді.",
    focusTitle: "Зосередься...",
    focusDesc: "Яку пораду ти шукаєш у карт сьогодні?",
    placeholder: "напр., На чому мені зосередитись у кар'єрі?",
    defaultQuestion: "Що мені потрібно знати про мій майбутній шлях?",
    translateBtn: "Перекласти англійською",
    drawBtn: "Витягнути три карти",
    drawingBtn: "Радимося з космосом...",
    asked: "Ваше питання:",
    cardsWhispering: "Карти шепочуть свої таємниці...",
    saveTxt: "Зберегти текст",
    printPdf: "Друк / PDF",
    speakBtn: "Послухати пророцтво",
    speakingBtn: "Викликаю голос (~ 20 sec)...",
    stopBtn: "Замовкнути",
    askAgain: "Запитати ще раз",
    footer: "Це ворожіння призначене лише для розваги!",
    past: "Минуле",
    present: "Теперішнє",
    future: "Майбутнє",
    reversed: "Перевернута",
    upright: "Пряма",
    clickDetails: "Натисни для деталей",
    uprightMeaning: "Пряме значення",
    reversedMeaning: "Перевернуте значення",
    settings: "Налаштування",
    soundEffects: "Звукові ефекти",
    chooseDeck: "Стиль колоди",
    chooseLang: "Мова",
    errorEmpty: "Будь ласка, введіть питання, щоб почати.",
    errorGeneric: "Сталася помилка при з'єднанні з духовним планом. Спробуйте ще раз.",
    cardPositionNames: ['Минуле', 'Теперішнє', 'Майбутнє'],
    about: "Про додаток",
    aboutTitle: "Про AI Майстер Таро",
    aboutPurpose: "Цей додаток поєднує стародавній символізм із сучасним штучним інтелектом. Працюючи на базі Google Gemini API, він інтерпретує розклади карт, щоб запропонувати унікальні, глибокі відповіді на ваші запитання.",
    aboutArt: "Колода 'Fantasy' використовує класичні зображення Rider-Waite. Колода 'Classic' виконана у стилі піксель-арт 'Nyukers', пропонуючи ретро-цифрову естетику.",
    aboutDisclaimer: "Будь ласка, пам'ятайте, що цей інструмент призначений лише для розваги та саморефлексії. Він не передбачає майбутнє і не замінює професійних медичних, юридичних чи фінансових порад.",
    geminiLink:"Powered by (C) Nyukers, 2026"
  }
};

const NYUKERS_DECK: TarotCardData[] = [
  // Major Arcana (22 Cards) - Original Images
  { 
    name: 'The Fool', 
    meaning: 'Beginnings, innocence, spontaneity, a free spirit',
    image: 'https://nyukers.ucoz.net/tarot/jester.jpg',
    uprightMeaning: 'The Fool represents new beginnings, having faith in the future, being inexperienced, beginner\'s luck, improvisation, and believing in the universe. It encourages you to take a leap of faith.',
    reversedMeaning: 'The Fool reversed suggests acting recklessly, taking unnecessary risks, or being naive. It may indicate a lack of direction, negligence, or stalling on a new journey out of fear.'
  },
  { 
    name: 'The Magician', 
    meaning: 'Manifestation, resourcefulness, power, inspired action',
    image: 'https://nyukers.ucoz.net/tarot/magician.jpg',
    uprightMeaning: 'The Magician signifies that you have all the skills and tools you need to succeed. It represents willpower, desire, creation, and the power to manifest your goals into reality.',
    reversedMeaning: 'Reversed, The Magician warns of trickery, illusions, and being out of touch with reality. It can also suggest unused potential, manipulation, or a lack of mental clarity.'
  },
  { 
    name: 'The High Priestess', 
    meaning: 'Intuition, sacred knowledge, divine feminine, the subconscious mind',
    image: 'https://nyukers.ucoz.net/tarot/high-priestess.jpg',
    uprightMeaning: 'She sits at the gate of the great mystery. This card indicates a time to trust your intuition and look inward. It represents wisdom, spiritual enlightenment, and secrets waiting to be revealed.',
    reversedMeaning: 'Reversed, it suggests you are ignoring your inner voice or suppressing your feelings. It can also indicate surface-level knowledge, hidden agendas, or a disconnection from your intuition.'
  },
  { 
    name: 'The Empress', 
    meaning: 'Femininity, beauty, nature, nurturing, abundance',
    image: 'https://nyukers.ucoz.net/tarot/empress.jpg',
    uprightMeaning: 'The Empress is a call to connect with your feminine energy. She brings abundance, fertility, and creativity. It is a sign of nature, beauty, and nurturing oneself and others.',
    reversedMeaning: 'When reversed, The Empress can indicate creative blocks, dependence on others, or smothering behavior. It may also suggest a lack of self-care or feeling empty.'
  },
  { 
    name: 'The Emperor', 
    meaning: 'Authority, establishment, structure, a father figure',
    image: 'https://nyukers.ucoz.net/tarot/emperor.jpg',
    uprightMeaning: 'The Emperor represents authority, structure, and solid foundations. It suggests a time for logic, organization, and discipline to achieve your goals. He is the father figure of the deck.',
    reversedMeaning: 'Reversed, this card signifies domination, excessive control, rigidity, and inflexibility. It can also represent a lack of discipline or a rebellious attitude toward authority.'
  },
  { 
    name: 'The Hierophant', 
    meaning: 'Spiritual wisdom, religious beliefs, conformity, tradition, institutions',
    image: 'https://nyukers.ucoz.net/tarot/hierophant.jpg',
    uprightMeaning: 'The Hierophant stands for tradition, convention, and spiritual guidance. It suggests following established social structures or seeking knowledge from a mentor or institution.',
    reversedMeaning: 'Reversed, it represents challenging the status quo, personal beliefs, and freedom from restriction. It encourages you to make your own rules and question rigid traditions.'
  },
  { 
    name: 'The Lovers', 
    meaning: 'Love, harmony, relationships, values alignment, choices',
    image: 'https://nyukers.ucoz.net/tarot/choice.jpg',
    uprightMeaning: 'The Lovers represent relationships and choices. Its appearance often indicates a soul connection, harmony, and shared values. It asks you to clarify your beliefs and make choices from the heart.',
    reversedMeaning: 'Reversed, it suggests disharmony, trust issues, and detachment. It can point to bad choices, conflicts within a relationship, or a misalignment of values.'
  },
  { 
    name: 'The Chariot', 
    meaning: 'Control, willpower, success, action, determination',
    image: 'https://nyukers.ucoz.net/tarot/chariot.jpg',
    uprightMeaning: 'The Chariot represents overcoming challenges through control and willpower. It is a card of victory, determination, and success. Keep your focus and drive forward.',
    reversedMeaning: 'Reversed, The Chariot suggests a lack of control, aggression, or lack of direction. It warns against letting obstacles overwhelm you or forcing your will upon others.'
  },
  { 
    name: 'Strength', 
    meaning: 'Strength, courage, persuasion, influence, compassion',
    image: 'https://nyukers.ucoz.net/tarot/strength.jpg',
    uprightMeaning: 'Strength represents inner fortitude, patience, and compassion. It is about taming your raw emotions and finding courage not through force, but through gentle influence and confidence.',
    reversedMeaning: 'Reversed, it indicates self-doubt, weakness, or insecurity. You may be letting fear or anxiety control you. It calls for you to reconnect with your inner core of power.'
  },
  { 
    name: 'The Hermit', 
    meaning: 'Soul-searching, introspection, being alone, inner guidance',
    image: 'https://nyukers.ucoz.net/tarot/hermit.jpg',
    uprightMeaning: 'The Hermit suggests a time for solitude and introspection. It asks you to withdraw from the noise of the world to find the answers within yourself and seek your own truth.',
    reversedMeaning: 'Reversed, it can mean isolation, loneliness, or withdrawal from the world to an unhealthy degree. It may also suggest you are rejecting advice or feeling lost.'
  },
  { 
    name: 'Wheel of Fortune', 
    meaning: 'Good luck, karma, life cycles, destiny, a turning point',
    image: 'https://nyukers.ucoz.net/tarot/wheel-of-fortune.jpg',
    uprightMeaning: 'The Wheel represents the cycles of life, fate, and destiny. It indicates a turning point and reminds you that what goes up must come down, and vice versa. Embrace change.',
    reversedMeaning: 'Reversed, it signals bad luck, resistance to change, or breaking a negative cycle. It can indicate a period of hardship, but reminds you that this too is temporary.'
  },
  { 
    name: 'Justice', 
    meaning: 'Justice, fairness, truth, cause and effect, law',
    image: 'https://nyukers.ucoz.net/tarot/justice.jpg',
    uprightMeaning: 'Justice signifies fairness, truth, and the law of cause and effect. It indicates that a decision will be made fairly. Take responsibility for your actions and seek the truth.',
    reversedMeaning: 'Reversed, Justice suggests dishonesty, unaccountability, or unfairness. It may indicate that you are avoiding the truth or that a situation is legally or morally complicated.'
  },
  { 
    name: 'The Hanged Man', 
    meaning: 'Pause, surrender, letting go, new perspectives',
    image: 'https://nyukers.ucoz.net/tarot/hanged-man.jpg',
    uprightMeaning: 'The Hanged Man advises you to pause and surrender. It is a time to let go of control and view the world from a completely different perspective. Sacrifice may be necessary.',
    reversedMeaning: 'Reversed, it suggests stalling, unnecessary sacrifice, or a fear of letting go. You might be resisting the pause you need or holding onto something that no longer serves you.'
  },
  { 
    name: 'Death', 
    meaning: 'Endings, change, transformation, transition',
    image: 'https://nyukers.ucoz.net/tarot/death.jpg',
    uprightMeaning: 'Death rarely means physical death; it symbolizes the end of a major phase or aspect of your life. It represents profound transformation, new beginnings, and letting go of the past.',
    reversedMeaning: 'Reversed, Death indicates resistance to change, inability to move on, or holding onto the past. You may be stuck in a state of limbo, refusing to accept the inevitable.',
  },
  { 
    name: 'Temperance', 
    meaning: 'Balance, moderation, patience, purpose',
    image: 'https://nyukers.ucoz.net/tarot/time.jpg',
    uprightMeaning: 'Temperance calls for balance, patience, and moderation. It suggests avoiding extremes and finding the middle path. It is a card of alchemy, blending opposites to create harmony.',
    reversedMeaning: 'Reversed, it indicates imbalance, excess, or a lack of long-term vision. You may be acting hastily or indulging too much. It is a warning to restore equilibrium.',
  },
  { 
    name: 'The Devil', 
    meaning: 'Shadow self, attachment, addiction, restriction, sexuality',
    image: 'https://nyukers.ucoz.net/tarot/devil.jpg',
    uprightMeaning: 'The Devil represents the shadow self, addiction, and material attachment. It suggests you feel trapped by your own desires or choices. It calls for awareness of what binds you.',
    reversedMeaning: 'Reversed, The Devil signifies breaking free, releasing limiting beliefs, and reclaiming your power. You are beginning to see the chains for what they are and are ready to let go.',
  },
  { 
    name: 'The Tower', 
    meaning: 'Sudden change, upheaval, chaos, revelation, awakening',
    image: 'https://nyukers.ucoz.net/tarot/tower.jpg',
    uprightMeaning: 'The Tower brings sudden, often chaotic change. It represents the destruction of false structures and illusions. While painful, this upheaval clears the way for truth and new growth.',
    reversedMeaning: 'Reversed, it suggests avoiding disaster or delaying the inevitable. You might be resisting the pause you need or holding onto something that no longer serves you. It can also mean a crisis is fading.',
  },
  { 
    name: 'The Star', 
    meaning: 'Hope, faith, purpose, renewal, spirituality',
    image: 'https://nyukers.ucoz.net/tarot/star.jpg',
    uprightMeaning: 'The Star brings hope, renewal, and inspiration. After the chaos of The Tower, it offers healing and serenity. Trust that the universe is guiding you toward a brighter future.',
    reversedMeaning: 'Reversed, it indicates a lack of faith, despair, or discouragement. You may be feeling uninspired or disconnected. It asks you to nurture your own hope and self-esteem.',
  },
  { 
    name: 'The Moon', 
    meaning: 'Illusion, fear, anxiety, subconscious, intuition',
    image: 'https://nyukers.ucoz.net/tarot/moon.jpg',
    uprightMeaning: 'The Moon represents illusions, intuition, and the unconscious. Things are not as they seem. It asks you to trust your gut instincts and navigate through fear and uncertainty.',
    reversedMeaning: 'Reversed, The Moon releases fear and confusion. Secrets may be revealed, or you may be gaining clarity on a situation that was previously clouded by illusion.',
  },
  { 
    name: 'The Sun', 
    meaning: 'Positivity, fun, warmth, success, vitality',
    image: 'https://nyukers.ucoz.net/tarot/sun.jpg',
    uprightMeaning: 'The Sun is the card of ultimate positivity, success, and joy. It brings vitality, warmth, and clarity. Everything is coming together, and you are radiating confidence.',
    reversedMeaning: 'Reversed, The Sun still indicates positivity, but it may be temporary or hidden. You might be struggling to see the bright side or feeling overly optimistic to the point of unrealistic expectations.',
  },
  { 
    name: 'Judgement', 
    meaning: 'Judgement, rebirth, inner calling, absolution',
    image: 'https://nyukers.ucoz.net/tarot/judgment.jpg',
    uprightMeaning: 'Judgement calls for self-reflection and awakening. It is a time of reckoning where past actions are reviewed. It represents a rebirth and answering a higher calling.',
    reversedMeaning: 'Reversed, it suggests self-doubt, refusal to self-reflect, or ignoring a call to action. You may be being too critical of yourself or others, hindering your transformation.',
  },
  { 
    name: 'The World', 
    meaning: 'Completion, integration, accomplishment, travel',
    image: 'https://nyukers.ucoz.net/tarot/world.jpg',
    uprightMeaning: 'The World represents completion, achievement, and fulfillment. A major cycle in your life has come to a successful end, and you are ready for the next level.',
    reversedMeaning: 'Reversed, it indicates a lack of closure or feeling incomplete. You may be near the finish line but delayed. It asks what loose ends need to be tied up before you can move on.',
  }
];

// Map of card names to Rider-Waite image URLs (Wikimedia Commons)
const FANTASY_IMAGES: Record<string, string> = {
    'The Fool': 'https://upload.wikimedia.org/wikipedia/commons/9/90/RWS_Tarot_00_Fool.jpg',
    'The Magician': 'https://upload.wikimedia.org/wikipedia/commons/d/de/RWS_Tarot_01_Magician.jpg',
    'The High Priestess': 'https://upload.wikimedia.org/wikipedia/commons/8/88/RWS_Tarot_02_High_Priestess.jpg',
    'The Empress': 'https://upload.wikimedia.org/wikipedia/commons/d/d2/RWS_Tarot_03_Empress.jpg',
    'The Emperor': 'https://upload.wikimedia.org/wikipedia/commons/c/c3/RWS_Tarot_04_Emperor.jpg',
    'The Hierophant': 'https://upload.wikimedia.org/wikipedia/commons/8/8d/RWS_Tarot_05_Hierophant.jpg',
    'The Lovers': 'https://upload.wikimedia.org/wikipedia/commons/3/3a/RWS_Tarot_06_Lovers.jpg',
    'The Chariot': 'https://upload.wikimedia.org/wikipedia/commons/9/9b/RWS_Tarot_07_Chariot.jpg',
    'Strength': 'https://upload.wikimedia.org/wikipedia/commons/f/f5/RWS_Tarot_08_Strength.jpg',
    'The Hermit': 'https://upload.wikimedia.org/wikipedia/commons/4/4d/RWS_Tarot_09_Hermit.jpg',
    'Wheel of Fortune': 'https://upload.wikimedia.org/wikipedia/commons/3/3c/RWS_Tarot_10_Wheel_of_Fortune.jpg',
    'Justice': 'https://upload.wikimedia.org/wikipedia/commons/e/e0/RWS_Tarot_11_Justice.jpg',
    'The Hanged Man': 'https://upload.wikimedia.org/wikipedia/commons/2/2b/RWS_Tarot_12_Hanged_Man.jpg',
    'Death': 'https://upload.wikimedia.org/wikipedia/commons/d/d7/RWS_Tarot_13_Death.jpg',
    'Temperance': 'https://upload.wikimedia.org/wikipedia/commons/f/f8/RWS_Tarot_14_Temperance.jpg',
    'The Devil': 'https://upload.wikimedia.org/wikipedia/commons/5/55/RWS_Tarot_15_Devil.jpg',
    'The Tower': 'https://upload.wikimedia.org/wikipedia/commons/5/53/RWS_Tarot_16_Tower.jpg',
    'The Star': 'https://upload.wikimedia.org/wikipedia/commons/d/db/RWS_Tarot_17_Star.jpg',
    'The Moon': 'https://upload.wikimedia.org/wikipedia/commons/7/7f/RWS_Tarot_18_Moon.jpg',
    'The Sun': 'https://upload.wikimedia.org/wikipedia/commons/1/17/RWS_Tarot_19_Sun.jpg',
    'Judgement': 'https://upload.wikimedia.org/wikipedia/commons/d/dd/RWS_Tarot_20_Judgement.jpg',
    'The World': 'https://upload.wikimedia.org/wikipedia/commons/f/ff/RWS_Tarot_21_World.jpg',
};

// Create Fantasy (Rider-Waite) deck by mapping over Nyukers deck and replacing images
const FANTASY_DECK: TarotCardData[] = NYUKERS_DECK.map(card => ({
    ...card,
    image: FANTASY_IMAGES[card.name] || card.image
}));

export const DECKS = {
    classic: NYUKERS_DECK,
    fantasy: FANTASY_DECK
};

// For backward compatibility (initially used directly)
export const TAROT_DECK = NYUKERS_DECK;
