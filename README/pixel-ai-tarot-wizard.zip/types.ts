
export interface TarotCardData {
  name: string;
  meaning: string;
  image: string;
  uprightMeaning: string;
  reversedMeaning: string;
}

export interface DrawnCard {
  card: TarotCardData;
  isReversed: boolean;
}
