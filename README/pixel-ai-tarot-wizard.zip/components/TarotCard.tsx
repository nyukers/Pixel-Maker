
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { DrawnCard } from '../types';
import { useSound } from '../hooks/useSound';
import { useSettings } from '../contexts/SettingsContext';
import { TRANSLATIONS } from '../constants';

interface TarotCardProps {
  drawnCard: DrawnCard;
  delay: number;
}

const TarotCard: React.FC<TarotCardProps> = ({ drawnCard, delay }) => {
  const { card, isReversed } = drawnCard;
  const [isFlipped, setIsFlipped] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const { playSound } = useSound();
  const { language } = useSettings();
  const t = TRANSLATIONS[language];

  useEffect(() => {
    // Auto-flip the card after the entrance animation + a slight pause
    // The entrance animation is 0.5s + delay
    const totalDelay = (delay * 1000) + 600; 
    const timer = setTimeout(() => {
      setIsFlipped(true);
      playSound('flip');
    }, totalDelay);

    return () => clearTimeout(timer);
  }, [delay, playSound]);

  const handleCardClick = () => {
    if (isFlipped) {
      playSound('reveal');
      setShowModal(true);
    }
  };

  const closeModal = () => {
    playSound('click');
    setShowModal(false);
  };

  return (
    <>
      <div
        onClick={handleCardClick}
        className={`group relative w-48 h-[22rem] sm:w-56 sm:h-[26rem] perspective-1000 transform transition-all duration-500 ease-in-out ${isFlipped ? 'cursor-pointer hover:scale-110 hover:-translate-y-6 hover:z-20 hover:shadow-[0_0_30px_rgba(234,179,8,0.4)]' : ''}`}
        style={{ animation: `fadeInUp 0.5s ${delay}s both` }}
      >
        <div
          className={`relative w-full h-full transition-transform duration-1000 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}
        >
          {/* Card Back */}
          <div className="absolute w-full h-full backface-hidden rounded-xl overflow-hidden shadow-lg shadow-purple-900/50 border-2 border-yellow-600/50 bg-slate-900 z-10">
              {/* Background Image */}
              <img 
                src="https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=1000&auto=format&fit=crop"
                alt="Card Back"
                className="absolute inset-0 w-full h-full object-cover opacity-75 transition-transform duration-1000 group-hover:scale-110"
              />
              {/* Overlay Gradient for depth */}
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/90 via-purple-900/40 to-black/90 mix-blend-multiply"></div>
              
              {/* Decorative Frame */}
              <div className="absolute inset-3 border border-yellow-500/40 rounded-lg flex items-center justify-center">
                  <div className="absolute inset-1 border border-yellow-500/20 rounded-md"></div>
                  
                  {/* Central Emblem */}
                  <div className="relative flex items-center justify-center w-24 h-24 rounded-full bg-black/40 backdrop-blur-[2px] border border-yellow-400/40 shadow-[0_0_25px_rgba(234,179,8,0.2)] group-hover:shadow-[0_0_35px_rgba(234,179,8,0.4)] transition-shadow duration-500">
                      <div className="absolute inset-0 rounded-full border border-white/10 animate-pulse"></div>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-14 w-14 text-yellow-100/90 drop-shadow-[0_0_5px_rgba(253,224,71,0.5)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                      </svg>
                  </div>
              </div>
          </div>

          {/* Card Front */}
          <div className="absolute w-full h-full backface-hidden rotate-y-180 rounded-xl overflow-hidden shadow-lg shadow-black/50 border-2 border-yellow-500/30 bg-slate-800 flex items-center justify-center">
              <img 
                src={card.image} 
                alt={card.name} 
                className="w-full h-full object-cover" 
              />
              {/* Magic overlay on reveal */}
              <div className={`absolute inset-0 bg-yellow-400/20 mix-blend-overlay transition-opacity duration-1000 ${isFlipped ? 'opacity-0' : 'opacity-100'}`}></div>
              
              <div className={`absolute bottom-0 left-0 right-0 p-3 bg-black/80 backdrop-blur-sm text-center border-t border-yellow-500/30 ${isReversed ? 'rotate-180' : ''}`}>
                <h3 className={`font-cinzel text-yellow-300 text-lg transition-all duration-300 hover:text-yellow-100 hover:scale-105 inline-block ${isReversed ? 'rotate-180' : ''}`}>{card.name}</h3>
                {isReversed && <p className="text-purple-300 text-xs font-cinzel rotate-180">({t.reversed})</p>}
              </div>
          </div>
        </div>
        
        {/* Magic Particles (Decorative CSS elements) */}
        {isFlipped && (
            <>
                <div className="magic-particle w-1 h-1 top-[-10px] left-[20%] delay-75 duration-[2s]"></div>
                <div className="magic-particle w-1.5 h-1.5 top-[10%] right-[-15px] delay-150 duration-[2.5s]"></div>
                <div className="magic-particle w-1 h-1 bottom-[-5px] left-[60%] delay-300 duration-[1.8s]"></div>
            </>
        )}
        
        {/* Tooltip (Hover Summary) */}
        {isFlipped && (
            <div className="absolute bottom-full mb-4 w-64 p-3 bg-slate-900/95 border border-yellow-500/30 rounded-lg shadow-xl text-center opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-30 left-1/2 -translate-x-1/2 pointer-events-none transform group-hover:-translate-y-2">
                <h4 className="font-cinzel text-yellow-300 font-bold tracking-wide">{card.name}</h4>
                <p className="text-purple-200 text-sm mt-1 font-quicksand">{card.meaning}</p>
                <div className="text-xs text-yellow-500/80 mt-2 font-semibold tracking-wide uppercase">{t.clickDetails}</div>
                <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-8 border-x-transparent border-t-8 border-t-slate-900/95"></div>
            </div>
        )}
      </div>

      {/* Modal (Click Details) */}
      {showModal && createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-fadeIn" onClick={closeModal}>
          <div 
            className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-slate-900 border-2 border-yellow-500/50 rounded-xl shadow-[0_0_50px_rgba(147,51,234,0.3)] p-6 flex flex-col gap-4 animate-scaleIn"
            onClick={(e) => e.stopPropagation()}
          >
             <button 
                onClick={closeModal}
                className="absolute top-4 right-4 text-purple-300 hover:text-white transition-colors p-2"
                aria-label="Close details"
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
             </button>

             <div className="flex flex-col items-center mt-2">
                <h2 className="text-2xl sm:text-3xl font-cinzel text-yellow-300 text-center mb-1 drop-shadow-lg">{card.name}</h2>
                <div className="text-purple-200 text-sm font-cinzel mb-4 uppercase tracking-widest">
                    {isReversed ? t.reversed : t.upright} Position
                </div>
                <div className={`w-32 h-52 sm:w-48 sm:h-72 rounded-lg overflow-hidden border-2 border-yellow-500/50 shadow-2xl shadow-yellow-900/20 mb-6 transition-transform ${isReversed ? 'rotate-180' : ''}`}>
                    <img src={card.image} alt={card.name} className="w-full h-full object-cover" />
                </div>
             </div>

             <div className="space-y-4 text-justify">
                <div className={`p-4 rounded-lg border transition-colors duration-300 ${!isReversed ? 'bg-indigo-950/60 border-yellow-500/60 shadow-[0_0_15px_rgba(234,179,8,0.1)]' : 'bg-slate-800/40 border-slate-700 opacity-70'}`}>
                    <h3 className={`font-cinzel text-lg mb-2 flex items-center gap-2 ${!isReversed ? 'text-yellow-200' : 'text-slate-400'}`}>
                        {!isReversed && <span className="text-yellow-400">✦</span>} {t.uprightMeaning}
                    </h3>
                    <p className="text-sm sm:text-base text-purple-100 leading-relaxed font-quicksand">{card.uprightMeaning}</p>
                </div>

                <div className={`p-4 rounded-lg border transition-colors duration-300 ${isReversed ? 'bg-purple-950/60 border-purple-400/60 shadow-[0_0_15px_rgba(168,85,247,0.2)]' : 'bg-slate-800/40 border-slate-700 opacity-70'}`}>
                    <h3 className={`font-cinzel text-lg mb-2 flex items-center gap-2 ${isReversed ? 'text-purple-200' : 'text-slate-400'}`}>
                        {isReversed && <span className="text-purple-400">✦</span>} {t.reversedMeaning}
                    </h3>
                    <p className="text-sm sm:text-base text-purple-100 leading-relaxed font-quicksand">{card.reversedMeaning}</p>
                </div>
             </div>
          </div>
          <style>{`
            .animate-scaleIn {
                animation: scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            }
            @keyframes scaleIn {
                from { opacity: 0; transform: scale(0.95); }
                to { opacity: 1; transform: scale(1); }
            }
          `}</style>
        </div>,
        document.body
      )}
    </>
  );
};

export default TarotCard;
