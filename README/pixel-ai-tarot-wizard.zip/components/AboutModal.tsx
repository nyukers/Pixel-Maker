
import React from 'react';
import { createPortal } from 'react-dom';
import { useSettings } from '../contexts/SettingsContext';
import { TRANSLATIONS } from '../constants';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  const { language } = useSettings();
  const t = TRANSLATIONS[language];

  if (!isOpen) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn" onClick={onClose}>
      <div 
        className="relative w-full max-w-2xl bg-slate-900 border-2 border-yellow-500/50 rounded-xl shadow-2xl p-6 flex flex-col gap-6 animate-scaleIn max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center border-b border-white/10 pb-4">
          <h2 className="text-2xl font-cinzel text-yellow-300">{t.aboutTitle}</h2>
          <button 
            onClick={onClose}
            className="text-purple-300 hover:text-white transition-colors"
            aria-label="Close about"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-6 text-purple-100 leading-relaxed font-quicksand">
          {/* Image Column */}
          <div className="sm:w-5/12 flex-shrink-0">
            <div className="w-full h-48 sm:h-full rounded-lg overflow-hidden border border-yellow-500/20 shadow-lg relative min-h-[200px]">
              <img 
                src="https://nyukers.ucoz.net/tarot/about.jpg" 
                alt="About AI Tarot Wizard" 
                className="absolute inset-0 w-full h-full object-cover opacity-90 hover:opacity-100 transition-opacity"
              />
            </div>
          </div>

          {/* Text Content Column */}
          <div className="flex-1 space-y-4">
            <p className="text-base sm:text-lg">
              {t.aboutPurpose}
            </p>
            
            <div className="bg-white/5 p-4 rounded-lg border border-purple-500/20">
               <h3 className="text-yellow-200 font-cinzel mb-2 flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Art Inspiration
               </h3>
               <p className="text-sm text-purple-200">
                 {t.aboutArt}
               </p>
            </div>

            <div className="bg-red-900/20 p-4 rounded-lg border border-red-500/30 text-red-200 text-sm italic">
               <strong>Disclaimer:</strong> {t.aboutDisclaimer}
            </div>
            
            <div className="pt-2">
              <a 
                href="https://ai.google.dev/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-yellow-400 hover:text-yellow-200 transition-colors font-cinzel text-sm"
              >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                  </svg>
                  {t.geminiLink}
              </a>
            </div>
          </div>
        </div>
      </div>
      <style>{`
        .animate-scaleIn {
            animation: scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>,
    document.body
  );
};

export default AboutModal;
