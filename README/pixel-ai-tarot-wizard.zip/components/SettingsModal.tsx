
import React from 'react';
import { createPortal } from 'react-dom';
import { useSettings } from '../contexts/SettingsContext';
import { TRANSLATIONS } from '../constants';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { soundEnabled, toggleSound, selectedDeck, changeDeck, language, setLanguage } = useSettings();
  const t = TRANSLATIONS[language];

  if (!isOpen) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn" onClick={onClose}>
      <div 
        className="relative w-full max-w-sm bg-slate-900 border-2 border-yellow-500/50 rounded-xl shadow-2xl p-6 flex flex-col gap-6 animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center border-b border-white/10 pb-4">
          <h2 className="text-2xl font-cinzel text-yellow-300">{t.settings}</h2>
          <button 
            onClick={onClose}
            className="text-purple-300 hover:text-white transition-colors"
            aria-label="Close settings"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="space-y-6">
          {/* Sound Toggle */}
          <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-purple-500/20">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-900/50 rounded-full text-yellow-400">
                {soundEnabled ? (
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                     <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.414z" clipRule="evenodd" />
                   </svg>
                ) : (
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                     <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM12.293 7.293a1 1 0 011.414 1.414L10.414 12l3.293 3.293a1 1 0 01-1.414 1.414L9 13.414l-3.293 3.293a1 1 0 01-1.414-1.414L7.586 12 4.293 8.707a1 1 0 011.414-1.414L9 10.586l3.293-3.293z" clipRule="evenodd" />
                   </svg>
                )}
              </div>
              <span className="text-purple-100 font-cinzel">{t.soundEffects}</span>
            </div>
            
            <button 
              onClick={toggleSound}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-slate-900 ${soundEnabled ? 'bg-yellow-600' : 'bg-slate-700'}`}
            >
              <span className="sr-only">Enable notifications</span>
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${soundEnabled ? 'translate-x-6' : 'translate-x-1'}`}
              />
            </button>
          </div>

          {/* Language Selection */}
          <div>
            <h3 className="text-purple-200 font-cinzel mb-3 text-sm">{t.chooseLang}</h3>
            <div className="grid grid-cols-2 gap-3">
               <button
                  onClick={() => setLanguage('en')}
                  className={`p-3 rounded-lg border-2 transition-all font-cinzel text-sm ${language === 'en' ? 'bg-indigo-900/60 border-yellow-400 text-yellow-300' : 'bg-slate-800/50 border-white/10 text-slate-400 hover:border-purple-500/50'}`}
               >
                 English
               </button>
               <button
                  onClick={() => setLanguage('uk')}
                  className={`p-3 rounded-lg border-2 transition-all font-cinzel text-sm ${language === 'uk' ? 'bg-indigo-900/60 border-yellow-400 text-yellow-300' : 'bg-slate-800/50 border-white/10 text-slate-400 hover:border-purple-500/50'}`}
               >
                 Українська
               </button>
            </div>
          </div>

          {/* Deck Selection */}
          <div>
              <h3 className="text-purple-200 font-cinzel mb-3 text-sm">{t.chooseDeck}</h3>
              <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => changeDeck('classic')}
                    className={`relative p-3 rounded-lg border-2 transition-all flex flex-col items-center gap-2 group ${selectedDeck === 'classic' ? 'bg-indigo-900/60 border-yellow-400 shadow-[0_0_10px_rgba(234,179,8,0.3)]' : 'bg-slate-800/50 border-white/10 hover:border-purple-500/50'}`}
                  >
                      <div className="w-24 h-36 bg-slate-700 rounded overflow-hidden shadow-md">
                          <img src="https://nyukers.ucoz.net/tarot/jester.jpg" alt="Nyukers" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <span className={`text-xs font-cinzel ${selectedDeck === 'classic' ? 'text-yellow-300' : 'text-slate-400'}`}>Nyukers</span>
                      {selectedDeck === 'classic' && (
                          <div className="absolute top-2 right-2 w-2 h-2 bg-yellow-400 rounded-full shadow-[0_0_5px_rgba(234,179,8,1)]"></div>
                      )}
                  </button>

                  <button
                    onClick={() => changeDeck('fantasy')}
                    className={`relative p-3 rounded-lg border-2 transition-all flex flex-col items-center gap-2 group ${selectedDeck === 'fantasy' ? 'bg-indigo-900/60 border-yellow-400 shadow-[0_0_10px_rgba(234,179,8,0.3)]' : 'bg-slate-800/50 border-white/10 hover:border-purple-500/50'}`}
                  >
                      <div className="w-24 h-36 bg-slate-700 rounded overflow-hidden shadow-md">
                          <img src="https://upload.wikimedia.org/wikipedia/commons/9/90/RWS_Tarot_00_Fool.jpg" alt="Rider-Waite" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <span className={`text-xs font-cinzel ${selectedDeck === 'fantasy' ? 'text-yellow-300' : 'text-slate-400'}`}>Rider-Waite</span>
                      {selectedDeck === 'fantasy' && (
                          <div className="absolute top-2 right-2 w-2 h-2 bg-yellow-400 rounded-full shadow-[0_0_5px_rgba(234,179,8,1)]"></div>
                      )}
                  </button>
              </div>
          </div>
        </div>
        
        <div className="text-center text-xs text-purple-400/50 pt-4 border-t border-white/10">
           Pixel AI Tarot Wizard v0.777,
           (C) Nyukers, 2026
        </div>

      </div>
      <style>{`
        .animate-scaleIn {
            animation: scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>,
    document.body
  );
};

export default SettingsModal;
