
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { DrawnCard } from './types';
import { DECKS, TRANSLATIONS } from './constants';
import { getTarotReading, translateToEnglish, generateSpeech } from './services/geminiService';
import TarotCard from './components/TarotCard';
import { useSound } from './hooks/useSound';
import SettingsModal from './components/SettingsModal';
import AboutModal from './components/AboutModal';
import { useSettings } from './contexts/SettingsContext';

const ReadingDisplay = ({ text, labels }: { text: string, labels: any }) => {
    if (!text) return null;

    const paragraphs = text.split('\n').filter(p => p.trim() !== '');

    return (
        <div className="text-purple-100 max-w-none animate-fadeIn text-justify leading-relaxed space-y-4">
            {paragraphs.map((paragraph, index) => {
                if (paragraph.startsWith('Past: ') || paragraph.startsWith('Минуле: ')) {
                    const content = paragraph.replace(/^(Past:|Минуле:)\s*/, '');
                    return (
                        <div key={index} className="bg-white/5 p-4 rounded-lg border-l-2 border-yellow-500/50">
                            <strong className="text-yellow-300 font-cinzel tracking-wider text-lg block mb-1">{labels.past}</strong>
                            <p className="text-sm sm:text-base text-purple-100">{content}</p>
                        </div>
                    );
                }
                if (paragraph.startsWith('Present: ') || paragraph.startsWith('Теперішнє: ')) {
                    const content = paragraph.replace(/^(Present:|Теперішнє:)\s*/, '');
                    return (
                        <div key={index} className="bg-white/5 p-4 rounded-lg border-l-2 border-yellow-500/50">
                            <strong className="text-yellow-300 font-cinzel tracking-wider text-lg block mb-1">{labels.present}</strong>
                            <p className="text-sm sm:text-base text-purple-100">{content}</p>
                        </div>
                    );
                }
                if (paragraph.startsWith('Future: ') || paragraph.startsWith('Майбутнє: ')) {
                    const content = paragraph.replace(/^(Future:|Майбутнє:)\s*/, '');
                    return (
                        <div key={index} className="bg-white/5 p-4 rounded-lg border-l-2 border-yellow-500/50">
                            <strong className="text-yellow-300 font-cinzel tracking-wider text-lg block mb-1">{labels.future}</strong>
                            <p className="text-sm sm:text-base text-purple-100">{content}</p>
                        </div>
                    );
                }
                return <p key={index} className="text-sm sm:text-base">{paragraph}</p>;
            })}
        </div>
    );
};

const App: React.FC = () => {
  const { selectedDeck, language, soundEnabled } = useSettings();
  const t = TRANSLATIONS[language];
  
  // Initialize with the default question of the current language
  const [question, setQuestion] = useState<string>(t.defaultQuestion);
  const [drawnCards, setDrawnCards] = useState<DrawnCard[]>([]);
  const [reading, setReading] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [isGeneratingSpeech, setIsGeneratingSpeech] = useState<boolean>(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  
  // Refs for audio playback
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const { playSound } = useSound();

  // Update question if language changes and the user hasn't typed a custom question
  // (i.e., if it matches the OTHER language's default question)
  useEffect(() => {
    const otherLang = language === 'en' ? 'uk' : 'en';
    const otherDefault = TRANSLATIONS[otherLang].defaultQuestion;
    
    if (question === otherDefault) {
        setQuestion(t.defaultQuestion);
    }
  }, [language, question, t.defaultQuestion]);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
        }
        if (audioContextRef.current) {
            audioContextRef.current.close();
        }
    };
  }, []);

  const stopAudio = useCallback(() => {
      if (audioSourceRef.current) {
          try {
              audioSourceRef.current.stop();
          } catch (e) {
              // Ignore errors if already stopped
          }
          audioSourceRef.current = null;
      }
      setIsPlayingAudio(false);
  }, []);

  const handleSpeakReading = async () => {
    if (!reading) return;
    
    // If playing, stop it
    if (isPlayingAudio) {
        stopAudio();
        return;
    }

    setIsGeneratingSpeech(true);
    playSound('click');

    try {
        // Create AudioContext on user gesture
        if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
        }
        
        // Resume if suspended
        if (audioContextRef.current.state === 'suspended') {
            await audioContextRef.current.resume();
        }

        const audioBuffer = await generateSpeech(reading, audioContextRef.current);
        
        if (audioBuffer) {
            setIsGeneratingSpeech(false);
            setIsPlayingAudio(true);
            
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            source.onended = () => {
                setIsPlayingAudio(false);
                audioSourceRef.current = null;
            };
            source.start();
            audioSourceRef.current = source;
        } else {
            // Handle generation failure silently or with minor notification
             setIsGeneratingSpeech(false);
        }

    } catch (e) {
        console.error("Audio playback error", e);
        setIsGeneratingSpeech(false);
        setIsPlayingAudio(false);
    }
  };

  const drawCards = useCallback(async () => {
    if (!question.trim()) {
      setError(t.errorEmpty);
      return;
    }
    
    // Stop any playing audio
    stopAudio();

    // Play draw sound immediately
    playSound('draw');

    setError('');
    setIsLoading(true);
    setReading('');
    setDrawnCards([]);

    // Get the current deck based on settings
    const currentDeck = DECKS[selectedDeck];

    // Shuffle deck and draw 3 cards
    const shuffledDeck = [...currentDeck].sort(() => Math.random() - 0.5);
    const newDrawnCards = shuffledDeck.slice(0, 3).map(card => ({
      card,
      isReversed: Math.random() < 0.5,
    }));
    
    setDrawnCards(newDrawnCards);

    try {
      const result = await getTarotReading(question, newDrawnCards, language);
      setReading(result);
    } catch (e) {
      setError(t.errorGeneric);
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [question, playSound, selectedDeck, language, t, stopAudio]);
  
  const resetReading = () => {
      playSound('click');
      stopAudio();
      setQuestion(t.defaultQuestion);
      setDrawnCards([]);
      setReading('');
      setError('');
      setIsLoading(false);
  };

  const handleTranslateInput = async () => {
    if (!question.trim()) return;
    playSound('click');
    setIsTranslating(true);
    try {
        const translated = await translateToEnglish(question);
        setQuestion(translated);
    } catch (e) {
        console.error("Translation failed", e);
    } finally {
        setIsTranslating(false);
    }
  };

  const handleSaveTxt = () => {
    playSound('click');
    const cardDetails = drawnCards.map((c, i) => 
        `${t.cardPositionNames[i]}: ${c.card.name} ${c.isReversed ? `(${t.reversed})` : ''}`
    ).join('\n');

    const slogan = "Powered by Pixel AI Tarot Wizard, Nyukers (C), 2026, https://tinyurl.com/aitarotwizard";
    const content = `Your Tarot Reading\n\nQuestion: ${question}\n\nCards Drawn:\n${cardDetails}\n\n---\n\nReading:\n${reading}\n\n---\n${slogan}`;
    
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const href = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = href;
    link.download = 'tarot-reading.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);
  };

  const handlePrint = () => {
    playSound('click');
    const printWindow = window.open('', '_blank', 'width=800,height=800');
    
    if (!printWindow) {
        window.print();
        return;
    }

    const cardHtml = drawnCards.map((c, i) => `
        <div style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
            <h3 style="margin-bottom: 5px; color: #333;">${t.cardPositionNames[i]}: ${c.card.name} ${c.isReversed ? `(${t.reversed})` : ''}</h3>
            <p style="margin: 0; color: #555;">${c.card.meaning}</p>
        </div>
    `).join('');

    const readingHtml = reading.split('\n').filter(p => p.trim()).map(p => {
         const style = (p.startsWith('Past:') || p.startsWith('Минуле:') || 
                        p.startsWith('Present:') || p.startsWith('Теперішнє:') ||
                        p.startsWith('Future:') || p.startsWith('Майбутнє:')) 
            ? 'font-weight: bold; margin-top: 15px; color: #222;' 
            : 'margin-bottom: 10px;';
         return `<p style="${style}">${p}</p>`;
    }).join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${t.title}</title>
          <style>
            body { font-family: 'Georgia', serif; padding: 40px; color: #1a1a1a; line-height: 1.6; max-width: 800px; margin: 0 auto; background: white; }
            h1 { text-align: center; border-bottom: 2px solid #ddd; padding-bottom: 20px; margin-bottom: 30px; font-family: sans-serif; }
            .meta { background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 5px solid #666; }
            h2 { color: #444; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-top: 30px; }
            .footer { margin-top: 50px; text-align: center; color: #777; font-size: 0.85em; border-top: 1px solid #eee; padding-top: 20px; font-style: italic; }
            @media print {
               button { display: none; }
            }
          </style>
        </head>
        <body>
          <h1>${t.title}</h1>
          
          <div class="meta">
            <strong>${t.asked}</strong> ${question}<br/>
            <small>Date: ${new Date().toLocaleDateString()}</small>
          </div>

          <h2>Cards</h2>
          <div>${cardHtml}</div>

          <h2>Interpretation</h2>
          <div>${readingHtml}</div>

          <div class="footer">
            Powered by Pixel AI Tarot Wizard, Nyukers (C), 2026, https://tinyurl.com/aitarotwizard
          </div>

          <script>
            window.onload = function() {
                setTimeout(function() {
                    window.print();
                }, 500);
            }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  const toggleSettings = () => {
    playSound('click');
    setIsSettingsOpen(true);
  };
  
  const toggleAbout = () => {
    playSound('click');
    setIsAboutOpen(true);
  };

  return (
    <div className="min-h-screen relative text-white flex flex-col items-center overflow-x-hidden font-quicksand">
      {/* Background Image Layer - Multiplied Blend Mode */}
      <div 
        className="fixed inset-0 z-[-2] w-full h-full"
        style={{
            backgroundImage: "url('https://nyukers.ucoz.net/tarot/info2.gif')",
        //    backgroundColor: "#2e1065", // Dark purple (violet-950) base for multiply
        //    backgroundBlendMode: "multiply", 
            backgroundRepeat: "repeat",
            backgroundSize: "auto", 
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
        }}
      />
      
      {/* Overlay Layer for Readability */}
      <div className="fixed inset-0 z-[-1] bg-slate-950/70 pointer-events-none" aria-hidden="true" />
      
      {/* Header Buttons Container */}
      <div className="fixed top-4 right-4 z-40 flex gap-3 no-print">
        {/* About Button */}
        <button 
            onClick={toggleAbout}
            className="p-3 bg-black/40 backdrop-blur-md border border-purple-500/30 rounded-full text-purple-200 hover:text-white hover:border-yellow-400/50 hover:bg-black/60 transition-all shadow-lg group"
            aria-label="About"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
        </button>

        {/* Settings Button */}
        <button 
            onClick={toggleSettings}
            className="p-3 bg-black/40 backdrop-blur-md border border-purple-500/30 rounded-full text-purple-200 hover:text-yellow-300 hover:border-yellow-400/50 hover:bg-black/60 transition-all shadow-lg group"
            aria-label="Settings"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 transition-transform duration-700 group-hover:rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
        </button>
      </div>

      {/* Modals */}
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      <AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

      {/* Content Layer */}
      <div className="relative z-10 w-full flex flex-col items-center flex-grow p-4 sm:p-6">
          <header className="text-center my-6 sm:my-10 no-print">
            <h1 className="font-cinzel text-4xl sm:text-6xl font-bold text-yellow-300 tracking-wider drop-shadow-[0_0_15px_rgba(234,179,8,0.3)]">{t.title}</h1>
            <p className="text-purple-200 mt-2 text-sm sm:text-base drop-shadow-md">{t.subtitle}</p>
          </header>

          <main className="w-full max-w-5xl flex-grow flex flex-col items-center">
            {drawnCards.length === 0 ? (
              <div className="w-full max-w-lg text-center p-8 bg-black/40 rounded-xl backdrop-blur-md border border-purple-500/30 shadow-2xl no-print">
                <h2 className="font-cinzel text-2xl text-yellow-400 mb-4 drop-shadow-sm">{t.focusTitle}</h2>
                <p className="text-purple-200 mb-6">{t.focusDesc}</p>
                <div className="relative w-full">
                    <textarea
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      placeholder={t.placeholder}
                      className="w-full bg-slate-900/60 border border-purple-400/50 rounded-lg p-3 text-white placeholder-purple-300/60 focus:ring-2 focus:ring-yellow-400 focus:outline-none transition-all duration-300 h-28 resize-none shadow-inner"
                      rows={3}
                    />
                    <button
                        onClick={handleTranslateInput}
                        disabled={isTranslating || !question.trim()}
                        className="absolute bottom-3 right-3 p-2 bg-indigo-900/80 rounded-full border border-purple-500/30 text-purple-300 hover:text-white hover:bg-indigo-700/80 hover:border-yellow-400/50 transition-all disabled:opacity-30 disabled:hover:text-purple-300 disabled:hover:bg-indigo-900/80 disabled:cursor-not-allowed group"
                        title={t.translateBtn}
                    >
                        {isTranslating ? (
                            <div className="w-5 h-5 border-2 border-yellow-300 border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                            </svg>
                        )}
                    </button>
                </div>
                {error && <p className="text-red-400 mt-3">{error}</p>}
                <button
                  onClick={drawCards}
                  disabled={isLoading}
                  className="mt-6 font-cinzel font-bold text-lg bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 text-white px-10 py-3 rounded-full shadow-[0_0_20px_rgba(234,179,8,0.3)] hover:scale-105 hover:shadow-[0_0_30px_rgba(234,179,8,0.5)] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed border border-yellow-400/30"
                >
                  {isLoading ? t.drawingBtn : t.drawBtn}
                </button>
              </div>
            ) : (
              <div id="reading-content" className="w-full flex flex-col items-center">
                <div className="mb-8 p-4 bg-black/40 backdrop-blur-sm rounded-lg max-w-3xl text-center border border-purple-500/20 shadow-lg">
                    <p className="text-purple-300 font-cinzel text-sm">{t.asked}</p>
                    <p className="text-white text-lg italic mt-1">"{question}"</p>
                </div>
              
                <div className="flex flex-col md:flex-row justify-center items-center gap-8 sm:gap-12 mb-8">
                  {drawnCards.map((card, index) => (
                    <div key={index} className="flex flex-col items-center gap-2">
                        <h4 className="font-cinzel text-xl text-yellow-300 drop-shadow-md">{t.cardPositionNames[index]}</h4>
                        <TarotCard drawnCard={card} delay={index * 0.2}/>
                    </div>
                  ))}
                </div>

                <div className="w-full max-w-3xl p-6 bg-black/50 rounded-xl backdrop-blur-md border border-purple-500/30 min-h-[12rem] flex items-center justify-center shadow-2xl">
                  {isLoading ? (
                    <div className="flex flex-col items-center gap-4 text-purple-200">
                       <div className="w-10 h-10 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin shadow-[0_0_15px_rgba(234,179,8,0.5)]"></div>
                       <p className="font-cinzel text-lg animate-pulse">{t.cardsWhispering}</p>
                    </div>
                  ) : (
                    <ReadingDisplay text={reading} labels={t} />
                  )}
                </div>
                
                {!isLoading && reading && (
                    <div className="flex flex-wrap justify-center items-center gap-4 mt-6 no-print z-10 relative">
                        {/* Text to Speech Button - Only if Sound is Enabled */}
                        {soundEnabled && (
                            <button
                                type="button"
                                onClick={handleSpeakReading}
                                disabled={isGeneratingSpeech}
                                className={`font-cinzel text-sm px-6 py-2 rounded-full transition-all cursor-pointer hover:shadow-[0_0_15px_rgba(234,179,8,0.4)] hover:scale-105 flex items-center gap-2 ${
                                    isPlayingAudio 
                                        ? 'bg-red-900/80 border border-red-500/50 text-red-100 hover:bg-red-800/90' 
                                        : 'bg-yellow-900/60 border border-yellow-500/50 text-yellow-100 hover:bg-yellow-800/80'
                                }`}
                            >
                                {isGeneratingSpeech ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                        {t.speakingBtn}
                                    </>
                                ) : isPlayingAudio ? (
                                    <>
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 animate-pulse" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                                        </svg>
                                        {t.stopBtn}
                                    </>
                                ) : (
                                    <>
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.414z" clipRule="evenodd" />
                                        </svg>
                                        {t.speakBtn}
                                    </>
                                )}
                            </button>
                        )}

                        <button
                            type="button"
                            onClick={handleSaveTxt}
                            className="font-cinzel text-sm bg-indigo-900/80 border border-indigo-500/50 text-indigo-100 px-6 py-2 rounded-full hover:bg-indigo-800/90 transition-all cursor-pointer hover:shadow-[0_0_15px_rgba(99,102,241,0.4)] hover:scale-105"
                        >
                            {t.saveTxt}
                        </button>
                        <button
                            type="button"
                            onClick={handlePrint}
                            className="font-cinzel text-sm bg-purple-900/80 border border-purple-500/50 text-purple-100 px-6 py-2 rounded-full hover:bg-purple-800/90 transition-all cursor-pointer hover:shadow-[0_0_15px_rgba(168,85,247,0.4)] hover:scale-105"
                        >
                            {t.printPdf}
                        </button>
                    </div>
                )}

                <button
                  onClick={resetReading}
                  className="mt-8 font-cinzel font-bold text-base bg-transparent border border-purple-400/50 text-purple-200 px-8 py-2 rounded-full hover:bg-purple-900/30 hover:border-yellow-400/50 hover:text-yellow-200 hover:scale-105 transition-all duration-300 no-print"
                >
                  {t.askAgain}
                </button>
              </div>
            )}
          </main>

          <footer className="text-center text-purple-400/50 text-xs py-4 mt-auto no-print relative z-10">
            <p>{t.footer}</p>
          </footer>
      </div>
      
       <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fadeIn {
            animation: fadeIn 1s ease-in-out;
        }
        .perspective-1000 { perspective: 1000px; }
        .transform-style-3d { transform-style: preserve-3d; }
        .rotate-y-180 { transform: rotateY(180deg); }
        .backface-hidden { backface-visibility: hidden; -webkit-backface-visibility: hidden; }

        @media print {
            .no-print {
                display: none !important;
            }
        }
       `}</style>
    </div>
  );
};

export default App;
