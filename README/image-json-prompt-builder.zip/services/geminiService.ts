import { GoogleGenAI } from "@google/genai";
import { SchemaBlock, PromptData } from "../types";

const API_KEY = process.env.API_KEY || '';

// Initialize client only if key exists (handled in App)
const getAiClient = () => new GoogleGenAI({ apiKey: API_KEY });

export async function generatePromptDataWithGemini(
  schema: SchemaBlock[],
  userDescription: string,
  imageBase64?: string,
  mimeType: string = 'image/jpeg'
): Promise<PromptData | null> {
  if (!API_KEY) {
    console.warn("No API Key available");
    return null;
  }

  const ai = getAiClient();
  const model = "gemini-2.5-flash"; // Fast model for JSON tasks and Multimodal inputs

  const simplifiedSchema = schema.map(block => ({
    name: block.name,
    fields: block.fields.map(f => ({ path: f.path, type: f.type, label: f.label }))
  }));

  const systemInstruction = `
    You are an expert creative director, photographer, and prompt engineer.
    Your goal is to populate a JSON structure for an image generation prompt.
    
    You will be provided with:
    1. A Schema (list of blocks and fields).
    2. A User Description OR an Input Image (or both).
    
    Rules:
    - Return ONLY valid JSON.
    - Structure the JSON where top-level keys match the block names (e.g., "scene", "lighting").
    - Nested keys should follow the field paths provided.
    - IF AN IMAGE IS PROVIDED: Analyze it deeply. Reverse-engineer the prompt. describe the lighting, camera angle, subject details, and textures exactly as seen in the image to replicate its style.
    - IF TEXT IS PROVIDED: Expand on the user's description creatively.
    - If a field is boolean, use a boolean value.
    - If specific details are missing, infer plausible professional details suitable for a high-quality image.
  `;

  const schemaContext = `
    Schema:
    ${JSON.stringify(simplifiedSchema, null, 2)}
  `;

  const promptText = imageBase64 
    ? `Analyze this image and fill the schema to replicate this style/scene. ${userDescription ? `Additional context: ${userDescription}` : ''}`
    : `User Description: "${userDescription}". Generate the filled JSON data.`;

  const parts: any[] = [
    { text: schemaContext },
    { text: promptText }
  ];

  if (imageBase64) {
    parts.unshift({
      inlineData: {
        mimeType: mimeType,
        data: imageBase64
      }
    });
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts }, // Pass parts array correctly
      config: {
        systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) return null;

    return JSON.parse(text) as PromptData;
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
}