import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { SchemaBlock, PromptData, PromptInclude, AppSettings, PresetKey, StylePresetKey } from './types';
import { INITIAL_SCHEMA, STYLE_PRESETS } from './constants';
import { getPath, setPath, deepCopy, cleanObject, prunePath, buildInitialData, buildInitialInclude } from './utils';
import { useHistory } from './hooks/useHistory';
import BlockCard from './components/BlockCard';
import Preview from './components/Preview';
import MagicModal from './components/MagicModal';
import ValidatorModal from './components/ValidatorModal';
import { generatePromptDataWithGemini } from './services/geminiService';
import { Sparkles, Plus, RefreshCw, Code, FileCheck, Undo2, Redo2, Aperture, X, Image as ImageIcon } from 'lucide-react';

interface AppState {
  schema: SchemaBlock[];
  data: PromptData;
  include: PromptInclude;
  preset: PresetKey;
  settings: AppSettings;
}

const INITIAL_STATE: AppState = {
  schema: deepCopy(INITIAL_SCHEMA),
  data: buildInitialData(INITIAL_SCHEMA),
  include: buildInitialInclude(INITIAL_SCHEMA),
  preset: 'sample',
  settings: {
    includeMap: false, // Changed to false for cleaner JSON by default
    omitEmpty: true,
    schemaMode: false,
  }
};

function App() {
  const { state, set, undo, redo, canUndo, canRedo } = useHistory<AppState>(INITIAL_STATE);
  const { schema, data, include, settings, preset: currentPreset } = state;

  const [magicModalOpen, setMagicModalOpen] = useState(false);
  const [validatorModalOpen, setValidatorModalOpen] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  
  // Track last update for debouncing history entries (replace strategy)
  const lastUpdateRef = useRef<{ path: string, time: number } | null>(null);

  // Generate the final JSON prompt based on state
  const finalJson = useMemo(() => {
    const activeData: any = {};
    const activeInclude: any = {};

    schema.forEach(block => {
      if (include[block.name]) {
        // Deep copy block data to avoid mutation during cleaning
        let blockData = deepCopy(data[block.name] || {});
        
        // Apply cleaning if omitEmpty is true
        if (settings.omitEmpty) {
            blockData = cleanObject(blockData, true);
        }
        
        // Only add if there is data left after cleaning (or if we don't omit empty)
        activeData[block.name] = blockData || {};
        activeInclude[block.name] = true;
      }
    });

    if (settings.includeMap) {
      return { _include: activeInclude, ...activeData };
    }
    return activeData;
  }, [schema, data, include, settings]);

  const hasIncludedBlocks = Object.keys(finalJson).length > (settings.includeMap ? 1 : 0);

  // --- Actions & History Wrappers ---

  const handleUndo = useCallback(() => {
    undo();
    lastUpdateRef.current = null; // Reset debounce timer on history navigation
  }, [undo]);

  const handleRedo = useCallback(() => {
    redo();
    lastUpdateRef.current = null;
  }, [redo]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Undo: Ctrl+Z or Cmd+Z
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      }
      // Redo: Ctrl+Shift+Z or Cmd+Shift+Z or Ctrl+Y or Cmd+Y
      if ((e.metaKey || e.ctrlKey) && ((e.key.toLowerCase() === 'z' && e.shiftKey) || e.key.toLowerCase() === 'y')) {
        e.preventDefault();
        handleRedo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);


  // --- Handlers ---

  const handleUpdateData = (blockName: string, path: string, value: any) => {
    const fullPath = `${blockName}.${path}`;
    const now = Date.now();
    // If the same field is updated within 1000ms, replace the last history entry instead of pushing a new one
    const isRapidUpdate = lastUpdateRef.current 
      && lastUpdateRef.current.path === fullPath 
      && (now - lastUpdateRef.current.time < 1000);

    lastUpdateRef.current = { path: fullPath, time: now };

    set(prev => {
      const nextData = deepCopy(prev.data);
      if (!nextData[blockName]) nextData[blockName] = {};
      setPath(nextData[blockName], path, value);
      
      return {
        ...prev,
        data: nextData,
        preset: 'custom' // Switch to custom on manual edit
      };
    }, { replace: isRapidUpdate });
  };

  const handleUpdateInclude = (blockName: string, val: boolean) => {
    set(prev => ({
      ...prev,
      include: { ...prev.include, [blockName]: val },
      preset: 'custom'
    }));
  };

  const handlePresetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const key = e.target.value as PresetKey;
    
    set(prev => {
      if (key === 'blank') {
         // "Blank" logic: Reset non-highlighted blocks to empty
         const blankData: any = {};
         prev.schema.forEach(block => {
           blankData[block.name] = {};
           block.fields.forEach(field => {
              let val;
              if (block.highlight) {
                  val = field.default ?? (field.type === 'checkbox' ? false : '');
              } else {
                  val = field.type === 'checkbox' ? false : '';
              }
              setPath(blankData[block.name], field.path, val);
           });
         });
         return {
           ...prev,
           preset: 'blank',
           data: blankData,
           include: buildInitialInclude(prev.schema)
         };
      } else if (key === 'sample') {
         // Sample - Reset fully to initial
         return {
           ...prev,
           preset: 'sample',
           schema: deepCopy(INITIAL_SCHEMA),
           data: buildInitialData(INITIAL_SCHEMA),
           include: buildInitialInclude(INITIAL_SCHEMA)
         };
      }
      return { ...prev, preset: key };
    });
  };

  const handleStylePreset = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const key = e.target.value as StylePresetKey;
    if (key === 'none') return;
    
    const presetData = STYLE_PRESETS[key];
    if (!presetData) return;
    
    set(prev => {
      const nextData = deepCopy(prev.data);
      const nextInclude = { ...prev.include };

      Object.keys(presetData).forEach(blockName => {
        if (!nextData[blockName]) nextData[blockName] = {};
        
        const flatten = (obj: any, prefix: string) => {
          Object.keys(obj).forEach(k => {
            const val = obj[k];
            const path = prefix ? `${prefix}.${k}` : k;
            if (val && typeof val === 'object' && !Array.isArray(val)) {
               flatten(val, path);
            } else {
               setPath(nextData[blockName], path, val);
            }
          });
        };
        flatten(presetData[blockName], '');
        nextInclude[blockName] = true;
      });

      return {
        ...prev,
        data: nextData,
        include: nextInclude,
        preset: 'custom'
      };
    });
    
    // Reset select visual only (React state tracks action via history)
    e.target.value = 'none';
  };

  const handleSettingsChange = (key: keyof AppSettings, val: boolean) => {
    set(prev => ({
      ...prev,
      settings: { ...prev.settings, [key]: val }
    }));
  };

  // --- Schema Actions ---

  const addBlock = () => {
    const nameInput = prompt("Block key (snake_case):");
    if (!nameInput) return;
    const name = nameInput.trim().toLowerCase().replace(/\s+/g, '_');
    
    if (schema.find(b => b.name === name)) {
      alert("Block name already exists!");
      return;
    }

    const title = prompt("Block title:", name) || name;
    
    const newBlock: SchemaBlock = {
      name,
      title,
      hint: "Custom block",
      defaultInclude: true,
      fields: []
    };
    
    set(prev => ({
      ...prev,
      schema: [...prev.schema, newBlock],
      include: { ...prev.include, [name]: true },
      data: { ...prev.data, [name]: {} },
      preset: 'custom'
    }));
  };

  const duplicateBlock = (block: SchemaBlock) => {
    const baseName = block.name;
    let counter = 2;
    let newName = `${baseName}_${counter}`;
    while (schema.find(b => b.name === newName)) {
      counter++;
      newName = `${baseName}_${counter}`;
    }

    set(prev => {
      const newBlock = { ...block, name: newName, title: `${block.title} copy` };
      const newBlockIdx = prev.schema.findIndex(b => b.name === block.name) + 1;
      const newSchema = [...prev.schema];
      newSchema.splice(newBlockIdx, 0, newBlock);

      return {
        ...prev,
        schema: newSchema,
        include: { ...prev.include, [newName]: prev.include[block.name] },
        data: { ...prev.data, [newName]: deepCopy(prev.data[block.name] || {}) },
        preset: 'custom'
      };
    });
  };

  const deleteBlock = (name: string) => {
    if (schema.length <= 1) {
      alert("Keep at least one block.");
      return;
    }
    if (!confirm(`Delete block '${name}'?`)) return;
    
    set(prev => {
      const nextData = deepCopy(prev.data);
      const nextInclude = { ...prev.include };
      delete nextData[name];
      delete nextInclude[name];

      return {
        ...prev,
        schema: prev.schema.filter(b => b.name !== name),
        data: nextData,
        include: nextInclude,
        preset: 'custom'
      };
    });
  };

  const addField = (blockName: string) => {
    const path = prompt("Field path (dot notation):", "new_key");
    if (!path) return;
    const label = prompt("Label:", path) || path;
    const typeInput = prompt("Type (text / textarea / checkbox / number / date):", "text") || "text";
    
    const validTypes = ["text", "textarea", "checkbox", "number", "date", "select"];
    const type: any = validTypes.includes(typeInput.toLowerCase()) ? typeInput.toLowerCase() : "text";

    set(prev => ({
      ...prev,
      schema: prev.schema.map(b => {
        if (b.name === blockName) {
          return {
            ...b,
            fields: [...b.fields, { path, label, type, default: type === 'checkbox' ? false : '' }]
          };
        }
        return b;
      }),
      preset: 'custom'
    }));
  };

  const removeField = (blockName: string, path: string) => {
    if (!confirm(`Remove field '${path}'?`)) return;
    
    set(prev => {
      const nextData = deepCopy(prev.data);
      if (nextData[blockName]) {
        prunePath(nextData[blockName], path);
      }

      return {
        ...prev,
        schema: prev.schema.map(b => {
          if (b.name === blockName) {
            return { ...b, fields: b.fields.filter(f => f.path !== path) };
          }
          return b;
        }),
        data: nextData,
        preset: 'custom'
      };
    });
  };

  const moveField = (blockName: string, fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return;
    set(prev => ({
      ...prev,
      schema: prev.schema.map(b => {
        if (b.name === blockName) {
          const newFields = [...b.fields];
          const [movedField] = newFields.splice(fromIndex, 1);
          newFields.splice(toIndex, 0, movedField);
          return { ...b, fields: newFields };
        }
        return b;
      }),
      preset: 'custom'
    }));
  };

  // --- AI Generation ---

  const handleMagicGenerate = async (description: string, imageBase64?: string, mimeType?: string) => {
    try {
      const generatedData = await generatePromptDataWithGemini(schema, description, imageBase64, mimeType);
      if (generatedData) {
        if (imageBase64) {
          setReferenceImage(`data:${mimeType || 'image/jpeg'};base64,${imageBase64}`);
        } else {
          setReferenceImage(null);
        }

        set(prev => {
          const nextData = deepCopy(prev.data);
          const nextInclude = { ...prev.include };
          Object.keys(generatedData).forEach(blockName => {
            // Only update if block exists in current schema
            if (prev.schema.some(b => b.name === blockName)) {
              nextData[blockName] = generatedData[blockName];
              nextInclude[blockName] = true;
            }
          });
          return {
            ...prev,
            data: nextData,
            include: nextInclude,
            preset: 'custom'
          };
        });
      }
    } catch (e) {
      alert("Failed to generate with AI. Check console or API Key.");
    }
  };


  return (
    <div className="min-h-screen pb-12">
      <MagicModal 
        isOpen={magicModalOpen} 
        onClose={() => setMagicModalOpen(false)} 
        onGenerate={handleMagicGenerate}
      />
      <ValidatorModal
        isOpen={validatorModalOpen}
        onClose={() => setValidatorModalOpen(false)}
      />

      <div className="max-w-[1400px] mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6">
        
        {/* Header / Hero */}
        <header className="bg-gradient-to-br from-panel/90 to-panel2/95 border border-border rounded-3xl p-6 sm:p-8 shadow-glow backdrop-blur-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
          
          <div className="relative z-10">
            <p className="text-xs font-bold tracking-widest text-muted uppercase mb-2">Google Gemini • (C) Nyukers, 2026</p>
            
            <div className="flex items-center gap-4 mb-3">
              <div className="relative group">
                 <div className="absolute inset-0 bg-accent/20 blur-md rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                 <div className="relative p-2.5 bg-panel2/50 border border-accent/30 rounded-xl shadow-[0_0_15px_rgba(80,227,194,0.15)]">
                   <Aperture size={32} className="text-accent" />
                 </div>
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-text">Image JSON Prompt Builder</h1>
            </div>

            <p className="text-muted max-w-2xl leading-relaxed mb-6">
              Customize structured JSON prompts for AI image generation. 
              Or use <span className="text-accent font-medium">Google Gemini</span> to magical auto-fill details from a your simple description.
            </p>

            <div className="flex flex-col xl:flex-row gap-4 xl:items-center justify-between">
              
              {/* Controls Left */}
              <div className="flex flex-wrap items-center gap-3">
                 <div className="flex items-center gap-2 bg-panel2 border border-border rounded-lg px-3 py-2">
                   <span className="text-xs text-muted">Preset</span>
                   <select 
                      value={currentPreset}
                      className="bg-transparent text-sm font-semibold text-text focus:outline-none cursor-pointer min-w-[120px]"
                      onChange={handlePresetChange}
                   >
                     <option className="bg-panel2" value="sample">Sample (Beach)</option>
                     <option className="bg-panel2" value="blank">Blank Form</option>
                     <option className="bg-panel2" value="custom" disabled={currentPreset !== 'custom'}>Custom</option>
                   </select>
                 </div>

                 <div className="flex items-center gap-2 bg-panel2 border border-border rounded-lg px-3 py-2">
                   <span className="text-xs text-muted">Style</span>
                   <select 
                      className="bg-transparent text-sm font-semibold text-text focus:outline-none cursor-pointer min-w-[140px]"
                      onChange={handleStylePreset}
                   >
                     <option className="bg-panel2" value="none">Apply Style...</option>
                     <option className="bg-panel2" value="editorial">Editorial Beauty</option>
                     <option className="bg-panel2" value="packshot">Product Packshot</option>
                     <option className="bg-panel2" value="character">Character Concept</option>
                     <option className="bg-panel2" value="scifi">Sci-Fi Neon</option>
                     <option className="bg-panel2" value="xmas">Cozy Holiday (Xmas)</option>
                     <option className="bg-panel2" value="noir">Film Noir</option>
                     <option className="bg-panel2" value="vintage">Vintage Analog</option>
                   </select>
                 </div>

                 <div className="h-6 w-px bg-border mx-1 hidden sm:block"></div>

                 <label className="flex items-center gap-2 text-sm text-muted cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={settings.includeMap}
                      onChange={(e) => handleSettingsChange('includeMap', e.target.checked)}
                      className="w-4 h-4 rounded accent-accent bg-code border-border" 
                    />
                    Metadata (_include)
                 </label>

                 <label className="flex items-center gap-2 text-sm text-muted cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={settings.omitEmpty}
                      onChange={(e) => handleSettingsChange('omitEmpty', e.target.checked)}
                      className="w-4 h-4 rounded accent-accent bg-code border-border" 
                    />
                    Skip empty
                 </label>
              </div>

              {/* Controls Right */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1 bg-panel2 border border-border rounded-full p-1 mr-2">
                  <button 
                    onClick={handleUndo} 
                    disabled={!canUndo}
                    title="Undo (Ctrl+Z)"
                    className="p-2 rounded-full text-muted hover:text-text hover:bg-panel transition-all disabled:opacity-30 disabled:hover:bg-transparent"
                  >
                    <Undo2 size={16} />
                  </button>
                  <button 
                    onClick={handleRedo} 
                    disabled={!canRedo}
                    title="Redo (Ctrl+Y)"
                    className="p-2 rounded-full text-muted hover:text-text hover:bg-panel transition-all disabled:opacity-30 disabled:hover:bg-transparent"
                  >
                    <Redo2 size={16} />
                  </button>
                </div>

                <button 
                  onClick={() => setValidatorModalOpen(true)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-panel2 border border-border text-muted font-bold hover:text-text hover:border-accent transition-all active:scale-95"
                >
                  <FileCheck size={16} />
                  Validate JSON
                </button>
                
                 <label className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-medium cursor-pointer transition-all ${settings.schemaMode ? 'bg-accent/10 border-accent text-accent' : 'bg-transparent border-border text-muted hover:border-muted'}`}>
                    <input 
                      type="checkbox" 
                      checked={settings.schemaMode}
                      onChange={(e) => handleSettingsChange('schemaMode', e.target.checked)}
                      className="hidden" 
                    />
                    <Code size={16} />
                    Schema Mode
                 </label>

                <button 
                  onClick={() => setMagicModalOpen(true)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-accent text-panel2 font-bold shadow-accent hover:brightness-110 transition-all active:scale-95"
                >
                  <Sparkles size={16} />
                  Auto-Fill with AI
                </button>
              </div>
            </div>
            
            {settings.schemaMode && (
               <div className="mt-4 pt-4 border-t border-border flex gap-3">
                  <button onClick={addBlock} className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-accent hover:text-white transition-colors">
                    <Plus size={14} /> Add New Block
                  </button>
                  <button 
                    onClick={() => {
                        if(confirm("Reset entire schema to default?")) {
                            set({
                                ...INITIAL_STATE,
                                schema: deepCopy(INITIAL_SCHEMA),
                                data: buildInitialData(INITIAL_SCHEMA),
                                include: buildInitialInclude(INITIAL_SCHEMA),
                            });
                        }
                    }} 
                    className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted hover:text-danger transition-colors ml-auto"
                  >
                    <RefreshCw size={14} /> Reset Schema
                  </button>
               </div>
            )}
          </div>
        </header>

        {/* Main Builder Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Cards Column */}
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-6">
             <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
               {schema.map(block => (
                 <BlockCard
                   key={block.name}
                   block={block}
                   data={data[block.name]}
                   include={!!include[block.name]}
                   schemaMode={settings.schemaMode}
                   onUpdateInclude={(val) => handleUpdateInclude(block.name, val)}
                   onUpdateData={(path, val) => handleUpdateData(block.name, path, val)}
                   onDuplicateBlock={() => duplicateBlock(block)}
                   onDeleteBlock={() => deleteBlock(block.name)}
                   onAddField={() => addField(block.name)}
                   onRemoveField={(path) => removeField(block.name, path)}
                   onMoveField={(from, to) => moveField(block.name, from, to)}
                 />
               ))}
             </div>
             {schema.length === 0 && (
               <div className="p-12 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center text-muted">
                 <p>No blocks defined.</p>
                 <button onClick={addBlock} className="mt-2 text-accent hover:underline">Add a block</button>
               </div>
             )}
          </div>

          {/* Preview Column */}
          <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4">
             {referenceImage && (
                <div className="bg-panel2 border border-border rounded-xl p-4 shadow-glow relative group">
                    <div className="flex justify-between items-center mb-3">
                         <span className="text-xs font-bold text-accent tracking-wider uppercase flex items-center gap-2">
                            <ImageIcon size={14} /> Reference Context
                         </span>
                         <button 
                            onClick={() => setReferenceImage(null)}
                            className="text-muted hover:text-danger transition-colors"
                         >
                            <X size={16} />
                         </button>
                    </div>
                    <img 
                        src={referenceImage} 
                        alt="Reference" 
                        className="w-full h-auto rounded-lg border border-border/50" 
                    />
                </div>
             )}
             <Preview json={finalJson} isValid={hasIncludedBlocks} />
          </div>

        </div>
      </div>
    </div>
  );
}

export default App;