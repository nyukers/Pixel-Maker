import React, { useRef } from 'react';
import { SchemaBlock, SchemaField } from '../types';
import { Trash2, Copy, Plus, X, ChevronDown, GripVertical } from 'lucide-react';
import { getPath, setPath, deepCopy } from '../utils';

interface BlockCardProps {
  block: SchemaBlock;
  data: any;
  include: boolean;
  schemaMode: boolean;
  onUpdateInclude: (val: boolean) => void;
  onUpdateData: (path: string, val: any) => void;
  onDuplicateBlock: () => void;
  onDeleteBlock: () => void;
  onAddField: () => void;
  onRemoveField: (path: string) => void;
  onMoveField?: (fromIndex: number, toIndex: number) => void;
}

const BlockCard: React.FC<BlockCardProps> = ({
  block,
  data,
  include,
  schemaMode,
  onUpdateInclude,
  onUpdateData,
  onDuplicateBlock,
  onDeleteBlock,
  onAddField,
  onRemoveField,
  onMoveField
}) => {
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, position: number) => {
    dragItem.current = position;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', position.toString());
    // Add a ghost effect if needed, but browser default is usually okay
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, position: number) => {
    dragOverItem.current = position;
  };

  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
    const fromIndex = dragItem.current;
    const toIndex = dragOverItem.current;

    if (fromIndex !== null && toIndex !== null && fromIndex !== toIndex && onMoveField) {
      onMoveField(fromIndex, toIndex);
    }
    
    dragItem.current = null;
    dragOverItem.current = null;
  };

  return (
    <div className={`
      relative flex flex-col gap-4 p-5 rounded-2xl border transition-all duration-300
      ${include ? 'bg-panel border-border shadow-lg' : 'bg-panel2/50 border-border/50 opacity-60 hover:opacity-100'}
    `}>
      <div className="flex justify-between items-start gap-4">
        <div>
          <h3 className={`text-xl font-semibold tracking-tight mb-1 ${block.highlight ? 'text-accent2' : 'text-text'}`}>
            {block.title}
          </h3>
          <p className="text-xs text-muted leading-relaxed">{block.hint}</p>
        </div>
        
        <div className="flex flex-col items-end gap-2">
          <label className="flex items-center gap-2 text-sm text-muted cursor-pointer select-none">
            <input 
              type="checkbox" 
              checked={include}
              onChange={(e) => onUpdateInclude(e.target.checked)}
              className="w-4 h-4 rounded accent-accent bg-code border-border" 
            />
            Include
          </label>
          
          {schemaMode && (
            <div className="flex gap-2">
              <button onClick={onDuplicateBlock} className="p-1.5 text-xs font-medium text-text border border-dashed border-border rounded hover:bg-accent/10 hover:border-accent transition-colors" title="Duplicate Block">
                <Copy size={14} />
              </button>
              <button onClick={onDeleteBlock} className="p-1.5 text-xs font-medium text-danger border border-dashed border-danger/30 rounded hover:bg-danger/10 hover:border-danger transition-colors" title="Delete Block">
                <Trash2 size={14} />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className={`grid gap-3 ${!include ? 'opacity-50 pointer-events-none grayscale' : ''}`}>
        {block.fields.map((field, index) => {
          const value = getPath(data, field.path) ?? (field.default ?? '');
          const isCheckbox = field.type === 'checkbox';

          return (
            <div 
              key={field.path} 
              className={`relative group ${schemaMode ? 'cursor-move' : ''}`}
              draggable={schemaMode}
              onDragStart={(e) => schemaMode && handleDragStart(e, index)}
              onDragEnter={(e) => schemaMode && handleDragEnter(e, index)}
              onDragEnd={handleDragEnd}
              onDragOver={(e) => e.preventDefault()}
            >
               {isCheckbox ? (
                 <div className="flex items-center justify-between bg-panel2 border border-border rounded-lg p-3">
                    <div className="flex items-center gap-3 flex-1">
                      {schemaMode && <GripVertical size={14} className="text-muted/50 flex-shrink-0" />}
                      <label className="flex items-center gap-3 text-sm text-muted cursor-pointer flex-1">
                        <input 
                          type="checkbox" 
                          checked={!!value} 
                          onChange={(e) => onUpdateData(field.path, e.target.checked)}
                          className="w-5 h-5 rounded accent-accent bg-code border-border"
                        />
                        <span className="text-text">{field.label}</span>
                      </label>
                    </div>
                    {schemaMode && (
                      <button onClick={() => onRemoveField(field.path)} className="text-muted hover:text-danger p-1">
                        <X size={14} />
                      </button>
                    )}
                 </div>
               ) : (
                 <div className="flex flex-col gap-1.5 bg-panel2 border border-border rounded-lg p-3 transition-colors focus-within:border-accent/50">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        {schemaMode && <GripVertical size={14} className="text-muted/50" />}
                        <label className="text-xs font-medium text-muted flex items-center gap-2">
                          {field.label}
                          {field.help && <span className="opacity-60 font-normal hidden sm:inline">- {field.help}</span>}
                        </label>
                      </div>
                      {schemaMode && (
                        <button onClick={() => onRemoveField(field.path)} className="text-muted hover:text-danger p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                           <X size={14} />
                        </button>
                      )}
                    </div>
                    
                    {field.type === 'textarea' ? (
                      <textarea
                        value={value}
                        onChange={(e) => onUpdateData(field.path, e.target.value)}
                        placeholder={field.placeholder}
                        className="w-full bg-code text-text text-sm rounded-md p-2.5 border border-border focus:outline-none focus:border-accent min-h-[80px] resize-y placeholder:text-muted/30"
                      />
                    ) : field.type === 'select' && field.options ? (
                      <div className="relative">
                        <select
                          value={value}
                          onChange={(e) => onUpdateData(field.path, e.target.value)}
                          className="w-full appearance-none bg-code text-text text-sm rounded-md p-2.5 pr-8 border border-border focus:outline-none focus:border-accent cursor-pointer"
                        >
                          <option value="" disabled>Select an option</option>
                          {field.options.map(opt => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                        <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted pointer-events-none" />
                      </div>
                    ) : (
                      <input
                        type={field.type === 'number' ? 'number' : field.type === 'date' ? 'date' : 'text'}
                        value={value}
                        onChange={(e) => onUpdateData(field.path, e.target.value)}
                        placeholder={field.placeholder}
                        className={`w-full bg-code text-text text-sm rounded-md p-2.5 border border-border focus:outline-none focus:border-accent placeholder:text-muted/30 ${field.type === 'date' ? 'min-h-[42px]' : ''}`}
                      />
                    )}
                 </div>
               )}
            </div>
          );
        })}
      </div>

      {schemaMode && (
         <div className="flex justify-between items-center mt-2 pt-2 border-t border-border/50">
           <span className="text-xs text-muted italic">Add field to {block.name}</span>
           <button 
             onClick={onAddField}
             className="flex items-center gap-1.5 px-2 py-1 text-xs font-medium text-muted border border-dashed border-border rounded hover:text-accent hover:border-accent transition-all"
           >
             <Plus size={12} /> Add Field
           </button>
         </div>
      )}
    </div>
  );
};

export default BlockCard;