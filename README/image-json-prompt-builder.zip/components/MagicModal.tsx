import React, { useState, useRef } from 'react';
import { Sparkles, X, Loader2, Image as ImageIcon, Trash2 } from 'lucide-react';
import { fileToBase64 } from '../utils';

interface MagicModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (desc: string, imageBase64?: string, mimeType?: string) => Promise<void>;
}

const MagicModal: React.FC<MagicModalProps> = ({ isOpen, onClose, onGenerate }) => {
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleClearImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() && !selectedImage) return;
    
    setLoading(true);
    try {
      let base64 = undefined;
      let mimeType = undefined;

      if (selectedImage) {
        base64 = await fileToBase64(selectedImage);
        mimeType = selectedImage.type;
      }

      await onGenerate(description, base64, mimeType);
      
      onClose();
      setDescription('');
      handleClearImage();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-panel border border-border rounded-2xl w-full max-w-lg shadow-2xl scale-100 animate-in zoom-in-95 duration-200">
        <div className="flex justify-between items-center p-5 border-b border-border">
          <div className="flex items-center gap-2 text-accent">
            <Sparkles size={20} />
            <h3 className="font-semibold text-text">Auto-Fill with Gemini AI</h3>
          </div>
          <button onClick={onClose} className="text-muted hover:text-text transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-5 flex flex-col gap-4">
          <p className="text-sm text-muted">
            Describe the scene OR upload a reference image. Gemini will analyze the image to reverse-engineer the prompt settings.
          </p>
          
          {/* Image Upload Area */}
          <div className="flex gap-4">
             <input 
               type="file" 
               ref={fileInputRef}
               onChange={handleImageSelect}
               accept="image/*"
               className="hidden"
             />
             
             {!imagePreview ? (
               <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-4 py-3 rounded-lg border border-dashed border-border text-muted hover:text-accent hover:border-accent hover:bg-accent/5 transition-all w-full justify-center"
               >
                 <ImageIcon size={18} />
                 <span>Upload Reference Image (Optional)</span>
               </button>
             ) : (
               <div className="relative w-full h-32 bg-panel2 rounded-lg border border-border overflow-hidden group">
                 <img src={imagePreview} alt="Reference" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                 <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      type="button"
                      onClick={handleClearImage}
                      className="p-2 bg-danger/20 text-danger rounded-full hover:bg-danger hover:text-white transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                 </div>
               </div>
             )}
          </div>

          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={imagePreview ? "Add extra instructions (e.g. 'Make it night time instead')..." : "e.g., A cyberpunk street food vendor in Tokyo..."}
            className="w-full bg-code text-text rounded-lg p-3 border border-border focus:outline-none focus:border-accent h-24 resize-none placeholder:text-muted/30"
            autoFocus={!imagePreview}
          />

          <div className="flex justify-end gap-3 pt-2">
            <button 
              type="button" 
              onClick={onClose} 
              className="px-4 py-2 text-sm font-medium text-muted hover:text-text"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              disabled={loading || (!description.trim() && !selectedImage)}
              className="flex items-center gap-2 px-6 py-2 rounded-full bg-accent text-panel2 font-bold hover:brightness-110 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
              {loading ? 'Analyzing...' : (imagePreview ? 'Analyze & Fill' : 'Magic Fill')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MagicModal;