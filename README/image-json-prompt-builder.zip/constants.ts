import { SchemaBlock, PromptData, PromptInclude, StylePresetKey } from './types';

export const INITIAL_SCHEMA: SchemaBlock[] = [
  {
    name: "scene",
    title: "Scene",
    hint: "Environment, ground, backdrop, atmosphere, and narrative hook.",
    defaultInclude: true,
    fields: [
      { path: "environment.location", label: "Location", default: "tropical beach", help: "Where are we? City/studio/nature/room." },
      { path: "environment.ground", label: "Ground", default: "fine white sand with visible grain and compressibility under weight", help: "Surface material + texture + behavior." },
      { path: "environment.background", label: "Background", default: "calm blue ocean with realistic wave texture, straight horizon", help: "Backdrop clarity, horizon, depth cues." },
      { path: "environment.atmosphere", label: "Atmosphere", default: "clean, premium, high-end beauty photoshoot", help: "Mood and quality cues." },
      { path: "story", label: "Story / narrative hook", type: "textarea", placeholder: "e.g., sunlit editorial for oversized sunglasses", default: "" }
    ]
  },
  {
    name: "lighting",
    title: "Lighting",
    hint: "Light type, time, highlights, shadows, white balance.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { 
        path: "type", 
        label: "Type", 
        type: "select",
        default: "natural daylight", 
        help: "Natural/flash/softbox/rim/backlight.",
        options: [
          "natural daylight", 
          "studio flash", 
          "softbox diffuse", 
          "hard sunlight", 
          "cinematic rim lighting", 
          "neon lights", 
          "bioluminescent glow",
          "volumetric lighting",
          "butterfly lighting",
          "rembrandt lighting"
        ]
      },
      { 
        path: "time_of_day", 
        label: "Time of day", 
        type: "select",
        default: "noon",
        options: [
          "dawn",
          "golden hour",
          "morning",
          "noon",
          "afternoon",
          "blue hour",
          "twilight",
          "night",
          "midnight"
        ]
      },
      { 
        path: "quality", 
        label: "Quality", 
        type: "select",
        default: "neutral, even, crisp", 
        help: "Hard/soft/contrast direction.",
        options: [
          "neutral, even, crisp",
          "soft, wrapping, diffused",
          "hard, high contrast, dramatic",
          "ethereal, dreamy, glowing",
          "hazy, atmospheric",
          "sterile, clinical"
        ]
      },
      { 
        path: "white_balance", 
        label: "White balance", 
        type: "select",
        default: "accurate",
        options: [
          "accurate",
          "warm / tungsten",
          "cool / fluorescent",
          "neutral",
          "sepia tone",
          "black and white"
        ]
      },
      { 
        path: "highlights", 
        label: "Highlights", 
        type: "select",
        default: "controlled, no blooming",
        options: [
          "controlled, no blooming",
          "bright, specular, glossy",
          "soft rolloff",
          "blown out / overexposed style",
          "rim light emphasis"
        ]
      },
      { 
        path: "shadows", 
        label: "Shadows", 
        type: "select",
        default: "soft, following body contours, realistic",
        options: [
          "soft, following body contours, realistic",
          "deep, pitch black, high contrast",
          "lifted, matte look",
          "long, dramatic cast shadows",
          "minimal, nearly shadowless"
        ]
      }
    ]
  },
  {
    name: "subject",
    title: "Subject",
    hint: "Model type, pose, expression, gaze, skin, hair, clothing.",
    defaultInclude: true,
    fields: [
      { path: "type", label: "Type", default: "adult female model" },
      { path: "pose.description", label: "Pose description", type: "textarea", default: "sits across the product with slight lumbar arch, hips slightly lifted, toes pointed, model pose" },
      { path: "pose.body_language", label: "Body language", default: "relaxed but confident, sensual tension without exaggeration" },
      { path: "expression", label: "Expression", default: "calm, alluring confidence, slightly parted lips" },
      { path: "gaze", label: "Gaze", default: "soft focus forward, not looking at camera" },
      { path: "skin.tone", label: "Skin tone", default: "realistic warm tan" },
      { path: "skin.texture", label: "Skin texture", default: "visible pores, faint skin sheen, natural folds and relief" },
      { path: "hair.style", label: "Hair style", default: "tight sleek bun" },
      { path: "hair.flyaways", label: "Flyaways", default: "minimal natural strands" },
      { path: "hair.color", label: "Hair color", default: "dark brown" },
      { path: "clothing.top.type", label: "Top type", default: "ultra-sheer skin-tight long-sleeve top" },
      { path: "clothing.top.color", label: "Top color", default: "amber / warm honey, matching the product" },
      { path: "clothing.top.fabric_detail", label: "Top fabric detail", default: "high transparency, noticeable stretch on chest and arms" },
      { path: "clothing.bottom.type", label: "Bottom type", default: "minimal high-cut bikini bottoms" },
      { path: "clothing.bottom.color", label: "Bottom color", default: "matching amber / warm honey" },
      { path: "clothing.bottom.fit", label: "Bottom fit", default: "body-hugging, slightly cheeky, clean seams" }
    ]
  },
  {
    name: "primary_object",
    title: "Primary object",
    hint: "Product name, scale, materials, surface qualities.",
    defaultInclude: true,
    fields: [
      { path: "type", label: "Type", default: "large yellow sunglasses with dark lenses" },
      { path: "brand", label: "Brand", default: "RayBan" },
      { path: "product_name", label: "Product name", default: "RayBan" },
      { path: "shape", label: "Shape", default: "classic RayBan silhouette" },
      { path: "scale", label: "Scale", default: "human-sized, oversized" },
      { path: "material.frame", label: "Frame material", default: "bright yellow plastic", help: "Material stack: frame/surface/case." },
      { path: "material.surface", label: "Surface", default: "glossy, physically accurate reflections and refractions" },
      { path: "material.case", label: "Case", default: "matte yellow plastic with subtle microtexture" },
      { path: "print_quality", label: "Print quality", default: "sharp, high contrast, no blur" }
    ]
  },
  {
    name: "composition",
    title: "Composition",
    hint: "Camera angle, framing, perspective, focus.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { 
        path: "camera_angle", 
        label: "Camera angle", 
        type: "select",
        default: "eye level", 
        options: [
          "eye level",
          "low angle / hero view",
          "high angle / looking down",
          "top-down / flat lay",
          "worm's eye view",
          "side profile",
          "3/4 angle",
          "over-the-shoulder",
          "dutch angle (tilted)"
        ]
      },
      { 
        path: "framing", 
        label: "Framing", 
        type: "select",
        default: "medium shot (waist up)", 
        options: [
          "extreme close-up",
          "close-up",
          "medium shot (waist up)",
          "three-quarter shot",
          "full body shot",
          "wide shot",
          "extreme wide shot",
          "rule of thirds",
          "centered composition"
        ]
      },
      { 
        path: "perspective", 
        label: "Perspective", 
        type: "select",
        default: "natural / human eye", 
        options: [
          "natural / human eye",
          "wide angle distortion",
          "telephoto compression",
          "fisheye",
          "orthographic / isometric",
          "one-point perspective",
          "atmospheric perspective"
        ]
      },
      { 
        path: "focus", 
        label: "Focus", 
        type: "select",
        default: "shallow depth of field (bokeh)", 
        options: [
          "shallow depth of field (bokeh)",
          "deep focus (everything sharp)",
          "selective focus",
          "soft focus",
          "motion blur",
          "rack focus simulation"
        ]
      }
    ]
  },
  {
    name: "camera",
    title: "Camera",
    hint: "Rig, sensor, lens, aperture, sharpness, depth.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { 
        path: "type", 
        label: "Type", 
        type: "select",
        default: "professional commercial photoshoot",
        options: [
          "professional commercial photoshoot",
          "cinematic movie scene",
          "documentary style",
          "drone aerial",
          "macro photography",
          "vintage film look",
          "security camera footage",
          "smartphone snapshot"
        ]
      },
      { 
        path: "sensor", 
        label: "Sensor", 
        type: "select",
        default: "full-frame",
        options: [
          "full-frame",
          "APS-C",
          "micro 4/3",
          "medium format",
          "IMAX 70mm",
          "Super 35",
          "1-inch sensor",
          "vintage 35mm film"
        ]
      },
      { 
        path: "lens", 
        label: "Lens", 
        type: "select",
        default: "85mm",
        options: [
          "14mm wide angle",
          "24mm wide angle",
          "35mm street",
          "50mm standard",
          "85mm portrait",
          "100mm macro",
          "200mm telephoto",
          "anamorphic",
          "fisheye"
        ]
      },
      { 
        path: "aperture", 
        label: "Aperture", 
        type: "select",
        default: "f/5.6",
        options: [
          "f/1.2",
          "f/1.8",
          "f/2.8",
          "f/4",
          "f/5.6",
          "f/8",
          "f/11",
          "f/16",
          "f/22"
        ]
      },
      { 
        path: "sharpness", 
        label: "Sharpness", 
        type: "select",
        default: "edge-to-edge clarity",
        options: [
          "edge-to-edge clarity",
          "center sharp, soft corners",
          "dreamy soft focus",
          "motion blur",
          "oversharpened digital look",
          "vintage lens softness"
        ]
      },
      { 
        path: "depth_of_field", 
        label: "Depth of field", 
        type: "select",
        default: "natural subject separation",
        options: [
          "shallow (bokeh)",
          "natural subject separation",
          "deep (everything in focus)",
          "tilt-shift miniature effect"
        ]
      }
    ]
  },
  {
    name: "rendering",
    title: "Rendering",
    hint: "Style, resolution, DR, texture, realism, noise.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { 
        path: "style", 
        label: "Style", 
        type: "select",
        default: "hyper-photorealistic",
        options: [
          "hyper-photorealistic",
          "cinematic film still",
          "3D render (Octane/Unreal)",
          "digital painting",
          "analog film",
          "anime / cel-shaded",
          "studio photography",
          "concept art"
        ]
      },
      { 
        path: "resolution", 
        label: "Resolution", 
        type: "select",
        default: "8K",
        options: [
          "Full HD",
          "4K",
          "8K",
          "16K",
          "32K",
          "super-resolution"
        ]
      },
      { 
        path: "dynamic_range", 
        label: "Dynamic range", 
        type: "select",
        default: "high",
        options: [
          "standard",
          "high",
          "HDR",
          "very high",
          "clamped / low contrast"
        ]
      },
      { 
        path: "texture_fidelity", 
        label: "Texture fidelity", 
        type: "select",
        default: "maximum",
        options: [
          "standard",
          "high",
          "maximum",
          "insane detail",
          "soft / smooth"
        ]
      },
      { 
        path: "skin_realism", 
        label: "Skin realism", 
        type: "select",
        default: "no retouch, high detail",
        options: [
          "no retouch, high detail",
          "highly detailed pores",
          "natural imperfect",
          "airbrushed / smooth",
          "hyper-realistic",
          "stylized"
        ]
      },
      { 
        path: "fabric_realism", 
        label: "Fabric realism", 
        type: "select",
        default: "micro-weave visible",
        options: [
          "standard",
          "high detail",
          "micro-weave visible",
          "worn / textured",
          "smooth / simplified"
        ]
      },
      { 
        path: "material_realism", 
        label: "Material realism", 
        type: "select",
        default: "physically accurate lighting and reflections",
        options: [
          "standard",
          "physically accurate lighting and reflections",
          "ray-traced",
          "subsurface scattering",
          "stylized shader"
        ]
      },
      { 
        path: "noise", 
        label: "Noise", 
        type: "select",
        default: "subtle natural sensor grain",
        options: [
          "clean / noise-free",
          "subtle natural sensor grain",
          "film grain",
          "ISO noise",
          "chromatic aberration"
        ]
      }
    ]
  },
  {
    name: "constraints",
    title: "Constraints (Negative Prompt)",
    hint: "Avoid artifacts, bad anatomy, and unwanted styles.",
    defaultInclude: true,
    fields: [
      { path: "no_bad_anatomy", label: "No bad anatomy / extra limbs", type: "checkbox", default: true },
      { path: "no_bad_hands", label: "No bad hands / missing fingers", type: "checkbox", default: true },
      { path: "no_text_overlays", label: "No text / watermarks / signatures", type: "checkbox", default: true },
      { path: "no_low_quality", label: "No low quality / jpeg artifacts", type: "checkbox", default: true },
      { path: "no_blur", label: "No blurry / out of focus", type: "checkbox", default: true },
      { path: "no_distorted_perspective", label: "No distorted perspective / impossible geometry", type: "checkbox", default: true },
      { path: "no_asymmetrical_eyes", label: "No asymmetrical eyes / cross-eyed", type: "checkbox", default: true },
      { path: "no_cropping", label: "No cropped / cut off head", type: "checkbox", default: true },
      { path: "no_nudity", label: "No nudity", type: "checkbox", default: true },
      { path: "no_explicit_sexual_content", label: "No explicit sexual content", type: "checkbox", default: true },
      { path: "no_cartoon_style", label: "No cartoon / illustration / 3D render", type: "checkbox", default: false },
      { path: "no_oversaturated", label: "No oversaturated colors", type: "checkbox", default: false },
      { path: "no_cinematic_grading", label: "No cinematic grading", type: "checkbox", default: false },
      { path: "no_soft_glow", label: "No soft glow", type: "checkbox", default: false }
    ]
  }
];

export const STYLE_PRESETS: Record<StylePresetKey, any> = {
  none: {},
  editorial: {
    lighting: {
      type: "natural daylight",
      time_of_day: "golden hour",
      quality: "soft, wrapping, diffused"
    },
    composition: {
      framing: "three-quarter shot",
      perspective: "natural / human eye",
      focus: "shallow depth of field (bokeh)"
    },
    rendering: {
      style: "studio photography",
      resolution: "8K",
      dynamic_range: "high",
      noise: "subtle natural sensor grain"
    }
  },
  packshot: {
    scene: {
      environment: {
        background: "seamless paper backdrop, neutral gray",
        atmosphere: "sterile studio, product-forward"
      }
    },
    lighting: {
      type: "studio flash",
      quality: "neutral, even, crisp",
      highlights: "controlled, no blooming",
      shadows: "minimal, nearly shadowless"
    },
    composition: {
      camera_angle: "eye level",
      framing: "close-up"
    },
    rendering: {
      style: "studio photography",
      dynamic_range: "high",
      noise: "clean / noise-free"
    }
  },
  character: {
    scene: {
      atmosphere: "concept art sheet, neutral backdrop",
      story: "pose variants for character reference"
    },
    lighting: {
      type: "softbox diffuse",
      quality: "neutral, even, crisp",
      white_balance: "neutral"
    },
    composition: {
      framing: "full body shot",
      perspective: "orthographic / isometric"
    },
    rendering: {
      style: "concept art",
      resolution: "4K",
      texture_fidelity: "standard",
      noise: "clean / noise-free"
    }
  },
  scifi: {
    scene: {
      environment: {
        location: "futuristic neon alley",
        atmosphere: "moody, high-tech, vapor"
      }
    },
    lighting: {
      type: "neon lights",
      quality: "hard, high contrast, dramatic",
      white_balance: "cool / fluorescent",
      highlights: "bright, specular, glossy",
      shadows: "deep, pitch black, high contrast"
    },
    rendering: {
      style: "cinematic film still",
      dynamic_range: "very high",
      noise: "film grain"
    }
  },
  xmas: {
    scene: {
      environment: {
        atmosphere: "cozy, magical, festive holiday atmosphere, winter vibes"
      }
    },
    lighting: {
      type: "volumetric lighting",
      time_of_day: "twilight",
      white_balance: "warm / tungsten",
      quality: "ethereal, dreamy, glowing"
    },
    rendering: {
      style: "cinematic film still",
      skin_realism: "natural imperfect"
    }
  },
  noir: {
    scene: {
      environment: {
        atmosphere: "mysterious, tense, cinematic detective atmosphere"
      }
    },
    lighting: {
      type: "rembrandt lighting",
      white_balance: "black and white",
      shadows: "deep, pitch black, high contrast",
      quality: "hard, high contrast, dramatic"
    },
    composition: {
      camera_angle: "dutch angle (tilted)"
    },
    rendering: {
      style: "cinematic film still",
      noise: "film grain"
    }
  },
  vintage: {
    camera: {
      type: "vintage film look",
      sensor: "vintage 35mm film",
      lens: "35mm street",
      sharpness: "vintage lens softness"
    },
    lighting: {
      type: "studio flash",
      highlights: "blown out / overexposed style"
    },
    rendering: {
      style: "analog film",
      noise: "film grain"
    }
  }
};