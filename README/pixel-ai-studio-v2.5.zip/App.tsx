import React, { useState, useCallback, useEffect } from 'react';
import { ResultItem, ComparisonMode, PromptMode, AnalysisItem, AppMode, LoadedPreset, AspectRatio, Action, AnalysisResult, EditState, CreativeIdea } from './types';
import { restorePhoto, animatePhoto, fillPhoto, analyzeImage, generateImage, aiUpscaleImage, applyAiFilter, getDetailedAnalysis, getCreativeIdeas } from './services/geminiService';
import LeftPanel from './components/LeftPanel';
import CenterPanel from './components/CenterPanel';
import RightPanel from './components/RightPanel';
import { PRESET_PROMPTS, IMAGINATION_PRESET_PROMPTS, ANIMATION_PRESET_PROMPTS, GENERATE_PRESET_PROMPTS, AI_FILTER_PRESETS } from './constants';
import SettingsModal from './components/SettingsModal';
import UpscalingModal from './components/UpscalingModal';
import DownloadModal from './components/DownloadModal';
import WelcomeModal from './components/WelcomeModal';
import t from './locales/en';
import ActionEditorModal from './components/ActionEditorModal';
import { RotateDeviceIcon } from './components/icons/RotateDeviceIcon';
import InspirationModal from './components/InspirationModal';

declare const piexif: any;

interface ImageState {
  dataUrl: string;
  mimeType: string;
}

const COOLDOWN_SECONDS = 60;

const getImageDimensions = (dataUrl: string): Promise<{ width: number; height: number }> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.width, height: img.height });
      };
      img.onerror = (err) => {
          console.error("Failed to load image for dimension check", err);
          reject(new Error("Failed to get image dimensions."));
      }
      img.src = dataUrl;
    });
};

const parsePromptFile = (fileText: string): LoadedPreset[] => {
    const rows: LoadedPreset[] = [];
    const lines = fileText.trim().replace(/\r/g, '').split('\n');
    if (lines.length < 2) {
      if (!lines[0] || lines[0].trim() === '') return [];
    }

    if (lines[0].charCodeAt(0) === 0xFEFF) {
        lines[0] = lines[0].substring(1);
    }
    
    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const idIndex = headers.indexOf('id');
    const promptIndex = headers.indexOf('prompt');
    const displayNameIndex = headers.indexOf('displayName');
    const categoryIndex = headers.indexOf('category');

    if (idIndex === -1 || promptIndex === -1 || displayNameIndex === -1 || categoryIndex === -1) {
        console.error("File headers are missing required columns. Found:", headers.join(', '));
        throw new Error("Headers must include 'category', 'id', 'displayName', and 'prompt'.");
    }

    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g) || [];
        if (values.length === 0) continue;

        const cleanValues = values.map(v => v.trim().replace(/^"|"$/g, ''));

        const rowObject: { [key: string]: string } = {};
        headers.forEach((header, index) => {
            rowObject[header] = cleanValues[index] || '';
        });

        const category = rowObject['category'] as PromptMode;
        const id = rowObject['id'];
        const prompt = rowObject['prompt'];
        const displayName = rowObject['displayName'];
        
        if(category && id && prompt && displayName) {
            rows.push({
                category,
                id,
                prompt,
                displayName,
            });
        }
    }
    return rows;
};

const getCssFilterString = (filter: EditState['filter']): string => {
  if (!filter || filter.type === 'none') return 'none';
  const intensity = filter.intensity / 100;
  switch (filter.type) {
      case 'sepia':
          return `sepia(${intensity})`;
      case 'grayscale':
          return `grayscale(${intensity})`;
      case 'vintage':
          return `sepia(${intensity * 0.6}) contrast(1.1) brightness(0.95) saturate(1.2)`;
      default:
          return 'none';
  }
};


const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<ImageState | null>(null);
  const [processingImage, setProcessingImage] = useState<ImageState | null>(null);
  const [results, setResults] = useState<ResultItem[]>([]);
  const [selectedResult, setSelectedResult] = useState<ResultItem | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [isUpscaling, setIsUpscaling] = useState<boolean>(false);
  const [prompt, setPrompt] = useState<string>('');
  const [comparisonMode, setComparisonMode] = useState<ComparisonMode>('slider');
  const [error, setError] = useState<string | null>(null);
  const [promptMode, setPromptMode] = useState<PromptMode>('generate');
  const [imageDimensions, setImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const [beforeImageDimensions, setBeforeImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const [afterImageDimensions, setAfterImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isMasking, setIsMasking] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [quotaCooldownEnd, setQuotaCooldownEnd] = useState<number | null>(null);
  const [timeNow, setTimeNow] = useState(() => Date.now());
  const [downloadModalState, setDownloadModalState] = useState<{
    isOpen: boolean;
    result: ResultItem | null;
  }>({ isOpen: false, result: null });
  const [appMode, setAppMode] = useState<AppMode>('single');
  const [analysisItems, setAnalysisItems] = useState<AnalysisItem[]>([]);
  const [selectedAnalysisItem, setSelectedAnalysisItem] = useState<AnalysisItem | null>(null);
  const [isBatchAnalyzing, setIsBatchAnalyzing] = useState<boolean>(false);
  const [loadedPresets, setLoadedPresets] = useState<Record<PromptMode, LoadedPreset[]>>({ retouch: [], imagination: [], animation: [], generate: [] });
  const [isWelcomeModalOpen, setIsWelcomeModalOpen] = useState<boolean>(false);
  const [animationAspectRatio, setAnimationAspectRatio] = useState<AspectRatio>('16:9');
  const [generateAspectRatio, setGenerateAspectRatio] = useState<AspectRatio>('1:1');
  const [numberOfImages, setNumberOfImages] = useState<number>(1);
  const [actions, setActions] = useState<Action[]>([]);
  const [isActionEditorOpen, setIsActionEditorOpen] = useState<boolean>(false);
  const [editingAction, setEditingAction] = useState<Action | null>(null);
  const [detailedAnalysis, setDetailedAnalysis] = useState<string | null>(null);
  const [removeBgTolerance, setRemoveBgTolerance] = useState<number>(20);
  const [inspirationIdeas, setInspirationIdeas] = useState<CreativeIdea[]>([]);
  const [isInspirationModalOpen, setIsInspirationModalOpen] = useState<boolean>(false);

  const [customPrompts, setCustomPrompts] = useState(() => {
    try {
      const savedPrompts = localStorage.getItem('customPrompts');
      if (savedPrompts) {
        const parsed = JSON.parse(savedPrompts);
        if (Array.isArray(parsed)) {
          // Legacy format
          return { retouch: parsed, imagination: [], animation: [], generate: [] };
        } else {
          return { 
            retouch: parsed.retouch || [], 
            imagination: parsed.imagination || [],
            animation: parsed.animation || [],
            generate: parsed.generate || [],
          };
        }
      }
    } catch (e) {
      console.error("Failed to load custom prompts from localStorage", e);
    }
    return { retouch: [], imagination: [], animation: [], generate: [] };
  });

  // FIX: Explicitly type 'sum' as a number to resolve a type inference issue with reduce.
  const totalLoadedPrompts = Object.values(loadedPresets).reduce((sum: number, presets) => sum + (presets as LoadedPreset[]).length, 0);

  const [systemInstruction, setSystemInstruction] = useState<string>('');
  const [stylesUrl, setStylesUrl] = useState<string>('');


  useEffect(() => {
    try {
      const hasSeenWelcome = localStorage.getItem('hasSeenWelcomeModal');
      if (!hasSeenWelcome) {
        setIsWelcomeModalOpen(true);
      }
    } catch (e) {
      console.error("Failed to check for welcome modal status in localStorage", e);
    }
    
    try {
      const savedInstruction = localStorage.getItem('systemInstruction');
      if (savedInstruction) {
        setSystemInstruction(savedInstruction);
      }
      const savedStylesUrl = localStorage.getItem('stylesUrl');
      if (savedStylesUrl) {
        setStylesUrl(savedStylesUrl);
      }
      const savedActions = localStorage.getItem('actions');
      if (savedActions) {
        setActions(JSON.parse(savedActions));
      }
    } catch(e) {
      console.error("Failed to load persisted settings from localStorage", e);
    }

  }, []);
  
  useEffect(() => {
    let timer: number | undefined;
    if (quotaCooldownEnd && timeNow < quotaCooldownEnd) {
      timer = setInterval(() => setTimeNow(Date.now()), 1000) as unknown as number;
    } else if (quotaCooldownEnd && timeNow >= quotaCooldownEnd) {
      setQuotaCooldownEnd(null);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [quotaCooldownEnd, timeNow]);

  useEffect(() => {
    try {
      localStorage.setItem('systemInstruction', systemInstruction);
    } catch (e) {
      console.error("Failed to save system instruction to localStorage", e);
    }
  }, [systemInstruction]);
  
  useEffect(() => {
    try {
      localStorage.setItem('stylesUrl', stylesUrl);
    } catch (e) {
      console.error("Failed to save styles URL to localStorage", e);
    }
  }, [stylesUrl]);
  
  const handleSystemInstructionChange = (value: string) => {
    setSystemInstruction(value);
  };

  const handleStylesUrlChange = (value: string) => {
    setStylesUrl(value);
  };

  const processPromptFileContent = (fileText: string) => {
    if (fileText.trim().toLowerCase().startsWith('<!doctype html') || fileText.trim().startsWith('<html')) {
        throw new Error("The content appears to be a web page, not a raw file. Please use a direct link to the file content. For Google Sheets, use the 'File > Share > Publish to the web' option.");
    }
    
    const parsedData = parsePromptFile(fileText);

    const categorizedPresets: Record<PromptMode, LoadedPreset[]> = {
        retouch: [],
        imagination: [],
        animation: [],
        generate: [],
    };

    parsedData.forEach(item => {
        const category = item.category;
        if (categorizedPresets[category]) {
            categorizedPresets[category].push(item);
        }
    });
    
    setLoadedPresets(categorizedPresets);
    alert(t.promptsLoadedSuccess.replace('{count}', parsedData.length.toString()));
  };

  const handleLoadStyles = async () => {
    if (!stylesUrl || stylesUrl.trim() === '') {
        setError("Please set a valid Prompts File URL in the Settings.");
        setIsSettingsOpen(true);
        return;
    }
    setIsLoading(true);
    setLoadingMessage("Loading external prompts...");
    setError(null);

    try {
        const response = await fetch(stylesUrl);
        if (!response.ok) {
            throw new Error(`Failed to fetch file. Status: ${response.status}. Please check the URL and permissions.`);
        }
        const fileText = await response.text();
        processPromptFileContent(fileText);

    } catch (e: any) {
        console.error("Failed to load or parse prompts file:", e);
        let errorMessage = `Could not load prompts. ${e.message || 'Check the URL, file format, and sharing permissions.'}`;
        
        if (e instanceof TypeError && e.message === 'Failed to fetch') {
            errorMessage = "Failed to fetch the URL due to browser security policies (CORS). The server must allow cross-origin requests. Please use a direct 'raw' file link. For Google Drive/Sheets, the only reliable method is to use 'File > Share > Publish to the web' and use the generated link.";
        }
        
        setError(errorMessage);
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleLoadPromptsFromFileContent = (fileContent: string) => {
    setIsLoading(true);
    setLoadingMessage("Loading external prompts...");
    setError(null);
    try {
        processPromptFileContent(fileContent);
    } catch (e: any) {
        console.error("Failed to load or parse prompts file content:", e);
        setError(`Could not load prompts. ${e.message || 'Check the file format.'}`);
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const updateAndSelectResult = useCallback(async (result: ResultItem | null) => {
      setSelectedResult(result);
      
      if (!result) {
          setBeforeImageDimensions(null);
          setAfterImageDimensions(null);
          setImageDimensions(null);
          return;
      }
      
      const beforeUrl = result.sourceImageUrl ?? originalImage?.dataUrl ?? null;
      const afterUrl = result.imageUrl;

      try {
          const beforeDims = beforeUrl ? await getImageDimensions(beforeUrl) : null;
          const afterDims = (afterUrl && !result.videoUrl) ? await getImageDimensions(afterUrl) : beforeDims;
          setBeforeImageDimensions(beforeDims);
          setAfterImageDimensions(afterDims);
          setImageDimensions(afterDims ?? beforeDims);
      } catch (e) {
          setError("Could not load image properties.");
          setBeforeImageDimensions(null);
          setAfterImageDimensions(null);
          setImageDimensions(null);
      }
  }, [originalImage?.dataUrl]);

  const saveCustomPrompts = (prompts: { [key in PromptMode]: string[] }) => {
    try {
      localStorage.setItem('customPrompts', JSON.stringify(prompts));
    } catch (e) {
      console.error("Failed to save custom prompts to localStorage", e);
    }
  };

  const addCustomPrompt = (newPrompt: string) => {
    const allPresetPrompts = [...PRESET_PROMPTS, ...IMAGINATION_PRESET_PROMPTS, ...ANIMATION_PRESET_PROMPTS, ...GENERATE_PRESET_PROMPTS].map(p => p.prompt);
    if (newPrompt && !customPrompts[promptMode].includes(newPrompt) && !allPresetPrompts.includes(newPrompt)) {
      const updatedPrompts = {
        ...customPrompts,
        [promptMode]: [...customPrompts[promptMode], newPrompt]
      };
      setCustomPrompts(updatedPrompts);
      saveCustomPrompts(updatedPrompts);
    }
  };

  const deleteCustomPrompt = (promptToDelete: string) => {
    const updatedPrompts = {
      ...customPrompts,
      [promptMode]: customPrompts[promptMode].filter(p => p !== promptToDelete)
    };
    setCustomPrompts(updatedPrompts);
    saveCustomPrompts(updatedPrompts);
  };
  
  const handleClearAll = useCallback(() => {
    setOriginalImage(null);
    setProcessingImage(null);
    setResults([]);
    setSelectedResult(null);
    setError(null);
    setPrompt('');
    setImageDimensions(null);
    setBeforeImageDimensions(null);
    setAfterImageDimensions(null);
    setPromptMode('generate');
    setComparisonMode('slider');
    setQuotaCooldownEnd(null);
    setIsEditing(false);
    setIsMasking(false);
    setDetailedAnalysis(null);
  }, []);

  const handleImageUpload = async (imageDataUrl: string, mimeType: string) => {
    handleClearAll();
    setPromptMode('retouch'); // Switch to retouch mode after upload
    const imageState = { dataUrl: imageDataUrl, mimeType };
    setOriginalImage(imageState);
    setProcessingImage(imageState);
    
    const { width, height } = await getImageDimensions(imageDataUrl);
    const originalResult: ResultItem = {
        id: `original-${Date.now()}`,
        imageUrl: imageDataUrl,
        mimeType: mimeType,
        prompt: "Original Image",
        sourceImageUrl: imageDataUrl,
        width,
        height,
    };
    setResults([originalResult]);
    setDetailedAnalysis(null);
    await updateAndSelectResult(originalResult);
  };

  const handleFilesSelected = async (files: File[]) => {
    if (appMode === 'single') {
        if (!files.length) return;
        const file = files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
            const result = e.target?.result as string;
            handleImageUpload(result, file.type);
        };
        reader.readAsDataURL(file);
    } else {
        const newAnalysisItems: AnalysisItem[] = await Promise.all(
            files.map(async (file, index) => {
                const dataUrl = await new Promise<string>((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = (e) => resolve(e.target?.result as string);
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                });
                return {
                    id: `analyze-${Date.now()}-${index}`,
                    file: file,
                    originalDataUrl: dataUrl,
                    mimeType: file.type,
                    analysisResult: null,
                    status: 'pending',
                };
            })
        );
        setAnalysisItems(prev => [...prev, ...newAnalysisItems]);
    }
  };
  
  const handleStartAnalysis = async () => {
    if (isBatchAnalyzing || !analysisItems.some(item => item.status === 'pending')) return;

    setIsBatchAnalyzing(true);
    setError(null);
    
    const itemsToProcess = analysisItems.filter(item => item.status === 'pending');

    for (const item of itemsToProcess) {
        setAnalysisItems(prev => prev.map(i => i.id === item.id ? { ...i, status: 'processing' } : i));
        
        try {
            const base64Data = item.originalDataUrl.split(',')[1];
            const result = await analyzeImage(base64Data, item.mimeType);

            if (result) {
                setAnalysisItems(prev => prev.map(i => i.id === item.id ? { ...i, status: 'completed', analysisResult: result } : i));
            } else {
                throw new Error('The model did not return an analysis.');
            }
        } catch (err: any) {
            console.error(`Error analyzing ${item.file.name}:`, err);
            const errorMessage = (err.message || 'Unknown error').replace('QUOTA_EXCEEDED: ', '');
            setAnalysisItems(prev => prev.map(i => i.id === item.id ? { ...i, status: 'error', error: errorMessage } : i));
            if (err.message.startsWith('QUOTA_EXCEEDED:')) {
              setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
              break;
            }
        }
    }

    setIsBatchAnalyzing(false);
  };

  const handleRemoveAnalysisItem = (id: string) => {
    if (selectedAnalysisItem?.id === id) {
        setSelectedAnalysisItem(null);
    }
    setAnalysisItems(prev => prev.filter(item => item.id !== id));
  };
  
  const handleClearAnalysis = () => {
      setAnalysisItems([]);
      setSelectedAnalysisItem(null);
      setIsBatchAnalyzing(false);
  };
  
  const handleSelectAnalysisItem = (item: AnalysisItem) => {
    if (item.status === 'completed' || item.status === 'error') {
      setSelectedAnalysisItem(item);
    }
  };

  const handleSetAppMode = (mode: AppMode) => {
    if (appMode !== mode) {
        setSelectedAnalysisItem(null);
        setAppMode(mode);
    }
  };

  const handleGenerate = useCallback(async () => {
    if (isLoading || (quotaCooldownEnd && Date.now() < quotaCooldownEnd)) return;

    setIsLoading(true);
    setError(null);
    setLoadingMessage('Generating your masterpiece...');
    
    try {
      const results = await generateImage(prompt, generateAspectRatio, numberOfImages);
      
      if (results && results.length > 0) {
        const newResultItems: ResultItem[] = await Promise.all(results.map(async (result, index) => {
          const { width, height } = await getImageDimensions(result.imageUrl);
          return {
            id: `gen-${Date.now()}-${index}`,
            imageUrl: result.imageUrl,
            mimeType: result.mimeType,
            prompt: prompt,
            sourceImageUrl: null,
            width,
            height,
          };
        }));
        
        const firstResult = newResultItems[0];
        const imageState = { dataUrl: firstResult.imageUrl, mimeType: firstResult.mimeType };

        if (!originalImage) {
          setOriginalImage(imageState);
          setProcessingImage(imageState);
          const originalResult: ResultItem = {
            id: `original-${Date.now()}`,
            imageUrl: firstResult.imageUrl,
            mimeType: firstResult.mimeType,
            prompt: "Original Image",
            sourceImageUrl: firstResult.imageUrl,
            width: firstResult.width,
            height: firstResult.height,
          };
          setResults([originalResult, ...newResultItems.slice(1)]);
          await updateAndSelectResult(originalResult);
        } else {
          setResults(prev => [...newResultItems, ...prev]);
          await updateAndSelectResult(newResultItems[0]);
        }
        
        setPromptMode('retouch');

      } else {
        throw new Error('The model did not return any images. Please try a different prompt.');
      }
    } catch (err: any) {
      const errorMessage = err.message || 'An unexpected error occurred.';
      setError(errorMessage.replace('QUOTA_EXCEEDED: ', ''));
      console.error(err);
      if (errorMessage.startsWith('QUOTA_EXCEEDED:')) {
        setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
      }
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [prompt, isLoading, quotaCooldownEnd, generateAspectRatio, numberOfImages, originalImage, updateAndSelectResult]);

  const handleRestore = useCallback(async () => {
    if (!processingImage || isLoading || (quotaCooldownEnd && Date.now() < quotaCooldownEnd)) return;

    setIsLoading(true);
    setError(null);
    setDetailedAnalysis(null);
    
    try {
      const base64Data = processingImage.dataUrl.split(',')[1];
      
      if (promptMode === 'animation') {
        setLoadingMessage("Initializing animation...");
        const result = await animatePhoto(base64Data, processingImage.mimeType, prompt, setLoadingMessage, animationAspectRatio);

        if (result) {
          const { width, height } = await getImageDimensions(processingImage.dataUrl);
          const newResult: ResultItem = {
            id: `res-${Date.now()}`,
            imageUrl: processingImage.dataUrl,
            videoUrl: result.videoUrl,
            mimeType: result.mimeType,
            prompt: prompt,
            sourceImageUrl: processingImage.dataUrl,
            width,
            height,
          };
          setResults(prev => [newResult, ...prev]);
          await updateAndSelectResult(newResult);
        } else {
          throw new Error('The model did not return a video. Please try a different prompt.');
        }

      } else {
        setLoadingMessage('');
        const result = await restorePhoto(base64Data, processingImage.mimeType, prompt, systemInstruction, removeBgTolerance);

        if (result) {
          const { width, height } = await getImageDimensions(result.imageUrl);
          const newResult: ResultItem = {
            id: `res-${Date.now()}`,
            imageUrl: result.imageUrl,
            mimeType: result.mimeType,
            prompt: prompt,
            sourceImageUrl: processingImage.dataUrl,
            width,
            height,
          };
          
          setResults(prev => {
              const updatedResults = [newResult, ...prev];
              return updatedResults.length > 15 ? updatedResults.slice(0, 15) : updatedResults;
          });
          setProcessingImage({ dataUrl: newResult.imageUrl, mimeType: newResult.mimeType });
          await updateAndSelectResult(newResult);

        } else {
          throw new Error('The model did not return an image. Please try a different prompt.');
        }
      }
      
      if (comparisonMode === 'single') {
          setComparisonMode('slider');
      }

    } catch (err: any) {
      const errorMessage = err.message || 'An unexpected error occurred.';
      setError(errorMessage.replace('QUOTA_EXCEEDED: ', ''));
      console.error(err);
      if (errorMessage.startsWith('QUOTA_EXCEEDED:')) {
        setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
      }
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [processingImage, prompt, isLoading, updateAndSelectResult, comparisonMode, quotaCooldownEnd, promptMode, systemInstruction, animationAspectRatio, removeBgTolerance]);
  
  const handleMask = useCallback(async (maskDataUrl: string) => {
    if (!processingImage || isLoading || (quotaCooldownEnd && Date.now() < quotaCooldownEnd)) return;

    setIsLoading(true);
    setError(null);
    setLoadingMessage('Applying targeted edit...');
    setDetailedAnalysis(null);

    try {
        const base64Data = processingImage.dataUrl.split(',')[1];
        const result = await fillPhoto(base64Data, processingImage.mimeType, prompt, maskDataUrl, systemInstruction);

        if (result) {
            const { width, height } = await getImageDimensions(result.imageUrl);
            const newResult: ResultItem = {
                id: `mask-${Date.now()}`,
                imageUrl: result.imageUrl,
                mimeType: result.mimeType,
                prompt: prompt,
                sourceImageUrl: processingImage.dataUrl,
                width,
                height,
            };
            
            setResults(prev => {
                const updatedResults = [newResult, ...prev];
                return updatedResults.length > 15 ? updatedResults.slice(0, 15) : updatedResults;
            });
            setProcessingImage({ dataUrl: newResult.imageUrl, mimeType: newResult.mimeType });
            await updateAndSelectResult(newResult);

        } else {
            throw new Error('The model did not return an image for the fill operation.');
        }
        
        if (comparisonMode === 'single') {
            setComparisonMode('slider');
        }

    } catch (err: any) {
        const errorMessage = err.message || 'An unexpected error occurred.';
        setError(errorMessage.replace('QUOTA_EXCEEDED: ', ''));
        console.error(err);
        if (errorMessage.startsWith('QUOTA_EXCEEDED:')) {
            setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
        }
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
        setIsMasking(false);
    }
  }, [processingImage, prompt, isLoading, updateAndSelectResult, comparisonMode, quotaCooldownEnd, systemInstruction]);

  const handleUseResultAsSource = async (result: ResultItem) => {
    setProcessingImage({ dataUrl: result.imageUrl, mimeType: result.mimeType });
    setDetailedAnalysis(null);
    await updateAndSelectResult(result);
  };
  
  const handleResetToOriginal = async () => {
    if (originalImage) {
      setProcessingImage(originalImage);
      const originalResultItem = results.find(r => r.prompt === "Original Image");
      if (originalResultItem) {
          setDetailedAnalysis(null);
          await updateAndSelectResult(originalResultItem);
      }
    }
  };
  
  const handleSelectResultForView = async (result: ResultItem) => {
    if (result.prompt === 'Image Edited' || result.videoUrl || result.prompt.startsWith('Upscaled 2x')) {
        setComparisonMode('single');
    } else if (comparisonMode === 'single') {
        setComparisonMode('slider');
    }
    await updateAndSelectResult(result);
  }

  const handleConfirmEdits = async (finalEditState: EditState) => {
    const sourceResult = selectedResult;
    const sourceMimeType = processingImage?.mimeType || 'image/png';
    if (!sourceResult) return;
  
    setIsLoading(true);
    setError(null);
    setLoadingMessage(t.processingMessage);
  
    try {
      const clientEditedDataUrl = await new Promise<string>((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          const transformedCanvas = document.createElement('canvas');
          const transformedCtx = transformedCanvas.getContext('2d');
          if (!transformedCtx) return reject(new Error("Could not get canvas context."));
  
          const straightenRad = finalEditState.straightenAngle * (Math.PI / 180);
          const angle = (finalEditState.rotation * Math.PI / 180) + straightenRad;
  
          const { width: w, height: h } = img;
          const absCos = Math.abs(Math.cos(angle));
          const absSin = Math.abs(Math.sin(angle));
          const newWidth = w * absCos + h * absSin;
          const newHeight = w * absSin + h * absCos;
  
          transformedCanvas.width = newWidth;
          transformedCanvas.height = newHeight;
  
          transformedCtx.translate(newWidth / 2, newHeight / 2);
          transformedCtx.rotate(angle);
          transformedCtx.scale(finalEditState.scaleX, 1);
          transformedCtx.filter = getCssFilterString(finalEditState.filter);
          transformedCtx.drawImage(img, -w / 2, -h / 2);
          transformedCtx.filter = 'none';
          
          resolve(transformedCanvas.toDataURL(sourceMimeType));
        };
        img.onerror = () => reject(new Error("Failed to load image for editing."));
        img.src = sourceResult.imageUrl;
      });
  
      let finalImageUrl = clientEditedDataUrl;
      let finalMimeType = sourceMimeType;
      let finalPrompt = t.imageEdited;

      if (finalEditState.aiFilter && finalEditState.aiFilter.type !== 'none') {
        setLoadingMessage(t.applyingAiFilterMessage);
        const base64Data = clientEditedDataUrl.split(',')[1];
        const filterPreset = AI_FILTER_PRESETS.find(p => p.id === finalEditState.aiFilter!.type);
        if (!filterPreset) throw new Error("AI Filter preset not found");
  
        const aiResult = await applyAiFilter(
          base64Data,
          finalMimeType,
          filterPreset.prompt,
          finalEditState.aiFilter.intensity,
          systemInstruction
        );
  
        if (aiResult) {
          finalImageUrl = aiResult.imageUrl;
          finalMimeType = aiResult.mimeType;
          finalPrompt = `${t[filterPreset.id as keyof typeof t] || filterPreset.id} (${finalEditState.aiFilter.intensity}%)`;
        } else {
          throw new Error("AI filter did not return an image.");
        }
      }
  
      const { width, height } = await getImageDimensions(finalImageUrl);
      const newResult: ResultItem = {
        id: `edit-${Date.now()}`,
        imageUrl: finalImageUrl,
        mimeType: finalMimeType,
        prompt: finalPrompt,
        sourceImageUrl: processingImage?.dataUrl,
        width,
        height,
      };
  
      setResults(prev => [newResult, ...prev]);
      setProcessingImage({ dataUrl: newResult.imageUrl, mimeType: newResult.mimeType });
      setComparisonMode('single');
      setDetailedAnalysis(null);
      await updateAndSelectResult(newResult);
  
    } catch (err: any) {
      const errorMessage = err.message || 'An unexpected error occurred during editing.';
      setError(errorMessage);
      console.error(err);
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
      setIsEditing(false);
    }
  };

  const handleDeleteResult = useCallback(async (resultToDelete: ResultItem) => {
    if (resultToDelete.prompt === 'Original Image') {
        return;
    }

    const newResults = results.filter(r => r.id !== resultToDelete.id);
    setResults(newResults);

    if (selectedResult?.id === resultToDelete.id) {
        const nextResult = newResults[0] ?? null;
        await updateAndSelectResult(nextResult);
    }
  }, [results, selectedResult, updateAndSelectResult]);

  const handleOpenDownloadModal = (result: ResultItem) => {
    setDownloadModalState({ isOpen: true, result });
  };

  const handleCloseDownloadModal = () => {
      setDownloadModalState({ isOpen: false, result: null });
  };

  const handleConfirmDownload = (format: 'png' | 'jpeg', quality: number, metadataComment: string) => {
    const { result } = downloadModalState;
    if (!result) return;

    if (result.videoUrl) {
      downloadDataUrl(result.videoUrl, `pixel-studio-animated-${result.id}.mp4`);
      handleCloseDownloadModal();
      return;
    }
    
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            setError("Could not create canvas context for download.");
            handleCloseDownloadModal();
            return;
        }

        canvas.width = img.width;
        canvas.height = img.height;
        
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        const mimeType = `image/${format}`;
        let dataUrl = canvas.toDataURL(mimeType, format === 'jpeg' ? quality / 100 : undefined);
        
        if (format === 'jpeg' && metadataComment.trim() !== '' && typeof piexif !== 'undefined') {
          try {
            const exifObj = {"0th": {[piexif.ImageIFD.ImageDescription]: metadataComment}};
            const exifBytes = piexif.dump(exifObj);
            dataUrl = piexif.insert(exifBytes, dataUrl);
          } catch (e) {
            console.error("Failed to write EXIF data:", e);
          }
        }
        
        const link = document.createElement('a');
        link.href = dataUrl;
        
        const isUpscaled = result.prompt.startsWith('Upscaled 2x');
        const suffix = isUpscaled ? `-2x` : '';
        link.download = `pixel-studio-${result.id}${suffix}.${format}`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        handleCloseDownloadModal();
    };
    img.onerror = () => {
        setError("Failed to load image for download.");
        handleCloseDownloadModal();
    }
    img.src = result.imageUrl;
  };

  const handleUpscaleResult = async (result: ResultItem) => {
    if (isLoading || isUpscaling) return;

    setIsUpscaling(true);

    try {
        const upscaledDataUrl = await new Promise<string>((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    reject(new Error("Could not create canvas context for upscaling."));
                    return;
                }

                const scale = 2;
                canvas.width = img.width * scale;
                canvas.height = img.height * scale;
                
                ctx.imageSmoothingEnabled = true;
                ctx.imageSmoothingQuality = 'high';
                ctx.filter = 'contrast(105%) saturate(105%) brightness(102%)';
                
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                
                ctx.filter = 'none';

                const mimeType = 'image/png';
                const dataUrl = canvas.toDataURL(mimeType);
                resolve(dataUrl);
            };
            img.onerror = () => {
                reject(new Error("Failed to load image for upscaling."));
            };
            img.src = result.imageUrl;
        });

        const { width, height } = await getImageDimensions(upscaledDataUrl);
        const newResult: ResultItem = {
            id: `upscaled-${Date.now()}`,
            imageUrl: upscaledDataUrl,
            mimeType: 'image/png',
            prompt: `Upscaled 2x (${result.prompt === 'Original Image' ? t.originalImage : result.prompt})`,
            sourceImageUrl: result.imageUrl,
            width,
            height,
            isQuickUpscaled: true,
        };
        
        setResults(prev => [newResult, ...prev]);
        setDetailedAnalysis(null);
        await updateAndSelectResult(newResult);
        setComparisonMode('single');

    } catch (e: any) {
        setError(e.message || "An error occurred during upscaling.");
    } finally {
        setIsUpscaling(false);
    }
  };

  const handleAiUpscaleResult = async (result: ResultItem) => {
    if (isLoading || (quotaCooldownEnd && Date.now() < quotaCooldownEnd)) return;

    setIsLoading(true);
    setLoadingMessage(t.aiUpscalingMessage);
    setError(null);

    try {
        const base64Data = result.imageUrl.split(',')[1];
        const upscaledResult = await aiUpscaleImage(base64Data, result.mimeType, systemInstruction);

        if (upscaledResult) {
            const { width, height } = await getImageDimensions(upscaledResult.imageUrl);
            const newResult: ResultItem = {
                id: `ai-upscaled-${Date.now()}`,
                imageUrl: upscaledResult.imageUrl,
                mimeType: upscaledResult.mimeType,
                prompt: `AI Upscaled 2x (${result.prompt === 'Original Image' ? t.originalImage : result.prompt})`,
                sourceImageUrl: result.imageUrl,
                width,
                height,
                isAiUpscaled: true,
            };
            
            setResults(prev => [newResult, ...prev]);
            setDetailedAnalysis(null);
            await updateAndSelectResult(newResult);
            setComparisonMode('single');
        } else {
            throw new Error('The AI upscaling model did not return an image.');
        }

    } catch (err: any) {
        const errorMessage = err.message || 'An unexpected error occurred during AI upscaling.';
        setError(errorMessage.replace('QUOTA_EXCEEDED: ', ''));
        console.error(err);
        if (errorMessage.startsWith('QUOTA_EXCEEDED:')) {
            setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
        }
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
};

  const handleCloseWelcomeModal = () => {
    localStorage.setItem('hasSeenWelcomeModal', 'true');
    setIsWelcomeModalOpen(false);
    // Request fullscreen on user interaction for a better experience
    document.documentElement.requestFullscreen().catch(err => {
      // It's common for this to fail if not triggered by a direct, trusted user event,
      // so we'll log it for debugging but won't show an error to the user.
      console.log(`Could not enter full-screen mode: ${err.message}`);
    });
  };

  const handleExportVideoFrame = useCallback(async (result: ResultItem) => {
    if (!result.videoUrl) return;

    setIsLoading(true);
    setLoadingMessage(t.exportingFrameMessage);
    setError(null);

    try {
      const frameDataUrl = await new Promise<string>((resolve, reject) => {
        const video = document.createElement('video');
        video.muted = true;
        video.playsInline = true;
        
        const cleanup = () => {
            URL.revokeObjectURL(video.src);
            video.onloadedmetadata = null;
            video.onseeked = null;
            video.onerror = null;
        };

        video.onloadedmetadata = () => {
          video.currentTime = video.duration - 0.01; 
        };

        video.onseeked = () => {
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            cleanup();
            reject(new Error("Could not create canvas context."));
            return;
          }
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/png'));
          cleanup();
        };

        video.onerror = (e) => {
          cleanup();
          console.error("Video error:", e);
          reject(new Error("Failed to load video for frame export."));
        };

        video.src = result.videoUrl;
        video.load();
      });

      const { width, height } = await getImageDimensions(frameDataUrl);
      const newResult: ResultItem = {
        id: `frame-${Date.now()}`,
        imageUrl: frameDataUrl,
        mimeType: 'image/png',
        prompt: t.lastFrameFromVideo,
        sourceImageUrl: result.imageUrl,
        width,
        height,
      };

      setResults(prev => [newResult, ...prev]);
      await updateAndSelectResult(newResult);

    } catch (e: any) {
      setError(e.message || "Failed to export video frame.");
    } finally {
      setIsLoading(false);
      setLoadingMessage("");
    }
  }, [t, updateAndSelectResult]);
  
  const handleOpenActionEditor = (action: Action | null) => {
    setEditingAction(action);
    setIsActionEditorOpen(true);
  };
  
  const handleSaveAction = (action: Action) => {
    setActions(prev => {
        const existingIndex = prev.findIndex(a => a.id === action.id);
        const newActions = [...prev];
        if (existingIndex > -1) {
            newActions[existingIndex] = action;
        } else {
            newActions.push(action);
        }
        try {
            localStorage.setItem('actions', JSON.stringify(newActions));
        } catch(e) { console.error("Failed to save actions", e); }
        return newActions;
    });
    setIsActionEditorOpen(false);
  };
  
  const handleDeleteAction = (actionId: string) => {
    setActions(prev => {
        const newActions = prev.filter(a => a.id !== actionId);
        try {
            localStorage.setItem('actions', JSON.stringify(newActions));
        } catch(e) { console.error("Failed to save actions", e); }
        return newActions;
    });
  };

  const handleRunAction = async (action: Action) => {
    if (!processingImage || isLoading) return;

    setIsLoading(true);
    setError(null);
    setDetailedAnalysis(null);
    
    let currentImage = processingImage;
    const allPresets = [...PRESET_PROMPTS, ...IMAGINATION_PRESET_PROMPTS, ...loadedPresets.retouch, ...loadedPresets.imagination];

    for (let i = 0; i < action.steps.length; i++) {
        const stepId = action.steps[i];
        const preset = allPresets.find(p => p.id === stepId);
        
        const presetDisplayName = PRESET_PROMPTS.find(p => p.id === stepId) ? t[stepId as keyof typeof t] : (IMAGINATION_PRESET_PROMPTS.find(p => p.id === stepId) ? t[stepId as keyof typeof t] : (loadedPresets.retouch.find(p => p.id === stepId)?.displayName || loadedPresets.imagination.find(p => p.id === stepId)?.displayName));

        if (!preset) {
            const errorMsg = `Action failed: Preset with ID "${stepId}" not found.`;
            setError(errorMsg);
            console.error(errorMsg);
            setIsLoading(false);
            return;
        }

        setLoadingMessage(t.runningActionStatus
            .replace('{actionName}', action.name)
            .replace('{step}', (i + 1).toString())
            .replace('{totalSteps}', action.steps.length.toString())
            .replace('{promptName}', presetDisplayName || preset.prompt)
        );

        try {
            const base64Data = currentImage.dataUrl.split(',')[1];
            const result = await restorePhoto(base64Data, currentImage.mimeType, preset.prompt, systemInstruction, removeBgTolerance);

            if (result) {
                const { width, height } = await getImageDimensions(result.imageUrl);
                const newResult: ResultItem = {
                    id: `res-action-${action.id}-${i}-${Date.now()}`,
                    imageUrl: result.imageUrl,
                    mimeType: result.mimeType,
                    prompt: `Action: ${action.name} - ${presetDisplayName || preset.prompt}`,
                    sourceImageUrl: currentImage.dataUrl,
                    width,
                    height,
                };
                
                setResults(prev => [newResult, ...prev]);
                currentImage = { dataUrl: newResult.imageUrl, mimeType: newResult.mimeType };
                setProcessingImage(currentImage);
                await updateAndSelectResult(newResult);
            } else {
                throw new Error(`Step ${i + 1} (${preset.prompt}) did not return an image.`);
            }

        } catch (err: any) {
            setError(`Error during action step ${i + 1}: ${err.message}`);
            console.error(err);
            setIsLoading(false);
            return;
        }
    }

    setLoadingMessage('');
    setIsLoading(false);
  };

  const handleAnalyzeImage = async () => {
    if (!processingImage || isLoading) return;
    
    setIsLoading(true);
    setError(null);
    setDetailedAnalysis(null);
    setLoadingMessage(t.analyzingMessage);

    try {
        const base64Data = processingImage.dataUrl.split(',')[1];
        const result = await getDetailedAnalysis(base64Data, processingImage.mimeType);
        
        if (result) {
            setDetailedAnalysis(result);
        } else {
            throw new Error("Analysis did not return a valid result.");
        }

    } catch (err: any) {
        const errorMessage = err.message || 'An unexpected error occurred during analysis.';
        setError(errorMessage.replace('QUOTA_EXCEEDED: ', ''));
        console.error(err);
        if (errorMessage.startsWith('QUOTA_EXCEEDED:')) {
          setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
        }
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleGetCreativeIdeas = async () => {
    if (!processingImage || isLoading) return;
    
    setIsLoading(true);
    setError(null);
    setLoadingMessage(t.findingInspiration);

    try {
        const base64Data = processingImage.dataUrl.split(',')[1];
        const result = await getCreativeIdeas(base64Data, processingImage.mimeType);
        
        if (result && result.length > 0) {
            setInspirationIdeas(result);
            setIsInspirationModalOpen(true);
        } else {
            throw new Error("Could not generate creative ideas for this image.");
        }

    } catch (err: any) {
        const errorMessage = err.message || 'An unexpected error occurred while finding inspiration.';
        setError(errorMessage.replace('QUOTA_EXCEEDED: ', ''));
        console.error(err);
        if (errorMessage.startsWith('QUOTA_EXCEEDED:')) {
          setQuotaCooldownEnd(Date.now() + COOLDOWN_SECONDS * 1000);
        }
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleApplyInspiration = (inspiredPrompt: string) => {
    setPrompt(inspiredPrompt);
    setIsInspirationModalOpen(false);
  };

  const handleCloseAnalysisPanel = () => {
    setDetailedAnalysis(null);
  };
  
  const handleCopyToPrompt = (promptText: string) => {
    setPrompt(promptText);
    setDetailedAnalysis(null);
  };

  const downloadDataUrl = (dataUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const cooldownRemaining = quotaCooldownEnd ? Math.max(0, Math.ceil((quotaCooldownEnd - timeNow) / 1000)) : 0;
  const isQuotaLimited = cooldownRemaining > 0;

  return (
    <div className="flex h-screen w-screen bg-gray-900 text-gray-100 font-sans overflow-hidden">
      <div className="rotate-device-overlay">
        <RotateDeviceIcon className="w-24 h-24 text-yellow-400" />
        <h2 className="text-2xl font-bold text-gray-200">{t.rotateDeviceTitle}</h2>
        <p className="text-lg text-gray-400">{t.rotateDeviceMessage}</p>
      </div>
      <WelcomeModal isOpen={isWelcomeModalOpen} onClose={handleCloseWelcomeModal} />
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)}
        systemInstruction={systemInstruction}
        onSystemInstructionChange={handleSystemInstructionChange}
        stylesUrl={stylesUrl}
        onStylesUrlChange={handleStylesUrlChange}
        onLoadPromptsFromFileContent={handleLoadPromptsFromFileContent}
      />
      <ActionEditorModal
        isOpen={isActionEditorOpen}
        onClose={() => setIsActionEditorOpen(false)}
        onSave={handleSaveAction}
        actionToEdit={editingAction}
        availablePresets={[...PRESET_PROMPTS.map(p => ({...p, displayName: t[p.id as keyof typeof t] || p.prompt, category: 'retouch' as PromptMode})), ...IMAGINATION_PRESET_PROMPTS.map(p => ({...p, displayName: t[p.id as keyof typeof t] || p.prompt, category: 'imagination' as PromptMode})), ...loadedPresets.retouch, ...loadedPresets.imagination]}
      />
      <InspirationModal
        isOpen={isInspirationModalOpen}
        onClose={() => setIsInspirationModalOpen(false)}
        ideas={inspirationIdeas}
        onApply={handleApplyInspiration}
      />
      <UpscalingModal isOpen={isUpscaling} />
      <DownloadModal 
        isOpen={downloadModalState.isOpen}
        onClose={handleCloseDownloadModal}
        result={downloadModalState.result}
        onConfirmDownload={handleConfirmDownload}
      />
      <LeftPanel
        onFilesSelected={handleFilesSelected}
        processingImageUrl={processingImage?.dataUrl}
        prompt={prompt}
        setPrompt={setPrompt}
        onRestore={promptMode === 'generate' ? handleGenerate : handleRestore}
        isLoading={isLoading}
        hasImage={!!originalImage}
        onReset={handleResetToOriginal}
        isProcessingOriginal={originalImage?.dataUrl === processingImage?.dataUrl}
        customPrompts={customPrompts[promptMode]}
        onAddCustomPrompt={addCustomPrompt}
        onDeleteCustomPrompt={deleteCustomPrompt}
        promptMode={promptMode}
        setPromptMode={setPromptMode}
        isEditing={isEditing}
        isMasking={isMasking}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isQuotaLimited={isQuotaLimited}
        quotaCooldownRemaining={cooldownRemaining}
        appMode={appMode}
        setAppMode={handleSetAppMode}
        analysisItems={analysisItems}
        isBatchAnalyzing={isBatchAnalyzing}
        onStartAnalysis={handleStartAnalysis}
        onClearAnalysis={handleClearAnalysis}
        onRemoveAnalysisItem={handleRemoveAnalysisItem}
        onLoadStyles={() => handleLoadStyles()}
        loadedPresets={loadedPresets}
        totalLoadedPrompts={totalLoadedPrompts}
        animationAspectRatio={animationAspectRatio}
        setAnimationAspectRatio={setAnimationAspectRatio}
        generateAspectRatio={generateAspectRatio}
        setGenerateAspectRatio={setGenerateAspectRatio}
        numberOfImages={numberOfImages}
        setNumberOfImages={setNumberOfImages}
        actions={actions}
        onRunAction={handleRunAction}
        onOpenActionEditor={handleOpenActionEditor}
        onDeleteAction={handleDeleteAction}
        onAnalyzeImage={handleAnalyzeImage}
        onGetCreativeIdeas={handleGetCreativeIdeas}
        removeBgTolerance={removeBgTolerance}
        setRemoveBgTolerance={setRemoveBgTolerance}
        selectedAnalysisItem={selectedAnalysisItem}
        onSelectAnalysisItem={handleSelectAnalysisItem}
      />
      <CenterPanel
        appMode={appMode}
        beforeImage={selectedResult?.prompt === 'Original Image' ? null : (selectedResult?.sourceImageUrl ?? originalImage?.dataUrl ?? null)}
        afterImage={selectedResult?.imageUrl ?? null}
        mimeType={selectedResult?.mimeType ?? originalImage?.mimeType ?? 'image/png'}
        comparisonMode={comparisonMode}
        setComparisonMode={setComparisonMode}
        isLoading={isLoading}
        loadingMessage={loadingMessage}
        error={error}
        hasImage={!!originalImage}
        imageDimensions={imageDimensions}
        beforeImageDimensions={beforeImageDimensions}
        afterImageDimensions={afterImageDimensions}
        onConfirmEdits={handleConfirmEdits}
        isEditing={isEditing}
        setIsEditing={setIsEditing}
        isMasking={isMasking}
        setIsMasking={setIsMasking}
        onImageMasked={handleMask}
        promptMode={promptMode}
        selectedResult={selectedResult}
        animationAspectRatio={animationAspectRatio}
        detailedAnalysis={detailedAnalysis}
        onCloseAnalysis={handleCloseAnalysisPanel}
        onCopyToPrompt={handleCopyToPrompt}
        selectedAnalysisItem={selectedAnalysisItem}
      />
      {appMode === 'single' && (
        <RightPanel
          results={results}
          selectedResultId={selectedResult?.id ?? null}
          onSelectResult={handleSelectResultForView}
          onUseAsSource={handleUseResultAsSource}
          onDownloadResult={handleOpenDownloadModal}
          onUpscaleResult={handleUpscaleResult}
          onAiUpscaleResult={handleAiUpscaleResult}
          onDeleteResult={handleDeleteResult}
          onClearAll={handleClearAll}
          isLoading={isLoading}
          onExportFrame={handleExportVideoFrame}
        />
      )}
    </div>
  );
};

export default App;