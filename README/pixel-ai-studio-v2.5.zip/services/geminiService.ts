

import { GoogleGenAI, Modality, Type } from "@google/genai";
import { PRESET_PROMPTS } from '../constants';
import { makeBackgroundTransparent } from "../utils/imageUtils";
import { AnalysisResult, CreativeIdea } from "../types";


const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

async function callGeminiForImage(
  base64ImageData: string,
  mimeType: string,
  prompt: string,
  systemInstruction?: string
): Promise<{ imageUrl: string; mimeType: string } | null> {
  try {
    const config: {
        responseModalities: Modality[];
        systemInstruction?: string;
    } = {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
    };

    if (systemInstruction && systemInstruction.trim() !== '') {
        config.systemInstruction = systemInstruction;
    }

    const response = await ai.models.generateContent({
      // FIX: Updated deprecated model name to align with guidelines for image editing tasks.
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: config,
    });

    // Handle cases where the prompt was blocked or no candidates were returned.
    if (!response.candidates || response.candidates.length === 0) {
      if (response.promptFeedback?.blockReason) {
        throw new Error(`Request was blocked: ${response.promptFeedback.blockReason}. Please adjust your prompt or image.`);
      }
      throw new Error("The model did not return any content. Please try a different prompt.");
    }
    
    const candidate = response.candidates[0];
    const imagePart = candidate.content?.parts?.find(part => part.inlineData);

    if (imagePart && imagePart.inlineData) {
      const restoredBase64 = imagePart.inlineData.data;
      const restoredMimeType = imagePart.inlineData.mimeType;
      return {
        imageUrl: `data:${restoredMimeType};base64,${restoredBase64}`,
        mimeType: restoredMimeType,
      };
    }
    
    // If no image is found, check for a text response to provide a more specific error.
    const textResponse = response.text.trim();
    if (textResponse) {
      throw new Error(`Model returned text instead of an image: "${textResponse}"`);
    }

    // This is a fallback. The user will see the generic "did not return an image" message from App.tsx.
    return null;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
             throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota. To prevent further errors, the process button will be disabled for 60 seconds.`);
        }
        // Let our custom, more informative errors pass through without being re-wrapped.
        if (error.message.startsWith('Request was blocked') || 
            error.message.startsWith('The model did not return') || 
            error.message.startsWith('Model returned text')) {
            throw error;
        }
        throw new Error(`Gemini API Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the Gemini API.");
  }
}

async function performUnifiedAnalysis(
  base64ImageData: string,
  mimeType: string
): Promise<string | null> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
        ],
      },
      config: {
        systemInstruction: "You are a world-class photo analyst. Your task is to analyze the provided image in detail and suggest a prompt for enhancing it. First, provide a description for each of the following categories, with each category on a new line and formatted as '**Category:** Description'. The categories are: Subject, Background, Style, Composition, and Mood. After the analysis, provide a section titled '### Recommended Prompt' followed by a single, concise prompt inside a markdown code block (```) that could be used to improve or creatively alter this image.",
      },
    });

    const text = response.text.trim();
    if (!text) {
        throw new Error("Model returned an empty analysis.");
    }
    return text;

  } catch (error) {
    console.error("Error calling Gemini API for analysis:", error);
    if (error instanceof Error) {
        if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
             throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota.`);
        }
        throw new Error(`Gemini Analysis Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred during image analysis.");
  }
}

export async function getCreativeIdeas(
  base64ImageData: string,
  mimeType: string
): Promise<CreativeIdea[] | null> {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64ImageData,
                            mimeType: mimeType,
                        },
                    },
                ],
            },
            config: {
                systemInstruction: "You are a creative art director. Analyze this image and propose 3-4 different, unexpected, and artistic concepts for its transformation. For each idea, provide a catchy title, a short description, and a detailed, ready-to-use prompt. Format the response as a valid JSON array of objects.",
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING, description: "A short, catchy title for the creative concept." },
                            description: { type: Type.STRING, description: "A brief, one-sentence description of the artistic idea." },
                            prompt: { type: Type.STRING, description: "A detailed, ready-to-use prompt for an image generation model to execute this idea." }
                        },
                        required: ['title', 'description', 'prompt']
                    }
                }
            },
        });

        const jsonString = response.text.trim();
        if (!jsonString) {
            throw new Error("Model returned an empty set of ideas.");
        }

        const parsed = JSON.parse(jsonString) as CreativeIdea[];
        return parsed;

    } catch (error) {
        console.error("Error calling Gemini API for creative ideas:", error);
        if (error instanceof Error) {
            if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
                throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota.`);
            }
            throw new Error(`Gemini Creative Ideas Error: ${error.message}`);
        }
        throw new Error("An unknown error occurred while generating creative ideas.");
    }
}

export async function getDetailedAnalysis(
  base64ImageData: string,
  mimeType: string
): Promise<string | null> {
  return performUnifiedAnalysis(base64ImageData, mimeType);
}

export async function applyAiFilter(
  base64ImageData: string,
  mimeType: string,
  filterStyleDescription: string,
  intensity: number,
  systemInstruction?: string
): Promise<{ imageUrl: string; mimeType: string } | null> {
  const finalPrompt = `Redraw the provided image in a new artistic style.
  
Style Description: ${filterStyleDescription}.

Effect Intensity: ${intensity}%.

Instructions:
- The output image must be a creative reinterpretation based on the style description. It should be visually distinct from the original.
- Do not just apply a simple color filter. The texture, lines, and medium of the new style must be apparent.
- The core subject matter and composition of the original image must be preserved.`;
  return callGeminiForImage(base64ImageData, mimeType, finalPrompt, systemInstruction);
}

export async function aiUpscaleImage(
  base64ImageData: string,
  mimeType: string,
  systemInstruction?: string
): Promise<{ imageUrl: string; mimeType: string } | null> {
  const upscalePrompt = "Please intelligently enhance this image in preparation for a 2x digital upscale. Focus on sharpening details, improving clarity, and realistically reconstructing features, especially faces, to create a high-quality version. The output should be a detailed image at the original resolution.";
  
  // Step 1: Get the AI-enhanced image at the original resolution.
  const aiEnhancedResult = await callGeminiForImage(base64ImageData, mimeType, upscalePrompt, systemInstruction);

  if (!aiEnhancedResult) {
    return null; // The AI call failed or returned nothing.
  }

  // Step 2: Perform a high-quality client-side 2x upscale on the AI-enhanced result.
  try {
    const upscaledDataUrl = await new Promise<string>((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                return reject(new Error("Could not create canvas context for upscaling."));
            }

            const scale = 2;
            canvas.width = img.width * scale;
            canvas.height = img.height * scale;
            
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            
            const mimeType = 'image/png'; // Upscaling often works best with a lossless format.
            const dataUrl = canvas.toDataURL(mimeType);
            resolve(dataUrl);
        };
        img.onerror = () => {
            reject(new Error("Failed to load AI-enhanced image for upscaling."));
        };
        img.src = aiEnhancedResult.imageUrl;
    });

    return {
      imageUrl: upscaledDataUrl,
      mimeType: 'image/png',
    };

  } catch (e) {
    console.error("Error during client-side upscaling after AI enhancement:", e);
    // Fallback: return the AI-enhanced image at its original size if client-side scaling fails.
    return aiEnhancedResult;
  }
}

export async function generateImage(
  prompt: string,
  aspectRatio: string,
  numberOfImages: number
): Promise<{ imageUrl: string; mimeType: string }[] | null> {
  try {
    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: numberOfImages,
        outputMimeType: 'image/jpeg',
        aspectRatio: aspectRatio,
      },
    });

    if (!response.generatedImages || response.generatedImages.length === 0) {
      throw new Error("The model did not return any images. Your prompt might have been blocked for safety reasons.");
    }

    const results = response.generatedImages.map(img => {
      const base64ImageBytes: string = img.image.imageBytes;
      const mimeType = 'image/jpeg';
      return {
        imageUrl: `data:${mimeType};base64,${base64ImageBytes}`,
        mimeType: mimeType,
      };
    });
    
    return results;

  } catch (error) {
    console.error("Error calling Gemini Image Generation API:", error);
    if (error instanceof Error) {
        if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
             throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota. To prevent further errors, the process button will be disabled for 60 seconds.`);
        }
        if (error.message.startsWith('The model did not return')) {
            throw error;
        }
        throw new Error(`Gemini API Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the Gemini API.");
  }
}

export async function fillPhoto(
  base64ImageData: string,
  mimeType: string,
  prompt: string,
  base64MaskData: string,
  systemInstruction?: string
): Promise<{ imageUrl: string; mimeType: string } | null> {
  try {
    const maskDataOnly = base64MaskData.split(',')[1];

    // Create a more specific prompt for the inpainting task.
    // This guides the model to blend with surroundings rather than replacing objects.
    const inpaintingPrompt = `Inpaint the masked area based on the following instruction: "${prompt}". Blend the result seamlessly with the surrounding image, matching texture, lighting, and color. Focus on filling the area naturally, not adding new, distinct objects unless the prompt explicitly asks for them.`;
    
    const config: {
        responseModalities: Modality[];
        systemInstruction?: string;
    } = {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
    };

    if (systemInstruction && systemInstruction.trim() !== '') {
        config.systemInstruction = systemInstruction;
    }

    const response = await ai.models.generateContent({
      // FIX: Updated deprecated model name to align with guidelines for image editing tasks.
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: inpaintingPrompt,
          },
          {
            inlineData: {
                data: maskDataOnly,
                mimeType: 'image/png',
            },
          }
        ],
      },
      config: config,
    });

    if (!response.candidates || response.candidates.length === 0) {
      if (response.promptFeedback?.blockReason) {
        throw new Error(`Request was blocked: ${response.promptFeedback.blockReason}. Please adjust your prompt or image.`);
      }
      throw new Error("The model did not return any content. Please try a different prompt.");
    }
    
    const candidate = response.candidates[0];
    const imagePart = candidate.content?.parts?.find(part => part.inlineData);

    if (imagePart && imagePart.inlineData) {
      const restoredBase64 = imagePart.inlineData.data;
      const restoredMimeType = imagePart.inlineData.mimeType;
      return {
        imageUrl: `data:${restoredMimeType};base64,${restoredBase64}`,
        mimeType: restoredMimeType,
      };
    }
    
    // If no image is found, check for a text response to provide a more specific error.
    const textResponse = response.text.trim();
    if (textResponse) {
      throw new Error(`Model returned text instead of an image: "${textResponse}"`);
    }

    return null;

  } catch (error) {
    console.error("Error calling Gemini API for inpainting:", error);
    if (error instanceof Error) {
        if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
             throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota. To prevent further errors, the process button will be disabled for 60 seconds.`);
        }
        if (error.message.startsWith('Request was blocked') || 
            error.message.startsWith('The model did not return') || 
            error.message.startsWith('Model returned text')) {
            throw error;
        }
        throw new Error(`Gemini API Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the Gemini API.");
  }
}

export async function restorePhoto(
  base64ImageData: string,
  mimeType: string,
  prompt: string,
  systemInstruction?: string,
  removeBgTolerance: number = 20
): Promise<{ imageUrl: string; mimeType: string } | null> {
  const removeBgPrompt = PRESET_PROMPTS.find(p => p.id === "retouch_remove_background")?.prompt;
  if (prompt === removeBgPrompt) {
    try {
      const geminiResult = await callGeminiForImage(base64ImageData, mimeType, prompt, systemInstruction);
      if (geminiResult) {
        const transparentImageUrl = await makeBackgroundTransparent(geminiResult.imageUrl, removeBgTolerance);
        return {
          imageUrl: transparentImageUrl,
          mimeType: 'image/png'
        };
      }
      return null;
    } catch (e) {
      throw e;
    }
  } else {
    return callGeminiForImage(base64ImageData, mimeType, prompt, systemInstruction);
  }
}

export async function animatePhoto(
  base64ImageData: string,
  mimeType: string,
  prompt: string,
  setLoadingMessage: (message: string) => void,
  aspectRatio: string
): Promise<{ videoUrl: string, mimeType: string } | null> {
    try {
        setLoadingMessage("Starting video generation... This may take a few minutes.");

        let operation = await ai.models.generateVideos({
            model: 'veo-2.0-generate-001',
            prompt: prompt,
            image: {
                imageBytes: base64ImageData,
                mimeType: mimeType,
            },
            config: {
                numberOfVideos: 1,
            }
        });

        const progressMessages = [
            "Analyzing image and prompt...",
            "Setting up the animation scene...",
            "Rendering initial frames...",
            "Generating motion vectors...",
            "Compositing video layers...",
            "Almost there, finalizing the video...",
            "Still working, this is a complex animation...",
            "Polishing the final frames..."
        ];
        let messageIndex = 0;
        
        while (!operation.done) {
            setLoadingMessage(progressMessages[messageIndex % progressMessages.length]);
            messageIndex++;
            await new Promise(resolve => setTimeout(resolve, 10000));
            try {
                operation = await ai.operations.getVideosOperation({ operation: operation });
            } catch (pollError: any) {
                console.warn("Polling for video operation status failed, retrying...", pollError);
                await new Promise(resolve => setTimeout(resolve, 5000)); 
            }
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) {
            throw new Error("Video generation completed, but no download link was provided.");
        }

        setLoadingMessage("Downloading generated video...");
        const response = await fetch(`${downloadLink}&key=${API_KEY}`);
        if (!response.ok) {
            throw new Error(`Failed to download video file. Status: ${response.status}`);
        }
        const videoBlob = await response.blob();
        const videoUrl = URL.createObjectURL(videoBlob);
        
        return { videoUrl, mimeType: 'video/mp4' };

    } catch (error) {
        console.error("Error calling Gemini Video API:", error);
        if (error instanceof Error) {
            if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
                throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota. To prevent further errors, the process button will be disabled for 60 seconds.`);
            }
            throw new Error(`Gemini API Error: ${error.message}`);
        }
        throw new Error("An unknown error occurred while generating the video.");
    }
}

export async function analyzeImage(
  base64ImageData: string,
  mimeType: string
): Promise<AnalysisResult | null> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: `Perform a detailed analysis of the image, breaking it down into the following categories: composition, subject, background, style, artist (if a specific artist's style is identifiable), mood, and era (if a specific time period is identifiable). Return your response as a valid JSON object.`,
          },
        ],
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                composition: { type: Type.STRING, description: 'Analysis of the image composition.' },
                subject: { type: Type.STRING, description: 'Description of the primary subject.' },
                background: { type: Type.STRING, description: 'Description of the background elements.' },
                style: { type: Type.STRING, description: 'Analysis of the artistic or photographic style.' },
                artist: { type: Type.STRING, description: "Identifiable artist whose style is resembled, if any." },
                mood: { type: Type.STRING, description: 'The overall mood or feeling of the image.' },
                era: { type: Type.STRING, description: "The historical era the image appears to be from, if any." },
            },
            required: ['composition', 'subject', 'background', 'style', 'mood']
        }
      }
    });

    const jsonString = response.text.trim();
    if (!jsonString) {
        throw new Error("Model returned an empty analysis.");
    }

    const parsed = JSON.parse(jsonString) as AnalysisResult;
    return parsed;

  } catch (error) {
    console.error("Error calling Gemini API for batch analysis:", error);
    if (error instanceof Error) {
        if (error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
             throw new Error(`QUOTA_EXCEEDED: You have exceeded your API quota.`);
        }
        throw new Error(`Gemini Analysis Error: ${error.message}`);
    }
    throw new Error("An unknown error occurred during batch image analysis.");
  }
}