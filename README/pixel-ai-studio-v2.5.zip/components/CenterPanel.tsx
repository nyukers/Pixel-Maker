import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ComparisonMode, Pan, ResultItem, AppMode, FilterState, FilterType, EditState, CropBox, PromptMode, AspectRatio, AiFilterState, AnalysisItem } from '../types';
import ComparisonSlider from './ComparisonSlider';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { EnhanceIcon } from './icons/EnhanceIcon';
import t from '../locales/en';
import { EditIcon } from './icons/EditIcon';
import { RotateLeft90Icon } from './icons/RotateLeft90Icon';
import { RotateRight90Icon } from './icons/RotateRight90Icon';
import { FlipIcon } from './icons/FlipIcon';
import { CropIcon } from './icons/CropIcon';
import { CheckIcon } from './icons/CheckIcon';
import { XIcon } from './icons/XIcon';
import { PlusIconCircle } from './icons/PlusIconCircle';
import { MinusIconCircle } from './icons/MinusIconCircle';
import { ResetIcon } from './icons/ResetIcon';
import { UndoIcon } from './icons/UndoIcon';
import { RedoIcon } from './icons/RedoIcon';
import { AnalysisIcon } from './icons/AnalysisIcon';
import { FilterIcon } from './icons/FilterIcon';
import HistoryPanel from './HistoryPanel';
import { BrushIcon } from './icons/BrushIcon';
import { ClearIcon } from './icons/ClearIcon';
import { WandIcon } from './icons/WandIcon';
import { AI_FILTER_PRESETS } from '../constants';

interface CenterPanelProps {
  appMode: AppMode;
  beforeImage: string | null;
  afterImage: string | null;
  mimeType: string;
  comparisonMode: ComparisonMode;
  setComparisonMode: (mode: ComparisonMode) => void;
  isLoading: boolean;
  loadingMessage: string;
  error: string | null;
  hasImage: boolean;
  imageDimensions: { width: number; height: number } | null;
  beforeImageDimensions: { width: number; height: number } | null;
  afterImageDimensions: { width: number; height: number } | null;
  onConfirmEdits: (editState: EditState) => void;
  onImageMasked: (maskDataUrl: string) => void;
  isEditing: boolean;
  setIsEditing: (isEditing: boolean) => void;
  isMasking: boolean;
  setIsMasking: (isEditing: boolean) => void;
  promptMode: PromptMode;
  selectedResult: ResultItem | null;
  animationAspectRatio: AspectRatio;
  detailedAnalysis: string | null;
  onCloseAnalysis: () => void;
  onCopyToPrompt: (prompt: string) => void;
  selectedAnalysisItem: AnalysisItem | null;
}

interface CropPreview {
    top: number;
    right: number;
    bottom: number;
    left: number;
}

const AnalysisCategory: React.FC<{ title: string, content?: string | null }> = ({ title, content }) => {
  if (!content) return null;
  return (
    <div>
      <h4 className="text-md font-semibold text-gray-200 mb-2">{title}</h4>
      <p className="text-sm text-gray-300 bg-gray-900/50 p-3 rounded-md">{content}</p>
    </div>
  );
};

const CenterPanel: React.FC<CenterPanelProps> = ({
  appMode,
  beforeImage,
  afterImage,
  mimeType,
  comparisonMode,
  setComparisonMode,
  isLoading,
  loadingMessage,
  error,
  hasImage,
  imageDimensions,
  beforeImageDimensions,
  afterImageDimensions,
  onConfirmEdits,
  onImageMasked,
  isEditing,
  setIsEditing,
  isMasking,
  setIsMasking,
  promptMode,
  selectedResult,
  animationAspectRatio,
  detailedAnalysis,
  onCloseAnalysis,
  onCopyToPrompt,
  selectedAnalysisItem,
}) => {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState<Pan>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [startPan, setStartPan] = useState<Pan>({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const prevIsEditing = useRef(isEditing);
  const prevIsMasking = useRef(isMasking);

  // Edit mode state with History
  const [history, setHistory] = useState<EditState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  
  const currentEditState = history[historyIndex];
  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  // Box Crop state
  const [isCropping, setIsCropping] = useState(false);
  const [isDrawingCrop, setIsDrawingCrop] = useState(false);
  const [drawingCropBox, setDrawingCropBox] = useState<CropBox | null>(null);
  const [showFiltersPanel, setShowFiltersPanel] = useState<boolean>(false);
  const [showAiFiltersPanel, setShowAiFiltersPanel] = useState<boolean>(false);

  // Fill (masking) state
  const [brushSize, setBrushSize] = useState(40);
  const [isDrawingMask, setIsDrawingMask] = useState(false);
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const [customCursorPos, setCustomCursorPos] = useState({ x: -100, y: -100 });
  const [isMouseInPanel, setIsMouseInPanel] = useState(false);
  const [cropPreview, setCropPreview] = useState<CropPreview | null>(null);

  const createInitialState = (): EditState => ({
      actionKey: 'initialState',
      rotation: 0,
      scaleX: 1,
      straightenAngle: 0,
      editZoom: 1,
      editPan: { x: 0, y: 0 },
      cropBox: null,
      filter: { type: 'none', intensity: 100 },
      aiFilter: null,
  });

  const getCssFilterString = (filter: FilterState | undefined): string => {
    if (!filter || filter.type === 'none') return 'none';
    const intensity = filter.intensity / 100;
    switch (filter.type) {
        case 'sepia':
            return `sepia(${intensity})`;
        case 'grayscale':
            return `grayscale(${intensity})`;
        case 'vintage':
            // A combination for vintage effect. Intensity affects sepia.
            return `sepia(${intensity * 0.6}) contrast(1.1) brightness(0.95) saturate(1.2)`;
        default:
            return 'none';
    }
  };

  const fitAll = useCallback(() => {
    const masterDimensions = afterImageDimensions || beforeImageDimensions || imageDimensions;
    if (!masterDimensions || !containerRef.current) {
        setZoom(1);
        setPan({ x: 0, y: 0 });
        return;
    }
    
    const containerWidth = containerRef.current.clientWidth;
    const containerHeight = containerRef.current.clientHeight;
    
    if (containerWidth <= 0 || containerHeight <= 0) return;

    let { width: imgWidth, height: imgHeight } = masterDimensions;
    
    if (comparisonMode === 'side' && beforeImage && afterImage && !isEditing && !isMasking) {
        imgWidth *= 2;
    }

    const scaleX = containerWidth / imgWidth;
    const scaleY = containerHeight / imgHeight;
    
    const newZoom = Math.min(scaleX, scaleY) * 0.95;

    setZoom(newZoom > 0 ? newZoom : 1);
    setPan({ x: 0, y: 0 });
  }, [
    afterImageDimensions, 
    beforeImageDimensions, 
    imageDimensions, 
    comparisonMode, 
    beforeImage, 
    afterImage,
    isEditing,
    isMasking
  ]);

  const fitToHeight = useCallback(() => {
    const masterDimensions = afterImageDimensions || imageDimensions;
    if (!masterDimensions || !containerRef.current) {
      setZoom(1);
      setPan({ x: 0, y: 0 });
      return;
    }
    const containerHeight = containerRef.current.clientHeight;
    if (containerHeight <= 0) return;
    const { height: imgHeight } = masterDimensions;
    const scaleY = containerHeight / imgHeight;
    setZoom(scaleY > 0 ? scaleY : 1);
    setPan({ x: 0, y: 0 });
  }, [afterImageDimensions, imageDimensions]);

  const fitAllForEditing = useCallback(() => {
    const dims = afterImageDimensions || imageDimensions;
    if (!dims || !containerRef.current || history.length === 0) {
      return;
    }

    const containerWidth = containerRef.current.clientWidth;
    const containerHeight = containerRef.current.clientHeight;
    if (containerWidth <= 0 || containerHeight <= 0) return;

    const { width: imgWidth, height: imgHeight } = dims;
    const scaleX = containerWidth / imgWidth;
    const scaleY = containerHeight / imgHeight;
    const newZoom = Math.min(scaleX, scaleY) * 0.95;

    setHistory(prev => {
        if (prev.length === 0) return prev;
        const newHistory = [...prev];
        const updatedState = { ...newHistory[0], editZoom: newZoom > 0 ? newZoom : 1, editPan: {x: 0, y: 0} };
        newHistory[0] = updatedState;
        return newHistory;
    });
    setHistoryIndex(0);
  }, [afterImageDimensions, imageDimensions, history.length]);
  
  const setZoomAndCenter = (newZoom: number) => {
    setZoom(newZoom);
    setPan({ x: 0, y: 0 });
  }

  const recordHistory = (actionKey: string, newState: Partial<Omit<EditState, 'actionKey'>>) => {
    if (!currentEditState) return;
    
    const newHistory = history.slice(0, historyIndex + 1);
    const lastEntry = newHistory[newHistory.length - 1];

    const continuousActions = ['actionZoom', 'actionStraighten', 'actionPan', 'actionFilter', 'actionAiFilter'];
    const shouldCoalesce = lastEntry && lastEntry.actionKey === actionKey && continuousActions.includes(actionKey);

    if (shouldCoalesce) {
        const updatedState = { ...lastEntry, ...newState };
        newHistory[newHistory.length - 1] = updatedState;
        setHistory(newHistory);
    } else {
        const nextState: EditState = {
            ...currentEditState,
            ...newState,
            actionKey,
        };
        newHistory.push(nextState);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
    }
  };
  
  useEffect(() => {
    if (hasImage && !isEditing && !isMasking) {
        const timer = setTimeout(() => fitAll(), 50);
        return () => clearTimeout(timer);
    }
  }, [hasImage, afterImage, afterImageDimensions, comparisonMode, isEditing, isMasking, fitAll]);

  useEffect(() => {
    if (!hasImage) return;
    const handleResize = () => {
        if (isEditing) {
            fitAllForEditing();
        } else {
            fitAll();
        }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [hasImage, isEditing, fitAll, fitAllForEditing]);
  
  useEffect(() => {
    if (isEditing && !prevIsEditing.current) {
        setIsMasking(false);
        setHistory([createInitialState()]);
        setHistoryIndex(0);
        const timer = setTimeout(() => fitAllForEditing(), 50);
        return () => clearTimeout(timer);
    } else if (!isEditing && prevIsEditing.current) {
      fitAll();
    }
    prevIsEditing.current = isEditing;
  }, [isEditing, fitAll, fitAllForEditing, setIsMasking]);

  useEffect(() => {
    if(isMasking && !prevIsMasking.current) {
        setIsEditing(false);
        fitAll(); // Fit view for drawing
    }
    prevIsMasking.current = isMasking;
  }, [isMasking, setIsEditing, fitAll]);
  
  useEffect(() => {
    if (!isEditing) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'z') {
          e.preventDefault();
          if (e.shiftKey) {
            handleRedo();
          } else {
            handleUndo();
          }
      } else if (e.key === 'Escape') {
        if (isDrawingCrop) {
          setIsDrawingCrop(false);
          setDrawingCropBox(null); 
        } else if (isCropping) {
          setIsCropping(false);
        } else if (showFiltersPanel) {
          setShowFiltersPanel(false);
        } else if (showAiFiltersPanel) {
          setShowAiFiltersPanel(false);
        } else {
          handleCancelEdits();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isEditing, isCropping, isDrawingCrop, historyIndex, history.length, showFiltersPanel, showAiFiltersPanel]);
  
  useEffect(() => {
    if (appMode === 'single' && promptMode === 'animation' && hasImage && imageDimensions) {
        const [targetW, targetH] = animationAspectRatio.split(':').map(Number);
        const targetRatio = targetW / targetH;

        const { width: imgW, height: imgH } = imageDimensions;
        const imgRatio = imgW / imgH;

        if (Math.abs(imgRatio - targetRatio) < 0.01) {
            setCropPreview(null);
            return;
        }

        let top = 0, bottom = 0, left = 0, right = 0;

        if (imgRatio > targetRatio) { // Wider image, crop sides
            const newWidth = imgH * targetRatio;
            const margin = (imgW - newWidth) / 2;
            left = (margin / imgW) * 100;
            right = (margin / imgW) * 100;
        } else { // Taller image, crop top/bottom
            const newHeight = imgW / targetRatio;
            const margin = (imgH - newHeight) / 2;
            top = (margin / imgH) * 100;
            bottom = (margin / imgH) * 100;
        }

        setCropPreview({ top, right, bottom, left });

    } else {
        setCropPreview(null);
    }
  }, [appMode, promptMode, hasImage, imageDimensions, animationAspectRatio]);

  const handleWheel = (e: React.WheelEvent) => {
    if (!hasImage || isCropping || isMasking) return;
    e.preventDefault();
    const scaleAmount = 0.1;
    const currentZoom = isEditing ? currentEditState?.editZoom : zoom;
    const newZoom = Math.min(Math.max(0.1, currentZoom * (1 - e.deltaY * scaleAmount * 0.1)), 10);
    
    if (isEditing) {
        recordHistory('actionZoom', { editZoom: newZoom });
    } else {
        setZoom(newZoom);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!hasImage || appMode === 'analyze' || isMasking) return;
    if ((e.target as HTMLElement).closest('button')) return;
    if (isCropping) return;
    
    e.preventDefault();
    setIsPanning(true);
    if (isEditing && currentEditState) {
        setStartPan({ x: e.clientX - currentEditState.editPan.x, y: e.clientY - currentEditState.editPan.y });
    } else {
        setStartPan({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isMasking) {
        setCustomCursorPos({ x: e.clientX, y: e.clientY });
    }
    if (!isPanning || isCropping || isMasking) return;
    e.preventDefault();
    const newPan = { x: e.clientX - startPan.x, y: e.clientY - startPan.y };
    if (isEditing) {
        recordHistory('actionPan', { editPan: newPan });
    } else {
        setPan(newPan);
    }
  };

  const handleMouseUpOrLeave = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsPanning(false);
  };
  
  const handleApplyEdits = () => {
    if (!currentEditState) return;
    onConfirmEdits(currentEditState);
  };
  
  const handleUndo = () => canUndo && setHistoryIndex(i => i - 1);
  const handleRedo = () => canRedo && setHistoryIndex(i => i + 1);

  const resetEditState = () => {
      const initialState = createInitialState();
      recordHistory('actionReset', {
        rotation: initialState.rotation,
        scaleX: initialState.scaleX,
        straightenAngle: initialState.straightenAngle,
        editZoom: initialState.editZoom,
        editPan: initialState.editPan,
        cropBox: initialState.cropBox,
        filter: initialState.filter,
        aiFilter: initialState.aiFilter,
      });
      setIsCropping(false);
      setDrawingCropBox(null);
      setShowFiltersPanel(false);
      setShowAiFiltersPanel(false);
  };
  
  const handleCancelEdits = () => {
      setIsEditing(false);
      setIsCropping(false);
      setDrawingCropBox(null);
      setHistory([]);
      setHistoryIndex(-1);
      setShowFiltersPanel(false);
      setShowAiFiltersPanel(false);
  };
  
  const handleCropMouseDown = (e: React.MouseEvent) => {
    if (!isCropping) return;
    setIsDrawingCrop(true);
    setDrawingCropBox({ startX: e.clientX, startY: e.clientY, endX: e.clientX, endY: e.clientY });
  };
  
  const handleCropMouseMove = (e: React.MouseEvent) => {
    if (!isDrawingCrop || !drawingCropBox) return;
    setDrawingCropBox({ ...drawingCropBox, endX: e.clientX, endY: e.clientY });
  };
  
  const handleCropMouseUp = () => {
    if(isDrawingCrop) {
        recordHistory('actionCrop', { cropBox: drawingCropBox });
        setDrawingCropBox(null);
    }
    setIsDrawingCrop(false);
  };

  const handleFilterChange = (filter: FilterState, actionKey: string) => {
    recordHistory(actionKey, { filter });
  };
  
  const handleAiFilterChange = (aiFilter: AiFilterState | null, actionKey: string) => {
    recordHistory(actionKey, { aiFilter });
  };

  const getRelativeCoords = (e: React.MouseEvent): { x: number; y: number } | null => {
    const canvas = maskCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;
    return { x, y };
  };

  const handleMaskMouseDown = (e: React.MouseEvent) => {
    if (!isMasking) return;
    const coords = getRelativeCoords(e);
    if (!coords) return;
    setIsDrawingMask(true);
    lastPointRef.current = coords;
  };

  const handleMaskMouseMove = (e: React.MouseEvent) => {
    if (!isDrawingMask) return;
    const canvas = maskCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    const currentPoint = getRelativeCoords(e);
    if (!ctx || !currentPoint || !lastPointRef.current) return;
    
    ctx.strokeStyle = 'rgba(250, 204, 21, 0.6)';
    ctx.lineWidth = brushSize / zoom;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.beginPath();
    ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
    ctx.lineTo(currentPoint.x, currentPoint.y);
    ctx.stroke();

    lastPointRef.current = currentPoint;
  };

  const handleMaskMouseUp = () => {
    setIsDrawingMask(false);
    lastPointRef.current = null;
  };
  
  const handleClearMask = () => {
    const canvas = maskCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx && canvas) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const handleCancelMask = () => {
    handleClearMask();
    setIsMasking(false);
  };
  
  const handleApplyMask = () => {
    const maskCanvas = maskCanvasRef.current;
    if (!maskCanvas) return;

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = maskCanvas.width;
    tempCanvas.height = maskCanvas.height;
    const ctx = tempCanvas.getContext('2d');
    if (!ctx) return;

    const originalCtx = maskCanvas.getContext('2d');
    if (!originalCtx) return;

    const imageData = originalCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height);
    const data = imageData.data;

    // The inpainting model requires a specific mask format to determine which parts of the image to edit.
    // Based on empirical testing with the model:
    // - The area the user draws on (to be filled) must be BLACK.
    // - The area to be kept untouched must be WHITE.
    for (let i = 0; i < data.length; i += 4) {
      // Check the alpha channel of the visual drawing canvas to see if a pixel was drawn on.
      if (data[i + 3] > 0) { // This is the user-drawn area.
        // Set to BLACK to indicate "fill this area".
        data[i] = 0;     // R
        data[i + 1] = 0; // G
        data[i + 2] = 0; // B
      } else { // This is the untouched background.
        // Set to WHITE to indicate "keep this area".
        data[i] = 255;
        data[i + 1] = 255;
        data[i + 2] = 255;
      }
      // Ensure the final mask is fully opaque for the API.
      data[i + 3] = 255;
    }

    ctx.putImageData(imageData, 0, 0);
    const maskDataUrl = tempCanvas.toDataURL('image/png');
    onImageMasked(maskDataUrl);
    handleClearMask();
  };

  const getCropBoxStyle = (): React.CSSProperties => {
    const boxToDraw = drawingCropBox || currentEditState?.cropBox;
    if (!boxToDraw) return { display: 'none' };

    const left = Math.min(boxToDraw.startX, boxToDraw.endX);
    const top = Math.min(boxToDraw.startY, boxToDraw.endY);
    const width = Math.abs(boxToDraw.endX - boxToDraw.startX);
    const height = Math.abs(boxToDraw.endY - boxToDraw.startY);

    return {
        position: 'fixed',
        left,
        top,
        width,
        height,
        border: `2px dashed #facc15`,
        backgroundColor: 'rgba(0, 0, 0, 0.2)',
        boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.6)',
        pointerEvents: 'none',
        zIndex: 45,
    };
  };

  const parseAnalysis = (text: string | null) => {
    if (!text) return { prompt: '', content: '' };
    const promptRegex = /```([\s\S]*?)```/;
    const match = text.match(promptRegex);
    const prompt = match ? match[1].trim() : '';
    const content = text.replace('### Recommended Prompt', '').replace(promptRegex, '').trim();
    return { prompt, content };
  };

  const singleImage = afterImage || beforeImage;
  const isComparisonDisabled = selectedResult?.prompt === 'Image Edited' || !!selectedResult?.videoUrl;
  const isVideoResult = !!selectedResult?.videoUrl;
  const inSpecialMode = isEditing || isMasking;

  const renderContent = () => {
    if (appMode === 'analyze') {
      if (selectedAnalysisItem) {
        const { originalDataUrl, analysisResult, file, error, status } = selectedAnalysisItem;
        return (
          <div className="w-full h-full flex items-start justify-center p-4 overflow-hidden">
            <div className="w-full h-full max-w-5xl flex flex-col lg:flex-row gap-4">
              {/* Image preview */}
              <div className="flex-1 w-full lg:w-1/2 h-1/2 lg:h-full flex items-center justify-center bg-black/20 rounded-lg p-2">
                <img
                  src={originalDataUrl}
                  alt={file.name}
                  className="max-w-full max-h-full object-contain rounded-md"
                />
              </div>

              {/* Analysis results */}
              <div className="flex-1 w-full lg:w-1/2 h-1/2 lg:h-full bg-gray-800/50 rounded-lg p-4 overflow-y-auto">
                <h3 className="text-xl font-bold text-yellow-300 mb-3 pb-3 border-b border-gray-700 truncate" title={file.name}>{file.name}</h3>
                {status === 'completed' && analysisResult && (
                  <div className="space-y-4">
                    <AnalysisCategory title={t.analysisSubject} content={analysisResult.subject} />
                    <AnalysisCategory title={t.analysisComposition} content={analysisResult.composition} />
                    <AnalysisCategory title={t.analysisBackground} content={analysisResult.background} />
                    <AnalysisCategory title={t.analysisStyle} content={analysisResult.style} />
                    <AnalysisCategory title={t.analysisArtist} content={analysisResult.artist} />
                    <AnalysisCategory title={t.analysisMood} content={analysisResult.mood} />
                    <AnalysisCategory title={t.analysisEra} content={analysisResult.era} />
                  </div>
                )}
                {status === 'error' && error && (
                  <div className="text-red-400 bg-red-900/20 p-3 rounded-md">
                    <p className="font-bold text-lg mb-2">{t.errorTitle}</p>
                    <p>{error}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        );

      } else {
        return (
          <div className="flex flex-col items-center justify-center h-full text-gray-400 p-8">
            <AnalysisIcon className="h-24 w-24 mb-4" />
            <h2 className="text-2xl font-semibold text-gray-300">{t.analyzePlaceholderTitle}</h2>
            <p className="text-center">{t.analysisQueueSelect}</p>
          </div>
        );
      }
    }
    
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-gray-400 p-4">
          <SpinnerIcon className="h-16 w-16 animate-spin text-yellow-400" />
          <p className="mt-4 text-lg">{t.processingMessage}</p>
          <p className="text-sm text-center">{loadingMessage || t.processingSubMessage}</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-red-400 bg-red-900/20 p-8 rounded-lg">
          <p className="font-bold text-lg mb-2">{t.errorTitle}</p>
          <p className="text-center">{error}</p>
        </div>
      );
    }

    if (!hasImage) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-gray-400">
          <EnhanceIcon className="h-24 w-24 mb-4 text-yellow-400/30" />
          <h2 className="text-2xl font-semibold text-gray-300">{t.uploadPromptTitle}</h2>
          <p>{t.uploadPromptSubtitle}</p>
        </div>
      );
    }
    
    if (beforeImage && afterImage && comparisonMode === 'slider' && !inSpecialMode) {
      return (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <ComparisonSlider 
            before={beforeImage} 
            after={afterImage} 
            zoom={zoom} 
            pan={pan}
            beforeImageDimensions={beforeImageDimensions}
            afterImageDimensions={afterImageDimensions}
            onPanMouseDown={handleMouseDown}
            isPanning={isPanning}
          />
        </div>
      );
    }
    
    if (beforeImage && afterImage && comparisonMode === 'side' && !inSpecialMode) {
      const scaleCorrection = (beforeImageDimensions && afterImageDimensions && beforeImageDimensions.width > 0)
        ? afterImageDimensions.width / beforeImageDimensions.width
        : 1;

      const baseTransform = `translate(${pan.x}px, ${pan.y}px)`;
      const baseStyle: Omit<React.CSSProperties, 'transform'> = {
          transition: isPanning ? 'none' : 'transform 0.1s',
          maxWidth: 'none',
          maxHeight: 'none',
          width: 'auto',
          height: 'auto',
      };

      const beforeTransformStyle: React.CSSProperties = {
          ...baseStyle,
          transform: `${baseTransform} scale(${zoom * scaleCorrection})`,
      };
      
      const afterTransformStyle: React.CSSProperties = {
          ...baseStyle,
          transform: `${baseTransform} scale(${zoom})`,
      };

      return (
        <div className="grid grid-cols-2 gap-4 w-full h-full p-4">
          <div className="flex flex-col items-center justify-start overflow-hidden">
            <div className="relative w-full h-full flex items-center justify-center">
              <div className="absolute top-2 left-2 z-10 bg-black/50 text-gray-100 text-sm px-2 py-1 rounded-md pointer-events-none">
                <h3 className="font-semibold">{t.beforeLabel}</h3>
                {beforeImageDimensions && (
                    <p className="text-xs text-gray-300">{`${beforeImageDimensions.width} x ${beforeImageDimensions.height} px`}</p>
                )}
              </div>
              <img key={beforeImage} src={beforeImage} alt={t.beforeLabel} style={beforeTransformStyle} className="object-contain rounded-lg shadow-md" />
            </div>
          </div>
          <div className="flex flex-col items-center justify-start overflow-hidden">
            <div className="relative w-full h-full flex items-center justify-center">
              <div className="absolute top-2 left-2 z-10 bg-black/50 text-sm px-2 py-1 rounded-md pointer-events-none">
                <h3 className="font-semibold text-yellow-300">{t.afterLabel}</h3>
                 {afterImageDimensions && (
                    <p className="text-xs text-gray-100">{`${afterImageDimensions.width} x ${afterImageDimensions.height} px`}</p>
                 )}
              </div>
              <img key={afterImage} src={afterImage} alt={t.afterLabel} style={afterTransformStyle} className="object-contain rounded-lg shadow-md" />
            </div>
          </div>
        </div>
      )
    }
    
    if (selectedResult?.videoUrl) {
      return (
        <div className="absolute inset-0 w-full h-full flex items-center justify-center p-4">
            <video 
                key={selectedResult.videoUrl} 
                src={selectedResult.videoUrl}
                controls 
                autoPlay 
                loop 
                muted
                className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                style={{
                  transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                  transition: isPanning ? 'none' : 'transform 0.1s',
                }}
            />
        </div>
      );
    }


    if (singleImage) {
        const staticTransform = currentEditState ? `rotate(${currentEditState.rotation}deg) scaleX(${currentEditState.scaleX}) rotate(${currentEditState.straightenAngle}deg)` : '';
        const viewTransform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
        const editViewTransform = currentEditState ? `translate(${currentEditState.editPan.x}px, ${currentEditState.editPan.y}px) scale(${currentEditState.editZoom})` : '';

        const transformString = isEditing ? `${editViewTransform} ${staticTransform}` : viewTransform;
        
        const wrapperTransformStyle: React.CSSProperties = {
            transform: transformString,
            transition: (isPanning || isDrawingCrop) ? 'none' : 'transform 0.1s',
            display: 'inline-block', // Make wrapper fit content
        };

        const imageStyle: React.CSSProperties = {
            filter: isEditing ? getCssFilterString(currentEditState?.filter) : 'none',
            maxWidth: 'none',
            maxHeight: 'none',
            width: 'auto',
            height: 'auto',
            touchAction: 'none',
            display: 'block',
        };

        return (
            <div className="absolute inset-0 w-full h-full flex items-center justify-center p-4">
                <div style={wrapperTransformStyle}>
                    <div className="relative"> {/* Container for image and overlays */}
                        <img ref={imageRef} src={singleImage} alt="Display" style={imageStyle} className="object-contain rounded-lg shadow-lg"/>
                        {isMasking && afterImageDimensions && (
                            <canvas
                                ref={maskCanvasRef}
                                width={afterImageDimensions.width}
                                height={afterImageDimensions.height}
                                className="absolute inset-0 w-full h-full"
                                onMouseDown={handleMaskMouseDown}
                                onMouseMove={handleMaskMouseMove}
                                onMouseUp={handleMaskMouseUp}
                                onMouseLeave={handleMaskMouseUp}
                            />
                        )}
                         {isEditing && currentEditState?.aiFilter && (
                          <div className="absolute inset-0 bg-black/60 flex items-center justify-center pointer-events-none">
                            <div className="text-center p-4 rounded-lg bg-gray-900/80">
                              <WandIcon className="w-8 h-8 mx-auto text-yellow-300 mb-2" />
                              <p className="text-white font-semibold">{t.aiFilterPreviewTitle}</p>
                              <p className="text-gray-300 text-sm font-semibold">{t.aiFilterPreviewInstruction}</p>
                            </div>
                          </div>
                        )}
                        {cropPreview && !inSpecialMode && (
                            <>
                                {/* Top */}
                                <div className="absolute left-0 right-0 bg-black/60 pointer-events-none" style={{ top: 0, height: `${cropPreview.top}%` }}></div>
                                {/* Bottom */}
                                <div className="absolute left-0 right-0 bg-black/60 pointer-events-none" style={{ bottom: 0, height: `${cropPreview.bottom}%` }}></div>
                                {/* Left */}
                                <div className="absolute left-0 bg-black/60 pointer-events-none" style={{ top: `${cropPreview.top}%`, bottom: `${cropPreview.bottom}%`, width: `${cropPreview.left}%` }}></div>
                                {/* Right */}
                                <div className="absolute right-0 bg-black/60 pointer-events-none" style={{ top: `${cropPreview.top}%`, bottom: `${cropPreview.bottom}%`, width: `${cropPreview.right}%` }}></div>
                                
                                {/* Dashed line for the crop box itself */}
                                <div 
                                    className="absolute border-2 border-dashed border-yellow-400 pointer-events-none" 
                                    style={{
                                        top: `${cropPreview.top}%`,
                                        right: `${cropPreview.right}%`,
                                        bottom: `${cropPreview.bottom}%`,
                                        left: `${cropPreview.left}%`,
                                    }}
                                >
                                    <span className="absolute -top-6 left-1/2 -translate-x-1/2 bg-black/60 text-white text-xs px-2 py-0.5 rounded whitespace-nowrap">
                                        {t.animationCropPreviewLabel.replace('{ratio}', animationAspectRatio)}
                                    </span>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    return null;
  };
  
  const { prompt: analysisPrompt, content: analysisContent } = parseAnalysis(detailedAnalysis);

  return (
    <main className="flex-grow flex flex-col items-center justify-center p-4 bg-gray-900 relative">
      {isMasking && isMouseInPanel && (
          <div
              className="pointer-events-none fixed z-[9999] rounded-full bg-yellow-400/50 border-2 border-yellow-500 -translate-x-1/2 -translate-y-1/2"
              style={{
                  left: customCursorPos.x,
                  top: customCursorPos.y,
                  width: brushSize,
                  height: brushSize,
              }}
          />
      )}
      {(isCropping || drawingCropBox) && <div style={getCropBoxStyle()}></div>}
      {isEditing && currentEditState && (
         <>
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center space-y-2">
                 {/* AI Filters Panel */}
                {showAiFiltersPanel && (
                    <div className="p-3 bg-gray-800 rounded-lg shadow-lg border border-gray-700 w-full max-w-xl flex flex-col items-center gap-3">
                        <div className="flex justify-center items-center flex-wrap gap-2">
                             <button onClick={() => handleAiFilterChange(null, 'aiFilterNone')} className={`py-1.5 px-3 text-sm rounded-md font-semibold transition ${!currentEditState.aiFilter ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>{t.filterNone}</button>
                            {AI_FILTER_PRESETS.map(preset => (
                               <button 
                                key={preset.id} 
                                onClick={() => handleAiFilterChange({ type: preset.id, intensity: currentEditState.aiFilter?.type === preset.id ? currentEditState.aiFilter.intensity : 50 }, `aiFilter${preset.id}`)} 
                                className={`py-1.5 px-3 text-sm rounded-md font-semibold transition ${currentEditState.aiFilter?.type === preset.id ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}
                                >
                                    {t[preset.id as keyof typeof t] || preset.id}
                                </button>
                            ))}
                        </div>
                        {currentEditState.aiFilter && (
                            <div className="w-full max-w-sm pt-2">
                                <label htmlFor="ai-filter-intensity" className="block text-xs font-medium text-gray-300 mb-2">{t.filterIntensityLabel} ({currentEditState.aiFilter.intensity}%)</label>
                                <input
                                    id="ai-filter-intensity"
                                    type="range"
                                    min="1"
                                    max="100"
                                    value={currentEditState.aiFilter.intensity}
                                    onChange={e => handleAiFilterChange({ ...currentEditState.aiFilter!, intensity: parseInt(e.target.value, 10) }, 'actionAiFilter')}
                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-400"
                                />
                            </div>
                        )}
                    </div>
                )}
                {/* CSS Filters Panel */}
                {showFiltersPanel && (
                    <div className="p-3 bg-gray-800 rounded-lg shadow-lg border border-gray-700 w-full max-w-xl flex flex-col items-center gap-3">
                        <div className="flex justify-center items-center flex-wrap gap-2">
                            <button onClick={() => handleFilterChange({ type: 'none', intensity: 100 }, 'filterNone')} className={`py-1.5 px-3 text-sm rounded-md font-semibold transition ${currentEditState.filter.type === 'none' ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>{t.filterNone}</button>
                            <button onClick={() => handleFilterChange({ type: 'sepia', intensity: currentEditState.filter.type === 'sepia' ? currentEditState.filter.intensity : 80 }, 'filterSepia')} className={`py-1.5 px-3 text-sm rounded-md font-semibold transition ${currentEditState.filter.type === 'sepia' ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>{t.filterSepia}</button>
                            <button onClick={() => handleFilterChange({ type: 'grayscale', intensity: currentEditState.filter.type === 'grayscale' ? currentEditState.filter.intensity : 100 }, 'filterGrayscale')} className={`py-1.5 px-3 text-sm rounded-md font-semibold transition ${currentEditState.filter.type === 'grayscale' ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>{t.filterGrayscale}</button>
                            <button onClick={() => handleFilterChange({ type: 'vintage', intensity: currentEditState.filter.type === 'vintage' ? currentEditState.filter.intensity : 100 }, 'filterVintage')} className={`py-1.5 px-3 text-sm rounded-md font-semibold transition ${currentEditState.filter.type === 'vintage' ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>{t.filterVintage}</button>
                        </div>
                        {currentEditState.filter.type !== 'none' && (
                            <div className="w-full max-w-sm pt-2">
                                <label htmlFor="filter-intensity" className="block text-xs font-medium text-gray-300 mb-2">{t.filterIntensityLabel} ({currentEditState.filter.intensity}%)</label>
                                <input
                                    id="filter-intensity"
                                    type="range"
                                    min="0"
                                    max="100"
                                    value={currentEditState.filter.intensity}
                                    onChange={e => handleFilterChange({ ...currentEditState.filter, intensity: parseInt(e.target.value, 10) }, 'actionFilter')}
                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-400"
                                />
                            </div>
                        )}
                    </div>
                )}
                
                {/* Main Toolbar */}
                <div className="p-2 flex justify-center items-center flex-wrap gap-2 bg-gray-800 rounded-lg shadow-lg border border-gray-700">
                    <button title={t.undoTitle} onClick={handleUndo} disabled={!canUndo} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition disabled:opacity-40 disabled:cursor-not-allowed"><UndoIcon className="w-5 h-5"/></button>
                    <button title={t.redoTitle} onClick={handleRedo} disabled={!canRedo} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition disabled:opacity-40 disabled:cursor-not-allowed"><RedoIcon className="w-5 h-5"/></button>
                    <div className="w-px h-6 bg-gray-600"></div>
                    <button title={t.rotateLeft90Title} onClick={() => recordHistory('actionRotate', { rotation: (currentEditState.rotation - 90 + 360) % 360 })} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><RotateLeft90Icon className="w-5 h-5"/></button>
                    <button title={t.rotateRight90Title} onClick={() => recordHistory('actionRotate', { rotation: (currentEditState.rotation + 90) % 360 })} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><RotateRight90Icon className="w-5 h-5"/></button>
                    <button title={t.flipTitle} onClick={() => recordHistory('actionFlip', { scaleX: currentEditState.scaleX * -1 })} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><FlipIcon className="w-5 h-5"/></button>
                    <div className="w-px h-6 bg-gray-600"></div>
                    <button title={t.zoomOutTitle} onClick={() => recordHistory('actionZoom', { editZoom: Math.max(0.1, currentEditState.editZoom / 1.1) })} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><MinusIconCircle className="w-5 h-5"/></button>
                    <button title={t.zoomInTitle} onClick={() => recordHistory('actionZoom', { editZoom: Math.min(10, currentEditState.editZoom * 1.1) })} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><PlusIconCircle className="w-5 h-5"/></button>
                    <div className="w-px h-6 bg-gray-600"></div>
                    <div className="flex items-center space-x-2">
                        <label htmlFor="straighten" className="text-sm text-gray-300">{t.straightenLabel}</label>
                        <input type="range" id="straighten" min="-15" max="15" step="0.5" value={currentEditState.straightenAngle} onChange={e => recordHistory('actionStraighten', { straightenAngle: parseFloat(e.target.value) })} className="w-32"/>
                        <span className="text-xs w-12 text-gray-400 text-center">{currentEditState.straightenAngle.toFixed(1)}°</span>
                    </div>
                    <div className="w-px h-6 bg-gray-600"></div>
                    <button title={t.filtersTitle} onClick={() => {setShowFiltersPanel(s => !s); setShowAiFiltersPanel(false);}} className={`p-2 rounded-md transition ${showFiltersPanel ? 'bg-yellow-400 text-gray-900' : 'text-gray-300 bg-gray-700 hover:bg-gray-600 hover:text-gray-100'}`}><FilterIcon className="w-5 h-5"/></button>
                    <button title={t.cropTitle} onClick={() => setIsCropping(c => !c)} className={`p-2 rounded-md transition ${isCropping ? 'bg-yellow-400 text-gray-900' : 'text-gray-300 bg-gray-700 hover:bg-gray-600 hover:text-gray-100'}`}><CropIcon className="w-5 h-5"/></button>
                    <div className="w-px h-6 bg-gray-600"></div>
                    <button title={t.resetEditsTitle} onClick={resetEditState} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><ResetIcon className="w-5 h-5"/></button>
                    <button title={t.cancelEditsTitle} onClick={handleCancelEdits} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-red-500 hover:text-white transition"><XIcon className="w-5 h-5"/></button>
                    {currentEditState.aiFilter ? (
                         <button title={t.applyAiFilterTooltip} onClick={handleApplyEdits} className="px-3 py-2 text-sm text-gray-900 bg-yellow-400 rounded-md hover:bg-yellow-300 transition flex items-center space-x-2">
                            <WandIcon className="w-5 h-5"/>
                            <span>{t.applyAiFilterBtn}</span>
                         </button>
                    ) : (
                         <button title={t.applyEditsTitle} onClick={handleApplyEdits} className="p-2 text-gray-900 bg-yellow-400 rounded-md hover:bg-yellow-300 transition"><CheckIcon className="w-5 h-5"/></button>
                    )}
                </div>
            </div>
            <HistoryPanel history={history} currentIndex={historyIndex} onJump={setHistoryIndex} />
         </>
      )}
      {isMasking && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50 p-2 flex justify-center items-center flex-wrap gap-3 bg-gray-800 rounded-lg shadow-lg border border-gray-700">
            <span className='text-sm font-medium text-gray-300 whitespace-nowrap'>{t.brushSizeLabel}:</span>
            <input type="range" min="5" max="150" value={brushSize} onChange={e => setBrushSize(parseInt(e.target.value, 10))} className="w-32 accent-yellow-400"/>
            <span className="text-xs w-10 text-gray-400">{brushSize}px</span>
            <div className="w-px h-6 bg-gray-600"></div>
            <button onClick={handleClearMask} title={t.clearMaskBtn} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 hover:text-gray-100 transition"><ClearIcon className="w-5 h-5"/></button>
            <button onClick={handleCancelMask} title={t.cancelMaskBtn} className="p-2 text-gray-300 bg-gray-700 rounded-md hover:bg-red-500 hover:text-white transition"><XIcon className="w-5 h-5"/></button>
            <button onClick={handleApplyMask} title={t.applyMaskBtn} className="p-2 text-gray-900 bg-yellow-400 rounded-md hover:bg-yellow-300 transition"><CheckIcon className="w-5 h-5"/></button>
        </div>
      )}
      <div 
        ref={containerRef}
        className={`w-full flex-grow bg-black/20 rounded-lg flex items-center justify-center overflow-hidden shadow-2xl relative ${hasImage && appMode === 'single' ? (isMasking ? 'cursor-none' : (isCropping ? 'cursor-crosshair' : (isPanning ? 'cursor-grabbing' : 'cursor-grab'))) : 'cursor-default'}`}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseEnter={() => { if(isMasking) setIsMouseInPanel(true); }}
        onMouseLeave={(e) => {
            handleMouseUpOrLeave(e);
            if(isMasking) setIsMouseInPanel(false);
        }}
      >
        {isCropping && (
            <div 
                className="absolute inset-0 z-40"
                onMouseDown={handleCropMouseDown}
                onMouseMove={handleCropMouseMove}
                onMouseUp={handleCropMouseUp}
                onMouseLeave={handleCropMouseUp}
            />
        )}
        {renderContent()}
      </div>
      {hasImage && !inSpecialMode && appMode === 'single' && (
        <div 
            className="flex-shrink-0 mt-4 z-10 p-2 flex justify-center items-center flex-wrap gap-2 bg-gray-800 rounded-lg shadow-lg border border-gray-700"
        >
          <button onMouseDown={(e) => e.stopPropagation()} onClick={() => setIsEditing(true)} disabled={isVideoResult} className={`px-3 py-1 text-sm rounded-md transition whitespace-nowrap bg-gray-700 text-gray-300 hover:bg-gray-600 flex items-center space-x-2 disabled:opacity-40 disabled:cursor-not-allowed`}>
            <EditIcon className="w-4 h-4" />
            <span>{t.editBtn}</span>
          </button>
           <button onMouseDown={(e) => e.stopPropagation()} onClick={() => setIsMasking(true)} disabled={isVideoResult || promptMode !== 'retouch'} className={`px-3 py-1 text-sm rounded-md transition whitespace-nowrap bg-gray-700 text-gray-300 hover:bg-gray-600 flex items-center space-x-2 disabled:opacity-40 disabled:cursor-not-allowed`}>
            <BrushIcon className="w-4 h-4" />
            <span>{t.maskBtn}</span>
          </button>
          <div className="w-px h-5 bg-gray-600 mx-1"></div>
          <span className='text-sm font-medium text-gray-300 whitespace-nowrap'>{t.viewLabel}:</span>
          <button 
            onMouseDown={(e) => e.stopPropagation()} 
            onClick={() => setComparisonMode('slider')} 
            disabled={isComparisonDisabled}
            className={`px-3 py-1 text-sm rounded-md transition whitespace-nowrap ${comparisonMode === 'slider' && !isComparisonDisabled ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'} disabled:opacity-40 disabled:cursor-not-allowed`}
          >{t.sliderBtn}</button>
          <button 
            onMouseDown={(e) => e.stopPropagation()} 
            onClick={() => setComparisonMode('side')} 
            disabled={isComparisonDisabled}
            className={`px-3 py-1 text-sm rounded-md transition whitespace-nowrap ${comparisonMode === 'side' && !isComparisonDisabled ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'} disabled:opacity-40 disabled:cursor-not-allowed`}
            >{t.sideBySideBtn}</button>
          <div className="w-px h-5 bg-gray-600 mx-1"></div>
          <span className='text-sm font-medium text-gray-300 whitespace-nowrap'>{t.zoomLabel}:</span>
          <button onMouseDown={(e) => e.stopPropagation()} onClick={fitAll} className="px-3 py-1 text-sm rounded-md bg-gray-700 text-gray-300 hover:bg-gray-600 whitespace-nowrap">{t.fitBtn}</button>
          <button onMouseDown={(e) => e.stopPropagation()} onClick={fitToHeight} className="px-3 py-1 text-sm rounded-md bg-gray-700 text-gray-300 hover:bg-gray-600 whitespace-nowrap">{t.fitHBtn}</button>
          <button onMouseDown={(e) => e.stopPropagation()} onClick={() => setZoomAndCenter(0.5)} className="px-3 py-1 text-sm rounded-md bg-gray-700 text-gray-300 hover:bg-gray-600 whitespace-nowrap">50%</button>
          <button onMouseDown={(e) => e.stopPropagation()} onClick={() => setZoomAndCenter(1)} className="px-3 py-1 text-sm rounded-md bg-gray-700 text-gray-300 hover:bg-gray-600 whitespace-nowrap">100%</button>
          <button onMouseDown={(e) => e.stopPropagation()} onClick={() => setZoomAndCenter(2)} className="px-3 py-1 text-sm rounded-md bg-gray-700 text-gray-300 hover:bg-gray-600 whitespace-nowrap">200%</button>
           <span className='text-sm w-16 text-left font-medium text-gray-400 ml-1 whitespace-nowrap'>({(zoom * 100).toFixed(0)}%)</span>
        </div>
      )}
      {detailedAnalysis && (
        <div className="absolute inset-0 bg-black/80 z-[60] flex items-center justify-center p-4" onClick={onCloseAnalysis}>
            <div 
                className="bg-gray-800 border border-gray-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center p-4 border-b border-gray-700 flex-shrink-0">
                    <h2 className="text-xl font-bold text-yellow-300">{t.detailedAnalysisTitle}</h2>
                    <button onClick={onCloseAnalysis} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>

                <div className="p-6 overflow-y-auto" style={{ whiteSpace: 'pre-wrap' }}>
                  {analysisContent.split('\n').map((line, i) => {
                      if (line.startsWith('### ')) {
                        return <h3 key={i} className="text-lg font-semibold text-gray-200 mt-4 mb-2">{line.substring(4)}</h3>;
                      }
                      if (line.startsWith('- ')) {
                        return (
                          <div key={i} className="flex items-start text-gray-300 pl-2">
                            <span className="mr-2 mt-1 text-yellow-400">&bull;</span>
                            <p className="flex-1">{line.substring(2)}</p>
                          </div>
                        );
                      }
                      const boldTitleMatch = line.match(/^\*\*(.*?)\*\*:\s*(.*)/);
                      if (boldTitleMatch) {
                        const [, title, content] = boldTitleMatch;
                        return (
                          <div key={i} className="text-gray-300 mb-2">
                            <p>
                              <strong className="font-semibold text-gray-100">{title}:</strong>
                              <span className="ml-2">{content}</span>
                            </p>
                          </div>
                        );
                      }
                      if (line.trim()) {
                        return <p key={i} className="text-gray-300">{line}</p>
                      }
                      return null;
                    })}
                </div>
                
                <div className="flex-shrink-0 p-4 border-t border-gray-700 space-y-2">
                    <h3 className="text-base font-semibold text-gray-200">Recommended Prompt:</h3>
                    <div className="bg-gray-900 p-3 rounded-md">
                        <code className="text-sm text-gray-300 whitespace-pre-wrap">{analysisPrompt}</code>
                    </div>
                    <div className="flex justify-end pt-2">
                        <button 
                            onClick={() => onCopyToPrompt(analysisPrompt)} 
                            disabled={!analysisPrompt}
                            className="py-2 px-4 bg-yellow-400 text-gray-900 rounded-lg hover:bg-yellow-300 transition font-bold whitespace-nowrap disabled:bg-gray-600 disabled:cursor-not-allowed"
                        >
                            {t.copyAnalysisToPrompt}
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}
    </main>
  );
};

export default CenterPanel;