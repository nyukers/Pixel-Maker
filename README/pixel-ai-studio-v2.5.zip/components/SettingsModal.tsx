
import React, { useRef } from 'react';
import t from '../locales/en';
import { XIcon } from './icons/XIcon';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  systemInstruction: string;
  onSystemInstructionChange: (value: string) => void;
  stylesUrl: string;
  onStylesUrlChange: (value: string) => void;
  onLoadPromptsFromFileContent: (content: string) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
    isOpen, 
    onClose, 
    systemInstruction, 
    onSystemInstructionChange,
    stylesUrl,
    onStylesUrlChange,
    onLoadPromptsFromFileContent,
}) => {
  const systemInstructionFileInputRef = useRef<HTMLInputElement>(null);
  const promptsFileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) {
    return null;
  }

  const handleLoadSystemInstructionFromFileClick = () => {
    systemInstructionFileInputRef.current?.click();
  };

  const handleSystemInstructionFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'text/plain') {
        alert("Please select a valid .txt file.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target?.result as string;
        onSystemInstructionChange(text);
    };
    reader.onerror = (e) => {
        console.error("Failed to read file", e);
        alert("Error reading file.");
    };
    reader.readAsText(file);

    // Reset file input to allow re-uploading the same file
    if(event.target) {
      event.target.value = '';
    }
  };

  const handleLoadPromptsFromFileClick = () => {
    promptsFileInputRef.current?.click();
  };

  const handlePromptsFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const isCsv = file.type === 'text/csv' || file.name.endsWith('.csv');
    const isTxt = file.type === 'text/plain' || file.name.endsWith('.txt');

    if (!isCsv && !isTxt) {
        alert("Please select a valid .csv or .txt file.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target?.result as string;
        onLoadPromptsFromFileContent(text);
        onClose();
    };
    reader.onerror = (e) => {
        console.error("Failed to read file", e);
        alert("Error reading file.");
    };
    reader.readAsText(file);

    if (event.target) {
        event.target.value = '';
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/75 flex items-center justify-center z-50"
      aria-modal="true"
      role="dialog"
      onClick={onClose}
    >
      <div
        className="bg-gray-800 p-6 rounded-xl shadow-2xl border border-gray-700 w-full max-w-lg text-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-300">{t.settingsTitle}</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        
        <div className="space-y-6">
            <div>
                <div className="flex justify-between items-center mb-2">
                    <label htmlFor="system-instruction-input" className="block text-sm font-medium text-gray-300">
                        {t.systemInstructionLabel}
                    </label>
                    <button
                        onClick={handleLoadSystemInstructionFromFileClick}
                        className="text-xs text-yellow-300 hover:text-yellow-200 underline focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded"
                        title={t.loadFromFileTooltip}
                    >
                        {t.loadFromFileBtn}
                    </button>
                </div>
                <textarea
                    id="system-instruction-input"
                    rows={3}
                    value={systemInstruction}
                    onChange={(e) => onSystemInstructionChange(e.target.value)}
                    placeholder={t.systemInstructionPlaceholder}
                    className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 text-gray-100 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
                />
                <p className="text-xs text-gray-400 mt-2">{t.systemInstructionTooltip}</p>
            </div>
            <div>
                <div className="flex justify-between items-center mb-2">
                    <label htmlFor="styles-url-input" className="block text-sm font-medium text-gray-300">{t.stylesUrlLabel}</label>
                    <button
                        onClick={handleLoadPromptsFromFileClick}
                        className="text-xs text-yellow-300 hover:text-yellow-200 underline focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded"
                        title={t.loadPromptsFromFileTooltip}
                    >
                        {t.loadFromFileBtn}
                    </button>
                </div>
                 <input
                    id="styles-url-input"
                    type="url"
                    value={stylesUrl}
                    onChange={(e) => onStylesUrlChange(e.target.value)}
                    placeholder={t.stylesUrlPlaceholder}
                    className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 text-gray-100 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
                />
                <p className="text-xs text-gray-400 mt-2">{t.stylesUrlTooltip}</p>
            </div>
        </div>

        <input
            type="file"
            ref={systemInstructionFileInputRef}
            onChange={handleSystemInstructionFileChange}
            accept=".txt"
            className="hidden"
        />
        <input
            type="file"
            ref={promptsFileInputRef}
            onChange={handlePromptsFileChange}
            accept=".txt,.csv"
            className="hidden"
        />

        <div className="mt-8 flex justify-end">
            <button 
                onClick={onClose} 
                className="py-2 px-6 bg-yellow-400 text-gray-900 rounded-lg hover:bg-yellow-300 transition font-bold"
            >
                {t.okBtn}
            </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
