// FIX: Removed self-import of `AnalysisResult` that caused a declaration conflict.
export interface ResultItem {
  id: string;
  imageUrl: string; // Used as thumbnail or for image results
  videoUrl?: string; // For video results
  mimeType: string;
  prompt: string;
  sourceImageUrl?: string; // The URL of the image used to generate this result
  width?: number;
  height?: number;
  isQuickUpscaled?: boolean;
  isAiUpscaled?: boolean;
}

export type ComparisonMode = 'side' | 'slider' | 'single';

export type PromptMode = 'retouch' | 'imagination' | 'animation' | 'generate';

export type AspectRatio = '16:9' | '9:16' | '1:1' | '4:3' | '3:4';

export type AppMode = 'single' | 'analyze';

export type AnalysisItemStatus = 'pending' | 'processing' | 'completed' | 'error';

export interface AnalysisResult {
  composition: string;
  subject: string;
  background: string;
  style: string;
  artist?: string;
  mood: string;
  era?: string;
}

export interface CreativeIdea {
  title: string;
  description: string;
  prompt: string;
}

export interface AnalysisItem {
  id: string;
  file: File;
  originalDataUrl: string;
  mimeType: string;
  analysisResult: AnalysisResult | null;
  status: AnalysisItemStatus;
  error?: string;
}

export interface Pan {
  x: number;
  y: number;
}

export interface PresetPrompt {
  id: string;
  prompt: string;
}

export interface LoadedPreset extends PresetPrompt {
  displayName: string;
  category: PromptMode;
}

export type FilterType = 'none' | 'sepia' | 'grayscale' | 'vintage';

export interface FilterState {
  type: FilterType;
  intensity: number; // 0-100
}

export interface CropBox {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
}

export interface AiFilterState {
  type: string; // Corresponds to an ID in AI_FILTER_PRESETS
  intensity: number; // 0-100
}

export interface EditState {
  actionKey: string;
  rotation: number;
  scaleX: number;
  straightenAngle: number;
  editZoom: number;
  editPan: Pan;
  cropBox: CropBox | null;
  filter: FilterState;
  aiFilter: AiFilterState | null;
}

export interface Action {
  id: string;
  name: string;
  steps: string[]; // Array of preset prompt IDs
}