export interface EditResponse {
  html: string;
}

export enum EditorStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export type Platform = 'blogger' | 'facebook' | 'instagram' | 'linkedin' | 'medium' | 'telegram';
