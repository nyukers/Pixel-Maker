import React, { useState, useMemo } from 'react';
import { EditorStatus } from '../types';
import { Code, Eye, Copy, Check, FileJson, ClipboardCheck, Languages } from 'lucide-react';
import TurndownService from 'turndown';

interface PreviewProps {
  htmlContent: string;
  status: EditorStatus;
  onTranslate?: () => void;
  isTranslating?: boolean;
}

export const Preview: React.FC<PreviewProps> = ({ htmlContent, status, onTranslate, isTranslating }) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'html' | 'markdown'>('preview');
  const [copied, setCopied] = useState(false);

  // Initialize Markdown converter
  const turndownService = useMemo(() => new TurndownService({
    headingStyle: 'atx',
    codeBlockStyle: 'fenced',
    bulletListMarker: '-'
  }), []);

  // Convert HTML to Markdown whenever htmlContent changes
  const markdownContent = useMemo(() => {
    if (!htmlContent) return '';
    try {
        return turndownService.turndown(htmlContent);
    } catch (e) {
        console.error("Markdown conversion failed", e);
        return 'Error converting to Markdown.';
    }
  }, [htmlContent, turndownService]);

  const handleCopy = () => {
    let textToCopy = '';
    if (activeTab === 'preview' || activeTab === 'html') {
        textToCopy = htmlContent;
    } else {
        textToCopy = markdownContent;
    }

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getCopyLabel = () => {
      if (copied) return 'Copied Successfully!';
      switch (activeTab) {
          case 'markdown': return 'Copy Markdown';
          case 'html': return 'Copy HTML Code';
          default: return 'Copy HTML Content';
      }
  };

  if (status === EditorStatus.IDLE) {
    return (
        <div className="flex flex-col h-full items-center justify-center bg-slate-50/50 dark:bg-slate-900/50 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 text-slate-400 dark:text-slate-500 p-8">
            <Eye className="w-12 h-12 mb-3 opacity-20" />
            <p className="text-sm font-medium">Preview will appear here</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-xl shadow-md border border-slate-300 dark:border-slate-800 overflow-hidden relative transition-colors duration-300">
      {/* Header / Tabs */}
      <div className="flex items-center justify-between px-2 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
        <div className="flex gap-1 bg-slate-200 dark:bg-slate-800 p-1 rounded-lg border border-slate-300 dark:border-slate-700 w-full sm:w-auto justify-center">
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
              activeTab === 'preview'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-300 dark:border-slate-600'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 border border-transparent'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span className="sm:inline">Preview</span>
          </button>
          <button
            onClick={() => setActiveTab('html')}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
              activeTab === 'html'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-300 dark:border-slate-600'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 border border-transparent'
            }`}
          >
            <Code className="w-4 h-4" />
            <span className="sm:inline">HTML</span>
          </button>
          <button
            onClick={() => setActiveTab('markdown')}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
              activeTab === 'markdown'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-300 dark:border-slate-600'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 border border-transparent'
            }`}
          >
            <FileJson className="w-4 h-4" />
            <span className="sm:inline">Markdown</span>
          </button>
        </div>
        
        {onTranslate && (
          <button
            onClick={onTranslate}
            disabled={isTranslating || !htmlContent}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
              isTranslating || !htmlContent
                ? 'text-slate-400 dark:text-slate-600 cursor-not-allowed'
                : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30'
            }`}
            title="Translate between English and Ukrainian"
          >
            {isTranslating ? (
              <div className="w-4 h-4 border-2 border-indigo-400/30 border-t-indigo-400 rounded-full animate-spin" />
            ) : (
              <Languages className="w-4 h-4" />
            )}
            <span>Translate</span>
          </button>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto relative bg-slate-50/30 dark:bg-slate-950/30">
        {status === EditorStatus.LOADING && (
            <div className="absolute inset-0 z-10 bg-white/50 dark:bg-slate-900/50 backdrop-blur-[1px] flex items-center justify-center">
                 <div className="flex flex-col items-center animate-pulse">
                    <div className="h-4 w-3/4 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                    <div className="h-4 w-1/2 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                    <div className="h-4 w-5/6 bg-slate-200 dark:bg-slate-700 rounded"></div>
                 </div>
            </div>
        )}

        {activeTab === 'preview' && (
          <div className="p-8 prose prose-slate dark:prose-invert max-w-none prose-headings:font-bold prose-h1:text-3xl prose-h2:text-xl prose-a:text-indigo-600 dark:prose-a:text-indigo-400 prose-p:text-slate-600 dark:prose-p:text-slate-300 prose-p:leading-7">
             <div dangerouslySetInnerHTML={{ __html: htmlContent || '<p class="text-slate-400 italic">Waiting for generation...</p>' }} />
          </div>
        )}
        
        {activeTab === 'html' && (
          <pre className="p-4 text-xs font-mono text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed h-full overflow-auto">
            {htmlContent}
          </pre>
        )}

        {activeTab === 'markdown' && (
          <pre className="p-4 text-xs font-mono text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed h-full overflow-auto">
            {markdownContent}
          </pre>
        )}
      </div>

      {/* Footer with Copy Button */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
         <div className="flex justify-end mb-2 px-1 opacity-0 pointer-events-none" aria-hidden="true">
             <span className="text-[10px] font-semibold uppercase tracking-wider">Placeholder</span>
         </div>
         <button
            onClick={handleCopy}
            disabled={!htmlContent || status === EditorStatus.LOADING}
            className={`w-full py-3 px-4 rounded-lg flex items-center justify-center gap-2 font-semibold transition-all shadow-md border
              ${!htmlContent || status === EditorStatus.LOADING
                ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 border-slate-300 dark:border-slate-700 cursor-not-allowed shadow-none'
                : copied
                    ? 'bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white hover:shadow-lg scale-[1.02]' 
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-800 hover:border-slate-700 text-white dark:bg-slate-200 dark:text-slate-900 dark:border-slate-200 dark:hover:bg-white hover:shadow-lg active:scale-[0.99]'
              }`}
         >
            {copied ? <Check className="w-5 h-5" /> : <ClipboardCheck className="w-5 h-5" />}
            {getCopyLabel()}
         </button>
      </div>
    </div>
  );
};
