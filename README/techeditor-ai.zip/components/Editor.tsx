import React, { useState, useRef } from 'react';
import { EditorStatus, Platform } from '../types';
import { Upload, FileText, X, Sparkles, AlertCircle, PenTool, Facebook, Instagram, Trash2, Linkedin, Send, BookOpen } from 'lucide-react';

interface EditorProps {
  value: string;
  onChange: (val: string) => void;
  onGenerate: () => void;
  status: EditorStatus;
  platform: Platform;
  setPlatform: (p: Platform) => void;
}

export const Editor: React.FC<EditorProps> = ({ value, onChange, onGenerate, status, platform, setPlatform }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== "text/plain" && !file.name.endsWith('.md') && !file.name.endsWith('.txt')) {
        alert("Please upload a .txt or .md file");
        return;
    }

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result;
      if (typeof text === 'string') {
        onChange(text);
      }
    };
    reader.readAsText(file);
  };

  const clearFile = () => {
    setFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const clearAll = () => {
    onChange('');
    setFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const platforms = [
    { id: 'blogger', label: 'Blogger', icon: PenTool, color: 'text-orange-600 dark:text-orange-400' },
    { id: 'facebook', label: 'Facebook', icon: Facebook, color: 'text-blue-600 dark:text-blue-400' },
    { id: 'instagram', label: 'Instagram', icon: Instagram, color: 'text-pink-600 dark:text-pink-400' },
    { id: 'linkedin', label: 'LinkedIn', icon: Linkedin, color: 'text-blue-700 dark:text-blue-300' },
    { id: 'telegram', label: 'Telegram', icon: Send, color: 'text-sky-500 dark:text-sky-400' },
    { id: 'medium', label: 'Medium', icon: BookOpen, color: 'text-slate-800 dark:text-slate-200' },
  ] as const;

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-xl shadow-md border border-slate-300 dark:border-slate-800 overflow-hidden transition-colors duration-300">
      <div className="flex flex-col border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          {/* Top Bar: Title & Upload */}
          <div className="flex items-center justify-between px-4 py-3">
            <h2 className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Input Draft
            </h2>
            <div className="flex items-center gap-2">
            
            {value.length > 0 && (
                <button 
                    onClick={clearAll}
                    className="mr-2 text-xs flex items-center gap-1 text-slate-500 hover:text-red-600 dark:text-slate-500 dark:hover:text-red-400 transition-colors font-medium border border-transparent hover:bg-white dark:hover:bg-slate-800 hover:border-slate-200 dark:hover:border-slate-700 rounded px-2 py-1"
                    title="Clear text"
                >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear
                </button>
            )}

            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                className="hidden"
                accept=".txt,.md"
            />
            {fileName ? (
                <div className="flex items-center gap-1 text-xs bg-white dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-2 py-1 rounded-md border border-indigo-200 dark:border-indigo-800 shadow-sm">
                    <span className="truncate max-w-[100px]">{fileName}</span>
                    <button onClick={clearFile} className="hover:text-indigo-900 dark:hover:text-indigo-100"><X className="w-3 h-3"/></button>
                </div>
            ) : (
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs flex items-center gap-1 text-slate-600 dark:text-slate-400 bg-white dark:bg-transparent border border-slate-300 dark:border-transparent hover:border-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 px-2.5 py-1.5 rounded-md transition-all shadow-sm dark:shadow-none"
                >
                    <Upload className="w-3 h-3" />
                    Load File
                </button>
            )}
            </div>
          </div>

          {/* Platform Selector */}
          <div className="px-4 pb-3 grid grid-cols-3 gap-2">
            {platforms.map((p) => (
                <button
                    key={p.id}
                    onClick={() => setPlatform(p.id as Platform)}
                    className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                        platform === p.id 
                        ? `bg-white dark:bg-slate-800 ${p.color} shadow-sm border border-slate-300 dark:border-slate-700 ring-1 ring-slate-200 dark:ring-0` 
                        : 'text-slate-500 dark:text-slate-400 border border-transparent hover:bg-white dark:hover:bg-slate-800/50 hover:border-slate-200 dark:hover:border-slate-700'
                    }`}
                >
                    <p.icon className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{p.label}</span>
                </button>
            ))}
          </div>
      </div>
      
      <div className="flex-1 p-4 relative">
        <textarea
          className="w-full h-full resize-none outline-none text-slate-600 dark:text-slate-300 bg-transparent leading-relaxed font-mono text-sm placeholder:text-slate-400 dark:placeholder:text-slate-600"
          placeholder="Paste your raw blog post draft here..."
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={status === EditorStatus.LOADING}
        />
        {value.length === 0 && !fileName && (
           <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-slate-300 dark:text-slate-600">
              <div className="text-center">
                  <FileText className="w-12 h-12 mx-auto mb-2 opacity-20" />
                  <p className="text-sm font-medium">Type or upload a draft to begin</p>
              </div>
           </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
        <div className="flex justify-end mb-2 px-1">
             <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 transition-colors">
                {new Intl.NumberFormat('en-US').format(value.length)} characters
             </span>
        </div>
        <button
          onClick={onGenerate}
          disabled={status === EditorStatus.LOADING || value.trim().length === 0}
          className={`w-full py-3 px-4 rounded-lg flex items-center justify-center gap-2 font-semibold transition-all shadow-md border
            ${status === EditorStatus.LOADING 
              ? 'bg-indigo-400 dark:bg-indigo-500 border-indigo-400 dark:border-indigo-500 cursor-wait text-white' 
              : value.trim().length === 0
                ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 border-slate-300 dark:border-slate-700 cursor-not-allowed shadow-none'
                : 'bg-indigo-600 hover:bg-indigo-700 border-indigo-600 hover:border-indigo-700 text-white hover:shadow-lg active:scale-[0.99]'
            }`}
        >
          {status === EditorStatus.LOADING ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Processing Draft...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Generate {platform.charAt(0).toUpperCase() + platform.slice(1)} Post
            </>
          )}
        </button>
        {status === EditorStatus.ERROR && (
             <div className="mt-2 text-xs text-red-500 dark:text-red-400 flex items-center gap-1 justify-center">
                <AlertCircle className="w-3 h-3" />
                An error occurred. Please check your API key or try again.
             </div>
        )}
      </div>
    </div>
  );
};
