
import React, { useState, useCallback, useEffect } from 'react';
import { Editor } from './components/Editor';
import { Preview } from './components/Preview';
import { editBlogPost } from './services/geminiService';
import { EditorStatus, Platform } from './types';
import { Bot, Zap, Moon, Sun } from 'lucide-react';

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [outputHtml, setOutputHtml] = useState('');
  const [status, setStatus] = useState<EditorStatus>(EditorStatus.IDLE);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [platform, setPlatform] = useState<Platform>('blogger');

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleGenerate = useCallback(async () => {
    if (!inputText.trim()) return;

    setStatus(EditorStatus.LOADING);
    try {
      const generatedHtml = await editBlogPost(inputText, platform);
      setOutputHtml(generatedHtml);
      setStatus(EditorStatus.SUCCESS);
    } catch (error) {
      console.error(error);
      setStatus(EditorStatus.ERROR);
    }
  }, [inputText, platform]);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex flex-col transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-300 dark:border-slate-800 sticky top-0 z-30 transition-colors duration-300 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-md shadow-indigo-200 dark:shadow-none">
                <Bot className="w-5 h-5" />
            </div>
            <div>
                <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight leading-none">TechEditor<span className="text-indigo-600 dark:text-indigo-400">AI</span></h1>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider">Blog Automation Tool</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="hidden sm:flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-full border border-slate-300 dark:border-slate-700 shadow-sm dark:shadow-none">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>Powered by Gemini 3</span>
             </div>
             
             <button
               onClick={() => setIsDarkMode(!isDarkMode)}
               className="p-2 rounded-lg text-slate-500 dark:text-slate-400 bg-white dark:bg-transparent border border-slate-300 dark:border-transparent hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm dark:shadow-none"
               aria-label="Toggle theme"
             >
               {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
             </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-8rem)]">
            {/* Left Column: Input */}
            <section className="h-full min-h-[400px]">
                <Editor 
                    value={inputText} 
                    onChange={setInputText} 
                    onGenerate={handleGenerate}
                    status={status}
                    platform={platform}
                    setPlatform={setPlatform}
                />
            </section>

            {/* Right Column: Output */}
            <section className="h-full min-h-[400px]">
                <Preview 
                    htmlContent={outputHtml}
                    status={status}
                />
            </section>
        </div>
      </main>

      {/* Mobile Footer Spacing for sticky buttons if needed, currently mostly desktop optimized */}
      <div className="lg:hidden h-4"></div>
    </div>
  );
};

export default App;
