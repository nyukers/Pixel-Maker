
import React from 'react';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import StyleSelector from './components/StyleSelector';
import Spinner from './components/Spinner';
import ImageEditor from './components/ImageEditor';
import { generateHeadshot, editImage } from './services/geminiService';
import type { GenerationResult } from './services/geminiService';
import { ASPECT_RATIOS, STYLE_OPTIONS, UKRAINIAN_REGIONS, VYSHYVANKA_COLORS, VYSHYVANKA_FLOWERS, ACTION_POSES, AGENT_POSES, FANTASY_ROLES, MYTHICAL_PARTNERS, HAIRSTYLE_OPTIONS, HAIR_COLOR_OPTIONS, DIRECTOR_STYLES, WRITER_STYLES } from './constants';
import type { StyleOption, AspectRatio } from './types';

interface UploadedImage {
  dataUrl: string;
  mimeType: string;
}

// Default fallback aspect ratio to prevent crashes if constants fail to load
const DEFAULT_ASPECT_RATIO: AspectRatio = { id: 'square', name: 'Square', prompt: '1:1' };

function App() {
  const [originalImages, setOriginalImages] = React.useState<UploadedImage[]>([]);
  const [history, setHistory] = React.useState<GenerationResult[]>([]);
  const [historyIndex, setHistoryIndex] = React.useState<number>(-1);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [editPrompt, setEditPrompt] = React.useState<string>('');
  
  // Safe initialization of aspect ratio
  const [selectedAspectRatio, setSelectedAspectRatio] = React.useState<AspectRatio>(() => {
    if (Array.isArray(ASPECT_RATIOS) && ASPECT_RATIOS.length > 0) {
      return ASPECT_RATIOS[0];
    }
    return DEFAULT_ASPECT_RATIO;
  });

  const [cameraFocusPoint, setCameraFocusPoint] = React.useState({ x: 0.5, y: 0.5 });
  const [blurLevel, setBlurLevel] = React.useState<number>(0);
  const [customStyles, setCustomStyles] = React.useState<StyleOption[]>([]);
  const [selectedStyleId, setSelectedStyleId] = React.useState<string>('');
  
  // Initialize with the first pose (shared state for multiple style lists)
  const [selectedPoseId, setSelectedPoseId] = React.useState<string>(ACTION_POSES[0].id);

  // Initialize hair color selection (default to 'original')
  const [selectedHairColorId, setSelectedHairColorId] = React.useState<string>('original');

  const currentHistoryItem = history[historyIndex];
  const generatedImage = currentHistoryItem?.imageUrl ?? null;

  React.useEffect(() => {
    // Sync the edit prompt with the full prompt of the current history item
    const currentPrompt = currentHistoryItem?.fullPrompt ?? '';
    // Format the prompt for display
    const formattedPrompt = currentPrompt
        .replace(/ \*\*/g, '\n**')
        .replace(/^\*\*/, '**')
        .replace(/ IMPORTANT/g, '\nIMPORTANT')
        .replace(/ CRITICAL/g, '\nCRITICAL');
    setEditPrompt(formattedPrompt);
  }, [currentHistoryItem]);

  // Fix for iOS 100vh scroll issue and mobile scroll-to-top on view change
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [isLoading, generatedImage, historyIndex, originalImages.length]);

  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
    });

  const handleImageUpload = React.useCallback(async (files: File[]) => {
    if (files.length > 5) {
        setError("You can upload a maximum of 5 photos.");
        return;
    }
    setIsLoading(true);
    setError(null);
    setHistory([]);
    setHistoryIndex(-1);
    try {
      const dataUrlPromises = files.map(file => fileToBase64(file));
      const dataUrls = await Promise.all(dataUrlPromises);
      const newImages = dataUrls.map((dataUrl, index) => ({
        dataUrl,
        mimeType: files[index].type,
      }));
      setOriginalImages(newImages);
    } catch (e) {
      setError('Failed to read the image files. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const getFocusPointPrompt = React.useCallback((point: { x: number; y: number }): string => {
    const prompts = [];
    if (point.y < 0.33) prompts.push('a high-angle view, looking down on the subject');
    else if (point.y > 0.66) prompts.push('a low-angle hero view, looking up at the subject');
    else prompts.push('an eye-level view');

    if (point.x < 0.4) prompts.push('with the subject framed towards the left');
    else if (point.x > 0.6) prompts.push('with the subject framed towards the right');
    else prompts.push('with the subject centered in the frame');

    return `The camera composition should be ${prompts.join(', ')}.`;
  }, []);

  const handleGenerateHeadshot = React.useCallback(async (style: StyleOption) => {
    if (originalImages.length === 0) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);

    try {
      const imagesPayload = originalImages.map(img => ({
          data: img.dataUrl.split(',')[1],
          mimeType: img.mimeType,
      }));
      const cameraAnglePrompt = getFocusPointPrompt(cameraFocusPoint);
      
      let finalStylePrompt = style.prompt;
      
      // Determine a nice display name for the Result Screen
      let displayStyleName = style.name;

      // LOGIC FOR RANDOM REGION SURPRISE
      if (style.id === 'ukraine-region-surprise' && UKRAINIAN_REGIONS.length > 0) {
        const randomRegion = UKRAINIAN_REGIONS[Math.floor(Math.random() * UKRAINIAN_REGIONS.length)];
        // Replace placeholders in the prompt
        finalStylePrompt = finalStylePrompt
            .replace('{{REGION_NAME}}', randomRegion.name)
            .replace('{{REGION_DESC}}', randomRegion.desc);
      }
      
      // LOGIC FOR RANDOM COLOR VYSHYVANKA
      if (style.id === 'ukraine-modern-random' && VYSHYVANKA_COLORS.length > 0) {
        const randomColor = VYSHYVANKA_COLORS[Math.floor(Math.random() * VYSHYVANKA_COLORS.length)];
        // Replace placeholders
        finalStylePrompt = finalStylePrompt
            .replace('{{COLOR_DESC}}', randomColor.desc)
            .replace('{{BG_DESC}}', randomColor.bg)
            .replace('{{LIGHT_DESC}}', randomColor.light);
      }
      
      // LOGIC FOR RANDOM FLOWER VYSHYVANKA
      if (style.id === 'ukraine-modern-flower' && VYSHYVANKA_FLOWERS.length > 0) {
        const randomFlower = VYSHYVANKA_FLOWERS[Math.floor(Math.random() * VYSHYVANKA_FLOWERS.length)];
        // Completely override the prompt
        finalStylePrompt = randomFlower.prompt;
      }

      // LOGIC FOR URBAN ACTION POSE
      if (style.id === 'urban-fullbody-test') {
         // Fallback to first pose if ID invalid (or from another list)
         const selectedPose = ACTION_POSES.find(p => p.id === selectedPoseId) || ACTION_POSES[0];
         finalStylePrompt = finalStylePrompt.replace('{{ACTION_POSE}}', selectedPose.prompt);
         displayStyleName = `Urban Action: ${selectedPose.name}`;
      }
      
      // LOGIC FOR AGENT ACTION POSE
      if (style.id === 'secret-agent-action') {
         // Fallback to first pose if ID invalid (or from another list)
         const selectedPose = AGENT_POSES.find(p => p.id === selectedPoseId) || AGENT_POSES[0];
         finalStylePrompt = finalStylePrompt.replace('{{ACTION_POSE}}', selectedPose.prompt);
         displayStyleName = `Secret Agent: ${selectedPose.name}`;
      }
      
      // LOGIC FOR FANTASY HERO POSE
      if (style.id === 'fantasy-hero') {
         // Fallback to first pose if ID invalid (or from another list)
         const selectedRole = FANTASY_ROLES.find(p => p.id === selectedPoseId) || FANTASY_ROLES[0];
         finalStylePrompt = finalStylePrompt.replace('{{FANTASY_ROLE}}', selectedRole.prompt);
         displayStyleName = `Fantasy Hero: ${selectedRole.name}`;
      }
      
      // LOGIC FOR CINEMATIC HOLLYWOOD DIRECTOR
      if (style.id === 'cinematic-hollywood') {
         const selectedDirector = DIRECTOR_STYLES.find(p => p.id === selectedPoseId) || DIRECTOR_STYLES[0];
         finalStylePrompt = finalStylePrompt
            .replace('{{DIRECTOR_NAME}}', selectedDirector.name)
            .replace('{{DIRECTOR_PROMPT}}', selectedDirector.prompt);
         displayStyleName = `Director: ${selectedDirector.name}`;
      }

      // LOGIC FOR LITERARY UNIVERSE (WRITERS)
      if (style.id === 'literary-universe') {
         const selectedWriter = WRITER_STYLES.find(p => p.id === selectedPoseId) || WRITER_STYLES[0];
         finalStylePrompt = finalStylePrompt
            .replace('{{WRITER_NAME}}', selectedWriter.name)
            .replace('{{WRITER_PROMPT}}', selectedWriter.prompt);
         displayStyleName = `Universe: ${selectedWriter.name}`;
      }

      // LOGIC FOR MYTHICAL SELFIE (SELFIE WITH...)
      if (style.id === 'fun-mythical-selfie') {
        const selectedPartner = MYTHICAL_PARTNERS.find(p => p.id === selectedPoseId) || MYTHICAL_PARTNERS[0];
        finalStylePrompt = `A fun, wide-angle selfie photo featuring TWO characters. Subject 1 is the person from the uploaded photo (STRICTLY preserve their facial identity and likeness). Subject 2 is ${selectedPartner.prompt}. They are posing cheek-to-cheek or side-by-side. The lighting is cinematic.`;
        displayStyleName = `Selfie with: ${selectedPartner.name}`;
      }

      // LOGIC FOR HAIRSTYLE TRY-ON
      if (style.id === 'hairstyle-try-on') {
        const selectedHairstyle = HAIRSTYLE_OPTIONS.find(p => p.id === selectedPoseId) || HAIRSTYLE_OPTIONS[0];
        const selectedColor = HAIR_COLOR_OPTIONS.find(c => c.id === selectedHairColorId) || HAIR_COLOR_OPTIONS[0];
        
        finalStylePrompt = finalStylePrompt
            .replace('{{HAIRSTYLE_PROMPT}}', selectedHairstyle.prompt)
            .replace('{{HAIR_COLOR_PROMPT}}', selectedColor.prompt);
        
        displayStyleName = `💇‍♀️ Style: ${selectedHairstyle.name} | Color: ${selectedColor.name}`;
      }

      const result = await generateHeadshot(
          imagesPayload, 
          finalStylePrompt, 
          selectedAspectRatio.prompt, 
          cameraAnglePrompt,
          selectedAspectRatio.id,
          style.id
      );
      
      // Attach the detailed display name to the result
      const resultWithDisplayName: GenerationResult = {
          ...result,
          styleDisplayName: displayStyleName
      };

      setHistory([resultWithDisplayName]);
      setHistoryIndex(0);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred during image generation.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [originalImages, selectedAspectRatio, cameraFocusPoint, getFocusPointPrompt, selectedPoseId, selectedHairColorId]);

  const handleEditImage = React.useCallback(async () => {
    if (!generatedImage || !editPrompt) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);
    
    try {
      const base64Data = generatedImage.split(',')[1];
      const result = await editImage(base64Data, 'image/png', editPrompt);
      
      // Preserve the display name from the current item
      const resultWithPreservedName: GenerationResult = {
          ...result,
          styleDisplayName: currentHistoryItem?.styleDisplayName
      };

      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, resultWithPreservedName]);
      setHistoryIndex(newHistory.length);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred during image editing.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [generatedImage, editPrompt, history, historyIndex, currentHistoryItem]);

  const handleApplyEffect = React.useCallback(async (effectPrompt: string) => {
    if (!generatedImage) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);

    try {
      const base64Data = generatedImage.split(',')[1];
      const result = await editImage(base64Data, 'image/png', effectPrompt);
      
      // Preserve the display name from the current item
      const resultWithPreservedName: GenerationResult = {
          ...result,
          styleDisplayName: currentHistoryItem?.styleDisplayName
      };

      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, resultWithPreservedName]);
      setHistoryIndex(newHistory.length);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [generatedImage, history, historyIndex, currentHistoryItem]);

  const handleBlurChange = React.useCallback(async (level: number) => {
    if (!generatedImage) return;
    setBlurLevel(level);
    setIsLoading(true);
    setError(null);
    
    let blurPrompt = "Ensure the entire image is sharp and in deep focus (f/16 aperture). No visible bokeh.";
    if (level === 25) blurPrompt = "Simulate a portrait lens with f/5.6 aperture, creating slight background separation.";
    else if (level === 50) blurPrompt = "Apply a professional portrait look with f/2.8 aperture. Creamy bokeh background.";
    else if (level === 75) blurPrompt = "Create a strong bokeh effect with an f/1.8 aperture simulation.";
    else if (level === 100) blurPrompt = "Apply a dreamy, artistic bokeh effect with an ultra-wide f/1.2 aperture.";

    try {
        const base64Data = generatedImage.split(',')[1];
        const result = await editImage(base64Data, 'image/png', blurPrompt);
        
        // Preserve the display name from the current item
        const resultWithPreservedName: GenerationResult = {
            ...result,
            styleDisplayName: currentHistoryItem?.styleDisplayName
        };

        const newHistory = history.slice(0, historyIndex + 1);
        setHistory([...newHistory, resultWithPreservedName]);
        setHistoryIndex(newHistory.length);
    } catch (e: any) {
        setError(e.message || 'Blur failed.');
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  }, [generatedImage, history, historyIndex, currentHistoryItem]);

  const handleStartOver = React.useCallback(() => {
    setHistory([]);
    setHistoryIndex(-1);
    setError(null);
    setIsLoading(false);
    setBlurLevel(0);
  }, []);
  
  const handleReset = React.useCallback(() => {
    setOriginalImages([]);
    setHistory([]);
    setHistoryIndex(-1);
    setError(null);
    setIsLoading(false);
    setBlurLevel(0);
    setCustomStyles([]);
    setSelectedStyleId('');
    setSelectedPoseId(ACTION_POSES[0].id);
    setSelectedHairColorId('original');
  }, []);

  const handleDownload = React.useCallback(() => {
    if (!currentHistoryItem) return;
    const { imageUrl, fullPrompt, modelName } = currentHistoryItem;
    const img = new Image();
    img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);
        const jpegDataUrl = canvas.toDataURL('image/jpeg', 0.95);
        const base64Jpeg = jpegDataUrl.split(',')[1];
        const binaryStr = atob(base64Jpeg);
        const len = binaryStr.length;
        const jpegBytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) jpegBytes[i] = binaryStr.charCodeAt(i);
        const commentStr = `Pixel AI Photomaker\nPrompt: ${fullPrompt}\nModel: ${modelName}`;
        const encoder = new TextEncoder();
        const commentBytes = encoder.encode(commentStr);
        const commentSegmentLength = commentBytes.length + 2;
        const comSegment = new Uint8Array(4 + commentBytes.length);
        comSegment[0] = 0xFF; comSegment[1] = 0xFE;
        comSegment[2] = commentSegmentLength >> 8; comSegment[3] = commentSegmentLength & 0xFF;
        comSegment.set(commentBytes, 4);
        const newJpegBytes = new Uint8Array(2 + comSegment.length + (jpegBytes.length - 2));
        newJpegBytes.set(jpegBytes.subarray(0, 2), 0);
        newJpegBytes.set(comSegment, 2);
        newJpegBytes.set(jpegBytes.subarray(2), 2 + comSegment.length);
        const blob = new Blob([newJpegBytes], { type: 'image/jpeg' });
        const blobUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        
        // Generate random code (6 chars)
        const randomCode = Math.random().toString(36).substring(2, 8);
        link.download = `pixel-headshot-${randomCode}.jpeg`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
    };
    img.src = imageUrl;
  }, [currentHistoryItem]);

  const handleUndo = React.useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setBlurLevel(0);
    }
  }, [historyIndex]);

  const handleRedo = React.useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setBlurLevel(0);
    }
  }, [historyIndex, history.length]);

  const handleCustomStylesUpload = React.useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
        const text = event.target?.result as string;
        if (!text) return;
        try {
            const lines = text.trim().split(/\r\n|\n/);
            const headerLine = lines.shift()?.trim();
            if (!headerLine) throw new Error('Empty CSV');
            const header = headerLine.toLowerCase().split(',').map(h => h.trim().replace(/"/g, ''));
            const nameIndex = header.indexOf('name');
            const promptIndex = header.indexOf('prompt');
            if (nameIndex === -1 || promptIndex === -1) throw new Error('Invalid columns');
            const newStyles = lines.map((line, index) => {
                if (!line.trim()) return null;
                const columns = line.split(',');
                const name = columns[nameIndex]?.trim().replace(/^"|"$/g, '');
                const prompt = columns[promptIndex]?.trim().replace(/^"|"$/g, '');
                if (!name || !prompt) return null;
                return { id: `custom-${Date.now()}-${index}`, name, prompt };
            }).filter((style): style is StyleOption => style !== null);
            setCustomStyles(prevStyles => [...prevStyles, ...newStyles]);
        } catch (e: any) {
            setError(e.message || 'CSV failed');
        }
    };
    reader.readAsText(file);
}, []);

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  // Render logic safely
  const renderContent = () => {
    if (isLoading && !generatedImage) return <div className="flex-grow flex justify-center items-center"><Spinner /></div>;
    
    if (error) return (
        <div className="flex-grow flex flex-col justify-center items-center text-center p-4">
            <p className="text-red-400 text-lg mb-4">{error}</p>
            <button onClick={handleReset} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Try Again</button>
        </div>
    );
    
    if (generatedImage) {
        // Use the display name stored in the history item, or fallback to default text
        const styleName = currentHistoryItem?.styleDisplayName || 'Custom / Edited';

        return (
            <ImageEditor
                imageSrc={generatedImage!}
                editPrompt={editPrompt}
                onEditPromptChange={setEditPrompt}
                onEditSubmit={handleEditImage}
                onReset={handleStartOver}
                isLoading={isLoading}
                onDownload={handleDownload}
                onApplyEffect={handleApplyEffect}
                onUndo={handleUndo}
                onRedo={handleRedo}
                canUndo={canUndo}
                canRedo={canRedo}
                blurLevel={blurLevel}
                onBlurChange={handleBlurChange}
                styleName={styleName}
            />
        );
    }
    
    if (originalImages.length > 0) return (
      <StyleSelector 
          originalImages={originalImages.map(img => img.dataUrl)} 
          onStyleSelect={handleGenerateHeadshot} 
          selectedAspectRatio={selectedAspectRatio}
          onAspectRatioSelect={setSelectedAspectRatio}
          cameraFocusPoint={cameraFocusPoint}
          onFocusPointChange={setCameraFocusPoint}
          onReset={handleReset}
          onCustomStylesUpload={handleCustomStylesUpload}
          customStyleOptions={customStyles}
          selectedStyleId={selectedStyleId}
          onSelectedStyleIdChange={setSelectedStyleId}
          selectedPoseId={selectedPoseId}
          onPoseSelect={setSelectedPoseId}
          selectedHairColorId={selectedHairColorId}
          onHairColorSelect={setSelectedHairColorId}
      />
    );
    
    return <ImageUploader onImageUpload={handleImageUpload} isLoading={isLoading} />;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col">
      <Header />
      <main className="flex-grow flex flex-col justify-center items-center p-4">
        <div className="w-full flex flex-col justify-center items-center flex-grow">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;
