
import React from 'react';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import StyleSelector from './components/StyleSelector';
import Spinner from './components/Spinner';
import ImageEditor from './components/ImageEditor';
import { generateHeadshot, editImage } from './services/geminiService';
import type { GenerationResult } from './services/geminiService';
import { ASPECT_RATIOS, STYLE_OPTIONS, UKRAINIAN_REGIONS, VYSHYVANKA_COLORS, VYSHYVANKA_FLOWERS, ACTION_POSES, AGENT_POSES, FANTASY_ROLES, MYTHICAL_PARTNERS, HAIRSTYLE_OPTIONS, HAIR_COLOR_OPTIONS, DIRECTOR_STYLES, WRITER_STYLES, ART_STYLES, MUSIC_STYLES, PARTY_FLIRT_VARIATIONS } from './constants';
import type { StyleOption, AspectRatio } from './types';

interface UploadedImage {
  dataUrl: string;
  mimeType: string;
}

// Default fallback aspect ratio to prevent crashes if constants fail to load
const DEFAULT_ASPECT_RATIO: AspectRatio = { id: 'square', name: 'Square', prompt: '1:1' };

function App() {
  const [originalImages, setOriginalImages] = React.useState<UploadedImage[]>([]);
  const [history, setHistory] = React.useState<GenerationResult[]>([]);
  const [historyIndex, setHistoryIndex] = React.useState<number>(-1);
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [editPrompt, setEditPrompt] = React.useState<string>('');
  
  // Safe initialization of aspect ratio
  const [selectedAspectRatio, setSelectedAspectRatio] = React.useState<AspectRatio>(() => {
    if (Array.isArray(ASPECT_RATIOS) && ASPECT_RATIOS.length > 0) {
      return ASPECT_RATIOS[0];
    }
    return DEFAULT_ASPECT_RATIO;
  });

  const [cameraFocusPoint, setCameraFocusPoint] = React.useState({ x: 0.5, y: 0.5 });
  const [blurLevel, setBlurLevel] = React.useState<number>(0);
  const [customStyles, setCustomStyles] = React.useState<StyleOption[]>([]);
  const [selectedStyleId, setSelectedStyleId] = React.useState<string>('');
  
  // Initialize with the first pose (shared state for multiple style lists)
  const [selectedPoseId, setSelectedPoseId] = React.useState<string>(ACTION_POSES[0].id);

  // Initialize hair color selection (default to 'original')
  const [selectedHairColorId, setSelectedHairColorId] = React.useState<string>('original');

  const currentHistoryItem = history[historyIndex];
  const generatedImage = currentHistoryItem?.imageUrl ?? null;

  React.useEffect(() => {
    // Sync the edit prompt with the full prompt of the current history item
    const currentPrompt = currentHistoryItem?.fullPrompt ?? '';
    // Format the prompt for display
    const formattedPrompt = currentPrompt
        .replace(/ \*\*/g, '\n**')
        .replace(/^\*\*/, '**')
        .replace(/ IMPORTANT/g, '\nIMPORTANT')
        .replace(/ CRITICAL/g, '\nCRITICAL');
    setEditPrompt(formattedPrompt);
  }, [currentHistoryItem]);

  // Fix for iOS 100vh scroll issue and mobile scroll-to-top on view change
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [isLoading, generatedImage, historyIndex, originalImages.length]);

  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
    });

  // HELPER: Add Album Thumbnail with Peeking Vinyl Record AND Smooth Wave Visualizer
  const addAlbumThumbnail = async (imageUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            resolve(imageUrl);
            return;
        }

        // 1. Draw the main large image (background)
        ctx.drawImage(img, 0, 0);

        // Configuration
        const thumbSize = img.width * 0.22; 
        const margin = img.width * 0.04; 
        const borderThickness = img.width * 0.008;
        
        // Position of the Album Cover (Sleeve)
        const coverX = margin;
        const coverY = img.height - thumbSize - margin;

        // --- DRAW VINYL DISC (Behind the sleeve) ---
        // Center of the disc is shifted right so half of it peeks out
        // Shift amount: We want the center of the disc to be roughly at the right edge of the sleeve
        const discRadius = (thumbSize / 2) * 0.98; // Slightly smaller than sleeve
        const discCenterX = coverX + (thumbSize / 2) + (thumbSize * 0.45); // Shifted right 45%
        const discCenterY = coverY + (thumbSize / 2);

        ctx.save();
        
        // Disc Shadow
        ctx.shadowColor = "rgba(0, 0, 0, 0.5)";
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 4;
        ctx.shadowOffsetY = 4;

        // Main Black Vinyl Body
        ctx.beginPath();
        ctx.arc(discCenterX, discCenterY, discRadius, 0, Math.PI * 2);
        ctx.fillStyle = "#111111"; // Deep black
        ctx.fill();

        // Reset shadow for details
        ctx.shadowColor = "transparent";

        // Vinyl Grooves (Highlights) - Simple concentric circles
        ctx.strokeStyle = "#333333";
        ctx.lineWidth = thumbSize * 0.005; // Thin lines
        
        // Draw 3 groove lines
        [0.85, 0.7, 0.55].forEach(scale => {
            ctx.beginPath();
            ctx.arc(discCenterX, discCenterY, discRadius * scale, 0, Math.PI * 2);
            ctx.stroke();
        });

        // Center Label (Red)
        ctx.beginPath();
        ctx.arc(discCenterX, discCenterY, discRadius * 0.35, 0, Math.PI * 2);
        ctx.fillStyle = "#b91c1c"; // Vintage Red
        ctx.fill();
        
        // Center Hole
        ctx.beginPath();
        ctx.arc(discCenterX, discCenterY, discRadius * 0.05, 0, Math.PI * 2);
        ctx.fillStyle = "#ffffff"; // White hole
        ctx.fill();

        ctx.restore();

        // --- DRAW ALBUM COVER SLEEVE (On top of the disc) ---

        // Shadow for the Sticker effect
        ctx.shadowColor = "rgba(0, 0, 0, 0.6)";
        ctx.shadowBlur = 15;
        ctx.shadowOffsetX = 6;
        ctx.shadowOffsetY = 6;

        // White Border (Sticker Background)
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(
            coverX - borderThickness, 
            coverY - borderThickness, 
            thumbSize + (borderThickness * 2), 
            thumbSize + (borderThickness * 2)
        );

        // Reset shadow
        ctx.shadowColor = "transparent";
        ctx.shadowBlur = 0;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;

        // The Miniature Image inside the border
        ctx.drawImage(img, coverX, coverY, thumbSize, thumbSize);

        // --- DRAW SMOOTH WAVE VISUALIZER (Right of the thumbnail) ---
        ctx.save();
        
        // Calculate start position based on the VINYL DISC edge, not just the cover
        // discCenterX + discRadius is the absolute rightmost point of the vinyl
        const discRightEdge = discCenterX + discRadius;
        
        const visStartX = discRightEdge + (margin * 1.0); // Start after the record with a margin
        const maxVisWidth = img.width - visStartX - margin; // Remaining space to the right edge
        const visWidth = Math.max(maxVisWidth, img.width * 0.1); // Use available space
        
        const visHeight = thumbSize * 0.6; // Max height
        const visCenterY = coverY + (thumbSize / 2); // Center vertically with album

        // 1. Create Gradient (Purple -> Blue -> Cyan)
        const gradient = ctx.createLinearGradient(visStartX, visCenterY, visStartX + visWidth, visCenterY);
        gradient.addColorStop(0, "rgba(168, 85, 247, 0.7)"); // Purple
        gradient.addColorStop(0.5, "rgba(56, 189, 248, 0.8)"); // Cyan/Blue
        gradient.addColorStop(1, "rgba(236, 72, 153, 0.7)"); // Pink/Magenta

        // 2. Settings for the curves
        ctx.strokeStyle = gradient;
        ctx.lineWidth = img.width * 0.004; // Responsive line width
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        // Glow effect
        ctx.shadowColor = "rgba(56, 189, 248, 0.8)"; // Cyan glow
        ctx.shadowBlur = 8;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;

        // 3. Draw Multiple Intertwining Waves
        const numWaves = 4;
        const step = 5; // Resolution of the curve (pixels)

        for (let w = 0; w < numWaves; w++) {
            ctx.beginPath();
            
            // Varied parameters for each wave to create chaos/organic feel
            const frequency = 0.02 + (w * 0.01);
            const phase = w * 2.5; 
            const amplitudeBase = visHeight * 0.4;
            const amplitudeVar = 0.8 - (w * 0.15); // Outer waves are smaller

            for (let x = 0; x <= visWidth; x += step) {
                const globalX = visStartX + x;
                
                // "Windowing Function" (Hanning/Sine window)
                // This forces the wave to be 0 at the start and 0 at the end, 
                // creating that contained "audio burst" look.
                // normalizedX goes from 0 to 1
                const normalizedX = x / visWidth;
                const window = Math.sin(normalizedX * Math.PI); 

                // Calculate Sine Wave
                const yOffset = Math.sin((x * frequency) + phase) * (amplitudeBase * amplitudeVar) * window;
                const globalY = visCenterY + yOffset;

                if (x === 0) {
                    ctx.moveTo(globalX, globalY);
                } else {
                    ctx.lineTo(globalX, globalY);
                }
            }
            ctx.stroke();
        }

        // Draw a distinct straight center line (the "silence" line) with opacity
        ctx.beginPath();
        ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
        ctx.lineWidth = 1;
        ctx.moveTo(visStartX, visCenterY);
        ctx.lineTo(visStartX + visWidth, visCenterY);
        ctx.stroke();

        ctx.restore();

        resolve(canvas.toDataURL('image/png', 0.95));
      };
      img.onerror = (e) => {
          console.error("Failed to load image for thumbnail processing", e);
          resolve(imageUrl);
      };
      img.src = imageUrl;
    });
  };

  const handleImageUpload = React.useCallback(async (files: File[]) => {
    if (files.length > 5) {
        setError("You can upload a maximum of 5 photos.");
        return;
    }
    setIsLoading(true);
    setError(null);
    setHistory([]);
    setHistoryIndex(-1);
    try {
      const dataUrlPromises = files.map(file => fileToBase64(file));
      const dataUrls = await Promise.all(dataUrlPromises);
      const newImages = dataUrls.map((dataUrl, index) => ({
        dataUrl,
        mimeType: files[index].type,
      }));
      setOriginalImages(newImages);
    } catch (e) {
      setError('Failed to read the image files. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const getFocusPointPrompt = React.useCallback((point: { x: number; y: number }): string => {
    const prompts = [];
    if (point.y < 0.33) prompts.push('a high-angle view, looking down on the subject');
    else if (point.y > 0.66) prompts.push('a low-angle hero view, looking up at the subject');
    else prompts.push('an eye-level view');

    if (point.x < 0.4) prompts.push('with the subject framed towards the left');
    else if (point.x > 0.6) prompts.push('with the subject framed towards the right');
    else prompts.push('with the subject centered in the frame');

    return `The camera composition should be ${prompts.join(', ')}.`;
  }, []);

  const handleGenerateHeadshot = React.useCallback(async (style: StyleOption) => {
    if (originalImages.length === 0) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);

    try {
      const imagesPayload = originalImages.map(img => ({
          data: img.dataUrl.split(',')[1],
          mimeType: img.mimeType,
      }));
      const cameraAnglePrompt = getFocusPointPrompt(cameraFocusPoint);
      
      let finalStylePrompt = style.prompt;
      
      // Determine a nice display name for the Result Screen
      let displayStyleName = style.name;

      // LOGIC FOR RANDOM REGION SURPRISE
      if (style.id === 'ukraine-region-surprise' && UKRAINIAN_REGIONS.length > 0) {
        const randomRegion = UKRAINIAN_REGIONS[Math.floor(Math.random() * UKRAINIAN_REGIONS.length)];
        // Replace placeholders in the prompt
        finalStylePrompt = finalStylePrompt
            .replace('{{REGION_NAME}}', randomRegion.name)
            .replace('{{REGION_DESC}}', randomRegion.desc);
      }
      
      // LOGIC FOR RANDOM COLOR VYSHYVANKA
      if (style.id === 'ukraine-modern-random' && VYSHYVANKA_COLORS.length > 0) {
        const randomColor = VYSHYVANKA_COLORS[Math.floor(Math.random() * VYSHYVANKA_COLORS.length)];
        // Replace placeholders
        finalStylePrompt = finalStylePrompt
            .replace('{{COLOR_DESC}}', randomColor.desc)
            .replace('{{BG_DESC}}', randomColor.bg)
            .replace('{{LIGHT_DESC}}', randomColor.light);
      }
      
      // LOGIC FOR RANDOM FLOWER VYSHYVANKA
      if (style.id === 'ukraine-modern-flower' && VYSHYVANKA_FLOWERS.length > 0) {
        const randomFlower = VYSHYVANKA_FLOWERS[Math.floor(Math.random() * VYSHYVANKA_FLOWERS.length)];
        // Completely override the prompt
        finalStylePrompt = randomFlower.prompt;
      }

      // LOGIC FOR URBAN ACTION POSE
      if (style.id === 'urban-fullbody-test') {
         // Fallback to first pose if ID invalid (or from another list)
         const selectedPose = ACTION_POSES.find(p => p.id === selectedPoseId) || ACTION_POSES[0];
         finalStylePrompt = finalStylePrompt.replace('{{ACTION_POSE}}', selectedPose.prompt);
         displayStyleName = `Urban Action: ${selectedPose.name}`;
      }
      
      // LOGIC FOR AGENT ACTION POSE
      if (style.id === 'secret-agent-action') {
         // Fallback to first pose if ID invalid (or from another list)
         const selectedPose = AGENT_POSES.find(p => p.id === selectedPoseId) || AGENT_POSES[0];
         finalStylePrompt = finalStylePrompt.replace('{{ACTION_POSE}}', selectedPose.prompt);
         displayStyleName = `Secret Agent: ${selectedPose.name}`;
      }
      
      // LOGIC FOR FANTASY HERO POSE
      if (style.id === 'fantasy-hero') {
         // Fallback to first pose if ID invalid (or from another list)
         const selectedRole = FANTASY_ROLES.find(p => p.id === selectedPoseId) || FANTASY_ROLES[0];
         finalStylePrompt = finalStylePrompt.replace('{{FANTASY_ROLE}}', selectedRole.prompt);
         displayStyleName = `Fantasy Hero: ${selectedRole.name}`;
      }
      
      // LOGIC FOR CINEMATIC HOLLYWOOD DIRECTOR
      if (style.id === 'cinematic-hollywood') {
         const selectedDirector = DIRECTOR_STYLES.find(p => p.id === selectedPoseId) || DIRECTOR_STYLES[0];
         finalStylePrompt = finalStylePrompt
            .replace('{{DIRECTOR_NAME}}', selectedDirector.name)
            .replace('{{DIRECTOR_PROMPT}}', selectedDirector.prompt);
         displayStyleName = `Director: ${selectedDirector.name}`;
      }

      // LOGIC FOR LITERARY UNIVERSE (WRITERS)
      if (style.id === 'literary-universe') {
         const selectedWriter = WRITER_STYLES.find(p => p.id === selectedPoseId) || WRITER_STYLES[0];
         finalStylePrompt = finalStylePrompt
            .replace('{{WRITER_NAME}}', selectedWriter.name)
            .replace('{{WRITER_PROMPT}}', selectedWriter.prompt);
         displayStyleName = `Universe: ${selectedWriter.name}`;
      }

      // LOGIC FOR ART HISTORY MUSE
      if (style.id === 'art-history-muse') {
         const selectedArtist = ART_STYLES.find(p => p.id === selectedPoseId) || ART_STYLES[0];
         finalStylePrompt = finalStylePrompt
            .replace('{{ARTIST_NAME}}', selectedArtist.name)
            .replace('{{ARTIST_PROMPT}}', selectedArtist.prompt);
         displayStyleName = `Masterpiece: ${selectedArtist.name}`;
      }

      // LOGIC FOR MUSICAL VIBES
      if (style.id === 'musical-vibes') {
         const selectedMusic = MUSIC_STYLES.find(p => p.id === selectedPoseId) || MUSIC_STYLES[0];
         // The prompt in MUSIC_STYLES already contains the detailed instruction.
         // We wrap it to ensure the "Album Cover" aspect is dominant.
         finalStylePrompt = `Create a high-quality VINYL RECORD ALBUM COVER art. The subject is the music artist. ${selectedMusic.prompt} The subject fits perfectly into this musical era while retaining their likeness.`;
         displayStyleName = `Album: ${selectedMusic.name}`;
      }

      // LOGIC FOR MYTHICAL SELFIE (SELFIE WITH...)
      if (style.id === 'fun-mythical-selfie') {
        const selectedPartner = MYTHICAL_PARTNERS.find(p => p.id === selectedPoseId) || MYTHICAL_PARTNERS[0];
        finalStylePrompt = `A fun, wide-angle selfie photo featuring TWO characters. Subject 1 is the person from the uploaded photo (STRICTLY preserve their facial identity and likeness). Subject 2 is ${selectedPartner.prompt}. They are posing cheek-to-cheek or side-by-side. The lighting is cinematic.`;
        displayStyleName = `Selfie with: ${selectedPartner.name}`;
      }

      // LOGIC FOR PARTY FLIRT VARIATIONS
      if (style.id === 'party-flirt' && PARTY_FLIRT_VARIATIONS.length > 0) {
        const randomVar = PARTY_FLIRT_VARIATIONS[Math.floor(Math.random() * PARTY_FLIRT_VARIATIONS.length)];
        finalStylePrompt = `A dynamic, spontaneous, and unpredictable 'Party Flirt' portrait set in a stylish evening cafe or a dimly lit disco bar. SCENARIO: ${randomVar.prompt} The subject has a fit body, emphasized by minimal, stylish clothing that interacts with the movement. The lighting is moody with dynamic flashes or neon streaks. The background is a blur of night city lights or club atmosphere. The overall mood is wild, sexy, fun, and completely unpredictable.`;
        displayStyleName = `Party Flirt: ${randomVar.name}`;
      }

      // LOGIC FOR HAIRSTYLE TRY-ON
      if (style.id === 'hairstyle-try-on') {
        const selectedHairstyle = HAIRSTYLE_OPTIONS.find(p => p.id === selectedPoseId) || HAIRSTYLE_OPTIONS[0];
        const selectedColor = HAIR_COLOR_OPTIONS.find(c => c.id === selectedHairColorId) || HAIR_COLOR_OPTIONS[0];
        
        finalStylePrompt = finalStylePrompt
            .replace('{{HAIRSTYLE_PROMPT}}', selectedHairstyle.prompt)
            .replace('{{HAIR_COLOR_PROMPT}}', selectedColor.prompt);
        
        displayStyleName = `💇‍♀️ Style: ${selectedHairstyle.name} | Color: ${selectedColor.name}`;
      }

      const result = await generateHeadshot(
          imagesPayload, 
          finalStylePrompt, 
          selectedAspectRatio.prompt, 
          cameraAnglePrompt,
          selectedAspectRatio.id,
          style.id
      );
      
      let finalResult = result;

      // POST-PROCESSING: APPLY RECURSIVE THUMBNAIL FOR MUSIC STYLE
      if (style.id === 'musical-vibes') {
          try {
             // We apply the sticker overlay client-side to ensure it is perfect
             const modifiedImageUrl = await addAlbumThumbnail(result.imageUrl);
             finalResult = { ...result, imageUrl: modifiedImageUrl };
          } catch (e) {
             console.error("Error processing album thumbnail:", e);
             // Fail gracefully, keep original image
          }
      }
      
      // Attach the detailed display name to the result
      const resultWithDisplayName: GenerationResult = {
          ...finalResult,
          styleDisplayName: displayStyleName
      };

      setHistory([resultWithDisplayName]);
      setHistoryIndex(0);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred during image generation.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [originalImages, selectedAspectRatio, cameraFocusPoint, getFocusPointPrompt, selectedPoseId, selectedHairColorId]);

  const handleEditImage = React.useCallback(async () => {
    if (!generatedImage || !editPrompt) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);
    
    try {
      const base64Data = generatedImage.split(',')[1];
      const result = await editImage(base64Data, 'image/png', editPrompt);
      
      // Preserve the display name from the current item
      const resultWithPreservedName: GenerationResult = {
          ...result,
          styleDisplayName: currentHistoryItem?.styleDisplayName
      };

      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, resultWithPreservedName]);
      setHistoryIndex(newHistory.length);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred during image editing.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [generatedImage, editPrompt, history, historyIndex, currentHistoryItem]);

  const handleApplyEffect = React.useCallback(async (effectPrompt: string) => {
    if (!generatedImage) return;
    setIsLoading(true);
    setError(null);
    setBlurLevel(0);

    try {
      const base64Data = generatedImage.split(',')[1];
      const result = await editImage(base64Data, 'image/png', effectPrompt);
      
      // Preserve the display name from the current item
      const resultWithPreservedName: GenerationResult = {
          ...result,
          styleDisplayName: currentHistoryItem?.styleDisplayName
      };

      const newHistory = history.slice(0, historyIndex + 1);
      setHistory([...newHistory, resultWithPreservedName]);
      setHistoryIndex(newHistory.length);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [generatedImage, history, historyIndex, currentHistoryItem]);

  const handleBlurChange = React.useCallback(async (level: number) => {
    if (!generatedImage) return;
    setBlurLevel(level);
    setIsLoading(true);
    setError(null);
    
    let blurPrompt = "Ensure the entire image is sharp and in deep focus (f/16 aperture). No visible bokeh.";
    if (level === 25) blurPrompt = "Simulate a portrait lens with f/5.6 aperture, creating slight background separation.";
    else if (level === 50) blurPrompt = "Apply a professional portrait look with f/2.8 aperture. Creamy bokeh background.";
    else if (level === 75) blurPrompt = "Create a strong bokeh effect with an f/1.8 aperture simulation.";
    else if (level === 100) blurPrompt = "Apply a dreamy, artistic bokeh effect with an ultra-wide f/1.2 aperture.";

    try {
        const base64Data = generatedImage.split(',')[1];
        const result = await editImage(base64Data, 'image/png', blurPrompt);
        
        // Preserve the display name from the current item
        const resultWithPreservedName: GenerationResult = {
            ...result,
            styleDisplayName: currentHistoryItem?.styleDisplayName
        };

        const newHistory = history.slice(0, historyIndex + 1);
        setHistory([...newHistory, resultWithPreservedName]);
        setHistoryIndex(newHistory.length);
    } catch (e: any) {
        setError(e.message || 'Blur failed.');
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  }, [generatedImage, history, historyIndex, currentHistoryItem]);

  const handleStartOver = React.useCallback(() => {
    setHistory([]);
    setHistoryIndex(-1);
    setError(null);
    setIsLoading(false);
    setBlurLevel(0);
  }, []);
  
  const handleReset = React.useCallback(() => {
    setOriginalImages([]);
    setHistory([]);
    setHistoryIndex(-1);
    setError(null);
    setIsLoading(false);
    setBlurLevel(0);
    setCustomStyles([]);
    setSelectedStyleId('');
    setSelectedPoseId(ACTION_POSES[0].id);
    setSelectedHairColorId('original');
  }, []);

  const handleDownload = React.useCallback(() => {
    if (!currentHistoryItem) return;
    const { imageUrl, fullPrompt, modelName } = currentHistoryItem;
    const img = new Image();
    img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);
        const jpegDataUrl = canvas.toDataURL('image/jpeg', 0.95);
        const base64Jpeg = jpegDataUrl.split(',')[1];
        const binaryStr = atob(base64Jpeg);
        const len = binaryStr.length;
        const jpegBytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) jpegBytes[i] = binaryStr.charCodeAt(i);
        const commentStr = `Pixel AI Photomaker\nPrompt: ${fullPrompt}\nModel: ${modelName}`;
        const encoder = new TextEncoder();
        const commentBytes = encoder.encode(commentStr);
        const commentBytesLen = commentBytes.length;
        const commentSegmentLength = commentBytesLen + 2;
        const comSegment = new Uint8Array(4 + commentBytesLen);
        comSegment[0] = 0xFF; comSegment[1] = 0xFE;
        comSegment[2] = commentSegmentLength >> 8; comSegment[3] = commentSegmentLength & 0xFF;
        comSegment.set(commentBytes, 4);
        const newJpegBytes = new Uint8Array(2 + comSegment.length + (jpegBytes.length - 2));
        newJpegBytes.set(jpegBytes.subarray(0, 2), 0);
        newJpegBytes.set(comSegment, 2);
        newJpegBytes.set(jpegBytes.subarray(2), 2 + comSegment.length);
        const blob = new Blob([newJpegBytes], { type: 'image/jpeg' });
        const blobUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        
        // Generate random code (6 chars)
        const randomCode = Math.random().toString(36).substring(2, 8);
        link.download = `pixel-headshot-${randomCode}.jpeg`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
    };
    img.src = imageUrl;
  }, [currentHistoryItem]);

  const handleUndo = React.useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setBlurLevel(0);
    }
  }, [historyIndex]);

  const handleRedo = React.useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setBlurLevel(0);
    }
  }, [historyIndex, history.length]);

  const handleCustomStylesUpload = React.useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
        const text = event.target?.result as string;
        if (!text) return;
        try {
            const lines = text.trim().split(/\r\n|\n/);
            const headerLine = lines.shift()?.trim();
            if (!headerLine) throw new Error('Empty CSV');
            
            // Helper to split CSV line respecting quotes
            const splitCSV = (str: string) => str.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
            
            const header = splitCSV(headerLine).map(h => h.trim().replace(/^"|"$/g, '').toLowerCase());
            const nameIndex = header.indexOf('name');
            const promptIndex = header.indexOf('prompt');
            
            if (nameIndex === -1 || promptIndex === -1) throw new Error('Invalid columns');
            
            const newStyles = lines.map((line, index) => {
                if (!line.trim()) return null;
                const columns = splitCSV(line);
                
                const rawName = columns[nameIndex];
                const rawPrompt = columns[promptIndex];

                if (!rawName || !rawPrompt) return null;

                // Clean up quotes (outer quotes and double-quotes inside)
                const name = rawName.trim().replace(/^"|"$/g, '').replace(/""/g, '"');
                const prompt = rawPrompt.trim().replace(/^"|"$/g, '').replace(/""/g, '"');
                
                return { id: `custom-${Date.now()}-${index}`, name, prompt };
            }).filter((style): style is StyleOption => style !== null);
            setCustomStyles(prevStyles => [...prevStyles, ...newStyles]);
        } catch (e: any) {
            setError(e.message || 'CSV failed');
        }
    };
    reader.readAsText(file);
}, []);

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  // Render logic safely
  const renderContent = () => {
    if (isLoading && !generatedImage) return <div className="flex-grow flex justify-center items-center"><Spinner /></div>;
    
    if (error) return (
        <div className="flex-grow flex flex-col justify-center items-center text-center p-4">
            <p className="text-red-400 text-lg mb-4">{error}</p>
            <button onClick={handleReset} className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Try Again</button>
        </div>
    );
    
    if (generatedImage) {
        // Use the display name stored in the history item, or fallback to default text
        const styleName = currentHistoryItem?.styleDisplayName || 'Custom / Edited';

        return (
            <ImageEditor
                imageSrc={generatedImage!}
                editPrompt={editPrompt}
                onEditPromptChange={setEditPrompt}
                onEditSubmit={handleEditImage}
                onReset={handleStartOver}
                isLoading={isLoading}
                onDownload={handleDownload}
                onApplyEffect={handleApplyEffect}
                onUndo={handleUndo}
                onRedo={handleRedo}
                canUndo={canUndo}
                canRedo={canRedo}
                blurLevel={blurLevel}
                onBlurChange={handleBlurChange}
                styleName={styleName}
            />
        );
    }
    
    if (originalImages.length > 0) return (
      <StyleSelector 
          originalImages={originalImages.map(img => img.dataUrl)} 
          onStyleSelect={handleGenerateHeadshot} 
          selectedAspectRatio={selectedAspectRatio}
          onAspectRatioSelect={setSelectedAspectRatio}
          cameraFocusPoint={cameraFocusPoint}
          onFocusPointChange={setCameraFocusPoint}
          onReset={handleReset}
          onCustomStylesUpload={handleCustomStylesUpload}
          customStyleOptions={customStyles}
          selectedStyleId={selectedStyleId}
          onSelectedStyleIdChange={setSelectedStyleId}
          selectedPoseId={selectedPoseId}
          onPoseSelect={setSelectedPoseId}
          selectedHairColorId={selectedHairColorId}
          onHairColorSelect={setSelectedHairColorId}
      />
    );
    
    return <ImageUploader onImageUpload={handleImageUpload} isLoading={isLoading} />;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col">
      <Header />
      <main className="flex-grow flex flex-col justify-center items-center p-4">
        <div className="w-full flex flex-col justify-center items-center flex-grow">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;
