
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center p-4 md:p-6 border-b border-gray-700">
      <div className="relative inline-block">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 relative z-10">
          Pixel AI Photomaker
        </h1>
      </div>
      <p className="text-gray-500 mt-1 text-xs">Nyukers (C)opyright, 2026</p>
      <p className="text-gray-400 mt-2 text-sm">Upload a selfie (or use webcam), select a camera angle, choose a built-in super style or upload your own, <br />and Photomaker will create a new professional photo for you.</p>
    </header>
  );
};

export default Header;
