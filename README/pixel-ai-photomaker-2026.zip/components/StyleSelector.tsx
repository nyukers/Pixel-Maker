
import React from 'react';
import { STYLE_OPTIONS, ASPECT_RATIOS, ACTION_POSES, AGENT_POSES, FANTASY_ROLES, MYTHICAL_PARTNERS, HAIRSTYLE_OPTIONS, HAIR_COLOR_OPTIONS, DIRECTOR_STYLES, WRITER_STYLES } from '../constants';
import type { StyleOption, AspectRatio } from '../types';
import CameraAngleController from './CameraAngleController';

interface StyleSelectorProps {
  onStyleSelect: (style: StyleOption) => void;
  originalImages: string[];
  onAspectRatioSelect: (ratio: AspectRatio) => void;
  selectedAspectRatio: AspectRatio;
  onFocusPointChange: (point: { x: number; y: number }) => void;
  cameraFocusPoint: { x: number; y: number };
  onReset: () => void;
  onCustomStylesUpload: (file: File) => void;
  customStyleOptions: StyleOption[];
  selectedStyleId: string;
  onSelectedStyleIdChange: (id: string) => void;
  selectedPoseId: string;
  onPoseSelect: (id: string) => void;
  selectedHairColorId: string;
  onHairColorSelect: (id: string) => void;
}

const StyleSelector: React.FC<StyleSelectorProps> = ({ 
    onStyleSelect, 
    originalImages,
    onAspectRatioSelect,
    selectedAspectRatio,
    onFocusPointChange,
    cameraFocusPoint,
    onReset,
    onCustomStylesUpload,
    customStyleOptions,
    selectedStyleId,
    onSelectedStyleIdChange,
    selectedPoseId,
    onPoseSelect,
    selectedHairColorId,
    onHairColorSelect
}) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Safe filtering with fallback to empty array
  const safeStyles = Array.isArray(STYLE_OPTIONS) ? STYLE_OPTIONS : [];
  const safeAspectRatios = Array.isArray(ASPECT_RATIOS) ? ASPECT_RATIOS : [];
  
  // 1. Separate Ukrainian Styles completely
  const ukrainianStyles = safeStyles.filter(style => style.name && style.name.startsWith('🇺🇦'));
  
  // 2. Filter remaining styles for the main dropdown
  const nonUkrainianStyles = safeStyles.filter(style => !style.name.startsWith('🇺🇦'));

  // Holidays
  const holidayStyles = nonUkrainianStyles.filter(style => 
    style.name && style.name.startsWith('*')
  );

  // Groups
  const groupStyles = nonUkrainianStyles.filter(style => 
    style.id && style.id.startsWith('group-')
  );

  // Fun Styles (containing "(Fun)")
  const funStyles = nonUkrainianStyles.filter(style => 
    style.name && style.name.includes('(Fun)')
  );
  
  // Hairstyle Collection
  const hairstyleTrigger = nonUkrainianStyles.find(style => style.id === 'hairstyle-try-on');

  // Writer Collection
  // Note: We still need to identify it for the isWriterModeActive logic, but it's now visually under Fun styles.
  const writerTrigger = nonUkrainianStyles.find(style => style.id === 'literary-universe');

  // Regular styles (Not Holiday, Not Group, Not Fun, Not Hairstyle)
  const regularStyles = nonUkrainianStyles.filter(style => 
    style.name &&
    !style.name.startsWith('*') && 
    style.id && 
    !style.id.startsWith('group-') &&
    !style.name.includes('(Fun)') &&
    style.id !== 'hairstyle-try-on'
  );

  const UA_TRIGGER_ID = 'ua-collection-trigger';
  const HOLIDAY_TRIGGER_ID = 'holiday-collection-trigger';
  const FUN_TRIGGER_ID = 'fun-collection-trigger';
  const HAIRSTYLE_TRIGGER_ID = 'hairstyle-try-on';
  const WRITER_TRIGGER_ID = 'literary-universe';

  // Check if current selection is a UA style or the trigger
  const isUaStyleSelected = ukrainianStyles.some(s => s.id === selectedStyleId);
  const isUaModeActive = selectedStyleId === UA_TRIGGER_ID || isUaStyleSelected;

  // Check if current selection is a Holiday style or the trigger
  const isHolidayStyleSelected = holidayStyles.some(s => s.id === selectedStyleId);
  const isHolidayModeActive = selectedStyleId === HOLIDAY_TRIGGER_ID || isHolidayStyleSelected;

  // Check if current selection is a Fun style or the trigger
  const isFunStyleSelected = funStyles.some(s => s.id === selectedStyleId);
  const isFunModeActive = selectedStyleId === FUN_TRIGGER_ID || isFunStyleSelected;
  
  // Check if current selection is Hairstyle
  const isHairstyleModeActive = selectedStyleId === HAIRSTYLE_TRIGGER_ID;

  // Check if current selection is Writer
  const isWriterModeActive = selectedStyleId === WRITER_TRIGGER_ID;

  // Determine the value for the Main Dropdown
  let mainDropdownValue = selectedStyleId;
  if (isUaModeActive) {
      mainDropdownValue = UA_TRIGGER_ID;
  } else if (isHolidayModeActive) {
      mainDropdownValue = HOLIDAY_TRIGGER_ID;
  } else if (isFunModeActive) {
      mainDropdownValue = FUN_TRIGGER_ID;
  }

  const isGroupStyle = (selectedStyleId || '').startsWith('group-');
  const isAvatarStyle = selectedStyleId === 'social-avatar';
  const isUrbanTestStyle = selectedStyleId === 'urban-fullbody-test';
  const isAgentActionStyle = selectedStyleId === 'secret-agent-action';
  const isFantasyHeroStyle = selectedStyleId === 'fantasy-hero';
  const isMythicalSelfieStyle = selectedStyleId === 'fun-mythical-selfie';
  const isHollywoodStyle = selectedStyleId === 'cinematic-hollywood';
  
  // Lock composition for specific styles to ensure best results
  const isCompositionLocked = isGroupStyle || isAvatarStyle || isMythicalSelfieStyle || isHairstyleModeActive || isWriterModeActive;

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onCustomStylesUpload(file);
    }
    if (event.target) {
        event.target.value = '';
    }
  };

  const handleDownloadTemplate = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "name,prompt\n"
      + '"My Custom Style","A headshot with a dramatic, cinematic feel, deep shadows, and a single key light."';
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "custom_styles_template.csv");
    document.body.appendChild(link); // Required for FF
    link.click();
    document.body.removeChild(link);
  };
  
  const handleGenerateClick = () => {
    const styleId = selectedStyleId;
    if (!styleId || styleId === UA_TRIGGER_ID || styleId === HOLIDAY_TRIGGER_ID || styleId === FUN_TRIGGER_ID) return;

    const allStyles = [...customStyleOptions, ...safeStyles];
    const selectedStyle = allStyles.find(style => style.id === styleId);
    if (selectedStyle) {
        onStyleSelect(selectedStyle);
    }
  };

  const handleMainStyleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const value = event.target.value;
    
    // Auto-select Aspect Ratio based on Style
    if (value === 'social-avatar') {
        const squareOption = safeAspectRatios.find(r => r.id === 'square');
        if (squareOption) onAspectRatioSelect(squareOption);
    } else if (value === HAIRSTYLE_TRIGGER_ID) {
        const portraitOption = safeAspectRatios.find(r => r.id === 'portrait');
        if (portraitOption) onAspectRatioSelect(portraitOption);
    }

    if (value === UA_TRIGGER_ID) {
        if (ukrainianStyles.length > 0) {
            onSelectedStyleIdChange(ukrainianStyles[0].id);
        } else {
            onSelectedStyleIdChange(UA_TRIGGER_ID);
        }
    } else if (value === HOLIDAY_TRIGGER_ID) {
        if (holidayStyles.length > 0) {
            onSelectedStyleIdChange(holidayStyles[0].id);
        } else {
            onSelectedStyleIdChange(HOLIDAY_TRIGGER_ID);
        }
    } else if (value === FUN_TRIGGER_ID) {
        if (funStyles.length > 0) {
            onSelectedStyleIdChange(funStyles[0].id);
        } else {
            onSelectedStyleIdChange(FUN_TRIGGER_ID);
        }
    } else {
        onSelectedStyleIdChange(value);
    }
  };

  const handleSubStyleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
      const value = event.target.value;
      
      // Secondary check for sub-dropdowns to also trigger aspect ratio changes
      if (value === 'fun-mythical-selfie') {
        const landscapeOption = safeAspectRatios.find(r => r.id === 'landscape');
        if (landscapeOption) onAspectRatioSelect(landscapeOption);
      } else if (value === 'cinematic-hollywood') {
        // Force Landscape (4:3) for Hollywood style now
        const landscapeOption = safeAspectRatios.find(r => r.id === 'landscape');
        if (landscapeOption) onAspectRatioSelect(landscapeOption);
      } else if (value === WRITER_TRIGGER_ID) {
        const portraitOption = safeAspectRatios.find(r => r.id === 'portrait');
        if (portraitOption) onAspectRatioSelect(portraitOption);
      }

      onSelectedStyleIdChange(value);
  }

  // Inline SVG rendering helper
  const renderIcon = (id: string) => {
    switch (id) {
        case 'square':
            return <svg aria-hidden="true" width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>;
        case 'portrait':
            return <svg aria-hidden="true" width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="3" width="12" height="18" rx="2" ry="2"></rect></svg>;
        case 'landscape':
            return <svg aria-hidden="true" width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="6" width="18" height="12" rx="2" ry="2"></rect></svg>;
        default:
            return null;
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto text-center p-4 md:p-8">
        <h2 className="text-2xl font-semibold mb-6 text-gray-100">Step 2: Customize Your Headshot</h2>
        
        <div className="flex flex-col gap-8">
            {/* Original Photos Block */}
            <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold text-gray-200 mb-4">Original Photos</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 max-w-full mx-auto">
                    {originalImages.map((src, index) => (
                        <img 
                            key={index} 
                            src={src} 
                            alt={`Your selfie ${index + 1}`} 
                            className="rounded-lg object-cover w-full h-32 border-2 border-gray-600 shadow-lg"
                        />
                    ))}
                </div>
                <button 
                  onClick={onReset}
                  className="text-sm text-blue-400 hover:underline mt-4"
                >
                  Use different photos
                </button>
            </div>
            
            {/* Composition Block */}
            <div className={`bg-gray-800/50 p-6 rounded-lg border border-gray-700 relative transition-all duration-300 ${isCompositionLocked ? 'opacity-50 pointer-events-none' : ''}`}>
                {isGroupStyle && (
                    <div className="absolute inset-0 z-10 flex items-center justify-center bg-gray-900/50 rounded-lg">
                        <span className="bg-gray-800 text-yellow-500 px-4 py-2 rounded-md font-bold shadow-lg border border-yellow-500/30">
                            Composition locked to preserve original group layout
                        </span>
                    </div>
                )}
                {isAvatarStyle && (
                     <div className="absolute inset-0 z-10 flex items-center justify-center bg-gray-900/50 rounded-lg">
                        <span className="bg-gray-800 text-cyan-400 px-4 py-2 rounded-md font-bold shadow-lg border border-cyan-400/30">
                            Avatar Style: Fixed 1:1 Square & Centered
                        </span>
                    </div>
                )}
                {isMythicalSelfieStyle && (
                     <div className="absolute inset-0 z-10 flex items-center justify-center bg-gray-900/50 rounded-lg">
                        <span className="bg-gray-800 text-pink-400 px-4 py-2 rounded-md font-bold shadow-lg border border-pink-400/30">
                            Auto-set to Landscape (4:3) to fit your selfie partner!
                        </span>
                    </div>
                )}
                {isHairstyleModeActive && (
                     <div className="absolute inset-0 z-10 flex items-center justify-center bg-gray-900/50 rounded-lg">
                        <span className="bg-gray-800 text-pink-400 px-4 py-2 rounded-md font-bold shadow-lg border border-pink-400/30">
                            Auto-set to Portrait (3:4) for best hair detail!
                        </span>
                    </div>
                )}
                {isHollywoodStyle && (
                     <div className="absolute inset-0 z-10 flex items-center justify-center bg-gray-900/50 rounded-lg">
                        <span className="bg-gray-800 text-amber-400 px-4 py-2 rounded-md font-bold shadow-lg border border-amber-400/30">
                            Auto-set to Cinematic (4:3) for movie view!
                        </span>
                    </div>
                )}
                {isWriterModeActive && (
                     <div className="absolute inset-0 z-10 flex items-center justify-center bg-gray-900/50 rounded-lg">
                        <span className="bg-gray-800 text-blue-400 px-4 py-2 rounded-md font-bold shadow-lg border border-blue-400/30">
                            Auto-set to Book Cover (3:4) for literary vibe!
                        </span>
                    </div>
                )}

                <h3 className="text-lg font-semibold text-gray-200 mb-4">Composition</h3>
                <p className="text-gray-400 mb-6 text-sm">Select your desired aspect ratio and camera angle.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    <div>
                        <div className="flex justify-center w-full mb-2">
                             <label className="text-sm font-medium text-gray-400">Aspect Ratio</label>
                        </div>
                        <div className="flex flex-col items-center justify-center flex-wrap gap-2">
                            {safeAspectRatios.map((ratio) => (
                                <button
                                    key={ratio.id}
                                    onClick={() => onAspectRatioSelect(ratio)}
                                    className={`px-4 py-2 text-sm rounded-md font-semibold transition-colors w-48 flex items-center justify-center gap-2 ${
                                        selectedAspectRatio.id === ratio.id 
                                        ? 'bg-blue-600 text-white' 
                                        : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                                    }`}
                                >
                                    {renderIcon(ratio.id)}
                                    {ratio.name}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="flex flex-col items-center w-full">
                        <label className="block text-sm font-medium text-gray-400 mb-2">Camera Angle</label>
                        <div className="w-full max-w-[200px]">
                            <CameraAngleController
                                focusPoint={cameraFocusPoint}
                                onFocusPointChange={onFocusPointChange}
                                aspectRatioId={selectedAspectRatio.id}
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Style selection Block */}
            <div className="space-y-6 bg-gray-800/50 p-6 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold text-gray-200 mb-4">Styles</h3>
                
                {/* MAIN DROPDOWN */}
                <div>
                    <label htmlFor="style-select" className="block text-sm font-medium text-gray-300 mb-2 text-left">
                        Category / Style
                    </label>
                    <select
                        id="style-select"
                        value={mainDropdownValue}
                        onChange={handleMainStyleChange}
                        className="w-full bg-gray-700 border border-gray-600 text-white rounded-md p-3 focus:ring-blue-500 focus:border-blue-500 text-lg font-medium"
                    >
                        <option value="">-- Select a Style --</option>
                        
                        {/* UKRAINIAN TRIGGER */}
                        <option 
                            value={UA_TRIGGER_ID} 
                            className="bg-blue-900 text-yellow-400 font-bold"
                        >
                           🇺🇦 UKRAINE SPECIAL COLLECTION
                        </option>

                        {/* HOLIDAY TRIGGER */}
                        <option 
                            value={HOLIDAY_TRIGGER_ID} 
                            className="bg-red-900 text-green-300 font-bold"
                        >
                           🎄 HOLIDAY SPECIAL COLLECTION
                        </option>

                        {/* FUN TRIGGER */}
                        <option 
                            value={FUN_TRIGGER_ID} 
                            className="bg-purple-900 text-pink-300 font-bold"
                        >
                           ✨ FUN & CREATIVE COLLECTION
                        </option>

                         {/* HAIRSTYLE TRIGGER */}
                         {hairstyleTrigger && (
                            <option 
                                value={HAIRSTYLE_TRIGGER_ID} 
                                className="bg-pink-900 text-pink-200 font-bold"
                            >
                            {hairstyleTrigger.name}
                            </option>
                        )}

                        <option disabled>──────────────────────────</option>

                        {/* Group & Couples */}
                        {groupStyles.length > 0 && (
                            <optgroup label="Group & Couples" className="bg-gray-900 font-bold text-pink-500">
                                {groupStyles.map(style => (
                                    <option key={style.id} value={style.id} className="bg-gray-700 text-white font-normal">
                                        {style.name}
                                    </option>
                                ))}
                            </optgroup>
                        )}

                        {/* Regular Built-in Styles */}
                        <optgroup label="Built-in Styles" className="bg-gray-900 font-bold text-gray-300">
                            {regularStyles.map(style => (
                                <option key={style.id} value={style.id} className="bg-gray-700 text-white font-normal">
                                    {style.name}
                                </option>
                            ))}
                        </optgroup>

                        {/* Custom Styles */}
                        {customStyleOptions.length > 0 && (
                            <optgroup label="Your Custom Styles" className="bg-gray-900 font-bold text-gray-300">
                                {customStyleOptions.map(style => (
                                    <option key={style.id} value={style.id} className="bg-gray-700 text-cyan-400 font-semibold">
                                        {style.name}
                                    </option>
                                ))}
                            </optgroup>
                        )}
                    </select>
                </div>
                
                {/* SECONDARY DROPDOWN: UKRAINIAN STYLES */}
                {isUaModeActive && (
                    <div className="bg-gradient-to-r from-blue-900/40 to-yellow-900/20 border border-blue-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="ua-style-select" className="block text-sm font-bold text-blue-300 mb-2 text-left flex justify-between items-center">
                            <span>Specific Ukrainian Style ©</span>
                            <span className="text-xs text-yellow-500">Slava Ukraini! 🇺🇦</span>
                        </label>
                        <select
                            id="ua-style-select"
                            value={selectedStyleId}
                            onChange={handleSubStyleChange}
                            className="w-full bg-gray-800 border border-blue-500 text-white rounded-md p-3 focus:ring-yellow-500 focus:border-yellow-500 shadow-[0_0_15px_rgba(59,130,246,0.2)]"
                        >
                            {ukrainianStyles.map(style => (
                                <option key={style.id} value={style.id}>
                                    {style.name}
                                </option>
                            ))}
                        </select>
                         <p className="text-xs text-gray-400 mt-2 text-left">
                            These folk styles are specially crafted to celebrate Ukrainian culture and heritage.
                        </p>
                    </div>
                )}
                
                {/* SECONDARY DROPDOWN: HOLIDAY STYLES */}
                {isHolidayModeActive && (
                    <div className="bg-gradient-to-r from-red-900/40 to-green-900/20 border border-red-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="holiday-style-select" className="block text-sm font-bold text-red-300 mb-2 text-left flex justify-between items-center">
                            <span>Specific Holiday Style</span>
                            <span className="text-xs text-green-400">Happy Holidays! 🎁</span>
                        </label>
                        <select
                            id="holiday-style-select"
                            value={selectedStyleId}
                            onChange={handleSubStyleChange}
                            className="w-full bg-gray-800 border border-red-500 text-white rounded-md p-3 focus:ring-green-500 focus:border-green-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                        >
                            {holidayStyles.map(style => (
                                <option key={style.id} value={style.id}>
                                    {style.name.replace('* ', '')}
                                </option>
                            ))}
                        </select>
                         <p className="text-xs text-gray-400 mt-2 text-left">
                            Festive styles for various celebrations and seasons.
                        </p>
                    </div>
                )}

                {/* SECONDARY DROPDOWN: FUN STYLES */}
                {isFunModeActive && (
                    <div className="bg-gradient-to-r from-purple-900/40 to-pink-900/20 border border-purple-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="fun-style-select" className="block text-sm font-bold text-purple-300 mb-2 text-left flex justify-between items-center">
                            <span>Specific Fun Style</span>
                            <span className="text-xs text-pink-400">Experimental & Creative ✨</span>
                        </label>
                        <select
                            id="fun-style-select"
                            value={selectedStyleId}
                            onChange={handleSubStyleChange}
                            className="w-full bg-gray-800 border border-purple-500 text-white rounded-md p-3 focus:ring-pink-500 focus:border-pink-500 shadow-[0_0_15px_rgba(168,85,247,0.2)]"
                        >
                            {funStyles.map(style => (
                                <option key={style.id} value={style.id}>
                                    {style.name}
                                </option>
                            ))}
                        </select>
                         <p className="text-xs text-gray-400 mt-2 text-left">
                            Creative styles to transform your look completely!
                        </p>
                    </div>
                )}

                 {/* TERTIARY DROPDOWN: HOLLYWOOD STYLES (Under Fun Collection) */}
                {isHollywoodStyle && (
                    <div className="bg-gradient-to-r from-amber-900/40 to-yellow-900/20 border border-amber-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="hollywood-director-select" className="block text-sm font-bold text-amber-300 mb-2 text-left flex justify-between items-center">
                            <span>Select Film Director Style</span>
                            <span className="text-xs text-yellow-400">Cinematic Universe 🎬</span>
                        </label>
                        <select
                            id="hollywood-director-select"
                            value={selectedPoseId}
                            onChange={(e) => onPoseSelect(e.target.value)}
                            className="w-full bg-gray-800 border border-amber-500 text-white rounded-md p-3 focus:ring-yellow-500 focus:border-yellow-500 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
                        >
                            {DIRECTOR_STYLES.map(style => (
                                <option key={style.id} value={style.id}>
                                    {style.name}
                                </option>
                            ))}
                        </select>
                         <p className="text-xs text-gray-400 mt-2 text-left">
                            Apply the distinct color palette, lighting, and composition of famous directors.
                        </p>
                    </div>
                )}
                
                {/* SECONDARY DROPDOWN: WRITER STYLES */}
                {isWriterModeActive && (
                    <div className="bg-gradient-to-r from-blue-900/40 to-indigo-900/20 border border-blue-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="writer-select" className="block text-sm font-bold text-blue-300 mb-2 text-left flex justify-between items-center">
                            <span>Select Author Universe</span>
                            <span className="text-xs text-blue-400">Literary World 📚</span>
                        </label>
                        <select
                            id="writer-select"
                            value={selectedPoseId}
                            onChange={(e) => onPoseSelect(e.target.value)}
                            className="w-full bg-gray-800 border border-blue-500 text-white rounded-md p-3 focus:ring-indigo-500 focus:border-indigo-500 shadow-[0_0_15px_rgba(59,130,246,0.2)]"
                        >
                            {WRITER_STYLES.map(style => (
                                <option key={style.id} value={style.id}>
                                    {style.name}
                                </option>
                            ))}
                        </select>
                         <p className="text-xs text-gray-400 mt-2 text-left">
                            Immerse yourself in the atmosphere of famous literary worlds.
                        </p>
                    </div>
                )}

                {/* SECONDARY DROPDOWN: HAIRSTYLES */}
                {isHairstyleModeActive && (
                    <div className="bg-gradient-to-r from-pink-900/40 to-rose-900/20 border border-pink-500/50 rounded-lg p-4 mt-2 animate-fade-in flex flex-col gap-4">
                        {/* Hairstyle Shape */}
                        <div>
                            <label htmlFor="hairstyle-select" className="block text-sm font-bold text-pink-300 mb-2 text-left flex justify-between items-center">
                                <span>Select New Hairstyle</span>
                                <span className="text-xs text-rose-400">Step 1: The Cut ✂️</span>
                            </label>
                            <select
                                id="hairstyle-select"
                                value={selectedPoseId}
                                onChange={(e) => onPoseSelect(e.target.value)}
                                className="w-full bg-gray-800 border border-pink-500 text-white rounded-md p-3 focus:ring-rose-500 focus:border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.2)]"
                            >
                                {HAIRSTYLE_OPTIONS.map(style => (
                                    <option key={style.id} value={style.id}>
                                        {style.name}
                                    </option>
                                ))}
                            </select>
                        </div>

                         {/* Hair Color */}
                         <div>
                            <label htmlFor="hair-color-select" className="block text-sm font-bold text-pink-300 mb-2 text-left flex justify-between items-center">
                                <span>Select Hair Color</span>
                                <span className="text-xs text-rose-400">Step 2: The Color 🎨</span>
                            </label>
                            <select
                                id="hair-color-select"
                                value={selectedHairColorId}
                                onChange={(e) => onHairColorSelect(e.target.value)}
                                className="w-full bg-gray-800 border border-pink-500 text-white rounded-md p-3 focus:ring-rose-500 focus:border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.2)]"
                            >
                                {HAIR_COLOR_OPTIONS.map(color => (
                                    <option key={color.id} value={color.id}>
                                        {color.name}
                                    </option>
                                ))}
                            </select>
                        </div>

                         <p className="text-xs text-gray-400 mt-2 text-left">
                            This will retouch your photo to apply the new cut and color while keeping your face and clothes!
                        </p>
                    </div>
                )}

                 {/* SECONDARY DROPDOWN: ACTION POSE (For Urban Full Body) */}
                 {isUrbanTestStyle && (
                    <div className="bg-gradient-to-r from-purple-900/40 to-pink-900/20 border border-purple-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="action-pose-select" className="block text-sm font-bold text-purple-300 mb-2 text-left">
                            Select Dynamic Action Pose (Streetwear)
                        </label>
                        <select
                            id="action-pose-select"
                            value={selectedPoseId}
                            onChange={(e) => onPoseSelect(e.target.value)}
                            className="w-full bg-gray-800 border border-purple-500 text-white rounded-md p-3 focus:ring-pink-500 focus:border-pink-500 shadow-[0_0_15px_rgba(168,85,247,0.2)]"
                        >
                            {ACTION_POSES.map(pose => (
                                <option key={pose.id} value={pose.id}>
                                    {pose.name}
                                </option>
                            ))}
                        </select>
                    </div>
                )}

                {/* SECONDARY DROPDOWN: AGENT POSE (For Secret Agent) */}
                 {isAgentActionStyle && (
                    <div className="bg-gradient-to-r from-emerald-900/40 to-cyan-900/20 border border-emerald-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="agent-pose-select" className="block text-sm font-bold text-emerald-300 mb-2 text-left">
                            Select Cinematic Agent Pose
                        </label>
                        <select
                            id="agent-pose-select"
                            value={selectedPoseId}
                            onChange={(e) => onPoseSelect(e.target.value)}
                            className="w-full bg-gray-800 border border-emerald-500 text-white rounded-md p-3 focus:ring-cyan-500 focus:border-cyan-500 shadow-[0_0_15px_rgba(16,185,129,0.2)]"
                        >
                            {AGENT_POSES.map(pose => (
                                <option key={pose.id} value={pose.id}>
                                    {pose.name}
                                </option>
                            ))}
                        </select>
                    </div>
                )}

                {/* SECONDARY DROPDOWN: FANTASY HERO (For Fairy Tale Movies) */}
                {isFantasyHeroStyle && (
                    <div className="bg-gradient-to-r from-yellow-900/40 to-amber-900/20 border border-yellow-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="fantasy-role-select" className="block text-sm font-bold text-yellow-300 mb-2 text-left">
                            Select Your Legendary Role
                        </label>
                        <select
                            id="fantasy-role-select"
                            value={selectedPoseId}
                            onChange={(e) => onPoseSelect(e.target.value)}
                            className="w-full bg-gray-800 border border-yellow-500 text-white rounded-md p-3 focus:ring-amber-500 focus:border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
                        >
                            {FANTASY_ROLES.map(role => (
                                <option key={role.id} value={role.id}>
                                    {role.name}
                                </option>
                            ))}
                        </select>
                    </div>
                )}

                {/* SECONDARY DROPDOWN: MYTHICAL PARTNER (For Selfie With...) */}
                {isMythicalSelfieStyle && (
                    <div className="bg-gradient-to-r from-pink-900/40 to-purple-900/20 border border-pink-500/50 rounded-lg p-4 mt-2 animate-fade-in">
                        <label htmlFor="mythical-partner-select" className="block text-sm font-bold text-pink-300 mb-2 text-left">
                            Select Your Selfie Partner
                        </label>
                        <select
                            id="mythical-partner-select"
                            value={selectedPoseId}
                            onChange={(e) => onPoseSelect(e.target.value)}
                            className="w-full bg-gray-800 border border-pink-500 text-white rounded-md p-3 focus:ring-purple-500 focus:border-purple-500 shadow-[0_0_15px_rgba(236,72,153,0.2)]"
                        >
                            {MYTHICAL_PARTNERS.map(partner => (
                                <option key={partner.id} value={partner.id}>
                                    {partner.name}
                                </option>
                            ))}
                        </select>
                    </div>
                )}

                <div className="flex flex-col sm:flex-row justify-center items-center gap-4 border-t border-gray-700 pt-6">
                  <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      className="hidden"
                      accept=".csv"
                  />
                  <button
                      onClick={handleUploadClick}
                      className="bg-gray-700 text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 transition-transform transform hover:scale-105"
                  >
                      Upload Custom Styles (CSV)
                  </button>
                  <button
                      onClick={handleDownloadTemplate}
                      className="text-sm text-blue-400 hover:underline focus:outline-none focus:ring-2 focus:ring-blue-500 rounded"
                  >
                      Download Template
                  </button>
                </div>
            </div>
        </div>

        <div className="mt-12 pt-4 border-t border-gray-700">
            <button
                onClick={handleGenerateClick}
                disabled={!selectedStyleId || selectedStyleId === UA_TRIGGER_ID || selectedStyleId === HOLIDAY_TRIGGER_ID || selectedStyleId === FUN_TRIGGER_ID}
                className="group relative w-full max-w-md mx-auto bg-teal-400 text-gray-900 font-bold py-4 px-8 rounded-full shadow-[0_0_20px_rgba(45,212,191,0.5)] hover:bg-teal-300 hover:shadow-[0_0_30px_rgba(45,212,191,0.7)] hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-opacity-50 transition-all duration-300 disabled:bg-gray-600 disabled:text-gray-400 disabled:shadow-none disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3"
            >
                <svg className="w-6 h-6 transition-transform group-hover:scale-110 group-hover:rotate-12" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 6 6.5 9.5 3 12l3.5 2.5L9 18l2.5-3.5L15 12l-3.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z" />
                </svg>
                <span className="text-lg tracking-wide">Generate Headshot</span>
            </button>
        </div>
    </div>
  );
};

export default StyleSelector;
