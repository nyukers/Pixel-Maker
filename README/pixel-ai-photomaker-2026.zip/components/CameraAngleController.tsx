import React from 'react';

interface CameraAngleControllerProps {
    focusPoint: { x: number; y: number };
    onFocusPointChange: (point: { x: number; y: number }) => void;
    aspectRatioId: string;
}

const CameraAngleController: React.FC<CameraAngleControllerProps> = ({
    focusPoint,
    onFocusPointChange,
    aspectRatioId,
}) => {
    const containerRef = React.useRef<HTMLDivElement>(null);

    const handleMouseClick = (event: React.MouseEvent<HTMLDivElement>) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width;
        const y = (event.clientY - rect.top) / rect.height;
        onFocusPointChange({ x, y });
    };

    const points = [
        { x: 0, y: 0 },   // Top-left
        { x: 50, y: 0 },  // Top-center
        { x: 100, y: 0 }, // Top-right
        { x: 100, y: 50 },// Right-center
        { x: 100, y: 100 },// Bottom-right
        { x: 50, y: 100 },// Bottom-center
        { x: 0, y: 100 }, // Bottom-left
        { x: 0, y: 50 },  // Left-center
    ];
    
    const getAspectRatioValue = (id: string): string => {
        switch (id) {
            case 'square':
                return '1 / 1';
            case 'portrait':
                return '3 / 4';
            case 'landscape':
                return '4 / 3';
            default:
                return '1 / 1'; // Default to square to match initial state
        }
    };

    return (
        <div 
            ref={containerRef}
            className="relative w-full bg-gray-800 border-2 border-gray-700 rounded-lg cursor-pointer overflow-hidden transition-all duration-300 ease-in-out"
            style={{ aspectRatio: getAspectRatioValue(aspectRatioId) }}
            onClick={handleMouseClick}
            aria-label="Camera Angle Controller"
            title="Click to set the photo's focal point"
        >
            {/* Centered Schematic Portrait Icon */}
            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
                <g transform="translate(50 50) scale(2.5)" fill="none" stroke="#a0aec0" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="0" cy="-6" r="6" />
                    <path d="M -14 12 C -14 2, 14 2, 14 12" />
                </g>
            </svg>

            {/* Perspective Lines and Marker */}
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 w-full h-full pointer-events-none">
                {/* Lines */}
                <g stroke="rgba(239, 68, 68, 0.7)" strokeWidth="0.5">
                    {points.map((p, i) => (
                        <line
                            key={i}
                            x1={p.x}
                            y1={p.y}
                            x2={focusPoint.x * 100}
                            y2={focusPoint.y * 100}
                        />
                    ))}
                </g>
                {/* Marker */}
                <circle
                    cx={focusPoint.x * 100}
                    cy={focusPoint.y * 100}
                    r="2"
                    fill="rgba(239, 68, 68, 0.9)"
                    stroke="white"
                    strokeWidth="0.5"
                />
            </svg>
        </div>
    );
};

export default CameraAngleController;