import React from 'react';
import { PHOTO_EFFECTS } from '../constants';

interface ImageEditorProps {
  imageSrc: string;
  editPrompt: string;
  onEditPromptChange: (value: string) => void;
  onEditSubmit: () => void;
  onReset: () => void;
  isLoading: boolean;
  onDownload: () => void;
  onApplyEffect: (prompt: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  blurLevel: number;
  onBlurChange: (level: number) => void;
  styleName: string;
}

const ImageEditor: React.FC<ImageEditorProps> = ({
  imageSrc,
  editPrompt,
  onEditPromptChange,
  onEditSubmit,
  onReset,
  isLoading,
  onDownload,
  onApplyEffect,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  blurLevel,
  onBlurChange,
  styleName,
}) => {
  const textareaRef = React.useRef<HTMLTextAreaElement>(null);
  const [dimensions, setDimensions] = React.useState<{ w: number; h: number } | null>(null);

  React.useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto'; // Reset height to recalculate
      textarea.style.height = `${textarea.scrollHeight}px`; // Set to content height
    }
  }, [editPrompt]);

  const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const { naturalWidth, naturalHeight } = e.currentTarget;
    setDimensions({ w: naturalWidth, h: naturalHeight });
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-8">
      <h2 className="text-3xl font-semibold mb-8 text-gray-100 text-center">Step 3: Your AI Headshot</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
        {/* Left Column: Image Only */}
        <div>
            <div className="relative w-full h-fit group">
            <img 
                src={imageSrc} 
                alt="Generated AI headshot" 
                onLoad={handleImageLoad}
                className="rounded-xl shadow-2xl border-2 border-gray-700 w-full" 
            />
            
            {/* Dimension Badge on Hover */}
            {dimensions && (
                <div className="absolute top-3 right-3 bg-black/70 backdrop-blur-sm text-white text-xs font-mono px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none border border-white/20 shadow-lg">
                {dimensions.w} × {dimensions.h} px
                </div>
            )}

            {isLoading && (
                <div className="absolute inset-0 bg-black bg-opacity-60 flex justify-center items-center rounded-xl">
                        <div className="flex flex-col justify-center items-center text-center px-4">
                        <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <p className="text-white mt-2 font-medium">Refining...</p>
                        </div>
                </div>
            )}
            </div>
            {/* Style Name Badge */}
            <div className="mt-4 text-center">
                <div className="text-blue-300 font-medium text-lg mt-1">{styleName}</div>
            </div>
        </div>

        {/* Right Column: Controls */}
        <div className="flex flex-col gap-6 justify-center">
          {/* Blur Slider */}
          <div>
            <label htmlFor="blur-slider" className="block text-sm font-medium text-gray-300 mb-2">
              Background Blur Intensity (AI Bokeh)
            </label>
            <input
              id="blur-slider"
              type="range"
              min="0"
              max="100"
              step="25"
              value={blurLevel}
              onChange={(e) => onBlurChange(Number(e.target.value))}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
              disabled={isLoading}
            />
            <div className="flex justify-between text-xs text-gray-400 px-1 mt-1">
              <span>Sharp (f/16)</span>
              <span>Soft (f/5.6)</span>
              <span>Bokeh (f/2.8)</span>
              <span>Pro Bokeh (f/1.8)</span>
              <span>Max (f/1.2)</span>
            </div>
          </div>

          {/* Effects */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Or apply a quick effect:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PHOTO_EFFECTS.map((effect) => (
                <button
                  key={effect.id}
                  onClick={() => onApplyEffect(effect.prompt)}
                  disabled={isLoading}
                  className="bg-gray-700 text-white text-sm font-semibold py-2 px-3 rounded-md hover:bg-gray-600 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                >
                  {effect.name}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col items-center gap-4 mt-4 border-t border-gray-700 pt-6">
            {/* Primary Actions Row */}
            <div className="flex flex-wrap justify-center gap-3">
              <button
                onClick={onDownload}
                disabled={isLoading}
                className="bg-green-600 text-white font-bold py-2 px-5 rounded-md hover:bg-green-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
              >
                Download
              </button>
              <button
                onClick={onReset}
                className="bg-red-600 text-white font-bold py-2 px-5 rounded-md hover:bg-red-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
                disabled={isLoading}
              >
                Start Over
              </button>
            </div>

            {/* History Controls Row */}
            <div className="flex justify-center gap-3">
              <button
                onClick={onUndo}
                disabled={!canUndo || isLoading}
                className="bg-gray-700 text-white font-semibold py-2 px-6 rounded-md hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
                aria-label="Undo last action"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>
                Undo
              </button>
              <button
                onClick={onRedo}
                disabled={!canRedo || isLoading}
                className="bg-gray-700 text-white font-semibold py-2 px-6 rounded-md hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
                aria-label="Redo last action"
              >
                Redo
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 7v6h-6"/><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3L21 13"/></svg>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Row (Full Width): Prompt Input Area */}
        <div className="md:col-span-2 pt-2">
            <label htmlFor="edit-prompt" className="block text-sm font-medium text-gray-300 mb-2">
                The FINAL PROMPT is below. You can change (refine/inpaint) your result by writing text here INSTEAD, for example, “add a retro filter” “change the background to a library” etc, and pressing the "Go" button.
            </label>
            <div className="flex gap-2 items-start">
                <textarea
                    ref={textareaRef}
                    id="edit-prompt"
                    value={editPrompt}
                    onChange={(e) => onEditPromptChange(e.target.value)}
                    placeholder="Describe your change..."
                    className="flex-grow bg-gray-700 border border-gray-600 text-white rounded-md p-3 focus:ring-blue-500 focus:border-blue-500 resize-none overflow-hidden min-h-[50px]"
                    disabled={isLoading}
                />
                <button
                    onClick={onEditSubmit}
                    disabled={isLoading || !editPrompt}
                    className="bg-purple-600 text-white font-bold py-3 px-5 rounded-md hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors h-full"
                >
                    Go
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ImageEditor;