import React from 'react';

interface ImageUploaderProps {
  onImageUpload: (files: File[]) => void;
  isLoading: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, isLoading }) => {
  const inputRef = React.useRef<HTMLInputElement>(null);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const [isCameraOpen, setIsCameraOpen] = React.useState(false);
  const [cameraError, setCameraError] = React.useState<string | null>(null);

  // Stop the camera stream when component unmounts or camera is closed
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraOpen(false);
    setCameraError(null);
  };

  const handleStartCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      setIsCameraOpen(true);
      // Slight delay to ensure video element is rendered
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch (err) {
      console.error("Error accessing camera:", err);
      setCameraError("Could not access camera. Please check permissions.");
    }
  };

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext('2d');
      if (context) {
        // Draw the video frame to the canvas
        // Flip horizontally for a mirror effect if using front camera (optional, but standard for selfies)
        context.translate(canvas.width, 0);
        context.scale(-1, 1);
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert canvas to blob/file
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], "webcam-capture.jpg", { type: "image/jpeg" });
            onImageUpload([file]);
            stopCamera();
          }
        }, 'image/jpeg', 0.95);
      }
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      onImageUpload(Array.from(files));
    }
  };

  const handleUploadClick = () => {
    inputRef.current?.click();
  };

  return (
    <div className="w-full max-w-2xl mx-auto text-center p-4 sm:p-8">
      <h2 className="text-2xl font-semibold mb-4 text-gray-100">Step 1: Upload Your Selfie</h2>
      <p className="text-gray-400 mb-6">Choose a clear, front-facing photo</p>

      {cameraError && (
        <div className="mb-4 bg-red-900/50 border border-red-500 text-red-200 px-4 py-2 rounded-md">
          {cameraError}
        </div>
      )}

      {isCameraOpen ? (
        <div className="flex flex-col items-center animate-fade-in bg-gray-800 p-4 rounded-xl shadow-2xl border border-gray-700">
          <div className="relative w-full max-w-md aspect-video bg-black rounded-lg overflow-hidden mb-4 border-2 border-gray-600">
             <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted
                className="w-full h-full object-cover transform scale-x-[-1]" // Mirror effect CSS
             />
             <canvas ref={canvasRef} className="hidden" />
          </div>
          
          <div className="flex gap-4">
             <button
              onClick={handleCapture}
              className="bg-red-600 hover:bg-red-500 text-white font-bold py-3 px-8 rounded-full shadow-[0_0_15px_rgba(220,38,38,0.5)] transition-all flex items-center gap-2"
             >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                Snap Photo
             </button>
             <button
              onClick={stopCamera}
              className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 px-6 rounded-full transition-all"
             >
                Cancel
             </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-4 items-center">
            {/* Hidden Input */}
            <input
                type="file"
                ref={inputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/png, image/jpeg, image/webp"
                disabled={isLoading}
                multiple
            />
            
            {/* Main Upload Button */}
            <button
                onClick={handleUploadClick}
                disabled={isLoading}
                className="group relative w-full max-w-md bg-teal-400 text-gray-900 font-bold py-4 px-8 rounded-full shadow-[0_0_20px_rgba(45,212,191,0.5)] hover:bg-teal-300 hover:shadow-[0_0_30px_rgba(45,212,191,0.7)] hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-opacity-50 transition-all duration-300 disabled:bg-gray-600 disabled:text-gray-400 disabled:shadow-none disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3"
            >
                <svg className="w-6 h-6 transition-transform group-hover:scale-110 group-hover:rotate-12" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 6 6.5 9.5 3 12l3.5 2.5L9 18l2.5-3.5L15 12l-3.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z" />
                </svg>
                <span className="text-lg tracking-wide">{isLoading ? 'Processing...' : 'Select Photo(s)'}</span>
            </button>

            <div className="text-gray-500 font-medium">- OR -</div>

            {/* Camera Button */}
            <button
                onClick={handleStartCamera}
                disabled={isLoading}
                className="group w-full max-w-md bg-blue-600 text-white font-bold py-3 px-8 rounded-full shadow-lg hover:bg-blue-500 hover:shadow-blue-500/50 hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-3"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                <span className="text-lg tracking-wide">Use Webcam</span>
            </button>
        </div>
      )}
    </div>
  );
};

export default ImageUploader;