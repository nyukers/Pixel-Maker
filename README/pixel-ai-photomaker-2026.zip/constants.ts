
import type { StyleOption, PhotoEffect, AspectRatio, PoseOption } from './types';

export const ASPECT_RATIOS: AspectRatio[] = [
  {
    id: 'square',
    name: 'Square (1:1)',
    prompt: `square aspect ratio (1:1)`,
  },
  {
    id: 'portrait',
    name: 'Portrait (3:4)',
    prompt: `portrait aspect ratio (3:4)`,
  },
  {
    id: 'landscape',
    name: 'Cinematic / Landscape (4:3)',
    prompt: `cinematic landscape aspect ratio (4:3)`,
  },
];

export const ACTION_POSES: PoseOption[] = [
  {
    id: 'walking',
    name: 'Mid-Stride Walk',
    prompt: 'caught mid-stride walking confidently towards the camera, dynamic fashion week street style, showcasing a fit and athletic posture, hair gently moving with the stride',
  },
  {
    id: 'jumping',
    name: 'Mid-Air Jump',
    prompt: 'caught jumping high in the air, dynamic freeze-frame. Hair is flying upwards and messy due to the jump momentum. Energetic and floating, displaying a fit physique',
  },
  {
    id: 'squat',
    name: 'Low Squat / Crouch',
    prompt: 'squatting down in a cool street pose, low angle camera shot, knees bent, looking confident and strong',
  },
  {
    id: 'leaning',
    name: 'Leaning Against Wall',
    prompt: 'leaning casually against a textured wall, one foot resting on the wall, relaxed attitude, fit body shape',
  },
  {
    id: 'running',
    name: 'Fast Run',
    prompt: 'running fast towards the camera, slight motion blur on limbs. Hair is swept back violently by the wind/speed. High energy action shot, athletic build',
  },
  {
    id: 'sitting',
    name: 'Sitting on Steps',
    prompt: 'sitting relaxed on concrete steps or a ledge, elbows on knees, engaging with the camera, looking stylish and fit',
  },
  {
    id: 'looking-back',
    name: 'Walking Away & Looking Back',
    prompt: 'walking away from the camera but turning head back to look over the shoulder, mysterious, cool, and slim silhouette',
  },
  {
    id: 'split',
    name: 'Transverse Split',
    prompt: 'performing a perfect transverse split (side split) on the pavement, showcasing extreme flexibility and a fit athletic physique, impressive urban gymnastic pose',
  },
  {
    id: 'air-split',
    name: 'Air Split Jump (Longitudinal)',
    prompt: 'caught in mid-air performing a perfect longitudinal split (front split leap), showing extreme flexibility and athletic power. Hair is flying wildly and chaotically in the air due to the jump. Dynamic freeze-frame, high energy, perfect form',
  },
];

export const AGENT_POSES: PoseOption[] = [
  {
    id: 'casino-leaning',
    name: 'Casino Royale Lean (007)',
    prompt: 'leaning elegantly against a high-stakes baccarat table or a luxury bar in a grand casino. Holding a martini glass. Wearing an immaculate, expensive tuxedo or evening gown. The vibe is sophisticated, dangerous, and incredibly fit',
  },
  {
    id: 'wick-club',
    name: 'Neon Gun-Fu (John Wick)',
    prompt: 'standing in a tactical combat stance in a luxurious, rain-slicked neon nightclub. Wet hair, intense focused gaze, bruised but unstoppable. Wearing a sleek, dark, bulletproof three-piece suit. Cinematic purple and blue neon lighting reflecting on the wet pavement',
  },
  {
    id: 'top-gun-walk',
    name: 'Maverick Walk (Top Gun)',
    prompt: 'walking confidently away from a fighter jet on an aircraft carrier runway during golden hour. Wearing a green flight suit or a leather bomber jacket with patches and aviator sunglasses. Warm sunset lighting, heat haze from the jet engines',
  },
  {
    id: 'fast-furious',
    name: 'Quarter Mile King (Fast & Furious)',
    prompt: 'leaning casually against the hood of a modified, neon-lit American muscle car or JDM racer. Wearing a tight white tank top, jeans, and a silver cross necklace. Night street racing atmosphere, wet asphalt, lens flare from headlights. "I live my life a quarter mile at a time" attitude',
  },
  {
    id: 'jurassic-flare',
    name: 'T-Rex Flare Rescue (Jurassic Park)',
    prompt: 'standing in a pouring rainstorm in a prehistoric jungle, holding a bright red burning flare high to distract a dinosaur. Wearing a soaked blue denim shirt and khaki trousers. Mud on face, intense screaming expression. Dramatic red lighting from the flare illuminating the rain',
  },
  {
    id: 'matrix-dodge',
    name: 'Bullet Time Dodge (The Matrix)',
    prompt: 'leaning upper body backwards parallel to the ground to dodge bullets (The Matrix style). Long black trench coat billowing in slow motion, shockwaves in the air, extreme flexibility and core strength, green digital code tint in the shadows',
  },
  {
    id: 'kill-bill-sword',
    name: 'The Bride Stance (Kill Bill)',
    prompt: 'standing ready in a snowy Japanese garden at night. Wearing a bright yellow motorcycle jumpsuit with black stripes. Holding a katana sword with both hands. Intense focus, snowflakes falling gently, cinematic wide shot',
  },
  {
    id: 'terminator-march',
    name: 'Cybernetic March (Terminator)',
    prompt: 'walking relentlessly through fire and wreckage. Wearing a black leather jacket, dark sunglasses, and riding boots. Holding a shotgun resting on the shoulder. Half of the face is shadowed, robotic expression, apocalyptic blue night lighting',
  },
  {
    id: 'tomb-raider',
    name: 'Dual Pistol Jump (Tomb Raider)',
    prompt: 'caught in mid-air jumping across a crumbling ancient ruin. Firing dual pistols. Wearing a tank top, cargo shorts, and combat boots. braid flying in the wind. Dust and debris, sunny jungle adventure atmosphere',
  },
  {
    id: 'rappelling',
    name: 'Wire Descent (Mission: Impossible)',
    prompt: 'hanging horizontally suspended by a wire inches above a high-tech pressure-sensitive white floor. Tense muscles, beads of sweat, focused expression. Wearing a sleek black tactical stealth suit. Clean, sterile, high-security server room environment',
  },
  {
    id: 'mad-max',
    name: 'Wasteland Warrior (Mad Max)',
    prompt: 'standing in a modified, rusted war-rig vehicle in a vast desert wasteland. Wearing distressed leather armor, goggles, and survival gear. Sandstorm approaching in the background. High contrast, gritty, orange and teal color grading',
  },
  {
    id: 'die-hard',
    name: 'Nakatomi Survivor (Die Hard)',
    prompt: 'crawling through an industrial air vent or standing in a wrecked office floor. Wearing a dirty, sweat-stained white tank top. Holding a flashlight. Face smeared with grime and soot. The look of an exhausted but tough hero. Broken glass on the floor',
  },
  {
    id: 'motorcycle-slide',
    name: 'Motorcycle Slide (Akira)',
    prompt: 'captured in a dynamic low-angle slide next to a sleek, futuristic red spy motorcycle. Sparks flying from the metal sliding on asphalt. Intense action expression, wearing sleek leather racing gear, fit body, leaving a trail of light',
  },
  {
    id: 'explosion-walk',
    name: 'Explosion Walk (Desperado)',
    prompt: 'walking calmly and confidently towards the camera while a massive cinematic fireball explosion erupts in the background. Cool guys don\'t look at explosions. Wearing a torn but stylish tuxedo/evening gown, intense gaze, soot on skin, fit athletic body',
  },
];

export const FANTASY_ROLES: PoseOption[] = [
  {
    id: 'ring-bearer',
    name: 'The Ring Bearer (Hobbit)',
    prompt: 'standing in the lush green hills of the Shire, in front of a round wooden door. Wearing a rustic cloak, vest, and carrying a small backpack. Holding a golden ring on a chain. Atmosphere is cozy, sunny, and magical. High fantasy movie style',
  },
  {
    id: 'dragon-rider',
    name: 'Dragon Mother/Rider',
    prompt: 'standing majestically on a desert cliff edge. Wearing an elegant, structured leather and silk gown with dragon-scale textures. A small dragon is perched on the shoulder. Platinum blonde braided wig styling (optional). Intense, regal expression. Cinematic sunset lighting',
  },
  {
    id: 'wizard-student',
    name: 'Wizard School Student',
    prompt: 'standing in a grand, ancient magical castle hallway with floating candles. Wearing a black school robe with a striped tie and scarf. Holding a magic wand that is emitting sparks. Atmosphere is mysterious and magical',
  },
  {
    id: 'elven-archer',
    name: 'Elven Prince/Archer',
    prompt: 'standing in a golden autumn forest (Rivendell style). Wearing intricate silver and velvet elven armor. Holding a longbow. Elegant, ethereal appearance with long flowing hair. Lighting is soft, glowing, and divine',
  },
  {
    id: 'caribbean-pirate',
    name: 'Captain Pirate',
    prompt: 'standing on the deck of a wooden pirate ship in the Caribbean sea. Wearing a tricorne hat, dreadlocks or bandana, and a weathered coat. Holding a cutlass or compass. Ocean spray, sunlight, adventure atmosphere',
  },
  {
    id: 'wonder-warrior',
    name: 'Amazonian Warrior',
    prompt: 'standing in a heroic battle stance on a Greek island cliff. Wearing shiny red and gold metallic armor with a tiara and bracelets. Holding a glowing lasso or shield. Strong, athletic, god-like physique. Dramatic sunlight',
  },
  {
    id: 'dark-fairy',
    name: 'Dark Fairy (Maleficent)',
    prompt: 'standing in a dark, thorny forest. Wearing a dramatic black gown with high collar and magnificent black horns on the head. Pale skin, red lips, intense gaze. Holding a wooden staff with a green glowing orb. Gothic fantasy atmosphere',
  },
  {
    id: 'jedi-knight',
    name: 'Space Knight (Jedi)',
    prompt: 'standing in a futuristic sci-fi corridor or desert planet. Wearing brown hooded robes and tunics. Holding an ignited laser sword (lightsaber) - blue or green. Telekinetic pose. Cinematic sci-fi movie lighting',
  },
  {
    id: 'viking-god',
    name: 'God of Thunder (Viking)',
    prompt: 'standing amidst a storm on a rocky mountain. Wearing heavy silver plate armor and a red cape. Holding a crackling lightning hammer. Beard (if male), fierce expression. Lightning strikes in the background. Mythological blockbuster style',
  },
  {
    id: 'alice-wonder',
    name: 'Lost in Wonderland',
    prompt: 'standing in a surreal, giant mushroom forest. Wearing a classic blue dress with a white apron. Surrounded by floating tea cups and playing cards. Dreamy, colorful, psychedelic fantasy atmosphere',
  }
];

// DIRECTOR STYLES
export const DIRECTOR_STYLES: PoseOption[] = [
    {
        id: 'wes-anderson',
        name: 'Wes Anderson',
        prompt: 'A wide, PERFECTLY SYMMETRICAL tracking shot. The subject is standing dead-center holding a peculiar object. Pastel color palette (pink, mint, yellow). The background is a stylized, diorama-like set. Flat lighting, high saturation.',
    },
    {
        id: 'tarantino',
        name: 'Quentin Tarantino',
        prompt: 'A low-angle "Trunk Shot" or a tense standoff. The subject is framed using the RULE OF THIRDS, leaning into the camera or pointing a prop, looking tough and dangerous. High contrast, saturated colors (yellow and black). Grindhouse aesthetic.',
    },
    {
        id: 'nolan',
        name: 'Christopher Nolan',
        prompt: 'A high-stakes action scene on an IMAX scale. The subject is NOT centered, creating a sense of scale. Tactical suit or sharp formal wear. The background is complex architecture or a physics-bending environment. Cold, desaturated tones, deep blacks, teal highlights.',
    },
    {
        id: 'tim-burton',
        name: 'Tim Burton',
        prompt: 'A gothic fantasy shot. The subject is wandering through a twisted, dark forest. High contrast lighting with deep shadows. The subject has a mysterious, slightly pale look. Colors are dark blues, purples, and stripes. Off-center composition showing the environment.',
    },
    {
        id: 'wong-kar-wai',
        name: 'Wong Kar-wai',
        prompt: 'A dynamic, moody shot with step-printing motion blur. The subject is looking away from the camera in a neon-lit, rainy street. Colors are intense reds and greens. Shallow depth of field. A fleeting, romantic moment.',
    },
    {
        id: 'kubrick',
        name: 'Stanley Kubrick',
        prompt: 'A tense, psychological standoff in a one-point perspective corridor. SYMMETRICAL COMPOSITION. Sterile, bright lighting or ominous red emergency lighting. The subject has an intense "Kubrick Stare", looking slightly up from beneath the brow.',
    },
    {
        id: 'michael-bay',
        name: 'Michael Bay',
        prompt: 'A high-octane action blockbuster shot. The subject is running away from a massive explosion in slow motion. Low angle, ROTATING CAMERA feel. "Golden Hour" sunset lighting with intense lens flares. High contrast, sweaty skin, teal and orange grading.',
    },
    {
        id: 'denis-villeneuve',
        name: 'Denis Villeneuve',
        prompt: 'A wide, epic shot emphasizing scale. The subject is a small silhouette against a massive, brutalist structure in the distance (Rule of Thirds). Monochromatic color palette (orange fog or cold grey). Atmosphere is heavy and awe-inspiring.',
    },
    {
        id: 'greta-gerwig',
        name: 'Greta Gerwig',
        prompt: 'A candid, lively running shot. The subject is running down a street or dancing, full of emotion and life, not looking at the camera. Soft, warm, golden indie-film lighting. Authentic, hopeful, and dynamic motion.',
    },
    {
        id: 'fincher',
        name: 'David Fincher',
        prompt: 'A dark, intense investigation scene. The subject is looking through files or holding a flashlight. Monochromatic green/yellow tint. Low key lighting, crushed blacks. The camera is locked off and steady, framing the subject in the side of the frame.',
    },
    {
        id: 'ridley-scott',
        name: 'Ridley Scott',
        prompt: 'An epic sci-fi or historical battle stance. Atmospheric smoke and haze with "God Rays" (volumetric lighting). The subject is looking towards the horizon (3/4 view). High detail background, gritty realism, cool blues and metallic tones.',
    },
    {
        id: 'guillermo-del-toro',
        name: 'Guillermo del Toro',
        prompt: 'A dark fairy tale encounter. The subject is interacting with a magical artifact. Amber and teal color palette. Intricate textures, gears, and jars in the background. A moment of wonder and danger in a magical world.',
    },
    {
        id: 'james-cameron',
        name: 'James Cameron',
        prompt: 'A futuristic action hero pose. The subject is piloting a vehicle or holding high-tech gear. Dominant cool blue and teal color palette. The lighting is moody but crisp. Epic scale, technological integration, dynamic 3/4 angle.',
    },
    {
        id: 'luc-besson',
        name: 'Luc Besson',
        prompt: 'A stylized, vibrant action close-up. The subject is driving a flying car. Warm, golden lighting dominating the scene. Wide-angle lens close to the face (dynamic distortion). The background is a colorful futuristic metropolis.',
    },
    {
        id: 'guy-ritchie',
        name: 'Guy Ritchie',
        prompt: 'A dynamic freeze-frame of a fight or chase. The subject is throwing a punch or running, captured in a "Snorricam" style. High contrast, desaturated brownish/sepia grading. Fast-paced, gritty, street-smart, and aggressive.',
    }
];

// WRITER STYLES (New)
export const WRITER_STYLES: PoseOption[] = [
    {
        id: 'stephen-king',
        name: 'Stephen King (Horror)',
        prompt: 'Atmosphere of rural Maine. Eerie, misty, and slightly menacing. The subject is standing in front of an old, creepy Victorian house or a cornfield. Elements like red balloons or a vintage typewriter in the background. Lighting is moody and shadowy. 80s thriller vibe.',
    },
    {
        id: 'edgar-allan-poe',
        name: 'Edgar Allan Poe (Gothic)',
        prompt: 'Classic Gothic Horror. The subject is sitting in a dark, candlelit study with velvet curtains. A raven is perched nearby. Skulls, old books, and dust. The lighting is deep shadows and gloom (chiaroscuro). 19th-century melancholic vibe.',
    },
    {
        id: 'agatha-christie',
        name: 'Agatha Christie (Mystery)',
        prompt: 'Classic Murder Mystery. The subject looks suspicious or detective-like. Background is a luxurious wagon of the Orient Express or an English manor library. Props like a magnifying glass or a cup of tea. 1920s elegant fashion and Art Deco styling.',
    },
    {
        id: 'dan-brown',
        name: 'Dan Brown (Thriller)',
        prompt: 'High-stakes Conspiracy Thriller. The subject is running or investigating in a famous location (Louvre, Vatican, Rome). Background involves ancient symbols, cryptexes, and hidden maps. Lighting is blue and orange (action movie). Intellectual but urgent vibe.',
    },
    {
        id: 'tolkien',
        name: 'J.R.R. Tolkien (High Fantasy)',
        prompt: 'Epic High Fantasy. The subject is a traveler in Middle-earth. Background is a cozy Hobbit hole door or a majestic mountain range. Holding a wooden pipe or an ancient map. Earthy tones, green and gold. Peaceful yet adventurous.',
    },
    {
        id: 'rowling',
        name: 'J.K. Rowling (Magical)',
        prompt: 'Wizarding World. The subject is a student or professor at a magical school. Wearing a long scarf and holding a wand. Background of floating candles, moving paintings, and stone castle walls. Whimsical and magical lighting.',
    },
    {
        id: 'lovecraft',
        name: 'H.P. Lovecraft (Cosmic Horror)',
        prompt: 'Cosmic Horror / Noir. The subject is a 1920s investigator losing their mind. Background implies ancient, non-Euclidean geometry, tentacles in the shadows, or a gloomy fishing village (Innsmouth). Lighting is sickly green and dark grey. Grainy film texture.',
    },
    {
        id: 'jane-austen',
        name: 'Jane Austen (Romance)',
        prompt: 'Regency Era Romance. The subject is wearing elegant period clothing (bonnet, high collar). Background is a lush English garden or a grand ballroom. Soft, pastel colors. Romantic, airy, and painterly lighting. Oil painting aesthetic.',
    },
    {
        id: 'conan-doyle',
        name: 'Arthur Conan Doyle (Detective)',
        prompt: 'Victorian Detective. The subject is in foggy London (Baker Street). Wearing a tweed coat or deerstalker hat. Smoking a pipe. Gaslight streetlamps in the background. Sepia tones, mystery, and intellect.',
    },
    {
        id: 'george-rr-martin',
        name: 'George R.R. Martin (Grim Fantasy)',
        prompt: 'Grimdark Medieval Fantasy. The subject is sitting on a throne of swords or standing on a snowy wall. Wearing heavy furs and armor. A dragon silhouette in the sky. Cold, desaturated blue and grey tones. Gritty and dangerous.',
    },
    {
        id: 'hemingway',
        name: 'Ernest Hemingway (Adventure)',
        prompt: 'Rugged Adventure. The subject is at sea on a fishing boat or on a safari. Wearing a simple linen shirt or fisherman sweater. Tanned skin, beard (if male). Blue ocean or savannah background. Hard, natural sunlight. Minimalist and masculine.',
    },
    {
        id: 'lewis-carroll',
        name: 'Lewis Carroll (Surrealism)',
        prompt: 'Surreal Wonderland. The subject is at a tea party with impossible geometry. Giant mushrooms, floating clocks, and playing cards. Vibrant, psychedelic colors. Dreamy and slightly disorienting atmosphere.',
    }
];

// New "Selfie with..." partners
export const MYTHICAL_PARTNERS: PoseOption[] = [
  {
    id: 'shrek',
    name: 'Shrek (Swamp)',
    prompt: 'Shrek the Ogre. He is large, green, has trumpet-like ears, and is smiling broadly. The background is a sunny swamp with a wooden hut',
  },
  {
    id: 'spiderman',
    name: 'Spider-Man',
    prompt: 'Spider-Man in his classic red and blue suit, crouching slightly or hanging upside down next to the subject. The background is a high NYC rooftop with city skyscrapers',
  },
  {
    id: 'barbie',
    name: 'Barbie',
    prompt: 'Barbie (Margot Robbie style). She is wearing a bright pink western outfit or gingham dress, smiling perfectly. The background is a plastic fantastic Barbieland with pink houses and blue sky',
  },
  {
    id: 'jack-sparrow',
    name: 'Jack Sparrow',
    prompt: 'Captain Jack Sparrow. He is wearing his pirate hat, dreadlocks with beads, and eyeliner. He looks slightly confused or tipsy. The background is the deck of the Black Pearl ship with ocean waves',
  },
  {
    id: 'joker',
    name: 'The Joker',
    prompt: 'The Joker (Heath Ledger style). He has messy green hair, smudged clown makeup, and a purple suit. He is leaning in with a chaotic grin. The background is a gritty Gotham city street at night',
  },
  {
    id: 'yoda',
    name: 'Master Yoda',
    prompt: 'Master Yoda. He is small, green, wrinkled, and holding a cane. He is looking up wisely at the camera. The background is the swampy forests of Dagobah',
  },
  {
    id: 'deadpool',
    name: 'Deadpool',
    prompt: 'Deadpool in his red and black tactical suit. He is making a "peace" sign or bunny ears behind the subject\'s head. The background is a chaotic highway overpass',
  },
  {
    id: 'harry-potter',
    name: 'Harry Potter',
    prompt: 'Harry Potter wearing his Gryffindor school robes, round glasses, and holding a wand. He has a lightning scar. The background is the Great Hall of Hogwarts with floating candles',
  },
  {
    id: 'pikachu',
    name: 'Giant Detective Pikachu',
    prompt: 'a life-sized, furry Detective Pikachu wearing a deerstalker hat. He is cute and fuzzy. The background is Ryme City with neon lights',
  }
];

// New Hairstyle Options
export const HAIRSTYLE_OPTIONS: PoseOption[] = [
  {
    id: 'rapunzel-braid',
    name: 'Rapunzel Long Braid',
    prompt: 'an incredibly long single braid cascading down the back or over one shoulder (Rapunzel style). Intricate weaving, healthy shine, fairy-tale look',
  },
  {
    id: 'long-wavy',
    name: 'Long Wavy Layers',
    prompt: 'long, voluminous wavy hair with layers, cascading down the shoulders. Soft, romantic texture',
  },
  {
    id: 'curtain-bangs',
    name: 'Curtain Bangs & Layers',
    prompt: 'a trendy medium-length cut with face-framing curtain bangs and textured layers. Modern blow-out look',
  },
  {
    id: 'french-bob',
    name: 'French Bob with Bangs',
    prompt: 'a chic, chin-length French bob with soft fringe bangs. Stylish, Parisian, and face-framing',
  },
  {
    id: 'sleek-ponytail',
    name: 'Sleek High Ponytail',
    prompt: 'a sleek, high ponytail pulled back tightly for a snatched, modern look. Smooth texture, professional and sharp',
  },
  {
    id: 'half-up',
    name: 'Half-Up Half-Down',
    prompt: 'a romantic half-up, half-down hairstyle. The top section is pulled back gently, while the rest flows freely. Soft and versatile',
  },
  {
    id: 'high-bun',
    name: 'High Top Knot Bun',
    prompt: 'a sleek, high top knot bun. Elegant, lifting the face, very chic and clean',
  },
  {
    id: 'space-buns',
    name: 'Space Buns (Fun)',
    prompt: 'two cute space buns on top of the head (one on each side). Playful, youthful, and trendy festival look',
  },
  {
    id: 'side-braid',
    name: 'Boho Side Braid',
    prompt: 'a loose, bohemian side fishtail braid resting on one shoulder. Romantic, soft, and textured',
  },
  {
    id: 'pixie-cut',
    name: 'Textured Pixie Cut',
    prompt: 'a short, modern textured pixie cut. Bold, confident, and low-maintenance style',
  },
  {
    id: 'buzz-cut',
    name: 'Buzz Cut (Edgy)',
    prompt: 'a bold, ultra-short buzz cut. Edgy, high-fashion, and striking. Highlights facial structure',
  },
  {
    id: 'hollywood-waves',
    name: 'Old Hollywood Waves',
    prompt: 'glamorous, glossy Old Hollywood waves pushed to one side. Elegant, vintage red-carpet style',
  },
  {
    id: 'messy-bun',
    name: 'Messy Bun',
    prompt: 'a casual, effortless messy bun on top of the head with a few loose strands framing the face. Relaxed vibe',
  },
  {
    id: 'straight-sleek',
    name: 'Straight & Sleek (Middle Part)',
    prompt: 'long, bone-straight hair with a sharp middle part. Glossy, smooth, and high-fashion',
  },
  {
    id: 'double-braids',
    name: 'Double Dutch Braids',
    prompt: 'two tight Dutch braids (boxer braids) going down the back. Sporty, youthful, and neat',
  },
  {
    id: 'curly-shag',
    name: 'Curly Shag / Wolf Cut',
    prompt: 'a trendy curly shag or wolf cut with lots of volume and fringe. Edgy, rock-n-roll texture',
  },
  {
    id: 'afro-volume',
    name: 'Natural Afro Volume',
    prompt: 'beautiful, voluminous natural afro texture forming a halo around the face. Empowering and bold',
  }
];

export const HAIR_COLOR_OPTIONS: PoseOption[] = [
    {
        id: 'original',
        name: 'Keep Original Color',
        prompt: "IMPORTANT: Match the subject's ORIGINAL HAIR COLOR from the source photo.",
    },
    {
        id: 'highlights',
        name: 'Highlights / Balayage',
        prompt: "IMPORTANT: Dye the hair with natural-looking sun-kissed Highlights / Balayage, adding depth and dimension.",
    },
    {
        id: 'blonde',
        name: 'Platinum Blonde',
        prompt: "IMPORTANT: Dye the hair a shiny, icy Platinum Blonde.",
    },
    {
        id: 'golden-blonde',
        name: 'Golden Blonde',
        prompt: "IMPORTANT: Dye the hair a warm, sunny Golden Blonde.",
    },
    {
        id: 'brunette',
        name: 'Dark Brunette',
        prompt: "IMPORTANT: Dye the hair a rich, deep Dark Brunette.",
    },
    {
        id: 'chestnut',
        name: 'Warm Chestnut',
        prompt: "IMPORTANT: Dye the hair a warm Chestnut Brown with reddish undertones.",
    },
    {
        id: 'black',
        name: 'Jet Black',
        prompt: "IMPORTANT: Dye the hair a silky, shiny Jet Black.",
    },
    {
        id: 'ginger',
        name: 'Natural Ginger/Red',
        prompt: "IMPORTANT: Dye the hair a natural, vibrant Ginger Red.",
    },
    {
        id: 'silver',
        name: 'Silver / Grey',
        prompt: "IMPORTANT: Dye the hair a stylish, modern Metallic Silver/Grey.",
    },
    {
        id: 'pink',
        name: 'Pastel Pink',
        prompt: "IMPORTANT: Dye the hair a soft, trendy Pastel Pink.",
    },
    {
        id: 'neon-blue',
        name: 'Neon Blue',
        prompt: "IMPORTANT: Dye the hair a vibrant Electric Blue.",
    },
    {
        id: 'purple',
        name: 'Deep Purple',
        prompt: "IMPORTANT: Dye the hair a rich, dark Royal Purple.",
    },
    {
        id: 'rainbow',
        name: 'Rainbow / Holographic',
        prompt: "IMPORTANT: Dye the hair with a multi-colored Rainbow / Holographic effect.",
    }
];

export const PHOTO_EFFECTS: PhotoEffect[] = [
  {
    id: 'warm',
    name: 'Warm Tone',
    prompt: `Add a warm, golden sunlight filter to the image. Keep the subject unchanged, just adjust the color balance.`,
  },
  {
    id: 'cool',
    name: 'Cool Tone',
    prompt: `Add a cool, bluish, cinematic winter filter to the image. Keep the subject unchanged, just adjust the color balance.`,
  },
  {
    id: 'bw',
    name: 'Black & White',
    prompt: `Convert the image to high-contrast black and white. Keep the subject details sharp.`,
  },
  {
    id: 'vintage',
    name: 'Vintage',
    prompt: `Apply a vintage film grain and subtle sepia tone effect. Give it a classic look.`,
  },
  {
    id: 'cyber',
    name: 'Cyberpunk',
    prompt: `Add neon pink and blue lighting accents for a futuristic look.`,
  },
  {
    id: 'soft',
    name: 'Soft Focus',
    prompt: `Apply a dreamy soft focus effect, slightly glowing highlights.`,
  },
  {
    id: 'dramatic',
    name: 'Dramatic',
    prompt: `Increase contrast and darken shadows for a dramatic, moody look.`,
  },
  {
    id: 'pop',
    name: 'Pop Colors',
    prompt: `Increase saturation and vibrancy to make colors pop.`,
  },
];

// Database of Ukrainian Regional Embroidery Styles
export const UKRAINIAN_REGIONS = [
  {
    name: "Bukovyna (Буковина)",
    desc: "vibrant multicolored geometric ornaments with high density cross-stitch. The dominant colors are deep red, black, yellow, and touches of teal, forming intricate diagonal motifs on white linen."
  },
  {
    name: "Zhytomyrshchyna (Житомирщина)",
    desc: "geometric rosette and diamond symbols in red and black thread on white linen. It is a repetitive rhythmic ornament typical of traditional folk art."
  },
  {
    name: "Luhanshchyna (Луганщина)",
    desc: "stylized floral-geometric motifs using a combination of red and teal-blue threads on white fabric. It shows 'brokar' style influence with a distinct cross-stitch technique."
  },
  {
    name: "Prydniprovya (Придніпров'я)",
    desc: "dynamic red and black floral-geometric vines and stylized rosettes in the Dnipro style. The composition is airy on white canvas."
  },
  {
    name: "Khersonshchyna (Херсонщина)",
    desc: "strictly geometric black embroidery with red accents, featuring linear motifs, triangles, and crosses. The look is minimalist but with bold contrast on white linen."
  },
  {
    name: "Vinnychchyna (Вінниччина)",
    desc: "complex geometric zig-zags and diamonds with high contrast red and black threads, featuring the 'Nyzzynka' style stitching visual."
  },
  {
    name: "Zakarpattia (Закарпаття)",
    desc: "colorful geometric diamonds and zigzags in a warm color palette (yellow, orange, brown, deep red). The texture resembles woven rug patterns with thick stitching on rustic linen."
  },
  {
    name: "Lvivshchyna (Львівщина)",
    desc: "an airy geometric pattern with floral elements and spacing between motifs. It uses light red, blue, and yellow threads creating a delicate look on white fabric."
  },
  {
    name: "Rivnenshchyna (Рівненщина)",
    desc: "a simple and repetitive geometric rhombus pattern in a dominant red color. The design features clean lines and a classic folk textile look."
  },
  {
    name: "Khmelnychchyna (Хмельниччина)",
    desc: "bold black geometric lines with red fillings and large geometric shapes resembling stylized flowers. The stitching texture is heavy with high contrast."
  },
  {
    name: "Volyn (Волинь)",
    desc: "classic red geometric patterns on white linen with rows of rhombuses and crosses. It has a distinct simple rhythm and an archaic look."
  },
  {
    name: "Zaporizhzhia (Запоріжжя)",
    desc: "floral motifs arranged in horizontal bands, specifically red flowers with dark brown/black leaves and stylized plant ornamentation."
  },
  {
    name: "Mykolaivshchyna (Миколаївщина)",
    desc: "a distinctive horizontal border pattern with stylized floral and berry motifs using black, grey, and red threads."
  },
  {
    name: "Sumshchyna (Сумщина)",
    desc: "red and black floral ornaments featuring stylized roses and leaves, mixing soft curves with geometry in traditional cross-stitch."
  },
  {
    name: "Cherkashchyna (Черкащина)",
    desc: "vertical geometric plant motifs with 'Tree of Life' symbolism. The black and red patterns are complex and intricate on linen."
  },
  {
    name: "Hutsulshchyna (Гуцульщина)",
    desc: "a very dense and vibrant geometric mosaic in the Carpathian style. Colors include orange, bright green, yellow, and red, forming complex cruciform and rhombus shapes."
  },
  {
    name: "Kyivshchyna (Київщина)",
    desc: "rich red and black geometric patterns, specifically diamond shapes containing stylized plant elements like grapes or hops, on white linen."
  },
  {
    name: "Odeshchyna (Одещина)",
    desc: "geometric abstract motifs with dominant red and black colors. It shows the influence of Bessarabian styles with clean cross-stitch borders on a white background."
  },
  {
    name: "Ternopilshchyna (Тернопільщина)",
    desc: "dense horizontal bands of deep red and black geometric blocks with yellow accents. The embroidery has heavy visual weight and solid stitching rows."
  },
  {
    name: "Chernihivshchyna (Чернігівщина)",
    desc: "stylized red and black motifs depicting birds or abstract flowers. It features fine stitching and a rhythmic pattern typical of northern Ukraine."
  },
  {
    name: "Donechchina (Донеччина)",
    desc: "large red rose motifs with black leaves in the 'Brokar' cross-stitch style. The floral design is realistic and bright on white fabric."
  },
  {
    name: "Kirovohradshchyna (Кіровоградщина)",
    desc: "realistic floral vines with viburnum (kalyna) berries. It features red berries and black leaves in a horizontal composition."
  },
  {
    name: "Poltavshchyna (Полтавщина)",
    desc: "stylized red floral shapes with touches of blue and black. The flowers are arranged geometrically with tidy cross-stitch."
  },
  {
    name: "Kharkivshchyna (Харківщина)",
    desc: "rough red and black geometric-floral symbols in a vertical orientation. It features 'Tree of Life' motifs with a thick thread texture."
  },
  {
    name: "Crimea (Крим)",
    desc: "Crimean Tatar (Qırım) style with fluid floral vines and plant motifs in soft colors like olive green, muted red, and ochre. The lines are elegant and winding, with gold and silk thread texture."
  }
];

// Database of Modern Vyshyvanka Colors
export const VYSHYVANKA_COLORS = [
  {
    name: "White",
    desc: "classic WHITE Vyshyvanka (traditional Ukrainian embroidered shirt) made of fine linen. The embroidery is elegant, detailed, and minimalist (white-on-white, blue, or red patterns)",
    bg: "joyful, bright outdoor location: a blooming spring garden or a sunlit park with lush greenery",
    light: "soft, airy, and natural (High Key), creating a fresh and peaceful atmosphere"
  },
  {
     name: "Blue",
     desc: "stylish BLUE Vyshyvanka (traditional Ukrainian embroidered shirt) made of fine linen. The embroidery is elegant, detailed, and contrasting (gold, yellow, or white patterns)",
     bg: "joyful, bright outdoor location: a golden wheat field under a clear sky or a sunlit park",
     light: "soft, warm, and natural sunlight (Golden Hour), creating a patriotic and peaceful atmosphere"
  },
  {
     name: "Black",
     desc: "stylish BLACK Vyshyvanka (traditional Ukrainian embroidered shirt). The embroidery is striking (red, gold, or black-on-black)",
     bg: "warm, atmospheric outdoor scene at golden hour or sunset: a wheat field bathed in warm light or an evening park with soft, glowing bokeh",
     light: "dramatic and cinematic but natural. The overall look is strong, confident, and deeply connected to the land"
  },
  {
     name: "Red",
     desc: "vibrant RED Vyshyvanka (traditional Ukrainian embroidered shirt) made of high-quality linen. The embroidery is expressive and contrasting (white, black, or gold patterns)",
     bg: "passionate, warm outdoor setting: a blooming field of poppies or a sun-drenched summer garden",
     light: "bright, warm, and energetic sunlight, highlighting the richness of the red fabric"
  },
];

// Database of Modern Flower Vyshyvanka Variants
export const VYSHYVANKA_FLOWERS = [
    {
        name: "Poppies & Cornflowers (Classic)",
        prompt: "A sophisticated, high-quality portrait in a fantasy floral style. The subject is wearing a stunning modern WHITE Vyshyvanka heavily embroidered with rich, vibrant flowers (red poppies, cornflowers, sunflowers) and lush greenery. The embroidery is artistic, abundant, and colorful. The background is a breathtaking open landscape featuring a golden wheat field stretching to the horizon under a boundless clear blue sky. The lighting is bright, soft, and fairytale-like, emphasizing the beauty of Ukrainian nature, cinematic lighting, 8k resolution, photorealistic masterpiece."
    },
    {
        name: "Kalyna & Barvinok",
        prompt: "A sophisticated, high-quality portrait of a beautiful Ukrainian woman wearing a modern white Vyshyvanka. The embroidery is intricate and vibrant, featuring clusters of bright red Viburnum berries (Kalyna) paired with delicate blue Periwinkle flowers (Barvinok) and green leaves. The texture of the embroidery involves realistic satin stitching and French knots for the berries. The background is a traditional Ukrainian orchard with blurred blooming trees in the spring sunlight. The lighting is warm and natural, highlighting the glossy red threads of the berries. 8k resolution, photorealistic, cinematic depth of field."
    },
    {
        name: "Roses & Grapes (Brokar)",
        prompt: "A stunning hyper-realistic portrait of a Ukrainian woman in a luxurious linen Vyshyvanka. The shirt is heavily embroidered with lush Red Roses intertwined with purple Grape clusters and winding vine leaves, creating a rich 'Brokar' style pattern. The fabric texture is visible, emphasizing the contrast between the white linen and the deep red and purple threads. The background is a sun-drenched vineyard at golden hour, with soft warm light enveloping the subject. Atmospheric, romantic, highly detailed textile art, masterpiece."
    },
    {
        name: "White Lilies",
        prompt: "A high-fashion artistic portrait of a Ukrainian woman wearing an elegant white Vyshyvanka. The embroidery is sophisticated and graceful, featuring stylized White Lilies with green stems and closed buds, symbolizing purity and the continuity of life. The color palette is softer, mixing white, pale pink, and fresh green tones on the white fabric. The background is a misty morning meadow with dew on the grass, soft diffused lighting, ethereal and dreamy atmosphere. Macro shot details of the embroidery, 8k, photorealistic style."
    }
];

export const STYLE_OPTIONS: StyleOption[] = [
  // --- UKRAINIAN SPECIAL (Top priority via UI logic) ---
  {
    id: 'ukraine-independence',
    name: '🇺🇦 Ukraine Independence (Holiday)',
    prompt: `A celebratory Ukraine Independence themed portrait. The background is a joyful, sun-drenched outdoor landscape featuring a vibrant sunflower field or rolling hills under a clear blue sky with fluffy white clouds. The lighting is bright, warm, and radiant. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, she is wearing a traditional Ukrainian embroidered shirt (Vyshyvanka) and a large, beautiful traditional wreath (Vinok) with flowing colorful ribbons; her original hairstyle and hair length MUST be preserved. If the subject is male, he is wearing a stylish traditional Ukrainian embroidered shirt (Vyshyvanka) without a wreath.`,
  },
  {
    id: 'ukraine-region-surprise',
    name: '🇺🇦 Modern Vyshyvanka (Region+)',
    prompt: `A highly detailed, photorealistic portrait celebrating Ukrainian heritage. The subject is wearing an authentic, high-quality white linen Vyshyvanka (embroidered shirt) representing the **{{REGION_NAME}}** region. The embroidery is the focal point: it features **{{REGION_DESC}}**. Ensure the texture of the embroidery looks handmade and realistic. The background is a blurred, warm, sunlit Ukrainian landscape (wheat field or spring garden) that complements the outfit. Lighting is natural and soft.`,
  },
  {
    id: 'ukraine-modern-random',
    name: '🇺🇦 Modern Vyshyvanka (Color+)',
    prompt: `A sophisticated, high-quality portrait. The subject is wearing a {{COLOR_DESC}}. The setting is a {{BG_DESC}}. The lighting is {{LIGHT_DESC}} celebrating nature.`,
  },
  {
    id: 'ukraine-modern-flower',
    name: '🇺🇦 Modern Vyshyvanka (Flower+)',
    prompt: `{{RANDOM_FLOWER_FULL_PROMPT}}`,
  },
  {
    id: 'group-ukraine-independence',
    name: '🇺🇦 Ukraine Independence (Group)',
    prompt: `RETOUCH the source photo. Strictly preserve the facial features, identity, and POSES of ALL individuals from the source photo. Do NOT move them. Do NOT merge faces. OVERLAY new clothing on the existing body shapes: CHANGE the clothing to traditional Ukrainian embroidered shirts (Vyshyvanka). Smartly add headwear: Female subjects get large, beautiful traditional wreaths (Vinok) with flowing ribbons. Male subjects do NOT wear wreaths. REPLACE the background with a joyful, soft-focus sunny landscape of a vibrant sunflower field or a bright blue sky over green hills.`,
  },
  
  // --- HAIRSTYLE COLLECTION TRIGGER ---
  {
    id: 'hairstyle-try-on',
    name: '💇‍♀️ Hairstyle Try-On Collection',
    prompt: `RETOUCH the uploaded photo. KEEP the face, background, and clothing EXACTLY as they are. CHANGE ONLY the hairstyle. The new hairstyle is: {{HAIRSTYLE_PROMPT}}. {{HAIR_COLOR_PROMPT}}`,
  },

  // --- DEFAULT ---
  {
    id: 'no_style',
    name: 'NO STYLE',
    prompt: `Maintain the exact look, lighting, background, and clothing of the original photo. Do not apply any artistic style or filters. Only modify the image composition and camera angle as specified. Keep the original reality intact.`,
  },

  // --- TRENDING & VIRAL (Alphabetical) ---
  {
    id: '3d-cartoon',
    name: '3D Cartoon Character',
    prompt: `Transform the subject into a high-quality 3D rendered character, reminiscent of modern animated feature films (Pixar/Disney style). The skin texture should look smooth and slightly stylized (clay-like or soft render). The eyes are slightly larger and expressive, capturing the subject's personality. The hair is rendered in thick, stylized strands. The lighting is soft global illumination with warm rim lighting. The background is a soft, colorful blurred environment suitable for an animated movie poster. Keep the subject recognizable but cute and animated.`,
  },
  {
    id: '90s-yearbook',
    name: '90s Yearbook',
    prompt: `A retro 1990s American high school yearbook photo. The image has a distinct vintage texture, slightly grainy with soft focus. The background is a classic "school portrait" backdrop, such as mottled grey clouds or retro blue lasers. The lighting is flat studio flash. The subject is styled in classic 90s fashion (e.g., denim jacket, black turtleneck, flannel shirt, or oversized sweater). The expression is a classic, slightly awkward but charming school smile.`,
  },
  {
    id: 'cinematic-hollywood',
    name: '🎬 Cinematic Hollywood (Fun)',
    prompt: `A cinematic shot in the distinct visual style of director {{DIRECTOR_NAME}}. The scene features specific aesthetic traits: {{DIRECTOR_PROMPT}}. The subject fits perfectly into this world while retaining their likeness.`,
  },
  {
    id: 'literary-universe',
    name: '📚 Literary Universe (Fun)',
    prompt: `A cinematic portrait in the distinct literary style of {{WRITER_NAME}}. Atmosphere: {{WRITER_PROMPT}} The subject fits perfectly into this world while retaining their likeness. Ensure the subject has a fit, healthy body and maintains a youthful appearance.`,
  },
  {
    id: 'fantasy-hero',
    name: 'Cinematic Fantasy Hero (Fun)',
    prompt: `Wide-angle Cinematic shot. The subject is transformed into a legendary movie character: {{FANTASY_ROLE}}. **Ensure the subject has a fit, athletic body shape.** The background is a high-budget movie set piece perfectly matching the character trope. Lighting is cinematic and magical. **Hairstyle logic: styled to perfectly match the character role (e.g., wigs, elven hair, or rustic styling), but keeping facial recognition high.**`,
  },
  {
    id: 'old-money',
    name: 'Old Money Aesthetic',
    prompt: `A portrait in the "Old Money" or "Quiet Luxury" aesthetic. The subject looks sophisticated, wealthy, and relaxed. Clothing should be high-quality, understated elegance (e.g., linen shirts, cashmere sweaters, polo style, beige/navy/cream palette). The background is a blurred exclusive location like a private country club, a luxury yacht deck, or a manicured estate garden. The lighting is soft, warm, natural sunlight (golden hour). The overall vibe is timeless elegance and aristocratic heritage.`,
  },
  {
    id: 'fun-mythical-selfie',
    name: '🤳 Selfie with... (Fun)',
    prompt: `A fun, wide-angle selfie photo featuring TWO characters. Subject 1 is the person from the uploaded photo (STRICTLY preserve their facial identity and likeness, but adapt clothing style to fit the scene). Subject 2 is {{PARTNER_PROMPT}}. They are posing cheek-to-cheek or side-by-side, smiling at the camera. The background is {{BG_PROMPT}}. The lighting is cinematic and flattering.`,
  },
  {
    id: 'social-avatar',
    name: 'Social Media Avatar',
    prompt: `A stunning, high-quality digital art avatar perfect for social media profile pictures. STRICT COMPOSITION: The output MUST be a perfect SQUARE (1:1). The subject is PERFECTLY CENTERED. The image is designed as a CIRCULAR CUTOUT. **CRITICAL: The area OUTSIDE the central circle (the four corners of the square) MUST BE PURE SOLID WHITE (#FFFFFF).** The subject and the artistic background are strictly contained INSIDE the circle. Inside the circle, the background is a stylish, abstract artistic design or a clean, vibrant gradient. The style is a polished, semi-realistic Digital Illustration with smooth textures and vibrant, professional lighting. The look is confident, cool, and modern—the ultimate 'cool version' of the subject. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved.`,
  },

  // --- REGULAR STYLES (Alphabetical) ---
  {
    id: 'academic',
    name: 'Academic Scholar',
    prompt: `Professional headshot in a classic library or study setting. The background features bookshelves, warm wooden tones, and soft, focused lighting to create an intellectual and sophisticated mood.`,
  },
  {
    id: 'art-deco',
    name: 'Art Deco Glamour',
    prompt: `An elegant Art Deco style headshot. Features bold geometric patterns and gold accents in the background. The lighting is dramatic and glamorous, reminiscent of 1920s Hollywood portraits. The subject has a sophisticated and polished look.`,
  },
  {
    id: 'art-nouveau',
    name: 'Art Nouveau',
    prompt: `A stylized Art Nouveau portrait. The image features elegant, sinuous, organic lines and intricate decorative patterns inspired by nature (flowers, vines, leaves). The color palette is muted and sophisticated, with soft pastels, golds, and earth tones. The background involves elaborate floral or geometric ornamentation typical of the early 20th-century style. The lighting is soft and flat, emphasizing the graphic quality of the art style.`,
  },
  { 
    id: 'corporate', 
    name: 'Corporate Grey', 
    prompt: `Professional headshot, clean studio grey backdrop, sharp focus, studio lighting, looking confident and approachable.`,
  },
  { 
    id: 'creative', 
    name: 'Creative Studio', 
    prompt: `Artistic and creative headshot in a studio, interesting textures or a solid dark color in the background, dramatic side lighting to highlight features.`,
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    prompt: `Cyberpunk style headshot, moody, with dramatic neon lighting from the side, futuristic and edgy vibe, dark, rain-slicked city background.`,
  },
  {
    id: 'neon-fashion',
    name: 'Electric Fashion Glow',
    prompt: `A high-fashion portrait where the subject's ORIGINAL clothing is strictly preserved in form and cut. The outfit looks exactly the same but appears to have suddenly received a neon lighting effect. The edges, seams, and folds of the clothes are highlighted with luminous electric neon outlines (cyan, magenta, or lime green) glowing against a dark environment. The background is a solid dark color to emphasize the glowing details of the original attire.`,
  },
  {
    id: 'bw',
    name: 'Elegant Black & White',
    prompt: `Classic and elegant black and white headshot, high contrast, dramatic shadows, capturing a sophisticated and timeless look, against a simple dark backdrop.`,
  },
  {
    id: 'gamer',
    name: 'Gamer/Streamer',
    prompt: `Modern headshot for a gamer or streamer. The subject is in front of a high-tech gaming setup with RGB neon lights, a high-end microphone, and blurred monitor screens in the background. The mood is energetic and futuristic.`,
  },
  {
    id: 'golden-hour',
    name: 'Golden Hour Glow',
    prompt: `Headshot taken during the golden hour, with warm, soft, and glowing sunlight. The background is a beautiful, slightly blurred outdoor scene, creating a dreamy and serene atmosphere.`,
  },
  {
    id: 'ice-queen',
    name: 'Ice Queen',
    prompt: `A regal and majestic portrait in the style of an Ice Queen. The subject is dressed in an elegant, detailed gown with icy blue and silver accents, and wears a delicate crystal crown. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The background is a frozen palace or a shimmering ice cave with sharp, crystalline textures. The lighting is cold, magical, and ethereal, with a soft blue glow.`,
  },
  {
    id: 'impressionist',
    name: 'Impressionist Painting',
    prompt: `A headshot in the style of an Impressionist painting. Features visible, textured brushstrokes and a focus on capturing the play of light. The colors are vibrant and the overall feel is dreamy and artistic, as if painted by Monet or Renoir.`,
  },
  {
    id: 'medieval',
    name: 'Medieval Portrait',
    prompt: `A classical medieval-style portrait. The subject is dressed in rich, period-appropriate attire (e.g., velvet, fur). The background is a stone castle interior with soft, natural light from a window. The style should resemble an oil painting from the Renaissance era.`,
  },
  {
    id: 'line-art',
    name: 'Minimalist Line Art',
    prompt: `A minimalist single-line art portrait of the subject. The style should be clean and simple, capturing the essential features with a continuous black line on a plain white or off-white background. No color or shading.`,
  },
  {
    id: 'magic-wand',
    name: 'Magic Wand',
    prompt: `A whimsical and enchanting portrait. The subject is holding a glowing magic wand, surrounded by swirling magical particles and sparkles. The lighting is soft and ethereal. The background is a mystical forest or a starry night sky. The atmosphere is dreamy and fairytale-like.`,
  },
  {
    id: 'mascot',
    name: 'Mascot',
    prompt: `Transform the subject into a cute, friendly, and exaggerated mascot character. The outfit should be a full-body costume with a large, stylized head and simple, bold colors. The background should be a bright, cheerful stage or a simple, solid color.`,
  },
  { 
    id: 'tech', 
    name: 'Modern Tech Office', 
    prompt: `Professional headshot in a modern tech office, blurred background with subtle elements like computer screens and green plants, bright, natural window lighting.`,
  },
  { 
    id: 'outdoor', 
    name: 'Outdoor Natural', 
    prompt: `Friendly headshot outdoors with beautiful natural light, soft focus on a blurred park or nature background, warm and inviting expression.`,
  },
  {
    id: 'party-hat',
    name: 'Party Hat',
    prompt: `A fun and festive celebration portrait. The subject is wearing a colorful, cone-shaped party hat. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved (flowing from under the hat). The background is filled with vibrant falling confetti, streamers, and balloons in a bright, joyful party atmosphere. The lighting is colorful and energetic.`,
  },
  {
    id: 'sticker',
    name: 'Personal Sticker Art',
    prompt: `A high-quality die-cut vinyl sticker design. The subject is transformed into a vibrant digital illustration. The look is stylized and semi-realistic, resembling high-end vector art with clean lines, bold colors, and smooth shading. It should look almost like a drawing while remaining recognizable. The subject has a distinct, thick WHITE OUTLINE (sticker border) surrounding their silhouette. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The background is a solid, contrasting color (like electric blue or vibrant purple) to make the white sticker border stand out. The expression is charismatic and engaging.`,
  },
  {
    id: 'pop-art',
    name: 'Pop Art',
    prompt: `Pop Art style headshot inspired by Andy Warhol, with vibrant, saturated colors, bold outlines, and a graphic, screen-printed look.`,
  },
  {
    id: 'retro-neon',
    name: 'Retro Neon',
    prompt: `A vintage 80s Retro Neon portrait with a classic synthwave aesthetic. The lighting is dramatic and glowing, featuring vibrant neon colors: hot pink, electric purple, and teal. The background is dark with retro grid patterns or neon city lights. The overall vibe is energetic, nostalgic, and cinematic, allowing for a stylish pose fitting the era.`,
  },
  {
    id: 'secret-agent-action',
    name: 'Secret Agent Action (Fun)',
    prompt: `Wide-angle Full Body cinematic shot. The subject is a high-profile secret agent captured in a dramatic action pose: {{ACTION_POSE}}. **Ensure the subject has a fit, athletic body shape.** The attire is stylish and appropriate for the character trope (e.g., tactical gear, tuxedo, or leather). The background is a high-budget movie set piece perfectly matching the specific movie trope. Lighting is dramatic, high-contrast, and blockbuster style. **Hairstyle logic: dynamic, messy, windblown, or wet to match the intense action. You are free to change the hairstyle and length to maximize the cinematic impact.**`,
  },
  {
    id: 'pin-up',
    name: 'Retro Pin-Up',
    prompt: `A glamorous and playful 1950s Pin-Up style portrait. The look is retro, vibrant, and charming, reminiscent of classic American pin-up art. The lighting is soft, warm, and flattering. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, style her hair with vintage waves or curls while preserving the original length, and apply classic red lipstick and winged eyeliner. The background is a lively, sunny 1950s American diner setting or a bright, cheerful summer garden picnic. The atmosphere is vibrant, happy, and full of life.`,
  },
  {
    id: 'sci-fi',
    name: 'Sci-Fi Explorer',
    prompt: `Headshot of a sci-fi explorer on a futuristic alien planet or inside a starship bridge. The lighting is atmospheric, with lens flares and holographic interface glows. The attire is a sleek, functional spacesuit.`,
  },
  {
    id: 'summer',
    name: 'Summer Vibes',
    prompt: `A warm, sunny, and relaxed portrait. The background is a tropical beach with clear blue water and palm trees. The subject looks tanned and happy, wearing casual summer clothing. The lighting is bright and natural, like a perfect summer day. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved.`,
  },
  {
    id: 'urban',
    name: 'Urban Streetwear',
    prompt: `Stylish headshot in a dynamic urban city environment. The background is a blurred street scene with graffiti or interesting architecture. The lighting is natural but edgy, capturing a cool, confident vibe.`,
  },
  {
    id: 'urban-fullbody-test',
    name: 'Urban Streetwear (Fun)',
    prompt: `Wide-angle Full Body shot in a dynamic urban city environment. The subject is captured in a dynamic pose: {{ACTION_POSE}}, showing the entire outfit from head to shoes. **Ensure the subject has a fit, athletic body shape.** The background is a blurred street scene with **graffiti art**. **CRITICAL: If graffiti is visible on the walls, it MUST be a stylized, artistic portrait/caricature of the SUBJECT themselves, creating a cool meta-effect. The graffiti version does not need to match the current pose.** The lighting is natural but edgy, capturing a cool, confident, and energetic vibe.`,
  },
  {
    id: 'vintage',
    name: 'Vintage Film',
    prompt: `Headshot with a vintage film look, warm tones, subtle grain, and a classic, timeless feel, reminiscent of 35mm film photography.`,
  },

  // --- GROUP STYLES (Alphabetical) ---
  {
    id: 'group-christmas',
    name: 'Christmas Party (Group)',
    prompt: `RETOUCH the source photo. Strictly preserve the facial features, identity, and POSES of ALL individuals from the source photo. Do NOT move them. Do NOT merge faces. Count the people and ensure the same number appear in the result. OVERLAY new clothing on the existing body shapes: CHANGE the clothing to stylish, festive holiday party attire. Smartly add headwear: Female subjects get beautiful, magical ice crowns or tiaras (Snow Maiden style). Male subjects get classic red and white Santa hats. REPLACE the background with a beautiful, snowy outdoor winter scene with decorated trees and twinkling lights. The atmosphere is joyful and magical.`,
  },
  {
    id: 'group-team',
    name: 'Professional Team',
    prompt: `RETOUCH the source photo. Strictly preserve the facial features, identity, and POSES of ALL team members. Do NOT move them. Do NOT merge faces. OVERLAY new clothing on the existing body shapes: change attire to smart casual or business attire. REPLACE the background with a modern office environment or a clean studio backdrop. The look is confident and collaborative. CHANGE the clothing and background.`,
  },
  {
    id: 'group-halloween',
    name: 'Spooky Halloween (Group)',
    prompt: `RETOUCH the source photo. Strictly preserve the facial features, identity, and POSES of ALL individuals from the source photo. Do NOT move them. Do NOT merge faces. OVERLAY new clothing on the existing body shapes: CHANGE the clothing to include classic pointed witch hats and mystical attire. REPLACE the background with cheerful carved pumpkins (jack-o'lanterns) with happy, glowing faces. The lighting is dramatic with moody shadows and ethereal purple and green mist.`,
  },

  // --- HOLIDAY STYLES (Alphabetical) ---
  {
    id: 'christmas',
    name: '* Christmas Festive',
    prompt: `A festive Christmas-themed headshot. The subject is dressed in stylish, festive holiday party attire. Ensure the subject has a fit, healthy body and maintains a youthful appearance. Smartly adapt the headwear to the subject: If the subject is female, she is wearing a beautiful, magical ice crown or tiara (resembling a Snow Maiden/Snegurochka) with sparkling silver details, and her original hairstyle and hair length MUST be preserved. If the subject is male, he is wearing a classic red and white Santa Claus hat AND a white Santa beard with a slightly curled, playful mustache. The background is a beautiful, snowy outdoor winter scene, featuring decorated Christmas trees and warm, twinkling festive lights. The atmosphere is cozy, joyful, and magical.`,
  },
  {
    id: 'ice-figurine',
    name: '* Christmas Ice Figurine',
    prompt: `Hyper-realistic delicate ice sculpture figurine modeled after the uploaded photo. The subject is reimagined as a tiny, fragile carving made of clear, translucent ice. The face MUST match the person from the uploaded image with high accuracy, even if the source shows only a portrait. CRITICAL: Maintain realistic head-to-body proportions for the figurine; do not make the head oversized or caricature-like. Ensure the subject has a fit, healthy body and maintains a youthful appearance. **The figure is fully clothed in a detailed, elegant outfit carved from ice (dress, suit, or winter attire). Do NOT create a nude figure.** **The subject wears a small, delicate ice crown.** If the subject is female, her original hairstyle and hair length MUST be preserved (rendered in detailed ice carving). The texture is crystalline, glass-like, and incredibly delicate, looking as if it might shatter at a touch. Subsurface scattering of light, cold blue and white tones, with sharp, intricate details. **Magical, bright glowing lights (like fairy dust or tiny fireflies) play around the figure, creating dazzling reflections and refractions inside the ice.** The full-body ice figurine is suspended by a thin shimmering silver thread, hanging freely from a frosted pine branch of a Christmas tree. The background features snowy pine needles and a few other vintage glass ornaments hanging nearby to create a cozy composition. Macro photography, sharp focus on the ice details, with a dark, moody background to make the crystal figure and magical lights glow.`,
  },
  {
    id: 'christmas-ornament',
    name: '* Christmas Ornament Doll',
    prompt: `Hyper-realistic Christmas ornament modeled after the uploaded photo, reimagined as a small handcrafted full-body holiday figurine. The face MUST match the person from the uploaded image with high accuracy, even if the source shows only a portrait. CRITICAL: Maintain realistic head-to-body proportions for the figurine; do not make the head oversized or caricature-like. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The miniature keeps the same clothing style, color palette, materials and textures seen in the original photo. The pose can be changed to a graceful, artistic stance suitable for a hanging ornament. Naturally extend the outfit into a full-body design while maintaining visual continuity. Carefully sculpted fabric folds, tiny seams, miniature accessories, a mix of glossy polymer and matte hand-painted surfaces, subtle handmade imperfections, lifelike skin texture. The full-body ornament is hanging freely from a natural pine branch by a thin golden thread, dangling in the air like a classic Christmas bauble. It is surrounded by soft warm golden Christmas bokeh and other vintage glass ornaments hanging nearby to create a cozy composition. Photographed as if on a Canon EOS R5 with an 85mm lens at f/1.8, ultra-detailed, sharp focus on the ornament, silky smooth blurred background.`,
  },
  {
    id: 'christmas-sweater',
    name: '* Christmas Sweater',
    prompt: `A fun and cozy portrait featuring a classic 'Ugly Christmas Sweater'. The subject is wearing a thick, colorful, knitted sweater with festive patterns (reindeers, snowflakes, or Santa) AND a pair of festive reindeer antlers on their head. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The background is a warm, blurred indoor setting with a fireplace or soft holiday lights. The mood is cheerful and relaxed.`,
  },
  {
    id: 'dia-de-muertos',
    name: '* El Día de Muertos',
    prompt: `A highly artistic and fantasy-inspired Day of the Dead (Día de Muertos) portrait with a joyful atmosphere. The subject is gently smiling. The subject wears an elaborate, uniquely designed fantasy floral crown featuring a diverse mix of vibrant exotic flowers, glowing marigolds, and mystical blossoms in various colors and shapes, where no two flowers are alike. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The face features a highly imaginative, one-of-a-kind asymmetrical sugar skull (Calavera) makeup with intricate fantasy patterns, unique hand-painted artistic details, and shimmering iridescent accents that make this specific mask distinct and non-standard. CRITICAL: The subject must have a magnetic, enchanting, and magical gaze, with a captivating and graceful pose that exerts a powerful attraction on the viewer. The atmosphere is ethereal, magical, and bright. The background is a vibrant, blurred night carnival scene, illuminated by festive string lights, candles, and colorful papel picado, capturing the lively and magical spirit of the celebration.`,
  },
  {
    id: 'easter',
    name: '* Happy Easter',
    prompt: `A joyful and fresh Easter-themed headshot. The color palette focuses on soft pastels like mint green, baby blue, and pale pink. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The background is a sunny spring garden scene featuring blooming flowers (tulips, daffodils) and colorful decorative Easter eggs with intricate, traditional Ukrainian patterns (Pysanky). The lighting is bright, airy, and uplifting.`,
  },
  {
    id: 'knitted-winter',
    name: '* Knitted Winter Art',
    prompt: `Reimagine the uploaded photo as a handmade thread art piece. Create a winter snow composition. A Tilt-Shift diorama made of yarn and felt. The subject is transformed into a knitted character. Add knitted clouds, snowflakes, and animals. Macro photography, warm soft diffused light, pastel palette, high-detailed fibers and stitches, a cozy, fairytale atmosphere, and a slightly reduced scale, like a Tilt-Shift diorama. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved (rendered in yarn). Maintain the exact composition, framing, and aspect ratio of the original photo.`,
  },
  {
    id: 'halloween',
    name: '* Spooky Halloween',
    prompt: `A mystical Halloween-inspired headshot. The subject is wearing a classic pointed witch hat. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The background features cheerful carved pumpkins (jack-o'lanterns) with happy, glowing faces. The lighting is dramatic with moody shadows and ethereal purple and green mist, creating a mysterious yet festive witchy vibe.`,
  },
  {
    id: 'st-nicholas',
    name: '* St. Nicholas Magic',
    prompt: `A heartwarming and magical Saint Nicholas Day portrait, capturing the innocence and joy of childhood. The subject is wearing a cozy, textured white or cream knitted sweater. Ensure the subject has a fit, healthy body and maintains a youthful appearance. If the subject is female, her original hairstyle and hair length MUST be preserved. The background features a blurred, warm interior with soft Christmas lights, possibly with a hint of St. Nicholas/Santa Claus in the distance or holding a small gift. The lighting is warm and golden, evoking a sense of wonder and holiday spirit.`,
  },
];
