
import { GoogleGenAI } from "@google/genai";

const fileToGenerativePart = (base64: string, mimeType: string) => {
  return {
    inlineData: {
      data: base64,
      mimeType,
    },
  };
};

interface Base64Image {
    data: string;
    mimeType: string;
}

export interface GenerationResult {
    imageUrl: string;
    fullPrompt: string;
    modelName: string;
    styleDisplayName?: string; // Added field for UI display
}

// GLOBAL QUALITY BOOSTERS applied to all generations
const QUALITY_BOOSTERS = "Best quality, 8k resolution, highly detailed, photorealistic, masterpiece, sharp focus, distinct textures, professional photography.";

// 1. STANDARD HEADSHOT PROMPT (Default)
const BASE_HEADSHOT_PROMPT = `Generate a photorealistic, professional headshot. ${QUALITY_BOOSTERS} Use all of the provided images as a reference to create a single, consistent representation of the person. The headshot should be based on the person in the provided images. Do not copy the aspect ratio or camera angle from the input images. IMPORTANT: The person's face and facial features in the generated image MUST be an exact match to the original photos, combining their features accurately. Do not alter their likeness in any way. Only change the background, lighting, and clothing to match the requested style. The final output must be a single, high-quality photograph.`;

// 2. CREATIVE / ACTION PROMPT (For Full Body, Cinematic, Fantasy)
const BASE_ACTION_PROMPT = `Generate a photorealistic, cinematic wide-angle or full-body shot. ${QUALITY_BOOSTERS} Use all of the provided images as a reference to create a single, consistent representation of the person. IMPORTANT: The person's face and facial features in the generated image MUST be an exact match to the original photos. Do not create a generic face. 
INSTRUCTION: DO NOT CROP TO A HEADSHOT. Respect the requested pose (e.g., walking, jumping, full body) and composition.
Only change the background, lighting, and clothing to match the requested style. The final output must be a single, high-quality photograph.`;

// 3. GROUP PROMPT (For Multiple People)
const BASE_GROUP_PROMPT = `TASK: STRICT PHOTOREALISTIC RETOUCHING.
You are NOT generating a new image. You are modifying the source image. ${QUALITY_BOOSTERS}

ABSOLUTE CONSTRAINTS (Zero Tolerance for deviation):
1. ANCHOR THE SUBJECTS: The pixels representing the people's faces, heads, and body outlines MUST remain in the exact same coordinates as the source image.
2. FACE LOCK: Do NOT generate new faces. Do NOT blend faces. The identities must be 100% preserved from the source.
3. POSE LOCK: Do NOT change any gestures, hand positions, or head tilts. The geometry of the subjects must match the source exactly.

INSTRUCTIONS:
- Treat this as a "Change Clothes" and "Change Background" Photoshop task.
- Conform the new clothing styles strictly to the existing body shapes and poses of the subjects.
- Replace the background behind the subjects without moving the subjects themselves.
- If the source has 3 people, the output MUST have 3 people in the exact same arrangement.`;

const BASE_EDIT_PROMPT = `It is absolutely crucial to maintain the person's exact likeness and facial features from the original image. Only apply the requested changes. Maintain 8k resolution and high details.`

const CINEMATIC_COMPOSITION_RULE = `
CINEMATIC COMPOSITION RULES (Apply strictly unless the specific Director Style demands symmetry):
1. RULE OF THIRDS: Do NOT place the subject in the exact center of the frame. Shift the subject slightly to the left or right to create a dynamic cinematic look.
2. ANGLE: Avoid a flat, direct front-facing 'passport' angle. Use a 3/4 view, a profile view, or a dynamic body turn.
3. GAZE: The subject should generally look slightly off-camera or interact with the scene, creating narrative tension. Do not have them stare blankly into the lens.
`;

// Helper to safely get API Key
const getApiKey = (): string => {
    // Attempt to access process.env.API_KEY if process exists
    if (typeof process !== 'undefined' && process.env) {
        return process.env.API_KEY || '';
    }
    return '';
};

export async function generateHeadshot(
    base64Images: Base64Image[], 
    stylePrompt: string, 
    aspectRatioPrompt: string, 
    cameraAnglePrompt: string,
    aspectRatioId: string,
    styleId: string
): Promise<GenerationResult> {
    const apiKey = getApiKey();
    if (!apiKey) {
        console.error("API_KEY is missing.");
        throw new Error("API Key is missing. Please check your configuration.");
    }

    const ai = new GoogleGenAI({ apiKey });
    const model = 'gemini-2.5-flash-image';
    
    const imageParts = base64Images.map(image => fileToGenerativePart(image.data, image.mimeType));
    
    // Logic to determine the correct Base Prompt
    const isGroupStyle = styleId && styleId.startsWith('group-');
    const isActionStyle = 
        styleId === 'urban-fullbody-test' || 
        styleId === 'secret-agent-action' || 
        styleId === 'fantasy-hero' || 
        styleId === 'cinematic-hollywood' ||
        styleId === 'literary-universe' ||
        styleId === 'fun-mythical-selfie';

    const isAvatarStyle = styleId === 'social-avatar';
    const isHollywoodStyle = styleId === 'cinematic-hollywood';
    const isWriterStyle = styleId === 'literary-universe';
    const isMythicalSelfieStyle = styleId === 'fun-mythical-selfie';

    let basePrompt = BASE_HEADSHOT_PROMPT; // Default
    if (isGroupStyle) {
        basePrompt = BASE_GROUP_PROMPT;
    } else if (isActionStyle) {
        basePrompt = BASE_ACTION_PROMPT;
    }

    let effectiveCameraPrompt = cameraAnglePrompt;
    if (isGroupStyle) {
        effectiveCameraPrompt = "STRICTLY MAINTAIN the exact original camera angle, framing, and distance. Do NOT zoom in, do NOT zoom out, do NOT rotate. The composition must match the source exactly.";
    } else if (isAvatarStyle) {
        effectiveCameraPrompt = "STRICTLY CENTER the subject in the frame. The subject's face must be in the absolute center of the square canvas.";
    } else if (isHollywoodStyle || isWriterStyle) {
        // Apply the cinematic rule to force off-center/3/4 view
        effectiveCameraPrompt = `${effectiveCameraPrompt} ${CINEMATIC_COMPOSITION_RULE}`;
    }

    const fullPrompt = `${basePrompt} ${aspectRatioPrompt} ${effectiveCameraPrompt} Apply the following style: "${stylePrompt}".`;
    const textPart = { text: fullPrompt };

    let apiAspectRatio: "1:1" | "3:4" | "4:3" | "16:9" | "9:16" = "1:1";
    
    // Force Aspect Ratios based on Style ID logic to ensure consistency and override manual selection
    if (isAvatarStyle) {
        apiAspectRatio = "1:1";
    } else if (isHollywoodStyle) {
        apiAspectRatio = "4:3"; // Was 16:9, now mapped to Landscape 4:3
    } else if (isWriterStyle) {
        apiAspectRatio = "3:4"; // Book cover style
    } else if (isMythicalSelfieStyle) {
        apiAspectRatio = "4:3";
    } else {
        // Fallback to manual selection
        if (aspectRatioId === 'portrait') apiAspectRatio = "3:4";
        if (aspectRatioId === 'landscape') apiAspectRatio = "4:3";
    }

    const config: any = {};

    // For groups, we might not set aspect ratio to allow natural input size, 
    // but for others we enforce it.
    if (!isGroupStyle) {
        config.imageConfig = {
            aspectRatio: apiAspectRatio,
        };
    }

    try {
        const response = await ai.models.generateContent({
            model,
            contents: { parts: [...imageParts, textPart] },
            config: config,
        });

        let base64Result: string | undefined;
        let mimeType: string | undefined;

        const parts = response.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
            if (part.inlineData) {
                base64Result = part.inlineData.data;
                mimeType = part.inlineData.mimeType;
                break;
            }
        }

        if (base64Result && mimeType) {
            return {
                imageUrl: `data:${mimeType};base64,${base64Result}`,
                fullPrompt,
                modelName: model,
            };
        } else {
            console.error("Gemini response did not contain an image.", response);
            throw new Error("The AI generated text instead of an image. Please try again.");
        }
    } catch (e: any) {
        console.error("Generate Headshot Error:", e);
        throw e;
    }
}

export async function editImage(base64Image: string, mimeType: string, editPrompt: string): Promise<GenerationResult> {
    const apiKey = getApiKey();
    if (!apiKey) {
        throw new Error("API Key is missing.");
    }
    
    const ai = new GoogleGenAI({ apiKey });
    const model = 'gemini-2.5-flash-image';
    
    const imagePart = fileToGenerativePart(base64Image, mimeType);
    const fullPrompt = `Apply the following edit to the image: "${editPrompt}". ${BASE_EDIT_PROMPT}`;
    const textPart = { text: fullPrompt };

    try {
        const response = await ai.models.generateContent({
            model,
            contents: { parts: [imagePart, textPart] },
        });

        let base64Result: string | undefined;
        let resultMimeType: string | undefined;

        const parts = response.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
            if (part.inlineData) {
                base64Result = part.inlineData.data;
                resultMimeType = part.inlineData.mimeType;
                break;
            }
        }

        if (base64Result && resultMimeType) {
            return {
                imageUrl: `data:${resultMimeType};base64,${base64Result}`,
                fullPrompt,
                modelName: model,
            };
        } else {
            throw new Error("Failed to edit image.");
        }
    } catch (e: any) {
        console.error("Edit Image Error:", e);
        throw e;
    }
}
