import en from '../locales/en';

export const useTranslations = () => {
  return en;
};
