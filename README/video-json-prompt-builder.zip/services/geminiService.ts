import { GoogleGenAI } from "@google/genai";
import { SchemaBlock, PromptData } from "../types";

const API_KEY = process.env.API_KEY || '';

// Initialize client only if key exists (handled in App)
const getAiClient = () => new GoogleGenAI({ apiKey: API_KEY });

export async function generatePromptDataWithGemini(
  schema: SchemaBlock[],
  userDescription: string,
  imageBase64?: string,
  mimeType: string = 'image/jpeg'
): Promise<PromptData | null> {
  if (!API_KEY) {
    console.warn("No API Key available");
    return null;
  }

  const ai = getAiClient();
  const model = "gemini-2.5-flash"; 

  // Include 'options' in the schema sent to AI so it picks valid dropdown values
  const simplifiedSchema = schema.map(block => ({
    name: block.name, // e.g., "scene_1"
    title: block.title,
    fields: block.fields.map(f => ({ 
      path: f.path, 
      type: f.type, 
      label: f.label,
      description: f.help,
      options: f.options
    }))
  }));

  const isImageOnlyMode = imageBase64 && (!userDescription || userDescription.trim() === '');

  // Updated System Instruction for English Video Generation
  const systemInstruction = `
    You are an expert AI Video Director and Prompt Engineer for Google Veo.
    Your goal is to populate a specific JSON Form Schema based on a user idea or image.
    
    INPUTS:
    1. Schema: A list of blocks (e.g., "narrative", "scene_1").
    2. User Input: A text description or an image.

    CRITICAL OUTPUT RULES:
    1. **Structure**: Return a JSON object where the **ROOT KEYS are the BLOCK NAMES** defined in the schema (e.g., "general", "resources", "narrative", "scene_1", "scene_2", "scene_3", "audio").
       - Do NOT return a flat Veo prompt. You are filling the application state.
    
    2. **Field Nesting**: Inside each block, structure the data according to the field paths.
       - Example: If block "scene_1" has field "video_scenario.scenes.0.action", output:
         "scene_1": { "video_scenario": { "scenes": [ { "action": "..." } ] } }
    
    3. **Content Logic**:
       - **Options**: Strictly adhere to provided 'options' lists.
       - **Image Input**: If an image is provided, treat it as the starting point. 
         - Set "resources" block -> "input_resources.0.type" = "image".
         - Write a detailed description of the image in "input_resources.0.description".
         - Start "scene_1" action with "Shot starts with image_001...".
       - **Language**: English only.

    4. **Output Format**: Return ONLY raw JSON. No markdown formatting.
  `;

  const schemaContext = `
    Schema Definition:
    ${JSON.stringify(simplifiedSchema, null, 2)}
  `;

  let promptText = "";

  if (isImageOnlyMode) {
     // SPECIAL MODE: Image Animation Only (3 seconds, 1 scene)
     promptText = `
       TASK: Create a simple 3-second animation of the provided image.
       
       MANDATORY SETTINGS:
       1. **General**: Set 'duration_seconds' to "3".
       2. **Resources**: Describe the image in 'input_resources.0.description'.
       3. **Scene 1**: Create a subtle animation (e.g., "Slow zoom in", "Pan right", "Gentle movement") in 'scene_1.video_scenario.scenes.0.action'.
       4. **Structure**: 
          - GENERATE blocks: "general", "resources", "narrative", "scene_1", "audio".
          - OMIT/EXCLUDE blocks: "scene_2", "scene_3". 
       5. **Narrative**: Set description to "A short cinematic animation of a single image."
     `;
  } else if (imageBase64) {
     // Standard Image-to-Video with user story
     promptText = `
       Analyze this image as the visual reference. 
       1. Describe it in the 'resources' block. 
       2. Animate it in 'scene_1'.
       3. Continue the story in 'scene_2' and 'scene_3' based on the user's idea.
       User Idea: ${userDescription}
     `;
  } else {
     // Text-to-Video
     promptText = `User Description: "${userDescription}". Generate the full JSON structure filling all relevant blocks (narrative, scenes, audio, etc).`;
  }

  const parts: any[] = [
    { text: schemaContext },
    { text: promptText }
  ];

  if (imageBase64) {
    parts.unshift({
      inlineData: {
        mimeType: mimeType,
        data: imageBase64
      }
    });
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) return null;

    // Clean Markdown if present (Gemini sometimes adds ```json ... ```)
    const cleanedText = text.replace(/```json/g, '').replace(/```/g, '').trim();

    return JSON.parse(cleanedText) as PromptData;
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
}

export async function generateMotionFromAsset(assetDescription: string): Promise<string | null> {
  if (!API_KEY) return null;
  const ai = getAiClient();
  const model = "gemini-2.5-flash";

  const prompt = `
    You are a Cinematic Video Director.
    Input Asset Description: "${assetDescription}"
    
    Task: Write a concise, vivid "Action Description" (under 20 words) for a video scene that features this asset.
    Focus on camera movement (pan, zoom, orbit) and subject movement.
    Example output: "Slow zoom in on the character as they raise a hand, with soft lighting shifts."
    
    Output: ONLY the action description string.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text?.trim() || null;
  } catch (error) {
    console.error("Gemini Motion Gen Error:", error);
    return null;
  }
}