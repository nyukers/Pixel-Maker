export function getPath(obj: any, path: string): any {
  if (!obj) return undefined;
  const parts = path.split('.');
  let current = obj;
  for (const part of parts) {
    if (current == null || typeof current !== 'object') return undefined;
    current = current[part];
  }
  return current;
}

export function setPath(obj: any, path: string, value: any): void {
  const parts = path.split('.');
  let current = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    const nextPart = parts[i + 1];
    
    // Determine if the *next* part is an array index
    const isNextArray = !isNaN(Number(nextPart));

    if (!(part in current) || typeof current[part] !== 'object') {
      // Create array if next part is number, otherwise object
      current[part] = isNextArray ? [] : {};
    }
    current = current[part];
  }
  
  const lastPart = parts[parts.length - 1];
  // If explicitly setting an array index, ensure parent is array-like? 
  // JS handles array[index] = val fine even if it extends length.
  current[lastPart] = value;
}

export function deepCopy<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

// Recursively clean object based on 'omitEmpty' setting
export function cleanObject(obj: any, omitEmpty: boolean): any {
  if (!omitEmpty) return obj;
  
  if (Array.isArray(obj)) {
    const cleanedArray = obj.map(v => cleanObject(v, omitEmpty)).filter(v => v !== undefined);
    return cleanedArray.length > 0 ? cleanedArray : undefined;
  }
  
  if (obj !== null && typeof obj === 'object') {
    const newObj: any = {};
    let hasKeys = false;
    for (const key in obj) {
      const val = cleanObject(obj[key], omitEmpty);
      
      // Explicitly keep 0 (start time) and boolean false
      if (val !== undefined && val !== null) {
        if (typeof val === 'string') {
          if (val.trim() !== '') {
            newObj[key] = val;
            hasKeys = true;
          }
        } else if (typeof val === 'number') {
           newObj[key] = val;
           hasKeys = true;
        } else if (typeof val === 'boolean') {
           newObj[key] = val;
           hasKeys = true;
        } else if (typeof val === 'object' && Object.keys(val).length > 0) {
           newObj[key] = val;
           hasKeys = true;
        }
      }
    }
    return hasKeys ? newObj : undefined;
  }
  
  return obj;
}

export function prunePath(obj: any, path: string) {
  const parts = path.split('.');
  const [head, ...rest] = parts;
  if (!obj || !(head in obj)) return;

  if (rest.length === 0) {
    if (Array.isArray(obj)) {
       // If deleting from array, we might want to splice, but that shifts indices.
       // For simple path pruning in this app, delete is safer for object consistency until rebuild.
       // actually, let's just delete the key/index.
       delete obj[head]; 
    } else {
       delete obj[head];
    }
  } else {
    prunePath(obj[head], rest.join('.'));
    // Cleanup empty parents
    const val = obj[head];
    if (val && typeof val === 'object' && Object.keys(val).length === 0) {
       // Don't delete empty arrays if they were intentional, but here we prune empty branches
       if (!Array.isArray(val)) {
         delete obj[head];
       }
    }
  }
}

export function buildInitialData(schema: any[]): any {
  const data: any = {};
  schema.forEach(block => {
    const blockData: any = {};
    block.fields.forEach((f: any) => {
      setPath(blockData, f.path, f.default ?? (f.type === 'checkbox' ? false : ''));
    });
    data[block.name] = blockData;
  });
  return data;
}

export function buildInitialInclude(schema: any[]): any {
  const include: any = {};
  schema.forEach(block => {
    include[block.name] = block.defaultInclude ?? true;
  });
  return include;
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data url prefix (e.g. "data:image/jpeg;base64,")
      const base64 = result.split(',')[1]; 
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
}