import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { SchemaBlock, PromptData, PromptInclude, AppSettings, PresetKey, StylePresetKey } from './types';
import { INITIAL_SCHEMA, STYLE_PRESETS } from './constants';
import { getPath, setPath, deepCopy, cleanObject, prunePath, buildInitialData, buildInitialInclude } from './utils';
import { useHistory } from './hooks/useHistory';
import BlockCard from './components/BlockCard';
import Preview from './components/Preview';
import MagicModal from './components/MagicModal';
import ValidatorModal from './components/ValidatorModal';
import { generatePromptDataWithGemini, generateMotionFromAsset } from './services/geminiService';
import { Sparkles, Plus, RefreshCw, Code, FileCheck, Undo2, Redo2, Film, Clapperboard } from 'lucide-react';

interface AppState {
  schema: SchemaBlock[];
  data: PromptData;
  include: PromptInclude;
  preset: PresetKey;
  settings: AppSettings;
}

const INITIAL_STATE: AppState = {
  schema: deepCopy(INITIAL_SCHEMA),
  data: buildInitialData(INITIAL_SCHEMA),
  include: buildInitialInclude(INITIAL_SCHEMA),
  preset: 'sample',
  settings: {
    includeMap: false, 
    omitEmpty: true,
    schemaMode: false,
  }
};

function App() {
  const { state, set, undo, redo, canUndo, canRedo } = useHistory<AppState>(INITIAL_STATE);
  const { schema, data, include, settings, preset: currentPreset } = state;

  const [magicModalOpen, setMagicModalOpen] = useState(false);
  const [validatorModalOpen, setValidatorModalOpen] = useState(false);
  
  const lastUpdateRef = useRef<{ path: string, time: number } | null>(null);

  const finalJson = useMemo(() => {
    const activeData: any = {};
    const activeInclude: any = {};

    schema.forEach(block => {
      if (include[block.name]) {
        let blockData = deepCopy(data[block.name] || {});
        
        if (settings.omitEmpty) {
            blockData = cleanObject(blockData, true);
        }
        
        if (blockData) {
            // Recursive merge for monolithic JSON structure
            const recursiveMerge = (target: any, source: any) => {
                for (const key of Object.keys(source)) {
                     if (source[key] instanceof Array) {
                        if (!target[key]) target[key] = [];
                        source[key].forEach((val: any, idx: number) => {
                            if (!target[key][idx]) {
                                target[key][idx] = val;
                            } else if (typeof val === 'object' && val !== null) {
                                recursiveMerge(target[key][idx], val);
                            } else {
                                target[key][idx] = val;
                            }
                        });
                     } else if (source[key] instanceof Object && source[key] !== null) {
                         if (!target[key]) target[key] = {};
                         recursiveMerge(target[key], source[key]);
                     } else {
                         target[key] = source[key];
                     }
                }
            }
            recursiveMerge(activeData, blockData);
        }
        
        activeInclude[block.name] = true;
      }
    });

    const cleanArrays = (obj: any) => {
        for (const key in obj) {
            if (Array.isArray(obj[key])) {
                obj[key] = obj[key].filter((el: any) => el !== null && el !== undefined);
                obj[key].forEach((item: any) => {
                   if (typeof item === 'object') cleanArrays(item);
                });
            } else if (typeof obj === 'object' && obj !== null) {
                cleanArrays(obj[key]);
            }
        }
    };
    cleanArrays(activeData);

    if (settings.includeMap) {
      return { _debug_blocks: activeInclude, ...activeData };
    }
    return activeData;
  }, [schema, data, include, settings]);

  const hasIncludedBlocks = Object.keys(finalJson).length > (settings.includeMap ? 1 : 0);

  const handleUndo = useCallback(() => {
    undo();
    lastUpdateRef.current = null; 
  }, [undo]);

  const handleRedo = useCallback(() => {
    redo();
    lastUpdateRef.current = null;
  }, [redo]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      }
      if ((e.metaKey || e.ctrlKey) && ((e.key.toLowerCase() === 'z' && e.shiftKey) || e.key.toLowerCase() === 'y')) {
        e.preventDefault();
        handleRedo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  const handleUpdateData = (blockName: string, path: string, value: any) => {
    const fullPath = `${blockName}.${path}`;
    const now = Date.now();
    const isRapidUpdate = lastUpdateRef.current 
      && lastUpdateRef.current.path === fullPath 
      && (now - lastUpdateRef.current.time < 1000);

    lastUpdateRef.current = { path: fullPath, time: now };

    set(prev => {
      const nextData = deepCopy(prev.data);
      if (!nextData[blockName]) nextData[blockName] = {};
      setPath(nextData[blockName], path, value);
      
      return {
        ...prev,
        data: nextData,
        preset: 'custom' 
      };
    }, { replace: isRapidUpdate });
  };

  const handleUpdateInclude = (blockName: string, val: boolean) => {
    // Check if block is mandatory
    const block = state.schema.find(b => b.name === blockName);
    if (block?.mandatory && !val) return;

    set(prev => ({
      ...prev,
      include: { ...prev.include, [blockName]: val },
      preset: 'custom'
    }));
  };

  const handlePresetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const key = e.target.value as PresetKey;
    
    set(prev => {
      if (key === 'blank') {
         const blankData: any = {};
         prev.schema.forEach(block => {
           blankData[block.name] = {};
           block.fields.forEach(field => {
              let val;
              if (block.highlight) {
                  val = field.default ?? (field.type === 'checkbox' ? false : '');
              } else {
                  val = field.type === 'checkbox' ? false : '';
              }
              setPath(blankData[block.name], field.path, val);
           });
         });
         return {
           ...prev,
           preset: 'blank',
           data: blankData,
           include: buildInitialInclude(prev.schema)
         };
      } else if (key === 'sample') {
         return {
           ...prev,
           preset: 'sample',
           schema: deepCopy(INITIAL_SCHEMA),
           data: buildInitialData(INITIAL_SCHEMA),
           include: buildInitialInclude(INITIAL_SCHEMA)
         };
      }
      return { ...prev, preset: key };
    });
  };

  const handleSettingsChange = (key: keyof AppSettings, val: boolean) => {
    set(prev => ({
      ...prev,
      settings: { ...prev.settings, [key]: val }
    }));
  };

  const addBlock = () => {
    const nameInput = prompt("Block key (snake_case):");
    if (!nameInput) return;
    const name = nameInput.trim().toLowerCase().replace(/\s+/g, '_');
    
    if (schema.find(b => b.name === name)) {
      alert("Block name already exists!");
      return;
    }

    const title = prompt("Block title:", name) || name;
    
    const newBlock: SchemaBlock = {
      name,
      title,
      hint: "Custom block",
      defaultInclude: true,
      fields: []
    };
    
    set(prev => ({
      ...prev,
      schema: [...prev.schema, newBlock],
      include: { ...prev.include, [name]: true },
      data: { ...prev.data, [name]: {} },
      preset: 'custom'
    }));
  };

  const duplicateBlock = (block: SchemaBlock) => {
    const baseName = block.name;
    let counter = 2;
    let newName = `${baseName}_${counter}`;
    while (schema.find(b => b.name === newName)) {
      counter++;
      newName = `${baseName}_${counter}`;
    }

    set(prev => {
      const newBlock = { ...block, name: newName, title: `${block.title} copy` };
      // Remove mandatory status from duplicates to avoid locking user
      if (newBlock.mandatory) {
         delete newBlock.mandatory;
      }
      const newBlockIdx = prev.schema.findIndex(b => b.name === block.name) + 1;
      const newSchema = [...prev.schema];
      newSchema.splice(newBlockIdx, 0, newBlock);

      return {
        ...prev,
        schema: newSchema,
        include: { ...prev.include, [newName]: prev.include[block.name] },
        data: { ...prev.data, [newName]: deepCopy(prev.data[block.name] || {}) },
        preset: 'custom'
      };
    });
  };

  const deleteBlock = (name: string) => {
    const block = schema.find(b => b.name === name);
    if (block?.mandatory) {
       alert("This block is mandatory and cannot be deleted.");
       return;
    }
    if (schema.length <= 1) {
      alert("Keep at least one block.");
      return;
    }
    if (!confirm(`Delete block '${name}'?`)) return;
    
    set(prev => {
      const nextData = deepCopy(prev.data);
      const nextInclude = { ...prev.include };
      delete nextData[name];
      delete nextInclude[name];

      return {
        ...prev,
        schema: prev.schema.filter(b => b.name !== name),
        data: nextData,
        include: nextInclude,
        preset: 'custom'
      };
    });
  };

  const addField = (blockName: string) => {
    const path = prompt("Field path (dot notation). Use numbers for arrays (e.g., items.0.name):", "new_key");
    if (!path) return;
    const label = prompt("Label:", path) || path;
    const typeInput = prompt("Type (text / textarea / checkbox / number / date):", "text") || "text";
    
    const validTypes = ["text", "textarea", "checkbox", "number", "date", "select"];
    const type: any = validTypes.includes(typeInput.toLowerCase()) ? typeInput.toLowerCase() : "text";

    set(prev => ({
      ...prev,
      schema: prev.schema.map(b => {
        if (b.name === blockName) {
          return {
            ...b,
            fields: [...b.fields, { path, label, type, default: type === 'checkbox' ? false : '' }]
          };
        }
        return b;
      }),
      preset: 'custom'
    }));
  };

  const removeField = (blockName: string, path: string) => {
    if (!confirm(`Remove field '${path}'?`)) return;
    
    set(prev => {
      const nextData = deepCopy(prev.data);
      if (nextData[blockName]) {
        prunePath(nextData[blockName], path);
      }

      return {
        ...prev,
        schema: prev.schema.map(b => {
          if (b.name === blockName) {
            return { ...b, fields: b.fields.filter(f => f.path !== path) };
          }
          return b;
        }),
        data: nextData,
        preset: 'custom'
      };
    });
  };

  const moveField = (blockName: string, fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return;
    set(prev => ({
      ...prev,
      schema: prev.schema.map(b => {
        if (b.name === blockName) {
          const newFields = [...b.fields];
          const [movedField] = newFields.splice(fromIndex, 1);
          newFields.splice(toIndex, 0, movedField);
          return { ...b, fields: newFields };
        }
        return b;
      }),
      preset: 'custom'
    }));
  };

  const handleMagicGenerate = async (description: string, imageBase64?: string, mimeType?: string) => {
    try {
      const generatedData = await generatePromptDataWithGemini(schema, description, imageBase64, mimeType);
      
      const isImageOnlyMode = imageBase64 && (!description || description.trim() === '');

      if (generatedData) {
        set(prev => {
          const nextData = deepCopy(prev.data);
          const nextInclude = { ...prev.include };
          
          Object.keys(generatedData).forEach(blockName => {
            if (prev.schema.some(b => b.name === blockName)) {
              nextData[blockName] = generatedData[blockName];
              nextInclude[blockName] = true;
            }
          });

          // Special logic for Image Only Mode: explicitly disable extra scenes
          if (isImageOnlyMode) {
             nextInclude['scene_2'] = false;
             nextInclude['scene_3'] = false;
             // Ensure Scene 1 is enabled
             nextInclude['scene_1'] = true;
          }

          return {
            ...prev,
            data: nextData,
            include: nextInclude,
            preset: 'custom'
          };
        });
      }
    } catch (e) {
      alert("Failed to generate with AI. Check console or API Key.");
    }
  };

  // Feature: Generate motion description from specific asset input and place in corresponding scene
  const handleAutoGenerateMotion = async (resourceIndex: number, description: string) => {
    try {
      const motionDescription = await generateMotionFromAsset(description);
      if (motionDescription) {
         // Map Resource Index (0, 1, 2) to Scene Block (scene_1, scene_2, scene_3)
         const sceneBlockName = `scene_${resourceIndex + 1}`;
         // The schema defines scene actions as video_scenario.scenes.0.action for scene_1, etc.
         // Note: The schema path in constants.ts uses specific indices (0, 1, 2) for the action fields within the blocks
         const actionPath = `video_scenario.scenes.${resourceIndex}.action`;

         handleUpdateData(sceneBlockName, actionPath, motionDescription);
         // Also ensure the scene is included
         handleUpdateInclude(sceneBlockName, true);
      }
    } catch (e) {
      console.error(e);
      alert("Could not generate motion description.");
    }
  };

  // Helper to identify if a block belongs to the "Scenes" group
  const isSceneBlock = (blockName: string) => blockName.startsWith('scene_');
  const hasSceneBlocks = schema.some(b => isSceneBlock(b.name));
  let scenesRendered = false;

  return (
    <div className="min-h-screen pb-12 flex flex-col">
      <MagicModal 
        isOpen={magicModalOpen} 
        onClose={() => setMagicModalOpen(false)} 
        onGenerate={handleMagicGenerate}
      />
      <ValidatorModal
        isOpen={validatorModalOpen}
        onClose={() => setValidatorModalOpen(false)}
      />

      <div className="max-w-[1200px] w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6 flex-1">
        
        <header className="bg-gradient-to-br from-panel/90 to-panel2/95 border border-border rounded-3xl p-6 sm:p-8 shadow-glow backdrop-blur-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
          
          <div className="relative z-10">
            <p className="text-xs font-bold tracking-widest text-muted uppercase mb-2">Google Veo • (C) Nyukers, 2026</p>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-accent text-panel2 rounded-xl shadow-lg shadow-accent/20">
                <Clapperboard size={28} />
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-text">Video JSON Prompt Builder</h1>
            </div>
            <p className="text-muted max-w-2xl leading-relaxed mb-6">
              Create professional, temporal JSON prompts for Google Veo.
              Define scenes, timings, input assets, and audio transitions.
            </p>

            <div className="flex flex-col xl:flex-row gap-4 xl:items-center justify-between">
              
              <div className="flex flex-wrap items-center gap-3">
                 <div className="flex items-center gap-2 bg-panel2 border border-border rounded-lg px-3 py-2">
                   <span className="text-xs text-muted">Preset</span>
                   <select 
                      value={currentPreset}
                      className="bg-transparent text-sm font-semibold text-text focus:outline-none cursor-pointer min-w-[120px]"
                      onChange={handlePresetChange}
                   >
                     <option className="bg-panel2" value="sample">Veo Sample</option>
                     <option className="bg-panel2" value="blank">Blank Form</option>
                     <option className="bg-panel2" value="custom" disabled={currentPreset !== 'custom'}>Custom</option>
                   </select>
                 </div>

                 <div className="h-6 w-px bg-border mx-1 hidden sm:block"></div>

                 <label className="flex items-center gap-2 text-sm text-muted cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={settings.includeMap}
                      onChange={(e) => handleSettingsChange('includeMap', e.target.checked)}
                      className="w-4 h-4 rounded accent-accent bg-code border-border" 
                    />
                    Debug Info
                 </label>

                 <label className="flex items-center gap-2 text-sm text-muted cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={settings.omitEmpty}
                      onChange={(e) => handleSettingsChange('omitEmpty', e.target.checked)}
                      className="w-4 h-4 rounded accent-accent bg-code border-border" 
                    />
                    Skip empty
                 </label>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1 bg-panel2 border border-border rounded-full p-1 mr-2">
                  <button 
                    onClick={handleUndo} 
                    disabled={!canUndo}
                    title="Undo (Ctrl+Z)"
                    className="p-2 rounded-full text-muted hover:text-text hover:bg-panel transition-all disabled:opacity-30 disabled:hover:bg-transparent"
                  >
                    <Undo2 size={16} />
                  </button>
                  <button 
                    onClick={handleRedo} 
                    disabled={!canRedo}
                    title="Redo (Ctrl+Y)"
                    className="p-2 rounded-full text-muted hover:text-text hover:bg-panel transition-all disabled:opacity-30 disabled:hover:bg-transparent"
                  >
                    <Redo2 size={16} />
                  </button>
                </div>

                <button 
                  onClick={() => setValidatorModalOpen(true)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-panel2 border border-border text-muted font-bold hover:text-text hover:border-accent transition-all active:scale-95"
                >
                  <FileCheck size={16} />
                  Validate JSON 
                </button>
                
                 <label className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-medium cursor-pointer transition-all ${settings.schemaMode ? 'bg-accent/10 border-accent text-accent' : 'bg-transparent border-border text-muted hover:border-muted'}`}>
                    <input 
                      type="checkbox" 
                      checked={settings.schemaMode}
                      onChange={(e) => handleSettingsChange('schemaMode', e.target.checked)}
                      className="hidden" 
                    />
                    <Code size={16} />
                    Schema Mode
                 </label>

                <button 
                  onClick={() => setMagicModalOpen(true)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-accent text-panel2 font-bold shadow-accent hover:brightness-110 transition-all active:scale-95"
                >
                  <Sparkles size={16} />
                  Auto-Fill (AI)
                </button>
              </div>
            </div>
            
            {settings.schemaMode && (
               <div className="mt-4 pt-4 border-t border-border flex gap-3">
                  <button onClick={addBlock} className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-accent hover:text-white transition-colors">
                    <Plus size={14} /> Add New Block
                  </button>
                  <button 
                    onClick={() => {
                        if(confirm("Reset entire schema to default?")) {
                            set({
                                ...INITIAL_STATE,
                                schema: deepCopy(INITIAL_SCHEMA),
                                data: buildInitialData(INITIAL_SCHEMA),
                                include: buildInitialInclude(INITIAL_SCHEMA),
                            });
                        }
                    }} 
                    className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted hover:text-danger transition-colors ml-auto"
                  >
                    <RefreshCw size={14} /> Reset Schema
                  </button>
               </div>
            )}
          </div>
        </header>

        {/* Main Form Area */}
        <div className="flex flex-col gap-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 items-start">
             {schema.map((block) => {
               // 1. SCENES: Logic to render grouped scenes
               const isScene = isSceneBlock(block.name);
               
               if (isScene) {
                  if (scenesRendered) return null; // Skip subsequent scenes
                  scenesRendered = true;
                  const sceneBlocks = schema.filter(b => isSceneBlock(b.name));
                  
                  return (
                    <div key="scene-group" className="xl:col-span-2 mt-2 mb-2">
                       <div className="bg-panel/30 border border-border/60 rounded-2xl p-4 sm:p-6 relative overflow-hidden">
                          {/* Visual flair for the timeline container */}
                          <div className="absolute top-0 left-0 w-1 h-full bg-accent/20"></div>
                          
                          <div className="flex items-center gap-3 mb-5 pl-2">
                             <div className="p-2 bg-accent/10 rounded-lg text-accent">
                               <Film size={20} />
                             </div>
                             <div>
                               <h3 className="text-xl font-bold text-accent2">Timeline Sequence</h3>
                               <p className="text-sm text-muted">Define the sequential scenes of your video.</p>
                             </div>
                          </div>

                          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
                            {sceneBlocks.map(sceneBlock => (
                              <BlockCard
                                key={sceneBlock.name}
                                block={sceneBlock}
                                data={data[sceneBlock.name]}
                                include={!!include[sceneBlock.name]}
                                schemaMode={settings.schemaMode}
                                onUpdateInclude={(val) => handleUpdateInclude(sceneBlock.name, val)}
                                onUpdateData={(path, val) => handleUpdateData(sceneBlock.name, path, val)}
                                onDuplicateBlock={() => duplicateBlock(sceneBlock)}
                                onDeleteBlock={() => deleteBlock(sceneBlock.name)}
                                onAddField={() => addField(sceneBlock.name)}
                                onRemoveField={(path) => removeField(sceneBlock.name, path)}
                                onMoveField={(from, to) => moveField(sceneBlock.name, from, to)}
                              />
                            ))}
                          </div>
                       </div>
                    </div>
                  );
               }

               // 2. NARRATIVE: Render Scenario Overview full width
               if (block.name === 'narrative') {
                 return (
                   <div key={block.name} className="xl:col-span-2">
                     <BlockCard
                       block={block}
                       data={data[block.name]}
                       include={!!include[block.name]}
                       schemaMode={settings.schemaMode}
                       onUpdateInclude={(val) => handleUpdateInclude(block.name, val)}
                       onUpdateData={(path, val) => handleUpdateData(block.name, path, val)}
                       onDuplicateBlock={() => duplicateBlock(block)}
                       onDeleteBlock={() => deleteBlock(block.name)}
                       onAddField={() => addField(block.name)}
                       onRemoveField={(path) => removeField(block.name, path)}
                       onMoveField={(from, to) => moveField(block.name, from, to)}
                     />
                   </div>
                 );
               }

               // 3. NORMAL BLOCKS
               return (
                 <BlockCard
                   key={block.name}
                   block={block}
                   data={data[block.name]}
                   include={!!include[block.name]}
                   schemaMode={settings.schemaMode}
                   onUpdateInclude={(val) => handleUpdateInclude(block.name, val)}
                   onUpdateData={(path, val) => handleUpdateData(block.name, path, val)}
                   onDuplicateBlock={() => duplicateBlock(block)}
                   onDeleteBlock={() => deleteBlock(block.name)}
                   onAddField={() => addField(block.name)}
                   onRemoveField={(path) => removeField(block.name, path)}
                   onMoveField={(from, to) => moveField(block.name, from, to)}
                   onGenerateMotion={handleAutoGenerateMotion}
                 />
               );
             })}
          </div>

          {schema.length === 0 && (
            <div className="p-12 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center text-muted">
              <p>No blocks defined.</p>
              <button onClick={addBlock} className="mt-2 text-accent hover:underline">Add a block</button>
            </div>
          )}
        </div>

        {/* Preview Footer */}
        <div className="mt-4">
           <Preview json={finalJson} isValid={hasIncludedBlocks} />
        </div>

      </div>
    </div>
  );
}

export default App;