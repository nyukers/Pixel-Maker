import { SchemaBlock, PromptData, PromptInclude, StylePresetKey } from './types';

// VEO 3.1 Video Generation Schema (English Version)
export const INITIAL_SCHEMA: SchemaBlock[] = [
  {
    name: "general",
    title: "1. General Settings",
    hint: "Model version, language, and duration settings.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { path: "model", label: "Model", default: "Veo 3.1", type: "select", options: ["Veo 3.1", "Veo 3.0", "Sora-Turbo", "Runway Gen-3"] },
      { 
        path: "prompt_language", 
        label: "Prompt Language", 
        default: "en-US", 
        type: "text", 
        readonly: true 
      },
      { 
        path: "duration_seconds", 
        label: "Duration (sec)", 
        type: "select", 
        default: "8",
        options: ["3", "5", "8"] 
      },
    ]
  },
  {
    name: "resources",
    title: "2. Input Assets",
    hint: "Define reference images (ID and Description).",
    defaultInclude: true,
    fields: [
      // Resource 1
      { path: "input_resources.0.type", label: "Asset 1: Type", default: "image", options: ["image", "video"] },
      { path: "input_resources.0.id", label: "Asset 1: ID", default: "image_001" },
      { path: "input_resources.0.description", label: "Asset 1: Description", type: "textarea", default: "Opening scene: Character standing near an empty chalkboard." },
      // Resource 2
      { path: "input_resources.1.type", label: "Asset 2: Type", default: "image", options: ["image", "video"] },
      { path: "input_resources.1.id", label: "Asset 2: ID", default: "image_002" },
      { path: "input_resources.1.description", label: "Asset 2: Description", type: "textarea", default: "Final scene: Character proudly presenting a full cheese platter." },
       // Resource 3
      { path: "input_resources.2.type", label: "Asset 3: Type", default: "" },
      { path: "input_resources.2.id", label: "Asset 3: ID", default: "" },
      { path: "input_resources.2.description", label: "Asset 3: Description", type: "textarea", default: "" },
    ]
  },
  {
    name: "narrative",
    title: "3. Scenario Overview",
    hint: "Overall video concept and narrative arc.",
    defaultInclude: true,
    highlight: false,
    fields: [
      { path: "video_scenario.description", label: "General Description", type: "textarea", default: "A short animated video where the character magically creates a cheese platter." },
    ]
  },
  {
    name: "scene_1",
    title: "4. Scene 1 (Start)",
    hint: "The beginning of the video (0s - X)",
    defaultInclude: true,
    highlight: false,
    mandatory: true,
    fields: [
      { path: "video_scenario.scenes.0.start_time", label: "Start Time (s)", type: "number", default: 0 },
      { path: "video_scenario.scenes.0.end_time", label: "End Time (s)", type: "number", default: 3 },
      { path: "video_scenario.scenes.0.action", label: "Action Description", type: "textarea", default: "Shot starts with 'image_001'. The character makes smooth conductor-like hand movements." },
      { 
        path: "video_scenario.scenes.0.transition", 
        label: "Transition", 
        type: "select", 
        default: "smooth morphing", 
        options: ["smooth morphing", "hard cut", "fade out", "blur", "dissolve", "Page Curl", "Wipe Left", "Wipe Right", "Zoom In", "Zoom Out"] 
      }
    ]
  },
  {
    name: "scene_2",
    title: "5. Scene 2 (Middle)",
    hint: "The main action sequence.",
    defaultInclude: true,
    highlight: false,
    fields: [
      { path: "video_scenario.scenes.1.start_time", label: "Start Time (s)", type: "number", default: 3 },
      { path: "video_scenario.scenes.1.end_time", label: "End Time (s)", type: "number", default: 6 },
      { path: "video_scenario.scenes.1.action", label: "Action Description", type: "textarea", default: "Pieces of cheese and grapes begin to magically appear and arrange themselves on the board." },
      { 
        path: "video_scenario.scenes.1.transition", 
        label: "Transition", 
        type: "select", 
        default: "hard cut", 
        options: ["smooth morphing", "hard cut", "fade out", "blur", "dissolve", "Page Curl", "Wipe Left", "Wipe Right", "Zoom In", "Zoom Out"] 
      }
    ]
  },
  {
    name: "scene_3",
    title: "6. Scene 3 (End)",
    hint: "The ending / packshot.",
    defaultInclude: true,
    highlight: false,
    fields: [
      { path: "video_scenario.scenes.2.start_time", label: "Start Time (s)", type: "number", default: 6 },
      { path: "video_scenario.scenes.2.end_time", label: "End Time (s)", type: "number", default: 8 },
      { path: "video_scenario.scenes.2.action", label: "Action Description", type: "textarea", default: "Show packshot from 'image_003'. Logo appears in the center." },
      { 
        path: "video_scenario.scenes.2.transition", 
        label: "Transition", 
        type: "select",
        default: "end",
        options: ["end", "loop", "fade out", "hard cut", "Page Curl", "Wipe Left", "Wipe Right", "Zoom In", "Zoom Out"]
      }
    ]
  },
  {
    name: "audio",
    title: "7. Audio & SFX",
    hint: "Music, style, and sound effects.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { 
        path: "audio_track.music.style", 
        label: "Music Style", 
        type: "select",
        default: "Light, melodic folk music",
        options: [
          "Light, melodic folk music",
          "Cinematic / Orchestral",
          "Electronic / Synthwave",
          "Ambient / Drone",
          "Upbeat Pop",
          "Energetic Rock",
          "Jazz / Lounge",
          "Lo-Fi Beats",
          "Silence / None"
        ]
      },
      { 
        path: "audio_track.music.mood", 
        label: "Mood", 
        type: "select",
        default: "Magical, positive, welcoming",
        options: [
          "Magical, positive, welcoming",
          "Epic, heroic, grand",
          "Dark, tense, suspenseful",
          "Sad, melancholic, emotional",
          "Relaxed, calm, peaceful",
          "Fast-paced, chaotic",
          "Romantic, sentimental"
        ]
      },
      { 
        path: "audio_track.music.volume", 
        label: "Volume", 
        type: "select",
        default: "Background",
        options: [
          "Background",
          "Foreground",
          "Loud",
          "Soft",
          "Muted"
        ]
      },
      // SFX 1
      { 
        path: "audio_track.sfx.0.time", 
        label: "SFX 1: Time", 
        type: "select",
        default: "1-5s",
        options: [
          "0-2s (Start)",
          "1-5s",
          "3-6s (Middle)",
          "6-8s (End)",
          "Throughout video",
          "Sync with action"
        ]
      },
      { 
        path: "audio_track.sfx.0.description", 
        label: "SFX 1: Desc", 
        type: "textarea", 
        default: "Light magical chimes accompanying the movements." 
      }
    ]
  },
  {
    name: "voice",
    title: "8. Voiceover",
    hint: "Voice actor text and timing.",
    defaultInclude: true,
    fields: [
      { path: "voiceover.text", label: "Text", type: "textarea", default: "The Cheese Shop — your perfect cheese story." },
      { path: "voiceover.voice_type", label: "Voice Type", default: "Female, soft, welcoming" },
      { path: "voiceover.start_time", label: "Start (s)", type: "number", default: 5.5 },
      { path: "voiceover.end_time", label: "End (s)", type: "number", default: 8 }
    ]
  },
  {
    name: "constraints",
    title: "9. Rules",
    hint: "Special constraints or negative prompts.",
    defaultInclude: true,
    fields: [
      { path: "special_rules.0", label: "Rule 1", default: "Voiceover must be in English." },
      { path: "special_rules.1", label: "Rule 2", default: "No subtitles." },
      { path: "special_rules.2", label: "Rule 3", default: "" },
    ]
  },
  {
    name: "negative_constraints",
    title: "10. Negative Constraints",
    hint: "Define what should NOT appear in the video.",
    defaultInclude: true,
    fields: [
      { path: "negative_prompt", label: "Exclude Objects/Styles", type: "textarea", default: "blurry, distorted, grain, low resolution, text, watermark, bad anatomy, deformed" },
      { path: "constraints.no_camera_shake", label: "Stabilize (No Shake)", type: "checkbox", default: true },
      { path: "constraints.consistent_lighting", label: "Force Consistent Lighting", type: "checkbox", default: true }
    ]
  }
];

// Presets specifically for Video styles
export const STYLE_PRESETS: Record<StylePresetKey, any> = {
  none: {},
  editorial: {
    general: { "model": "Veo 3.1" },
    narrative: { "video_scenario": { "description": "High-fashion slow motion editorial video." } },
    scene_1: { "video_scenario": { "scenes": { "0": { "action": "Model posing in slow motion, wind in hair, soft lighting." } } } }
  },
  packshot: {
    general: { "duration_seconds": 5 },
    scene_1: { "video_scenario": { "scenes": { "0": { "action": "Product rotates 360 degrees on a clean background." } } } }
  },
  character: {},
  scifi: {
    audio: { "audio_track": { "music": { "style": "Electronic / Synthwave" } } }
  },
  xmas: {},
  noir: {},
  vintage: {
     general: { "duration_seconds": 10 },
     resources: { "input_resources": { "0": { "type": "image", "description": "Old film grain texture overlay" } } },
     negative_constraints: { "negative_prompt": "modern cars, digital glitch, 4k sharp" }
  }
};