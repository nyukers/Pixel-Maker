export interface SchemaField {
  path: string;
  label: string;
  type?: 'text' | 'textarea' | 'checkbox' | 'select' | 'number' | 'date';
  default?: string | boolean | number;
  placeholder?: string;
  help?: string;
  options?: string[];
  readonly?: boolean;
}

export interface SchemaBlock {
  name: string;
  title: string;
  hint?: string;
  defaultInclude?: boolean;
  fields: SchemaField[];
  highlight?: boolean;
  mandatory?: boolean;
}

export interface PromptData {
  [blockName: string]: {
    [key: string]: any;
  };
}

export interface PromptInclude {
  [blockName: string]: boolean;
}

export interface AppSettings {
  includeMap: boolean;
  omitEmpty: boolean;
  schemaMode: boolean;
}

export type PresetKey = 'sample' | 'blank' | 'custom';
export type StylePresetKey = 'none' | 'editorial' | 'packshot' | 'character' | 'scifi' | 'xmas' | 'noir' | 'vintage';