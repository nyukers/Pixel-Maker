import { useState, useCallback } from 'react';

export interface HistoryOptions {
  replace?: boolean;
}

export function useHistory<T>(initialState: T) {
  const [history, setHistory] = useState<{
    past: T[];
    present: T;
    future: T[];
  }>({
    past: [],
    present: initialState,
    future: [],
  });

  const canUndo = history.past.length > 0;
  const canRedo = history.future.length > 0;

  const undo = useCallback(() => {
    setHistory(curr => {
      if (curr.past.length === 0) return curr;
      const previous = curr.past[curr.past.length - 1];
      const newPast = curr.past.slice(0, -1);
      return {
        past: newPast,
        present: previous,
        future: [curr.present, ...curr.future],
      };
    });
  }, []);

  const redo = useCallback(() => {
    setHistory(curr => {
      if (curr.future.length === 0) return curr;
      const next = curr.future[0];
      const newFuture = curr.future.slice(1);
      return {
        past: [...curr.past, curr.present],
        present: next,
        future: newFuture,
      };
    });
  }, []);

  const set = useCallback((newState: T | ((curr: T) => T), options?: HistoryOptions) => {
    setHistory(curr => {
      const resolvedState = typeof newState === 'function' ? (newState as any)(curr.present) : newState;
      
      // Simple reference equality check
      if (resolvedState === curr.present) return curr;

      if (options?.replace) {
        return {
          ...curr,
          present: resolvedState,
          future: []
        };
      }

      return {
        past: [...curr.past, curr.present],
        present: resolvedState,
        future: [],
      };
    });
  }, []);
  
  return { state: history.present, set, undo, redo, canUndo, canRedo };
}