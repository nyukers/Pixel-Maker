import React, { useState } from 'react';
import { Copy, Download, Check } from 'lucide-react';

interface PreviewProps {
  json: object;
  isValid: boolean;
}

const Preview: React.FC<PreviewProps> = ({ json, isValid }) => {
  const [copied, setCopied] = useState(false);
  const jsonString = JSON.stringify(json, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "prompt.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-panel2 border border-border rounded-xl p-5 shadow-glow w-full">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 pb-4 border-b border-border">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-text">Resulting JSON</h2>
          <p className="text-sm text-muted">This is the final structure sent to the generation API.</p>
        </div>
        
        <div className="flex gap-3">
          <div className={`text-xs px-3 py-2 rounded-lg border flex items-center ${isValid ? 'bg-accent/10 border-accent/30 text-accent' : 'bg-danger/10 border-danger/30 text-danger'}`}>
             {isValid ? "Ready" : "No data"}
          </div>
          <button 
            onClick={handleCopy}
            disabled={!isValid}
            className="flex items-center gap-2 px-3 py-2 text-sm text-muted hover:text-accent border border-border bg-panel hover:bg-panel2 rounded-lg transition-all disabled:opacity-50"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
            <span>Copy</span>
          </button>
          <button 
            onClick={handleDownload}
            disabled={!isValid}
            className="flex items-center gap-2 px-3 py-2 text-sm text-muted hover:text-accent border border-border bg-panel hover:bg-panel2 rounded-lg transition-all disabled:opacity-50"
          >
            <Download size={16} />
            <span>Download</span>
          </button>
        </div>
      </div>
      
      <pre className="w-full bg-code border border-border rounded-lg p-4 text-xs sm:text-sm leading-relaxed text-text overflow-auto font-mono max-h-[500px]">
        {jsonString}
      </pre>
    </div>
  );
};

export default Preview;