import React, { useEffect, useRef } from 'react';
import { EditorStatus } from '../types';
import { Code, Eye } from 'lucide-react';

interface PreviewProps {
  htmlContent: string;
  status: EditorStatus;
  onChange: (content: string) => void;
}

export const Preview: React.FC<PreviewProps> = ({ htmlContent, status, onChange }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [htmlContent, status]);

  if (status === EditorStatus.IDLE) {
    return (
        <div className="flex flex-col h-full items-center justify-center bg-slate-50/50 dark:bg-slate-900/50 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 text-slate-400 dark:text-slate-500 p-8">
            <Eye className="w-12 h-12 mb-3 opacity-20" />
            <p className="text-sm font-medium">Preview will appear here</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col bg-white dark:bg-slate-900 rounded-xl shadow-md border border-slate-300 dark:border-slate-800 overflow-hidden relative transition-colors duration-300">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
             <Code className="w-4 h-4" />
             <span>Master Prompt (Editable Text)</span>
        </div>
      </div>

      {/* Content */}
      <div className="relative bg-slate-50/30 dark:bg-slate-950/30 min-h-[300px]">
        {status === EditorStatus.LOADING && (
            <div className="absolute inset-0 z-10 bg-white/50 dark:bg-slate-900/50 backdrop-blur-[1px] flex items-center justify-center">
                 <div className="flex flex-col items-center animate-pulse">
                    <div className="h-4 w-3/4 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                    <div className="h-4 w-1/2 bg-slate-200 dark:bg-slate-700 rounded mb-2"></div>
                    <div className="h-4 w-5/6 bg-slate-200 dark:bg-slate-700 rounded"></div>
                 </div>
            </div>
        )}

        <textarea
            ref={textareaRef}
            className="w-full p-4 text-xs font-mono text-slate-700 dark:text-slate-300 bg-transparent border-none resize-none focus:ring-0 focus:outline-none leading-relaxed overflow-hidden"
            value={htmlContent}
            onChange={(e) => onChange(e.target.value)}
            spellCheck={false}
            placeholder="Generated prompt will appear here..."
            style={{ minHeight: '300px' }}
        />
      </div>
    </div>
  );
};

