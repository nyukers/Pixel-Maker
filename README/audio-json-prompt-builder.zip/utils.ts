export function getPath(obj: any, path: string): any {
  if (!obj) return undefined;
  const parts = path.split('.');
  let current = obj;
  for (const part of parts) {
    if (current == null || typeof current !== 'object') return undefined;
    current = current[part];
  }
  return current;
}

export function setPath(obj: any, path: string, value: any): void {
  const parts = path.split('.');
  let current = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (!(part in current) || typeof current[part] !== 'object') {
      current[part] = {};
    }
    current = current[part];
  }
  current[parts[parts.length - 1]] = value;
}

export function deepCopy<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

// Recursively clean object based on 'omitEmpty' setting
export function cleanObject(obj: any, omitEmpty: boolean): any {
  if (!omitEmpty) return obj;
  
  if (Array.isArray(obj)) {
    return obj.map(v => cleanObject(v, omitEmpty));
  }
  
  if (obj !== null && typeof obj === 'object') {
    const newObj: any = {};
    let hasKeys = false;
    for (const key in obj) {
      const val = cleanObject(obj[key], omitEmpty);
      if (val !== undefined && val !== "" && val !== null) {
        // Keep booleans (false is valid)
        if (typeof val === 'boolean' || (typeof val === 'string' && val.trim() !== '') || typeof val === 'number') {
           newObj[key] = val;
           hasKeys = true;
        } else if (typeof val === 'object' && Object.keys(val).length > 0) {
           newObj[key] = val;
           hasKeys = true;
        }
      }
    }
    return hasKeys ? newObj : undefined;
  }
  
  return obj;
}

export function prunePath(obj: any, path: string) {
  const parts = path.split('.');
  const [head, ...rest] = parts;
  if (!obj || !(head in obj)) return;

  if (rest.length === 0) {
    delete obj[head];
  } else {
    prunePath(obj[head], rest.join('.'));
    if (obj[head] && typeof obj[head] === 'object' && Object.keys(obj[head]).length === 0) {
      delete obj[head];
    }
  }
}

export function buildInitialData(schema: any[]): any {
  const data: any = {};
  schema.forEach(block => {
    const blockData: any = {};
    block.fields.forEach((f: any) => {
      setPath(blockData, f.path, f.default ?? (f.type === 'checkbox' ? false : ''));
    });
    data[block.name] = blockData;
  });
  return data;
}

export function buildInitialInclude(schema: any[]): any {
  const include: any = {};
  schema.forEach(block => {
    include[block.name] = block.defaultInclude ?? true;
  });
  return include;
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data url prefix (e.g. "data:image/jpeg;base64,")
      const base64 = result.split(',')[1]; 
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
}

function decodeBase64(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function playPcmAudio(base64: string, sampleRate: number = 24000) {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
  
  const audioData = decodeBase64(base64);
  const dataInt16 = new Int16Array(audioData.buffer);
  
  // We need to normalize Int16 to Float32 [-1.0, 1.0]
  const buffer = audioContext.createBuffer(1, dataInt16.length, sampleRate);
  const channelData = buffer.getChannelData(0);
  
  for (let i = 0; i < dataInt16.length; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  source.start();
  
  return source;
}
