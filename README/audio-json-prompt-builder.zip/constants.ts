import { SchemaBlock, StylePresetKey } from './types';

export const INITIAL_SCHEMA: SchemaBlock[] = [
  {
    name: "meta_data",
    title: "Meta Data",
    hint: "General track information, genre, tempo, and mood.",
    defaultInclude: true,
    highlight: true,
    fields: [
      { 
        path: "genre", 
        label: "Genre", 
        default: "lo-fi hip hop", 
        type: "select", 
        options: [
          "lo-fi hip hop", "cinematic score", "industrial techno", "ambient", 
          "guided meditation", "podcast intro", "jazz", "synthwave", 
          "classical", "rock", "trap", "drum and bass", "nature sounds", 
          "audiobook background", "pop", "r&b", "soul", "blues", "reggae", 
          "dubstep", "house", "deep house", "trance", "folk", "country", 
          "heavy metal", "punk", "disco", "funk", "gospel", "latin", 
          "world music", "experimental", "noise", "drone", "vaporwave", 
          "chiptune", "orchestral hybrid", "electro swing", "indie", 
          "alternative", "k-pop", "j-pop", "afrobeats", "grime", "hyperpop", "idm"
        ],
        help: "Main musical style" 
      },
      { 
        path: "tempo", 
        label: "Tempo", 
        default: "80 bpm", 
        type: "select", 
        options: [
          "very slow (< 60 bpm)", "slow (60-80 bpm)", "80 bpm", "moderate (90-110 bpm)", 
          "upbeat (120-130 bpm)", "fast (140+ bpm)", "free flow (no beat)", "variable"
        ],
        help: "Speed of the track" 
      },
      { 
        path: "mood", 
        label: "Mood", 
        default: "relaxing, nostalgic", 
        type: "select", 
        options: [
          "relaxing, nostalgic", "epic, dramatic", "dark, energetic", 
          "zen, spiritual", "upbeat, professional", "melancholic, sad", 
          "joyful, happy", "suspenseful, tense", "romantic, soft", "chaotic, aggressive"
        ],
        help: "Emotional quality" 
      },
      { 
        path: "duration", 
        label: "Duration", 
        default: "30 seconds", 
        type: "select",
        options: ["10 seconds", "30 seconds", "1 minute", "2 minutes", "loopable segment"] 
      },
      { 
        path: "key", 
        label: "Musical Key", 
        default: "C Major", 
        type: "select",
        options: ["C Major", "A Minor", "G Major", "E Minor", "F Major", "D Minor", "Chromatic", "Atonal / Experimental"] 
      }
    ]
  },
  {
    name: "speech",
    title: "Speech / Voice",
    hint: "Voiceover text, style, and language details.",
    defaultInclude: true,
    fields: [
      { path: "text", label: "Text Content", type: "textarea", default: "Welcome to the world of tranquility.", placeholder: "Text to be spoken..." },
      { path: "voice_style", label: "Voice Style", default: "deep male voice", type: "select", 
        options: ["deep male voice", "soft female whisper", "energetic announcer", "robotic synthesis", "childlike wonder", "news anchor", "movie trailer narrator", "meditation guide"] 
      },
      { path: "emotion", label: "Emotion", default: "calm", type: "select",
        options: ["calm", "excited", "sad", "angry", "mysterious", "joyful", "neutral", "whispering"]
      },
      { 
        path: "language", 
        label: "Language", 
        default: "English", 
        type: "select",
        options: ["English", "Ukrainian", "Spanish", "French", "German", "Japanese", "Multi-lingual"] 
      },
      { 
        path: "speed", 
        label: "Speech Speed", 
        default: "slow and deliberate", 
        type: "select",
        options: ["very slow", "slow and deliberate", "normal conversation", "fast", "rapid fire"] 
      }
    ]
  },
  {
    name: "layer_background",
    title: "Layer: Background",
    hint: "Ambient sounds, textures, and atmosphere.",
    defaultInclude: true,
    fields: [
      { path: "layer", label: "Layer Role", default: "background", type: "text", help: "Role of this layer (read-only recommended)" },
      { 
        path: "instrument", 
        label: "Instrument/Source", 
        default: "vinyl crackle", 
        type: "select",
        options: [
          "vinyl crackle", "rain on window", "city traffic", "forest nature", 
          "ocean waves", "orchestral strings swell", "factory drone", 
          "flowing water", "singing bowls", "acoustic guitar strumming", "white noise", "space hum"
        ]
      },
      { path: "volume", label: "Volume", default: "low", type: "select", options: ["silent", "low", "medium", "loud", "dominant"] },
      { 
        path: "panning", 
        label: "Panning", 
        default: "wide stereo", 
        type: "select",
        options: ["center", "wide stereo", "hard left", "hard right", "slow auto-pan", "binaural"] 
      }
    ]
  },
  {
    name: "layer_melody",
    title: "Layer: Melody",
    hint: "Main musical theme or lead instrument.",
    defaultInclude: true,
    fields: [
      { path: "layer", label: "Layer Role", default: "melody", type: "text" },
      { 
        path: "instrument", 
        label: "Instrument", 
        default: "soft piano", 
        type: "select",
        options: [
          "soft piano", "grand piano", "rhodes piano", "electric guitar", 
          "acoustic guitar", "synthesizer lead", "acid 303 bassline", 
          "brass section", "violin", "cello", "flute drone", "whistle melody", "8-bit chiptune"
        ] 
      },
      { path: "complexity", label: "Complexity", default: "simple", type: "select", options: ["minimal", "simple", "complex", "virtuoso", "arpeggiated"] },
      { 
        path: "timbre", 
        label: "Timbre", 
        default: "warm, felt-dampened", 
        type: "select",
        options: ["warm, felt-dampened", "bright, sharp", "distorted", "clean", "mellow", "metallic", "wooden", "reverberant"] 
      }
    ]
  },
  {
    name: "layer_rhythm",
    title: "Layer: Rhythm/Drums",
    hint: "Beats, percussion, and groove.",
    defaultInclude: false, 
    fields: [
      { path: "layer", label: "Layer Role", default: "percussion", type: "text" },
      { 
        path: "instrument", 
        label: "Kit Type", 
        default: "lo-fi drum kit", 
        type: "select",
        options: [
          "lo-fi drum kit", "808 trap kit", "909 drum machine", 
          "acoustic jazz kit", "rock kit", "orchestral percussion", 
          "hand drums", "shakers only", "glitch percussion"
        ] 
      },
      { 
        path: "pattern", 
        label: "Pattern", 
        default: "slow boom-bap", 
        type: "select",
        options: [
          "slow boom-bap", "four-on-the-floor", "breakbeat", 
          "waltz (3/4)", "syncopated", "minimal techno", "chaotic", "no beat"
        ] 
      },
      { 
        path: "groove", 
        label: "Groove", 
        default: "slightly off-grid, swing", 
        type: "select",
        options: ["slightly off-grid, swing", "machine tight (quantized)", "humanized", "heavy swing", "loose"] 
      }
    ]
  },
  {
    name: "sound_effects",
    title: "Sound Effects",
    hint: "Specific sound effects or foley additions.",
    defaultInclude: true,
    fields: [
      { 
        path: "type", 
        label: "Type", 
        default: "impact", 
        type: "select",
        options: ["impact", "transition", "foley", "ui sound", "ambient riser", "drop", "loop", "footsteps", "nature", "sci-fi"]
      },
      { 
        path: "description", 
        label: "Description", 
        default: "cinematic boom", 
        type: "textarea", 
        placeholder: "Describe the sound effect..." 
      },
      { 
        path: "duration", 
        label: "Duration", 
        default: "one-shot", 
        type: "select",
        options: ["one-shot", "short (< 2s)", "medium (2-5s)", "long (5s+)", "loop"]
      }
    ]
  },
  {
    name: "effects",
    title: "Global Effects",
    hint: "Master bus processing and spatial effects.",
    defaultInclude: true,
    fields: [
      { 
        path: "reverb", 
        label: "Reverb", 
        default: "large hall", 
        type: "select",
        options: ["none", "small room", "large hall", "massive cathedral", "infinite decay", "plate reverb", "spring reverb"] 
      },
      { 
        path: "compression", 
        label: "Compression", 
        default: "heavy sidechain", 
        type: "select",
        options: ["none", "light glue", "heavy sidechain", "broadcast ready", "dynamic", "crushed"] 
      },
      { 
        path: "eq_profile", 
        label: "EQ Profile", 
        default: "boosted lows, cut highs", 
        type: "select",
        options: ["flat", "boosted lows, cut highs", "high pass (thin)", "low pass (muffled)", "telephone effect", "v-shape"] 
      }
    ]
  }
];

export const STYLE_PRESETS: Record<string, any> = {
  none: {},
  lofi: {
    meta_data: { genre: "lo-fi hip hop", tempo: "80 bpm", mood: "relaxing, nostalgic" },
    layer_background: { instrument: "rain on window", volume: "medium" },
    layer_melody: { instrument: "rhodes piano", timbre: "warm, felt-dampened" },
    layer_rhythm: { instrument: "lo-fi drum kit", pattern: "slow boom-bap", groove: "slightly off-grid, swing" },
    effects: { eq_profile: "low pass (muffled)" }
  },
  cinematic: {
    meta_data: { genre: "cinematic score", tempo: "slow (60-80 bpm)", mood: "epic, dramatic" },
    speech: { voice_style: "movie trailer narrator", emotion: "mysterious" },
    layer_background: { instrument: "orchestral strings swell", volume: "loud" },
    layer_melody: { instrument: "brass section", complexity: "simple", timbre: "warm, felt-dampened" },
    effects: { reverb: "massive cathedral", compression: "dynamic" }
  },
  techno: {
    meta_data: { genre: "industrial techno", tempo: "fast (140+ bpm)", mood: "dark, energetic" },
    speech: { voice_style: "robotic synthesis", emotion: "neutral" },
    layer_background: { instrument: "factory drone", volume: "low" },
    layer_melody: { instrument: "acid 303 bassline", complexity: "complex" },
    layer_rhythm: { instrument: "909 drum machine", pattern: "four-on-the-floor", groove: "machine tight (quantized)" }
  },
  meditation: {
    meta_data: { genre: "guided meditation", tempo: "free flow (no beat)", mood: "zen, spiritual" },
    speech: { voice_style: "soft female whisper", emotion: "calm", speed: "very slow" },
    layer_background: { instrument: "flowing water", volume: "medium" },
    layer_melody: { instrument: "flute drone", complexity: "minimal" },
    effects: { reverb: "infinite decay" }
  },
  podcast: {
    meta_data: { genre: "podcast intro", tempo: "moderate (90-110 bpm)", mood: "upbeat, professional" },
    speech: { voice_style: "energetic announcer", emotion: "joyful" },
    layer_background: { instrument: "acoustic guitar strumming", volume: "medium" },
    layer_melody: { instrument: "whistle melody", complexity: "simple" },
    effects: { compression: "broadcast ready" }
  }
};