import { GoogleGenAI, Modality } from "@google/genai";
import { SchemaBlock, PromptData } from "../types";

const API_KEY = process.env.API_KEY || '';

const getAiClient = () => new GoogleGenAI({ apiKey: API_KEY });

export async function generatePromptDataWithGemini(
  schema: SchemaBlock[],
  userDescription: string,
  imageBase64?: string,
  mimeType: string = 'image/jpeg'
): Promise<PromptData | null> {
  if (!API_KEY) {
    console.warn("No API Key available");
    return null;
  }

  const ai = getAiClient();
  const model = "gemini-2.5-flash"; 

  // Pass only necessary schema info to save tokens, but INCLUDE OPTIONS
  const simplifiedSchema = schema.map(block => ({
    name: block.name,
    fields: block.fields.map(f => ({ 
      path: f.path, 
      type: f.type, 
      label: f.label, 
      options: f.options, // Critical: AI needs to see the allowed values
      description: f.help 
    }))
  }));

  // Updated instruction for AUDIO generation with STRICT selection rules
  const systemInstruction = `
    You are an expert Audio Engineer, Music Producer, and Sound Designer.
    Your goal is to populate a JSON structure for an AI AUDIO generation prompt.
    
    You will be provided with:
    1. A Schema (list of blocks and fields with allowed OPTIONS).
    2. A User Description OR an Input Image (or both).
    
    Rules:
    1. **Return ONLY valid JSON.** No markdown, no comments.
    2. Top-level keys must match the block names (e.g., "meta_data", "speech").
    3. **STRICT OPTION SELECTION**: If a field has an 'options' array in the schema, you MUST choose one of those exact strings. Do not invent new values for dropdown fields.
    4. **Image Analysis (Synesthesia)**: 
       - If an image is provided, "listen" to it. Convert visual mood to audio parameters.
       - Dark/Neon -> Techno/Synthwave. 
       - Nature/Green -> Ambient/Nature sounds.
       - Rainy/Grey -> Lo-fi/Jazz.
    5. **Text Analysis**: Convert abstract descriptions (e.g., "scary") into technical parameters (e.g., "Key: Atonal", "Effects: Large Reverb").
    6. Fill as many fields as logical based on the context.
  `;

  const schemaContext = `
    Schema Definition:
    ${JSON.stringify(simplifiedSchema, null, 2)}
  `;

  const promptText = imageBase64 
    ? `Task: Analyze this image and generate the audio parameters (soundtrack/ambience) that best fit this scene. \n${userDescription ? `User Context: ${userDescription}` : ''}`
    : `Task: Generate the filled JSON audio parameters based on this description: "${userDescription}".`;

  const parts: any[] = [
    { text: schemaContext },
    { text: promptText }
  ];

  if (imageBase64) {
    parts.unshift({
      inlineData: {
        mimeType: mimeType,
        data: imageBase64
      }
    });
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) return null;

    return JSON.parse(text) as PromptData;
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
}

export async function generateSpeech(text: string, voice: string = 'Kore', emotion?: string, speed?: string, language: string = 'English'): Promise<string | null> {
  if (!API_KEY) return null;
  const ai = getAiClient();
  
  // Explicitly prompt the model to speak in the requested language
  const promptText = `Speak the following text in ${language}. Tone: ${emotion || 'neutral'}. Speed: ${speed || 'normal'}. Text: "${text}"`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: promptText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64 || null;
  } catch (error) {
    console.error("TTS Generation Error:", error);
    return null;
  }
}