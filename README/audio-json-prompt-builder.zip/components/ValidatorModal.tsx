import React, { useState, useRef } from 'react';
import { X, CheckCircle, AlertTriangle, FileJson, Upload, Eraser } from 'lucide-react';

interface ValidatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ValidatorModal: React.FC<ValidatorModalProps> = ({ isOpen, onClose }) => {
  const [jsonInput, setJsonInput] = useState('');
  const [result, setResult] = useState<{ valid: boolean; message: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const validate = (text: string) => {
    if (!text.trim()) {
      setResult(null);
      return;
    }
    try {
      JSON.parse(text);
      setResult({ valid: true, message: "Valid JSON! Structure is correct." });
    } catch (e: any) {
      setResult({ valid: false, message: e.message });
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setJsonInput(e.target.value);
    // Reset result on type to avoid stale state, or validate on type? 
    // Let's reset to encourage pressing "Check" or we can live validate.
    // Live validation might be annoying if typing large blobs. Let's keep manual check or validate on finish.
    // For now, simple clear result.
    setResult(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setJsonInput(text);
      validate(text);
    };
    reader.readAsText(file);
    // Reset input so same file can be selected again if needed
    e.target.value = '';
  };

  const handleClear = () => {
    setJsonInput('');
    setResult(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-panel border border-border rounded-2xl w-full max-w-2xl shadow-2xl scale-100 animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex justify-between items-center p-5 border-b border-border">
          <div className="flex items-center gap-2 text-accent">
            <FileJson size={20} />
            <h3 className="font-semibold text-text">JSON Validator</h3>
          </div>
          <button onClick={onClose} className="text-muted hover:text-text transition-colors">
            <X size={20} />
          </button>
        </div>
        
        {/* Content */}
        <div className="p-5 flex flex-col gap-4 flex-1 overflow-hidden">
          <p className="text-sm text-muted">
            Paste JSON code below or upload a file to check for syntax errors.
          </p>
          
          <div className="relative flex-1 min-h-[200px]">
            <textarea
              value={jsonInput}
              onChange={handleChange}
              placeholder='{ "key": "value" }'
              className={`w-full h-full bg-code text-text font-mono text-sm rounded-lg p-4 border focus:outline-none resize-none ${
                result 
                  ? result.valid 
                    ? 'border-accent/50 focus:border-accent' 
                    : 'border-danger/50 focus:border-danger'
                  : 'border-border focus:border-accent'
              }`}
              spellCheck={false}
            />
          </div>

          {/* Result Alert */}
          {result && (
            <div className={`p-3 rounded-lg border flex items-start gap-3 text-sm ${
              result.valid 
                ? 'bg-accent/10 border-accent/30 text-accent' 
                : 'bg-danger/10 border-danger/30 text-danger'
            }`}>
              {result.valid ? <CheckCircle size={18} className="mt-0.5 shrink-0" /> : <AlertTriangle size={18} className="mt-0.5 shrink-0" />}
              <div>
                <p className="font-bold">{result.valid ? "Valid JSON" : "Invalid JSON"}</p>
                <p className="opacity-90 font-mono mt-1 break-all">{result.message}</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-5 border-t border-border flex flex-wrap justify-between items-center gap-4 bg-panel2/50 rounded-b-2xl">
           <div className="flex gap-2">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                accept=".json,.txt" 
                className="hidden" 
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-3 py-2 rounded-lg bg-panel border border-border text-sm font-medium text-muted hover:text-text hover:border-muted transition-colors"
              >
                <Upload size={16} /> Upload File
              </button>
              
              {jsonInput && (
                <button 
                  onClick={handleClear}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-panel border border-border text-sm font-medium text-muted hover:text-danger hover:border-danger transition-colors"
                >
                  <Eraser size={16} /> Clear
                </button>
              )}
           </div>

           <div className="flex gap-3">
              <button 
                onClick={onClose} 
                className="px-4 py-2 text-sm font-medium text-muted hover:text-text"
              >
                Close
              </button>
              <button 
                onClick={() => validate(jsonInput)}
                disabled={!jsonInput.trim()}
                className="flex items-center gap-2 px-6 py-2 rounded-full bg-accent text-panel2 font-bold hover:brightness-110 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <CheckCircle size={16} />
                Validate
              </button>
           </div>
        </div>

      </div>
    </div>
  );
};

export default ValidatorModal;