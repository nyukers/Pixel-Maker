import React, { useState } from 'react';
import { Copy, Download, Check } from 'lucide-react';

interface PreviewProps {
  json: object;
  isValid: boolean;
}

const Preview: React.FC<PreviewProps> = ({ json, isValid }) => {
  const [copied, setCopied] = useState(false);
  const jsonString = JSON.stringify(json, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "prompt.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <aside className="bg-panel2 border border-border rounded-xl p-4 flex flex-col gap-4 shadow-glow h-fit sticky top-6 max-h-[calc(100vh-48px)]">
      <div className="flex justify-between items-center pb-2 border-b border-border">
        <h2 className="text-lg font-semibold tracking-tight text-text">Resulting JSON</h2>
        <div className="flex gap-2">
          <button 
            onClick={handleCopy}
            disabled={!isValid}
            className="p-1.5 text-muted hover:text-accent border border-border bg-panel hover:bg-panel2 rounded-lg transition-all disabled:opacity-50"
            title="Copy to Clipboard"
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button 
            onClick={handleDownload}
            disabled={!isValid}
            className="p-1.5 text-muted hover:text-accent border border-border bg-panel hover:bg-panel2 rounded-lg transition-all disabled:opacity-50"
            title="Download JSON"
          >
            <Download size={16} />
          </button>
        </div>
      </div>
      
      <pre className="flex-1 bg-code border border-border rounded-lg p-3 text-xs leading-relaxed text-text overflow-auto font-mono">
        {jsonString}
      </pre>

      <div className={`text-xs px-3 py-2 rounded-lg border ${isValid ? 'bg-accent/10 border-accent/30 text-text' : 'bg-danger/10 border-danger/30 text-danger'}`}>
        {isValid ? "Ready. Blocks included." : "Nothing included yet. Enable a block."}
      </div>
    </aside>
  );
};

export default Preview;
