import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { SchemaBlock, PromptData, PromptInclude, AppSettings, PresetKey } from './types';
import { INITIAL_SCHEMA, STYLE_PRESETS } from './constants';
import { getPath, setPath, deepCopy, cleanObject, prunePath, buildInitialData, buildInitialInclude, playPcmAudio } from './utils';
import { useHistory } from './hooks/useHistory';
import BlockCard from './components/BlockCard';
import Preview from './components/Preview';
import MagicModal from './components/MagicModal';
import ValidatorModal from './components/ValidatorModal';
import { generatePromptDataWithGemini, generateSpeech } from './services/geminiService';
import { Sparkles, Plus, RefreshCw, Code, FileCheck, Undo2, Redo2, Music, Mic } from 'lucide-react';

interface AppState {
  schema: SchemaBlock[];
  data: PromptData;
  include: PromptInclude;
  preset: PresetKey;
  settings: AppSettings;
}

const INITIAL_STATE: AppState = {
  schema: deepCopy(INITIAL_SCHEMA),
  data: buildInitialData(INITIAL_SCHEMA),
  include: buildInitialInclude(INITIAL_SCHEMA),
  preset: 'sample',
  settings: {
    includeMap: false,
    omitEmpty: true,
    schemaMode: false,
  }
};

function App() {
  const { state, set, undo, redo, canUndo, canRedo } = useHistory<AppState>(INITIAL_STATE);
  const { schema, data, include, settings, preset: currentPreset } = state;

  const [magicModalOpen, setMagicModalOpen] = useState(false);
  const [validatorModalOpen, setValidatorModalOpen] = useState(false);
  
  const lastUpdateRef = useRef<{ path: string, time: number } | null>(null);

  // --- Logic to transform flat blocks into specific Audio JSON structure ---
  const finalJson = useMemo(() => {
    const output: any = {
      request_type: "audio_generation"
    };

    const audioLayers: any[] = [];
    const activeInclude: any = {};

    schema.forEach(block => {
      if (include[block.name]) {
        // Deep copy and clean
        let blockData = deepCopy(data[block.name] || {});
        if (settings.omitEmpty) {
            blockData = cleanObject(blockData, true);
        }

        if (blockData && Object.keys(blockData).length > 0) {
          activeInclude[block.name] = true;

          // Special handling for Layers -> Array
          if (block.name.startsWith('layer_')) {
            audioLayers.push(blockData);
          } else {
            // Normal blocks (meta_data, speech, etc.)
            output[block.name] = blockData;
          }
        }
      }
    });

    if (audioLayers.length > 0) {
      output.audio_layers = audioLayers;
    }

    if (settings.includeMap) {
      output._meta_debug = { included_blocks: activeInclude };
    }

    return output;
  }, [schema, data, include, settings]);

  const hasIncludedBlocks = Object.keys(finalJson).length > 1; // >1 because request_type is always there

  // --- Actions & History ---

  const handleUndo = useCallback(() => {
    undo();
    lastUpdateRef.current = null;
  }, [undo]);

  const handleRedo = useCallback(() => {
    redo();
    lastUpdateRef.current = null;
  }, [redo]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      }
      if ((e.metaKey || e.ctrlKey) && ((e.key.toLowerCase() === 'z' && e.shiftKey) || e.key.toLowerCase() === 'y')) {
        e.preventDefault();
        handleRedo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  const handleUpdateData = (blockName: string, path: string, value: any) => {
    const fullPath = `${blockName}.${path}`;
    const now = Date.now();
    const isRapidUpdate = lastUpdateRef.current 
      && lastUpdateRef.current.path === fullPath 
      && (now - lastUpdateRef.current.time < 1000);

    lastUpdateRef.current = { path: fullPath, time: now };

    set(prev => {
      const nextData = deepCopy(prev.data);
      if (!nextData[blockName]) nextData[blockName] = {};
      setPath(nextData[blockName], path, value);
      return { ...prev, data: nextData, preset: 'custom' };
    }, { replace: isRapidUpdate });
  };

  const handleUpdateInclude = (blockName: string, val: boolean) => {
    set(prev => ({
      ...prev,
      include: { ...prev.include, [blockName]: val },
      preset: 'custom'
    }));
  };

  const handlePresetChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const key = e.target.value as PresetKey;
    set(prev => {
      if (key === 'blank') {
         const blankData: any = {};
         prev.schema.forEach(block => {
           blankData[block.name] = {};
           block.fields.forEach(field => {
              setPath(blankData[block.name], field.path, field.type === 'checkbox' ? false : '');
           });
         });
         return {
           ...prev,
           preset: 'blank',
           data: blankData,
           include: buildInitialInclude(prev.schema)
         };
      } else if (key === 'sample') {
         return {
           ...prev,
           preset: 'sample',
           schema: deepCopy(INITIAL_SCHEMA),
           data: buildInitialData(INITIAL_SCHEMA),
           include: buildInitialInclude(INITIAL_SCHEMA)
         };
      }
      return { ...prev, preset: key };
    });
  };

  const handleStylePreset = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const key = e.target.value;
    if (key === 'none') return;
    const presetData = STYLE_PRESETS[key];
    if (!presetData) return;
    
    set(prev => {
      const nextData = deepCopy(prev.data);
      const nextInclude = { ...prev.include };

      Object.keys(presetData).forEach(blockName => {
        if (!nextData[blockName]) nextData[blockName] = {};
        const flatten = (obj: any, prefix: string) => {
          Object.keys(obj).forEach(k => {
            const val = obj[k];
            const path = prefix ? `${prefix}.${k}` : k;
            if (val && typeof val === 'object' && !Array.isArray(val)) {
               flatten(val, path);
            } else {
               setPath(nextData[blockName], path, val);
            }
          });
        };
        flatten(presetData[blockName], '');
        nextInclude[blockName] = true;
      });

      return { ...prev, data: nextData, include: nextInclude, preset: 'custom' };
    });
    e.target.value = 'none';
  };

  const handleSettingsChange = (key: keyof AppSettings, val: boolean) => {
    set(prev => ({ ...prev, settings: { ...prev.settings, [key]: val } }));
  };

  // --- Schema Actions ---

  const addBlock = () => {
    const nameInput = prompt("Block key (e.g. 'layer_synth', 'effects'):");
    if (!nameInput) return;
    const name = nameInput.trim().toLowerCase().replace(/\s+/g, '_');
    
    if (schema.find(b => b.name === name)) {
      alert("Block name already exists!");
      return;
    }
    const title = prompt("Block title:", name) || name;
    
    const newBlock: SchemaBlock = {
      name,
      title,
      hint: "Custom audio block",
      defaultInclude: true,
      fields: []
    };
    
    set(prev => ({
      ...prev,
      schema: [...prev.schema, newBlock],
      include: { ...prev.include, [name]: true },
      data: { ...prev.data, [name]: {} },
      preset: 'custom'
    }));
  };

  const duplicateBlock = (block: SchemaBlock) => {
    const baseName = block.name;
    let counter = 2;
    let newName = `${baseName}_${counter}`;
    while (schema.find(b => b.name === newName)) {
      counter++;
      newName = `${baseName}_${counter}`;
    }

    set(prev => {
      const newBlock = { ...block, name: newName, title: `${block.title} copy` };
      const newBlockIdx = prev.schema.findIndex(b => b.name === block.name) + 1;
      const newSchema = [...prev.schema];
      newSchema.splice(newBlockIdx, 0, newBlock);

      return {
        ...prev,
        schema: newSchema,
        include: { ...prev.include, [newName]: prev.include[block.name] },
        data: { ...prev.data, [newName]: deepCopy(prev.data[block.name] || {}) },
        preset: 'custom'
      };
    });
  };

  const deleteBlock = (name: string) => {
    if (schema.length <= 1) { alert("Keep at least one block."); return; }
    if (!confirm(`Delete block '${name}'?`)) return;
    set(prev => {
      const nextData = deepCopy(prev.data);
      const nextInclude = { ...prev.include };
      delete nextData[name];
      delete nextInclude[name];
      return {
        ...prev,
        schema: prev.schema.filter(b => b.name !== name),
        data: nextData,
        include: nextInclude,
        preset: 'custom'
      };
    });
  };

  const addField = (blockName: string) => {
    const path = prompt("Field path:", "new_param");
    if (!path) return;
    const label = prompt("Label:", path) || path;
    const type = prompt("Type (text/select/number):", "text") || "text";
    
    set(prev => ({
      ...prev,
      schema: prev.schema.map(b => {
        if (b.name === blockName) {
          return {
            ...b,
            fields: [...b.fields, { path, label, type: type as any, default: '' }]
          };
        }
        return b;
      }),
      preset: 'custom'
    }));
  };

  const removeField = (blockName: string, path: string) => {
    if (!confirm(`Remove field '${path}'?`)) return;
    set(prev => {
      const nextData = deepCopy(prev.data);
      if (nextData[blockName]) prunePath(nextData[blockName], path);
      return {
        ...prev,
        schema: prev.schema.map(b => {
          if (b.name === blockName) return { ...b, fields: b.fields.filter(f => f.path !== path) };
          return b;
        }),
        data: nextData,
        preset: 'custom'
      };
    });
  };

  const moveField = (blockName: string, fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return;
    set(prev => ({
      ...prev,
      schema: prev.schema.map(b => {
        if (b.name === blockName) {
          const newFields = [...b.fields];
          const [movedField] = newFields.splice(fromIndex, 1);
          newFields.splice(toIndex, 0, movedField);
          return { ...b, fields: newFields };
        }
        return b;
      }),
      preset: 'custom'
    }));
  };

  const handleMagicGenerate = async (description: string, imageBase64?: string, mimeType?: string) => {
    try {
      const generatedData = await generatePromptDataWithGemini(schema, description, imageBase64, mimeType);
      if (generatedData) {
        set(prev => {
          const nextData = deepCopy(prev.data);
          const nextInclude = { ...prev.include };
          Object.keys(generatedData).forEach(blockName => {
            if (prev.schema.some(b => b.name === blockName)) {
              nextData[blockName] = generatedData[blockName];
              nextInclude[blockName] = true;
            }
          });
          return { ...prev, data: nextData, include: nextInclude, preset: 'custom' };
        });
      }
    } catch (e) {
      alert("AI Generation failed. Check API Key.");
    }
  };

  const handleSynthesize = async (text: string, voice: string, emotion?: string, speed?: string, language?: string) => {
    const base64 = await generateSpeech(text, voice, emotion, speed, language);
    if (base64) {
      await playPcmAudio(base64);
    } else {
      alert("Failed to synthesize audio.");
    }
  };

  return (
    <div className="min-h-screen pb-12">
      <MagicModal isOpen={magicModalOpen} onClose={() => setMagicModalOpen(false)} onGenerate={handleMagicGenerate} />
      <ValidatorModal isOpen={validatorModalOpen} onClose={() => setValidatorModalOpen(false)} />

      <div className="max-w-[1400px] mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6">
        
        {/* Header */}
        <header className="bg-gradient-to-br from-panel/90 to-panel2/95 border border-border rounded-3xl p-6 sm:p-8 shadow-glow backdrop-blur-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
          
          <div className="relative z-10">
            <p className="text-xs font-bold tracking-widest text-muted uppercase mb-2">Google Gemini • Audio Engine • (C) Nyukers, 2026</p>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-text mb-2 flex items-center gap-3">
              <Music className="text-accent" size={40} />
              Audio JSON Prompt Builder
            </h1>
            <p className="text-muted max-w-2xl leading-relaxed mb-6">
              Design complex soundscapes and music generation prompts.
              Use <span className="text-accent font-medium">Gemini AI</span> to convert images or descriptions into structured audio parameters.
            </p>

            <div className="flex flex-col xl:flex-row gap-4 xl:items-center justify-between">
              
              {/* Controls */}
              <div className="flex flex-wrap items-center gap-3">
                 <div className="flex items-center gap-2 bg-panel2 border border-border rounded-lg px-3 py-2">
                   <span className="text-xs text-muted">Genre</span>
                   <select className="bg-transparent text-sm font-semibold text-text focus:outline-none cursor-pointer min-w-[140px]" onChange={handleStylePreset}>
                     <option className="bg-panel2" value="none">Select Genre...</option>
                     <option className="bg-panel2" value="lofi">Lo-Fi Hip Hop</option>
                     <option className="bg-panel2" value="cinematic">Cinematic / Trailer</option>
                     <option className="bg-panel2" value="techno">Industrial Techno</option>
                     <option className="bg-panel2" value="meditation">Meditation / Ambient</option>
                     <option className="bg-panel2" value="podcast">Podcast Intro</option>
                   </select>
                 </div>

                 <div className="h-6 w-px bg-border mx-1 hidden sm:block"></div>

                 <label className="flex items-center gap-2 text-sm text-muted cursor-pointer select-none">
                    <input type="checkbox" checked={settings.omitEmpty} onChange={(e) => handleSettingsChange('omitEmpty', e.target.checked)} className="w-4 h-4 rounded accent-accent bg-code border-border" />
                    Skip empty
                 </label>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1 bg-panel2 border border-border rounded-full p-1 mr-2">
                  <button onClick={handleUndo} disabled={!canUndo} className="p-2 rounded-full text-muted hover:text-text hover:bg-panel transition-all disabled:opacity-30"><Undo2 size={16} /></button>
                  <button onClick={handleRedo} disabled={!canRedo} className="p-2 rounded-full text-muted hover:text-text hover:bg-panel transition-all disabled:opacity-30"><Redo2 size={16} /></button>
                </div>

                <button onClick={() => setValidatorModalOpen(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-panel2 border border-border text-muted font-bold hover:text-text hover:border-accent transition-all">
                  <FileCheck size={16} /> Validate JSON
                </button>
                
                 <label className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-medium cursor-pointer transition-all ${settings.schemaMode ? 'bg-accent/10 border-accent text-accent' : 'bg-transparent border-border text-muted hover:border-muted'}`}>
                    <input type="checkbox" checked={settings.schemaMode} onChange={(e) => handleSettingsChange('schemaMode', e.target.checked)} className="hidden" />
                    <Code size={16} /> Edit Schema
                 </label>

                <button onClick={() => setMagicModalOpen(true)} className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-accent text-panel2 font-bold shadow-accent hover:brightness-110 transition-all">
                  <Sparkles size={16} /> AI Auto-Fill
                </button>
              </div>
            </div>
            
            {settings.schemaMode && (
               <div className="mt-4 pt-4 border-t border-border flex gap-3">
                  <button onClick={addBlock} className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-accent hover:text-white transition-colors">
                    <Plus size={14} /> Add Block
                  </button>
                  <button onClick={() => { if(confirm("Reset schema?")) set({ ...INITIAL_STATE, schema: deepCopy(INITIAL_SCHEMA), data: buildInitialData(INITIAL_SCHEMA), include: buildInitialInclude(INITIAL_SCHEMA) }); }} className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted hover:text-danger transition-colors ml-auto">
                    <RefreshCw size={14} /> Reset
                  </button>
               </div>
            )}
          </div>
        </header>

        {/* Builder */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-6">
             {/* CHANGED to flex-col/single column to make cards wide */}
             <div className="flex flex-col gap-4"> 
               {schema.map(block => (
                 <BlockCard
                   key={block.name}
                   block={block}
                   data={data[block.name]}
                   include={!!include[block.name]}
                   schemaMode={settings.schemaMode}
                   onUpdateInclude={(val) => handleUpdateInclude(block.name, val)}
                   onUpdateData={(path, val) => handleUpdateData(block.name, path, val)}
                   onDuplicateBlock={() => duplicateBlock(block)}
                   onDeleteBlock={() => deleteBlock(block.name)}
                   onAddField={() => addField(block.name)}
                   onRemoveField={(path) => removeField(block.name, path)}
                   onMoveField={(from, to) => moveField(block.name, from, to)}
                   onSynthesizeSpeech={handleSynthesize}
                 />
               ))}
             </div>
          </div>
          <div className="lg:col-span-5 xl:col-span-4">
             <Preview json={finalJson} isValid={hasIncludedBlocks} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;