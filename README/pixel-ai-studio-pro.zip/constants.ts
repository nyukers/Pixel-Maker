
import { PresetPrompt } from "./types";

export const STICKER_SUBJECTS = [
    "a grumpy cat drinking coffee",
    "a skateboarding t-rex", 
    "a cute robot holding a flower",
    "a muscular hamster",
    "a wizard frog with a tiny staff",
    "a cyberpunk corgi with neon goggles",
    "a melting ice cream cone with a face",
    "a ninja slice of pepperoni pizza",
    "a meditating sloth floating on a cloud",
    "a rockstar unicorn playing electric guitar",
    "a happy avocado waving hello",
    "a space-faring octopus",
    "a detective raccoon with a magnifying glass",
    "a ghost reading a book",
    "a pixel art dragon"
];

export const TATTOO_SUBJECTS = [
    "a fierce tiger face",
    "a geometric wolf head",
    "a traditional red rose with thorns",
    "a japanese koi fish swimming upstream",
    "a vintage nautical anchor",
    "a celestial sun and moon composition",
    "a detailed human skull with flowers",
    "a majestic eagle in flight",
    "a coiled snake ready to strike",
    "a minimalist mountain landscape",
    "an ornate compass",
    "a wise owl sitting on a branch",
    "a mythical dragon wrapping around a sword",
    "a delicate butterfly with intricate wings",
    "a phoenix rising from ashes"
];

export const MYSTICAL_TATTOO_SUBJECTS = [
    "a femme fatale with sugar skull makeup holding a smoking gun",
    "a skull wearing a fedora surrounded by playing cards",
    "a roaring lion fading into smoke and geometric lines",
    "an antique pocket watch tangled in rose thorns",
    "a masked bandit girl with flowing hair",
    "a grim reaper hand holding a royal flush",
    "a realistic eye crying diamonds",
    "a broken statue face with gold kintsugi cracks",
    "a raven perched on a skull with a clock eye",
    "a burning stack of vintage money turning into ash",
    "a crying angel with broken wings",
    "two drama masks laughing and crying in smoke",
    "a revolver with roses growing out of the barrel",
    "a pair of dice showing snake eyes on fire",
    "a crown of thorns bleeding ink"
];

export const COLOR_TATTOO_SUBJECTS = [
    "a japanese koi fish swimming in water",
    "a blooming peony flower with leaves",
    "a fierce tiger head with glowing eyes",
    "a peacock feather with intricate details",
    "an ornate hourglass with golden sand",
    "a vintage lantern emitting light",
    "a ship sailing inside a glass bottle",
    "a dagger piercing a red heart",
    "a coiled snake protecting a gemstone",
    "a red fox portrait with flowers",
    "a large emperor moth",
    "a cluster of glowing crystals",
    "an anatomical heart with geometric shapes",
    "a wolf head with a floral headdress",
    "a swallow bird carrying a letter"
];

export const EDGY_STICKER_SUBJECTS = [
    "a classic pin-up girl sitting on a bomb",
    "a skull wearing aviator sunglasses and smoking",
    "a vintage microphone with red roses",
    "a retro cocktail glass with a neon sign",
    "a snarling panther head in old school style",
    "a switchblade knife with a heart handle",
    "a pair of red dice showing snake eyes",
    "a broken vinyl record with lightning bolts",
    "a 'Mom' heart tattoo style with a dagger",
    "a classic muscle car engulfed in flames",
    "a hand holding a ace of spades card",
    "a retro robot with a rebellious attitude",
    "a vintage cassette tape with tangled tape",
    "a crying eye in pop-art style",
    "a black cat with devil horns"
];

export const TAROT_SUBJECTS = [
    "The Fool", "The Magician", "The High Priestess", "The Empress", "The Emperor",
    "The Hierophant", "The Lovers", "The Chariot", "Strength", "The Hermit",
    "Wheel of Fortune", "Justice", "The Hanged Man", "Death", "Temperance",
    "The Devil", "The Tower", "The Star", "The Moon", "The Sun",
    "Judgement", "The World"
];

export const TAROT_STYLE_ARTISTS = [
    // Art Nouveau & Decorative
    "Alphonse Mucha", "Gustav Klimt", "Aubrey Beardsley", "Harry Clarke", "Louis Comfort Tiffany",
    
    // Surrealism & Fantasy
    "Salvador Dalí", "René Magritte", "H.R. Giger", "Zdzisław Beksiński", "Moebius", "Yoshitaka Amano", "Frank Frazetta", "Boris Vallejo", "M.C. Escher", "Remedios Varo", "Greg Rutkowski",
    
    // Classic & Renaissance
    "Leonardo da Vinci", "Michelangelo", "Sandro Botticelli", "Caravaggio", "Hieronymus Bosch", "Albrecht Dürer", "Rembrandt", "Francisco Goya", "El Greco", "William Blake", "Gustave Doré",
    
    // Impressionism & Expressionism
    "Vincent van Gogh", "Claude Monet", "Egon Schiele", "Edvard Munch", "Frida Kahlo",
    
    // Modern & Abstract
    "Pablo Picasso", "Wassily Kandinsky", "Piet Mondrian", "Andy Warhol", "Jean-Michel Basquiat", "Keith Haring",
    
    // Japanese Ukiyo-e
    "Katsushika Hokusai", "Utagawa Hiroshige", "Tsukioka Yoshitoshi",
    
    // Illustration & Gothic
    "Tim Burton", "Edward Gorey", "Arthur Rackham", "Kay Nielsen", "Norman Rockwell", "Beatrix Potter", "Tove Jansson"
];

export const PLAYING_CARD_RANKS = [
    { name: "Ace", initial: "A" },
    { name: "King", initial: "K" },
    { name: "Queen", initial: "Q" },
    { name: "Jack", initial: "J" },
    { name: "10", initial: "10" },
    { name: "9", initial: "9" },
    { name: "8", initial: "8" },
    { name: "7", initial: "7" },
    { name: "6", initial: "6" },
    { name: "5", initial: "5" },
    { name: "4", initial: "4" },
    { name: "3", initial: "3" },
    { name: "2", initial: "2" }
];

export const PLAYING_CARD_SUITS = [
    { name: "Hearts", symbol: "♥" },
    { name: "Diamonds", symbol: "♦" },
    { name: "Clubs", symbol: "♣" },
    { name: "Spades", symbol: "♠" }
];

export const PRESET_PROMPT_DISPLAY_NAMES: Record<string, string> = {
    retouch_remove_background: 'Remove Background',
    retouch_remove_background_ext: 'Remove Background Ext',
    retouch_brighten: 'Brighten & Contrast',
    retouch_colorize: 'Colorize',
    retouch_enhance_clarity: 'Enhance Clarity',
    retouch_fix_damage: 'Fix Damage',
    retouch_improve_skin: 'Improve Skin',
    retouch_remove_dust: 'Remove Dust & Scratches',
    retouch_remove_frame: 'Remove Frame & Repair Edges',
    retouch_remove_noise: 'Remove Noise & Grain',
    retouch_base: 'Basic Retouch',
    retouch_old_photo_restoration: 'Old Photo Restoration',
    retouch_restore_colors: 'Restore Colors',
    retouch_sharpen: 'Restore & Sharpen',
    retouch_soft_focus: 'Soft Focus Effect',
    retouch_lighting_dramatic_studio: 'Dramatic Studio Lighting',
    retouch_lighting_golden_hour: 'Golden Hour Lighting',
    retouch_lighting_soft_window: 'Soft Window Light',
    retouch_lighting_cinematic_moody: 'Moody Cinematic Lighting',
    retouch_lighting_balanced: 'Balance Lighting',
    retouch_lighting_neon_glow: 'Neon Glow',
    retouch_bokeh: 'AI Portrait Bokeh',
    imagination_art_deco: '1920s Art Deco Fashion',
    imagination_pinup_1950s: '1950s Pin-up Fashion',
    imagination_rustic_cabin: 'Rustic Cabin Scene',
    imagination_cyberpunk: 'Cyberpunk Gear',
    imagination_fantasy_forest: 'Fantastical Forest',
    imagination_film_noir: 'Film Noir Scene',
    imagination_futuristic_city: 'Futuristic City',
    imagination_ancient_jungle: 'Ancient Jungle Explorer',
    imagination_medieval: 'Medieval Royal Attire',
    imagination_studio_portrait: 'Modern Studio Portrait',
    imagination_steampunk: 'Steampunk City',
    imagination_sunny_beach: 'Sunny Beach Sunset',
    imagination_zen_garden: 'Zen Garden',
    imagination_paint_by_numbers: 'Paint by Numbers (beta)',
    imagination_festive_christmas: '* Festive Christmas',
    imagination_christmas_ornament: '* Christmas Ornament',
    imagination_spooky_halloween: '* Spooky Halloween',
    imagination_valentines_romance: '* Valentine\'s Romance',
    imagination_dia_de_muertos: '* El Día de Muertos',
    imagination_graffiti_art: 'Urban Graffiti Art',
    imagination_stereogram: '3D Magic Eye (SIRDS)',
    imagination_anaglyph_3d: '3D Anaglyph',
    imagination_atmospheric_fog: 'Atmospheric Fog',
    animation_dolly_zoom: 'Dolly Zoom',
    animation_gentle_sway: 'Gentle Sway',
    animation_gentle_zoom_in: 'Gentle Zoom In',
    animation_gentle_zoom_out: 'Gentle Zoom Out',
    animation_pan_left_right: 'Pan Left to Right',
    animation_pan_up_down: 'Pan Up to Down',
    animation_parallax: 'Parallax Effect',
    animation_autumn_leaves: 'Falling Autumn Leaves',
    animation_falling_snow: 'Falling Snow',
    animation_flickering_fire: 'Flickering Fire',
    animation_rippling_water: 'Rippling Water',
    animation_rising_steam: 'Rising Steam',
    animation_shimmer: 'Shimmering Lights',
    animation_windy_day: 'Windy Day',
    animation_wiggle_3d: '3D Wiggle (Depth Loop)',
    generate_photorealistic_cat: 'Photorealistic Cat',
    generate_surreal_landscape: 'Surreal Landscape',
    generate_cyberpunk_city: 'Cyberpunk Cityscape',
    generate_vintage_botanical: 'Vintage Botanical Illustration',
    generate_abstract_emotion: 'Abstract Joy',
    generate_fantasy_knight: 'Elven Knight Portrait',
    generate_sticker_design: 'Sticker Vector Design (Random)',
    generate_edgy_sticker: 'Sticker Edge Design (Random)',
    generate_tattoo_design: 'Tattoo BW Design (Random)',
    generate_mystical_tattoo: 'Tattoo Sketch Realism (Random)',
    generate_color_tattoo: 'Tattoo Color Design (Random)',
    generate_tarot_mucha: 'Tarot Card (Arcana/Style)',
    generate_playing_card: 'Playing Card (Artist Style)',
};

export const PRESET_PROMPTS: PresetPrompt[] = [
  { id: "retouch_bokeh", prompt: "AI Portrait Bokeh" },
  { id: "retouch_remove_background", prompt: "Segment the primary subject from the background. Output the result as a PNG file with the background removed and replaced with a full, transparent alpha channel. Do not simulate transparency with a checkerboard or solid color background." },
  { id: "retouch_remove_background_ext", prompt: '{"Task":"Create a high-quality transparent image by removing the background from a source image.","constraints":{"preserve_subject_details":true,"maintain_original_dimensions":true,"clean_edges":true},"steps":[{"step_id":1,"name":"Generate High-Contrast Matte","instructions":"Take the input image. Accurately segment the main subject(s) from the background. Replace the entire background with a solid, pure white color (hex #FFFFFF). The subject must be perfectly preserved with no alterations. The output image dimensions must be identical to the input image. Output this intermediate image as \'white_matte\'."},{"step_id":2,"name":"Create Transparency from Matte","instructions":"Take the original input image and the \'white_matte\' image from step 1. Use \'white_matte\' as a pixel-perfect transparency mask for the original input image. Where \'white_matte\' is pure white, the corresponding pixels of the original image must become fully transparent (alpha=0). Where \'white_matte\' is not white, the original image pixels must be fully opaque (alpha=255). The anti-aliased (near-white) pixels along the subject\'s edge in \'white_matte\' should be translated into corresponding levels of semi-transparency to ensure a smooth, clean edge. Output this as \'final_transparent_image\'."}],"Deliverables":{"transparent_png":"final_transparent_image"}}' },
   { id: "imagination_paint_by_numbers", prompt: "Convert the image into a clean, beautiful coloring book lineart canvas." },
  { id: "retouch_brighten", prompt: "Brighten and contrast enhance old photo" },
  { id: "retouch_colorize", prompt: "Colorize photo and enhance details, ensuring original facial features and likeness are perfectly preserved. Pay close attention to individual facial characteristics, such as noses, to maintain their unique shapes and subtle, natural variations in skin tone. Avoid applying a uniform or generic appearance to facial features across different people in the same photo. If the subject is a woman with hair that is not distinctly dark, color her hair blonde. For other light hair tones, render natural variations (light brown, auburn) instead of a single shade." },
  { id: "retouch_enhance_clarity", prompt: "Enhance image detail and clarity without altering composition" },
  { id: "retouch_fix_damage", prompt: "Fix damage and improve overall quality" },
  { id: "retouch_improve_skin", prompt: "Improve skin texture and reduce facial blemishes" },
  { id: "retouch_remove_dust", prompt: "Remove dust and scratches" },
  { id: "retouch_remove_frame", prompt: "Remove photo frame and repair torn edges" },
  { id: "retouch_remove_noise", prompt: "Remove digital noise and grain from the photo" },
  { id: "retouch_base", prompt: "Retouch this photo" },
  { id: "retouch_old_photo_restoration", prompt: "Comprehensive restoration of this old photo. Remove scratches, dust, tears, and creases. Reduce grain and noise. Sharpen facial details and improve clarity. Correct exposure and contrast to restore the image to its original quality." },
  { id: "retouch_restore_colors", prompt: "Restore faded colors to be vibrant and natural" },
  { id: "retouch_sharpen", prompt: "Restore and sharpen faded image" },
  { id: "retouch_soft_focus", prompt: "Apply a dreamy soft-focus effect" },
  { id: "retouch_lighting_dramatic_studio", prompt: "Add dramatic studio lighting with high contrast" },
  { id: "retouch_lighting_golden_hour", prompt: "Bathe the scene in warm, golden hour light" },
  { id: "retouch_lighting_soft_window", prompt: "Simulate soft, natural light coming from a window" },
  { id: "retouch_lighting_cinematic_moody", prompt: "Create a moody, cinematic atmosphere with low-key lighting" },
  { id: "retouch_lighting_balanced", prompt: "Balance the lighting, brightening shadows and softening harsh highlights" },
  { id: "retouch_lighting_neon_glow", prompt: "Introduce a vibrant, colorful neon glow" },
];

export const IMAGINATION_PRESET_PROMPTS: PresetPrompt[] = [
  { id: "imagination_christmas_ornament", prompt: "Transform the subject into a meticulously detailed Christmas ornament hanging from a snow-covered pine branch. The subject is reimagined as a charming, festive doll-like figurine with slightly stylized features, large expressive eyes, rosy cheeks, and a glossy porcelain or hand-painted texture. Adorned with delicate holiday details like gold trim or sparkles. Suspended by a golden chain. The background features soft, warm, glowing bokeh lights and blurred green foliage. The style is realistic, luxurious, and festive with a shallow depth of field." },
  { id: "imagination_festive_christmas", prompt: "A festive Christmas-themed headshot. The subject is wearing a classic red and white Santa Claus hat. The background features a softly blurred decorated Christmas tree with warm, twinkling bokeh lights. The atmosphere is cozy, joyful, and magical, with soft winter lighting." },
  { id: "imagination_spooky_halloween", prompt: "A mystical Halloween-inspired headshot. The subject is wearing a classic pointed witch hat. The lighting is dramatic with moody shadows and ethereal purple and green mist. The background features subtle magical elements like floating candles or ancient runes, creating a mysterious, spooky, and powerful witchy vibe." },
  { id: "imagination_valentines_romance", prompt: "A romantic Valentine's Day headshot. The color palette focuses on soft pinks, reds, and creams. The background is dreamy and blurred, perhaps with subtle heart motifs or floral arrangements. The lighting is soft, flattering, and lovely." },
  { id: "imagination_dia_de_muertos", prompt: "STRICTLY PRESERVE IDENTICAL POSE AND FACIAL EXPRESSION. Transform this person into a Day of the Dead (Día de Muertos) character. The subject wears an elaborate floral crown of lush red and white roses. The face features intricate, beautiful sugar skull (Calavera) makeup. The atmosphere is ethereal, magical, and joyful, with floating petals and soft, glowing candlelight. The background is a blurred, dreamlike festival scene with colorful papel picado and ornate decorative skulls, captured with cinematic lighting." },
  { id: "imagination_anaglyph_3d", prompt: "Convert the image into a Red/Cyan Anaglyph 3D image." },
  { id: "imagination_stereogram", prompt: "Generate a high-quality grayscale Depth Map of the scene. Objects closer to the camera should be lighter (white), and objects further away should be darker (black). The map should be smooth and accurately represent the 3D structure of the image."},
  { id: "imagination_atmospheric_fog", prompt: "Apply atmospheric fog effect"},
  { id: "imagination_graffiti_art", prompt: "Transform the image into a vibrant, high-quality street art graffiti mural painted on a textured urban wall. Use bold outlines, bright spray paint colors, dynamic drips, and an expressive, edgy artistic style, while keeping the subject recognizable." },
  { id: "imagination_art_deco", prompt: "Dress the person(s) in elegant 1920s Art Deco fashion." },
  { id: "imagination_pinup_1950s", prompt: "Reimagine the person(s) in the style of a classic 1950s pin-up illustration." },
  { id: "imagination_rustic_cabin", prompt: "Depict the person(s) in a cozy, rustic cabin with a fireplace." },
  { id: "imagination_cyberpunk", prompt: "Change the outfits to rugged, futuristic cyberpunk gear." },
  { id: "imagination_fantasy_forest", prompt: "Transform the scene into a vibrant, fantastical forest with glowing plants." },
  { id: "imagination_film_noir", prompt: "Place the character(s) in a classic, black-and-white film noir scene." },
  { id: "imagination_futuristic_city", prompt: "Place the subject(s) in a futuristic city with flying cars." },
  { id: "imagination_ancient_jungle", prompt: "Imagine the person(s) as explorers in a lush, ancient jungle." },
  { id: "imagination_medieval", prompt: "Place the subject(s) in royal, medieval-era attire." },
  { id: "imagination_studio_portrait", prompt: "Studio portrait of the subject(s) in modern, plain clothing against a light background." },
  { id: "imagination_steampunk", prompt: "Place the subject(s) in a bustling steampunk city with brass machinery." },
  { id: "imagination_sunny_beach", prompt: "Show the subject(s) on a beautiful, sunny beach at sunset." },
  { id: "imagination_zen_garden", prompt: "Imagine the scene as a serene zen garden with cherry blossoms." },
];

export const ANIMATION_PRESET_PROMPTS: PresetPrompt[] = [
    { id: "animation_wiggle_3d", prompt: "Generate a 3D Wiggle effect animation by looping between different viewing angles created from a depth map." },
    { id: "animation_dolly_zoom", prompt: "Create a cinematic dolly zoom effect on the subject." },
    { id: "animation_gentle_sway", prompt: "Add a gentle swaying motion to the entire scene, like a gentle breeze." },
    { id: "animation_gentle_zoom_in", prompt: "A gentle and slow zoom in on the center of the image." },
    { id: "animation_gentle_zoom_out", prompt: "A gentle and slow zoom out from the center of the image." },
    { id: "animation_pan_left_right", prompt: "A slow, smooth pan from left to right across the image." },
    { id: "animation_pan_up_down", prompt: "A slow, smooth pan from top to bottom across the image." },
    { id: "animation_parallax", prompt: "Create a subtle 2.5D parallax effect, with the foreground moving slightly faster than the background." },
    { id: "animation_autumn_leaves", prompt: "Animate colorful autumn leaves gently falling and drifting across the scene." },
    { id: "animation_falling_snow", prompt: "Animate gentle, slow-falling snowflakes across the entire scene, creating a peaceful winter atmosphere." },
    { id: "animation_flickering_fire", prompt: "Animate any visible flames (candles, fireplace) to flicker realistically, casting a gentle, moving light on nearby objects." },
    { id: "animation_rippling_water", prompt: "Create a subtle, realistic ripple effect across any visible water surfaces in the image, as if disturbed by a light breeze." },
    { id: "animation_rising_steam", prompt: "Add a subtle, slow rising motion to any steam, smoke, or mist in the image." },
    { id: "animation_shimmer", prompt: "Add a subtle shimmering or glowing effect to light sources in the image." },
    { id: "animation_windy_day", prompt: "A gentle, continuous breeze blowing from left to right, making objects like flags, hair, or trees sway realistically." },
];

export const GENERATE_PRESET_PROMPTS: PresetPrompt[] = [
    { id: "generate_tarot_mucha", prompt: 'High-quality image of the Tarot card "__SUBJECT__" in the style of "__SUBJECT_2__". The central character is shown with an emotional expression. The title "__SUBJECT__" is written at the bottom of the card in a masterpiece vintage font matching the art style. The card design features elegant rounded corners.', aspectRatio: '9:16' },
    { id: "generate_playing_card", prompt: "A single playing card, __RANK__ of __SUIT__, designed as a masterpiece in the distinct artistic style of __ARTIST__. \n\nCONTENT GUIDANCE:\n- If __RANK__ is King, Queen, or Jack: Depict a majestic, symmetrical character portrait in the artist's style.\n- If __RANK__ is Ace or a Number (2-10): Depict an ornamental, symmetrical arrangement of exactly that quantity of __SUIT__ symbols. Do NOT show a human character. The symbols should be stylized and woven into the artist's signature background patterns.\n\nThe artwork heavily reflects the artist's unique brushwork, color palette, and decorative elements. The design is perfectly symmetrical and reversible. The letter '__INITIAL__' and a __SYMBOL__ are clearly integrated into the top-left and bottom-right corners. The card features elegant rounded corners. High level of detail, vintage paper texture background.", aspectRatio: '9:16' },
    { id: "generate_sticker_design", prompt: "A die-cut sticker design of __SUBJECT__. Vector illustration style, flat design, bold lines. A clear white border surrounding the shape. Isolated on a black background. High quality sticker art." },
    { id: "generate_edgy_sticker", prompt: "A cool, edgy die-cut sticker design of __SUBJECT__. Vintage distressed aesthetic, bold black outlines, muted retro colors. High quality vector illustration style. Isolated on a black background." },
    { id: "generate_tattoo_design", prompt: "A professional tattoo design of __SUBJECT__. Blackwork style, high contrast, clean linework and stippling shading. Isolated on a white background." },
    { id: "generate_mystical_tattoo", prompt: "A stunning 'Sketch Realism' tattoo design of __SUBJECT__. The artwork features a highly detailed, photorealistic center that fades into loose pencil sketches, smoke, and abstract lines at the edges. High contrast black and grey ink. The composition includes subtle noir elements like swirling smoke, playing cards, or floating roses. Mysterious, edgy, and masterfully shaded. Isolated on a white background." },
    { id: "generate_color_tattoo", prompt: "A high-quality Neo-Traditional tattoo design of __SUBJECT__. The style features bold, clean black outlines with a rich, saturated color palette (teals, burnt oranges, deep reds). Illustrative shading, depth, and a balance of realism and stylized art. Isolated on a white background." },
    { id: "generate_photorealistic_cat", prompt: "A photorealistic close-up portrait of a fluffy orange cat with green eyes, sitting in a sunbeam. shallow depth of field, high detail, sharp focus." },
    { id: "generate_surreal_landscape", prompt: "A surreal landscape with floating islands, giant glowing mushrooms, and a waterfall that flows upwards into a cosmic sky. Ethereal, dreamlike, vibrant colors." },
    { id: "generate_cyberpunk_city", prompt: "A sprawling cyberpunk cityscape at night, drenched in neon light. Rain-slicked streets reflect holographic advertisements. Flying vehicles zip between towering skyscrapers. High detail, Blade Runner aesthetic." },
    { id: "generate_vintage_botanical", prompt: "A vintage botanical illustration of a fantastical, undiscovered flower. Detailed linework, muted colors, and aged paper texture. Style of a 19th-century scientific journal." },
    { id: "generate_abstract_emotion", prompt: "An abstract expressionist painting representing the feeling of 'joy'. Bold, sweeping brushstrokes, a vibrant color palette of yellows, oranges, and blues. Dynamic and energetic composition." },
    { id: "generate_fantasy_knight", prompt: "A detailed fantasy portrait of an elven knight in ornate, leaf-like armor, standing in a sun-dappled ancient forest. Regal, wise expression. Photorealistic, fantasy art style." },
];

export const AI_FILTER_PRESETS: PresetPrompt[] = [
  { id: "ai_filter_watercolor", prompt: "A vibrant watercolor painting with soft washes of color and visible paper texture" },
  { id: "ai_filter_oil_painting", prompt: "A classic oil painting with rich colors and visible, textured brushstrokes" },
  { id: "ai_filter_pencil_sketch", prompt: "A detailed pencil sketch focusing on lines, shading, and cross-hatching" },
  { id: "ai_filter_anime", prompt: "A vibrant, modern anime style with clean lines, cel-shading, and expressive features" },
];
