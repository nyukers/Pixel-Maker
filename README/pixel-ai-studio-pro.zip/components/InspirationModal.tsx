
import React from 'react';
import { CreativeIdea } from '../types';
import { XIcon } from './icons/XIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';

interface InspirationModalProps {
  isOpen: boolean;
  onClose: () => void;
  ideas: CreativeIdea[];
  onApply: (prompt: string) => void;
}

const InspirationModal: React.FC<InspirationModalProps> = ({ isOpen, onClose, ideas, onApply }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4"
      aria-modal="true"
      role="dialog"
      onClick={onClose}
    >
      <div
        className="bg-gray-800 border border-gray-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-gray-700 flex-shrink-0">
          <h2 className="text-xl font-bold text-yellow-300 flex items-center gap-3">
            <LightbulbIcon className="w-6 h-6" />
            Creative Ideas
          </h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors" title="Close">
            <XIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4">
          {ideas.length > 0 ? (
            ideas.map((idea, index) => (
              <div key={index} className="bg-gray-900/50 p-4 rounded-lg border border-gray-700/50">
                <h3 className="text-lg font-semibold text-gray-100">{idea.title}</h3>
                <p className="text-sm text-gray-400 mt-1 mb-3">{idea.description}</p>
                <div className="bg-gray-900 p-3 rounded-md mb-3">
                  <code className="text-xs text-gray-300 whitespace-pre-wrap">{idea.prompt}</code>
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={() => onApply(idea.prompt)}
                    className="py-1.5 px-4 bg-yellow-400 text-gray-900 rounded-lg hover:bg-yellow-300 transition text-sm font-bold"
                    title="Use this prompt in the editor"
                  >
                    Try this prompt
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-400 text-center">No ideas could be generated for this image.</p>
          )}
        </div>

        <div className="flex-shrink-0 p-4 border-t border-gray-700 flex justify-end">
          <button
            onClick={onClose}
            className="py-2 px-6 bg-gray-600 text-gray-200 rounded-lg hover:bg-gray-500 transition font-semibold"
            title="Close"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default InspirationModal;