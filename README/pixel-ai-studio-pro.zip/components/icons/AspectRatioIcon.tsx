
import React from 'react';
import { AspectRatio } from '../../types';

interface AspectRatioIconProps extends React.SVGProps<SVGSVGElement> {
  ratio: AspectRatio;
}

export const AspectRatioIcon: React.FC<AspectRatioIconProps> = ({ ratio, ...props }) => {
  const getRectProps = () => {
    switch (ratio) {
      case '1:1':
        return { x: 4, y: 4, width: 16, height: 16 };
      case '16:9':
        return { x: 2, y: 6.5, width: 20, height: 11 };
      case '9:16':
        return { x: 6.5, y: 2, width: 11, height: 20 };
      case '4:3':
        return { x: 2, y: 4.5, width: 20, height: 15 };
      case '3:4':
        return { x: 4.5, y: 2, width: 15, height: 20 };
      default:
        return { x: 4, y: 4, width: 16, height: 16 };
    }
  };

  const rectProps = getRectProps();

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="none"
      {...props}
    >
      <rect {...rectProps} rx="2" />
    </svg>
  );
};
