
import React from 'react';

export const HighDefIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}
    >
        <path d="M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" />
        <path d="M9 15v-3a2 2 0 0 1 2-2h2" />
        <path d="M13 15v-6" />
        <path d="M16 15l-3-3" />
        <text x="7" y="14" fontFamily="sans-serif" fontSize="8" stroke="none" fill="currentColor" fontWeight="bold">4K</text>
    </svg>
);
