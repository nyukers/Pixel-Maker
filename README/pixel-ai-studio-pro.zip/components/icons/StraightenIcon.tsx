import React from 'react';

export const StraightenIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        fill="none" 
        viewBox="0 0 24 24" 
        strokeWidth={1.5} 
        stroke="currentColor" 
        {...props}
    >
        <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            d="M3 18.75V5.25A2.25 2.25 0 015.25 3h13.5A2.25 2.25 0 0121 5.25v13.5A2.25 2.25 0 0118.75 21H5.25A2.25 2.25 0 013 18.75z"
            transform="rotate(-5 12 12)"
        />
        <path 
            strokeLinecap="round" 
            strokeLinejoin="round"
            strokeDasharray="2 2"
            d="M3.75 9h16.5M3.75 15h16.5M9 3.75v16.5m6-16.5v16.5"
            transform="rotate(-5 12 12)" 
        />
    </svg>
);