
import React, { useRef, useState, useEffect } from 'react';
import { XIcon } from './icons/XIcon';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  systemInstruction: string;
  onSystemInstructionChange: (value: string) => void;
  stylesUrl: string;
  onStylesUrlChange: (value: string) => void;
  onLoadPromptsFromFileContent: (content: string) => void;
  useProModel?: boolean;
  onUseProModelChange: (value: boolean) => void;
  promptFontSize: number;
  onPromptFontSizeChange: (value: number) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
    isOpen, 
    onClose, 
    systemInstruction, 
    onSystemInstructionChange,
    stylesUrl,
    onStylesUrlChange,
    onLoadPromptsFromFileContent,
    useProModel = false,
    onUseProModelChange,
    promptFontSize,
    onPromptFontSizeChange
}) => {
  const systemInstructionFileInputRef = useRef<HTMLInputElement>(null);
  const promptsFileInputRef = useRef<HTMLInputElement>(null);

  const [localSystemInstruction, setLocalSystemInstruction] = useState(systemInstruction);
  const [localStylesUrl, setLocalStylesUrl] = useState(stylesUrl);
  const [localUseProModel, setLocalUseProModel] = useState(useProModel);
  const [localPromptFontSize, setLocalPromptFontSize] = useState(promptFontSize);

  useEffect(() => {
    if (isOpen) {
      setLocalSystemInstruction(systemInstruction);
      setLocalStylesUrl(stylesUrl);
      setLocalUseProModel(useProModel);
      setLocalPromptFontSize(promptFontSize);
    }
  }, [isOpen, systemInstruction, stylesUrl, useProModel, promptFontSize]);

  if (!isOpen) {
    return null;
  }

  const handleLoadSystemInstructionFromFileClick = () => {
    systemInstructionFileInputRef.current?.click();
  };

  const handleSystemInstructionFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'text/plain') {
        alert("Please select a valid .txt file.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target?.result as string;
        setLocalSystemInstruction(text);
    };
    reader.onerror = (e) => {
        console.error("Failed to read file", e);
        alert("Error reading file.");
    };
    reader.readAsText(file);

    // Reset file input to allow re-uploading the same file
    if(event.target) {
      event.target.value = '';
    }
  };

  const handleLoadPromptsFromFileClick = () => {
    promptsFileInputRef.current?.click();
  };

  const handleDownloadTemplate = () => {
    const headers = ['category', 'id', 'displayName', 'prompt'];
    const rows = [
        ['retouch', 'custom_bw_filter', 'Custom B&W', '"Convert image to black and white with high contrast."'],
        ['imagination', 'custom_oil_paint', 'Oil Painting', '"Transform into a classic oil painting with visible brushstrokes."'],
        ['generate', 'custom_scifi_scene', 'Sci-Fi City', '"A futuristic cyberpunk city with neon lights, realistic style."']
    ];

    const csvContent = [
        headers.join(','),
        ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'presets_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePromptsFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const isCsv = file.type === 'text/csv' || file.name.endsWith('.csv');
    const isTxt = file.type === 'text/plain' || file.name.endsWith('.txt');

    if (!isCsv && !isTxt) {
        alert("Please select a valid .csv or .txt file.");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        const text = e.target?.result as string;
        onLoadPromptsFromFileContent(text);
        onClose();
    };
    reader.onerror = (e) => {
        console.error("Failed to read file", e);
        alert("Error reading file.");
    };
    reader.readAsText(file);

    if (event.target) {
        event.target.value = '';
    }
  };

  const handleSave = () => {
    onSystemInstructionChange(localSystemInstruction);
    onStylesUrlChange(localStylesUrl);
    onUseProModelChange(localUseProModel);
    onPromptFontSizeChange(localPromptFontSize);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 bg-black/75 flex items-center justify-center z-50"
      aria-modal="true"
      role="dialog"
      onClick={onClose}
    >
      <div
        className="bg-gray-800 p-6 rounded-xl shadow-2xl border border-gray-700 w-full max-w-lg text-gray-100 overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-300">Settings</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors" title="Close">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        
        <div className="space-y-6">
            {/* AI Models Info Section */}
            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                <h3 className="text-sm font-bold text-yellow-400 uppercase tracking-wider mb-3">AI Models Config</h3>
                <div className="space-y-3">
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Generate</label>
                        <input type="text" readOnly value="imagen-4.0-generate-001 (API)" className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1 text-xs text-gray-300 focus:outline-none cursor-default" />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Retouch & Imagination</label>
                        <select
                            value={localUseProModel ? 'true' : 'false'}
                            onChange={(e) => setLocalUseProModel(e.target.value === 'true')}
                            className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-xs text-gray-100 focus:outline-none focus:border-yellow-400 cursor-pointer"
                        >
                            <option value="false">gemini-2.5-flash-image (Standard) (API)</option>
                            <option value="true">gemini-3-pro-image-preview (High Quality) (API)</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Animation</label>
                        <input type="text" readOnly value="veo-3.1-fast-generate-preview (API)" className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1 text-xs text-gray-300 focus:outline-none cursor-default" />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">Analyzer (Analysis & Ideas)</label>
                        <input type="text" readOnly value="gemini-2.5-flash (API)" className="w-full bg-gray-800 border border-gray-600 rounded px-2 py-1 text-xs text-gray-300 focus:outline-none cursor-default" />
                    </div>
                </div>
            </div>

            {/* Interface Settings */}
            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                <h3 className="text-sm font-bold text-yellow-400 uppercase tracking-wider mb-3">Prompt</h3>
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Font Size ({localPromptFontSize}px)</label>
                    <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-400">A</span>
                        <input 
                            type="range" 
                            min="10" 
                            max="18" 
                            step="2"
                            value={localPromptFontSize} 
                            onChange={(e) => setLocalPromptFontSize(parseInt(e.target.value))} 
                            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-400"
                        />
                        <span className="text-lg text-gray-400 font-bold">A</span>
                    </div>
                </div>
            </div>

            <div>
                <div className="flex justify-between items-center mb-2">
                    <label htmlFor="system-instruction-input" className="block text-sm font-medium text-gray-300">
                        Studio System Instruction
                    </label>
                    <button
                        onClick={handleLoadSystemInstructionFromFileClick}
                        className="text-xs text-yellow-300 hover:text-yellow-200 underline focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded"
                        title="Load content from a .txt file"
                    >
                        Load from File
                    </button>
                </div>
                <textarea
                    id="system-instruction-input"
                    rows={3}
                    value={localSystemInstruction}
                    onChange={(e) => setLocalSystemInstruction(e.target.value)}
                    placeholder="e.g., You are a world-class digital artist and professional photo retoucher with an expert eye for photorealism, artistic composition, and subtle detail. Your primary goal is to interpret user prompts with maximum creativity and technical excellence to produce breathtaking, high-quality images."
                    className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 text-gray-100 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
                />
                <p className="text-xs text-gray-400 mt-2">This instruction guides the AI's behavior for all image editing tasks. Leave blank for default behavior.</p>
            </div>
            <div>
                <div className="flex justify-between items-center mb-2">
                    <label htmlFor="styles-url-input" className="block text-sm font-medium text-gray-300">Presets File URL</label>
                    <div className="flex space-x-3">
                        <button
                            onClick={handleDownloadTemplate}
                            className="text-xs text-yellow-300 hover:text-yellow-200 underline focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded"
                            title="Download a sample CSV file"
                        >
                            Download Template
                        </button>
                        <button
                            onClick={handleLoadPromptsFromFileClick}
                            className="text-xs text-yellow-300 hover:text-yellow-200 underline focus:outline-none focus:ring-2 focus:ring-yellow-400 rounded"
                            title="Load prompts from a local .csv or .txt file"
                        >
                            Load from File
                        </button>
                    </div>
                </div>
                 <input
                    id="styles-url-input"
                    type="url"
                    value={localStylesUrl}
                    onChange={(e) => setLocalStylesUrl(e.target.value)}
                    placeholder="https://.../prompts.csv"
                    className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 text-gray-100 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
                />
                <p className="text-xs text-gray-400 mt-2">URL for a CSV or TXT file with custom prompts. The file must contain "category", "id", "displayName", and "prompt" headers.</p>
            </div>
        </div>

        <input
            type="file"
            ref={systemInstructionFileInputRef}
            onChange={handleSystemInstructionFileChange}
            accept=".txt"
            className="hidden"
        />
        <input
            type="file"
            ref={promptsFileInputRef}
            onChange={handlePromptsFileChange}
            accept=".txt,.csv"
            className="hidden"
        />

        <div className="mt-8 flex justify-end space-x-3">
            <button 
                onClick={onClose} 
                className="py-2 px-4 bg-gray-600 text-gray-200 rounded-lg hover:bg-gray-500 transition font-semibold"
                title="Cancel and close this dialog"
            >
                Cancel
            </button>
            <button 
                onClick={handleSave} 
                className="py-2 px-6 bg-yellow-400 text-gray-900 rounded-lg hover:bg-yellow-300 transition font-bold"
                title="Save and close settings"
            >
                OK
            </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
