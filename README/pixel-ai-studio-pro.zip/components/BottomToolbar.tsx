
import React from 'react';
import { ComparisonMode, PromptMode, ResultItem } from '../types';
import { EditIcon } from './icons/EditIcon';
import { BrushIcon } from './icons/BrushIcon';
import { SearchIcon } from './icons/SearchIcon';

interface BottomToolbarProps {
  isEditing: boolean;
  setIsEditing: (isEditing: boolean) => void;
  isMasking: boolean;
  setIsMasking: (isMasking: boolean) => void;
  comparisonMode: ComparisonMode;
  setComparisonMode: (mode: ComparisonMode) => void;
  zoom: number;
  handleSetZoom: (zoom: number | 'fit' | 'fit-h') => void;
  hasImage: boolean;
  beforeImage: string | null;
  selectedResult: ResultItem | null;
  promptMode: PromptMode;
  isSpotting?: boolean;
  setIsSpotting?: (v: boolean) => void;
}

const BottomToolbar: React.FC<BottomToolbarProps> = ({
  isEditing, setIsEditing, isMasking, setIsMasking, comparisonMode, setComparisonMode,
  zoom, handleSetZoom, hasImage, beforeImage, selectedResult, promptMode, isSpotting, setIsSpotting
}) => {
  if (!hasImage || isEditing || isMasking || selectedResult?.videoUrl) return null;

  const buttonBaseClass = "px-3 py-1.5 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-colors";
  const activeClass = "bg-yellow-400 text-gray-900 shadow-sm";
  const inactiveClass = "bg-gray-700 text-gray-300 hover:bg-gray-600";
  
  const zoomBtnClass = (isActive: boolean) => 
    `px-2 py-1 text-[10px] font-medium rounded transition-colors ${isActive ? 'bg-gray-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`;

  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-2">
      <div className="flex items-center bg-gray-900/90 backdrop-blur-md p-1.5 rounded-xl shadow-2xl border border-gray-700/50 gap-3">
        
        {/* Tools Section */}
        <div className="flex gap-1.5">
            <button onClick={() => setIsEditing(true)} className={`${buttonBaseClass} ${inactiveClass}`}>
            <EditIcon className="w-4 h-4" /> Edit
            </button>
            <button onClick={() => setIsMasking(true)} className={`${buttonBaseClass} ${inactiveClass}`}>
            <BrushIcon className="w-4 h-4" /> Mask
            </button>
            {/* Spotter (Optional feature from code) */}
            <button 
                onClick={() => setIsSpotting?.(!isSpotting)} 
                className={`px-2 py-1.5 rounded-md transition-colors ${isSpotting ? 'text-yellow-400 bg-gray-800' : 'text-gray-400 hover:text-gray-200'}`}
                title="Toggle Spotter"
            >
            <SearchIcon className="w-4 h-4" />
            </button>
        </div>

        {/* Divider */}
        <div className="w-px h-6 bg-gray-700"></div>

        {/* View Section */}
        {beforeImage && (
            <>
                <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">View:</span>
                    <div className="flex bg-gray-800 rounded-lg p-0.5">
                        <button 
                            onClick={() => setComparisonMode('slider')} 
                            className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${comparisonMode === 'slider' ? 'bg-yellow-400 text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-200'}`}
                        >
                            Slider
                        </button>
                        <button 
                            onClick={() => setComparisonMode('side')} 
                            className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${comparisonMode === 'side' ? 'bg-yellow-400 text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-200'}`}
                        >
                            Side
                        </button>
                    </div>
                </div>
                <div className="w-px h-6 bg-gray-700"></div>
            </>
        )}

        {/* Zoom Section */}
        <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Zoom:</span>
            <div className="flex gap-1">
                <button onClick={() => handleSetZoom('fit')} className={zoomBtnClass(zoom === 1)}>Fit</button>
                <button onClick={() => handleSetZoom('fit-h')} className={zoomBtnClass(false)}>Fit H</button>
                <button onClick={() => handleSetZoom(0.5)} className={zoomBtnClass(zoom === 0.5)}>50%</button>
                <button onClick={() => handleSetZoom(1)} className={zoomBtnClass(zoom === 1)}>100%</button>
                <button onClick={() => handleSetZoom(2)} className={zoomBtnClass(zoom === 2)}>200%</button>
            </div>
        </div>
      </div>
      
      {/* Zoom Indicator */}
      <span className="text-[10px] text-gray-500 font-mono">({Math.round(zoom * 100)}%)</span>
    </div>
  );
};

export default BottomToolbar;
