
import React from 'react';
import ImageUploader from './ImageUploader';
import { 
    PRESET_PROMPTS, 
    IMAGINATION_PRESET_PROMPTS, 
    ANIMATION_PRESET_PROMPTS, 
    GENERATE_PRESET_PROMPTS, 
    PRESET_PROMPT_DISPLAY_NAMES,
    STICKER_SUBJECTS,
    EDGY_STICKER_SUBJECTS,
    TATTOO_SUBJECTS,
    MYSTICAL_TATTOO_SUBJECTS,
    COLOR_TATTOO_SUBJECTS,
    TAROT_SUBJECTS,
    TAROT_STYLE_ARTISTS,
    PLAYING_CARD_RANKS,
    PLAYING_CARD_SUITS
} from '../constants';
import { RestoreIcon } from './icons/RestoreIcon';
import { ResetIcon } from './icons/ResetIcon';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PromptMode, AppMode, AnalysisItem, LoadedPreset, AspectRatio, Action, PresetPrompt } from '../types';
import { SettingsIcon } from './icons/SettingsIcon';
import { XIcon } from './icons/XIcon';
import { ClearIcon } from './icons/ClearIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { ClockIcon } from './icons/ClockIcon';
import { CheckIcon } from './icons/CheckIcon';
import { EnhanceIcon } from './icons/EnhanceIcon';
import { WorkflowIcon } from './icons/WorkflowIcon';
import { PlayIcon } from './icons/PlayIcon';
import { EditIcon } from './icons/EditIcon';
import { WandIcon } from './icons/WandIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { DetectIcon } from './icons/DetectIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { UploadIcon } from './icons/UploadIcon';
import { AspectRatioIcon } from './icons/AspectRatioIcon';
import { TranslateIcon } from './icons/TranslateIcon';
import { PasteIcon } from './icons/PasteIcon';

interface LeftPanelProps {
  onFilesSelected: (files: File[]) => void;
  processingImageUrl: string | null;
  prompt: string;
  setPrompt: React.Dispatch<React.SetStateAction<string>>;
  onRestore: () => void;
  isLoading: boolean;
  hasImage: boolean;
  onReset: () => void;
  isProcessingOriginal: boolean;
  onTranslatePrompt: () => void;
  promptMode: PromptMode;
  setPromptMode: (mode: PromptMode) => void;
  isEditing: boolean;
  isMasking: boolean;
  onOpenSettings: () => void;
  isQuotaLimited: boolean;
  quotaCooldownRemaining: number;
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  analysisItems: AnalysisItem[];
  isBatchAnalyzing: boolean;
  runningAnalysisType: 'analysis' | 'detection' | null;
  onStartAnalysis: () => void;
  onStartAiDetection: () => void;
  onClearAnalysis: () => void;
  onRemoveAnalysisItem: (id: string) => void;
  onExportAnalysisResults: () => void;
  onLoadStyles: () => void;
  loadedPresets: Record<PromptMode, LoadedPreset[]>;
  totalLoadedPrompts: number;
  animationAspectRatio: AspectRatio;
  setAnimationAspectRatio: (ratio: AspectRatio) => void;
  generateAspectRatio: AspectRatio;
  setGenerateAspectRatio: (ratio: AspectRatio) => void;
  numberOfImages: number;
  setNumberOfImages: (num: number) => void;
  actions: Action[];
  onRunAction: (action: Action) => void;
  onOpenActionEditor: (action: Action | null) => void;
  onDeleteAction: (actionId: string) => void;
  onAnalyzeImage: () => void;
  onGetCreativeIdeas: () => void;
  removeBgTolerance: number;
  setRemoveBgTolerance: (value: number) => void;
  selectedAnalysisItem: AnalysisItem | null;
  onSelectAnalysisItem: (item: AnalysisItem) => void;
  paintByNumbersColors: number;
  setPaintByNumbersColors: (value: number) => void;
  onPresetClick: (preset: PresetPrompt) => void;
  isRandomMode: boolean;
  setIsRandomMode: (value: boolean) => void;
  promptFontSize: number;
}

const LeftPanel: React.FC<LeftPanelProps> = ({
  onFilesSelected,
  processingImageUrl,
  prompt,
  setPrompt,
  onRestore,
  isLoading,
  hasImage,
  onReset,
  isProcessingOriginal,
  onTranslatePrompt,
  promptMode,
  setPromptMode,
  isEditing,
  isMasking,
  onOpenSettings,
  isQuotaLimited,
  quotaCooldownRemaining,
  appMode,
  setAppMode,
  analysisItems,
  isBatchAnalyzing,
  runningAnalysisType,
  onStartAnalysis,
  onStartAiDetection,
  onClearAnalysis,
  onRemoveAnalysisItem,
  onExportAnalysisResults,
  onLoadStyles,
  loadedPresets,
  totalLoadedPrompts,
  animationAspectRatio,
  setAnimationAspectRatio,
  generateAspectRatio,
  setGenerateAspectRatio,
  numberOfImages,
  setNumberOfImages,
  actions,
  onRunAction,
  onOpenActionEditor,
  onDeleteAction,
  onAnalyzeImage,
  onGetCreativeIdeas,
  removeBgTolerance,
  setRemoveBgTolerance,
  selectedAnalysisItem,
  onSelectAnalysisItem,
  paintByNumbersColors,
  setPaintByNumbersColors,
  onPresetClick,
  isRandomMode,
  setIsRandomMode,
  promptFontSize,
}) => {
  const analysisFileInputRef = React.useRef<HTMLInputElement>(null);

  const handleAnalysisUploadClick = () => {
    analysisFileInputRef.current?.click();
  };

  const handleAnalysisFilesSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const supportedFiles = Array.from(files).filter((file: File) => file.type.startsWith('image/'));
      if (supportedFiles.length > 0) {
        onFilesSelected(supportedFiles);
      } else {
        alert('Please upload valid image files (e.g., PNG, JPG).');
      }
    }
    if (e.target) {
        e.target.value = '';
    }
  };
  
  const getPromptDisplayName = (promptId: string): string => {
    const allPrompts = [
      ...PRESET_PROMPTS,
      ...IMAGINATION_PRESET_PROMPTS,
      ...ANIMATION_PRESET_PROMPTS,
      ...GENERATE_PRESET_PROMPTS
    ];
    const preset = allPrompts.find(p => p.id === promptId);
    if (!preset) return promptId;
    return PRESET_PROMPT_DISPLAY_NAMES[promptId] || preset.prompt;
  };
  
  const handleSmartPresetClick = (preset: PresetPrompt) => {
      let promptText = preset.prompt;
      let subjectList: string[] = [];

      switch (preset.id) {
          case 'generate_sticker_design': subjectList = STICKER_SUBJECTS; break;
          case 'generate_edgy_sticker': subjectList = EDGY_STICKER_SUBJECTS; break;
          case 'generate_tattoo_design': subjectList = TATTOO_SUBJECTS; break;
          case 'generate_mystical_tattoo': subjectList = MYSTICAL_TATTOO_SUBJECTS; break;
          case 'generate_color_tattoo': subjectList = COLOR_TATTOO_SUBJECTS; break;
          case 'generate_tarot_mucha': 
              subjectList = TAROT_SUBJECTS;
              // Handle secondary subject (Artist) for Tarot
              if (TAROT_STYLE_ARTISTS.length > 0) {
                  const randomArtist = TAROT_STYLE_ARTISTS[Math.floor(Math.random() * TAROT_STYLE_ARTISTS.length)];
                  promptText = promptText.replace(/__SUBJECT_2__/g, randomArtist);
              }
              break;
          case 'generate_playing_card':
              const rank = PLAYING_CARD_RANKS[Math.floor(Math.random() * PLAYING_CARD_RANKS.length)];
              const suit = PLAYING_CARD_SUITS[Math.floor(Math.random() * PLAYING_CARD_SUITS.length)];
              const artistFullName = TAROT_STYLE_ARTISTS[Math.floor(Math.random() * TAROT_STYLE_ARTISTS.length)];
              
              promptText = promptText
                  .replace('__RANK__', rank.name)
                  .replace('__SUIT__', suit.name)
                  .replace('__ARTIST__', artistFullName)
                  .replace('__INITIAL__', rank.initial)
                  .replace('__SYMBOL__', suit.symbol);
              
              setIsRandomMode(true);
              break;
      }

      if (subjectList.length > 0) {
          const randomSubject = subjectList[Math.floor(Math.random() * subjectList.length)];
          // Globally replace placeholder with the random subject
          promptText = promptText.replace(/__SUBJECT__/g, randomSubject);
          setIsRandomMode(true);
      }

      if (preset.aspectRatio && promptMode === 'generate') {
          setGenerateAspectRatio(preset.aspectRatio);
      }

      onPresetClick({ ...preset, prompt: promptText });
  };
  
  const handlePaste = async () => {
      try {
          const text = await navigator.clipboard.readText();
          setPrompt(text);
          if (isRandomMode) setIsRandomMode(false);
      } catch (err) {
          console.error('Failed to read clipboard contents: ', err);
      }
  };

  const currentPresets = (() => {
    switch(promptMode) {
      case 'retouch': return PRESET_PROMPTS;
      case 'imagination': return IMAGINATION_PRESET_PROMPTS;
      case 'animation': return ANIMATION_PRESET_PROMPTS;
      case 'generate': return GENERATE_PRESET_PROMPTS;
      default: return [];
    }
  })();
  
  const generationAspectRatios: AspectRatio[] = ['1:1', '16:9', '9:16', '4:3', '3:4'];
  const animationAspectRatios: AspectRatio[] = ['16:9', '9:16'];

  const getButtonText = () => {
    if (isQuotaLimited) return `Quota Limit Reached (${quotaCooldownRemaining}s)`;
    if (isLoading) return 'Processing...';
    if (promptMode === 'animation') return 'Animate Image';
    if (promptMode === 'generate') return 'Generate Image';
    return 'Process Image';
  };
  
  const getAnalysisButtonText = () => {
    if (isQuotaLimited) return `Quota Limit Reached (${quotaCooldownRemaining}s)`;
    if (runningAnalysisType === 'analysis') {
        const completed = analysisItems.filter(i => i.status === 'completed' || i.status === 'error').length;
        return `Processing... (${completed}/${analysisItems.length})`;
    }
    return 'Start Analysis';
  };

  const getStatusIcon = (status: AnalysisItem['status']) => {
      switch (status) {
          case 'pending': return <span title="Pending"><ClockIcon className="w-5 h-5 text-gray-400" /></span>;
          case 'processing': return <span title="Processing"><SpinnerIcon className="w-5 h-5 text-yellow-400 animate-spin" /></span>;
          case 'completed': return <span title="Completed"><CheckIcon className="w-5 h-5 text-green-400"/></span>;
          case 'error': return <span title="Error"><XIcon className="w-5 h-5 text-red-400" /></span>;
      }
  };

  return (
    <div className="w-1/4 max-w-sm flex flex-col bg-gray-800 p-6 border-r border-gray-700 space-y-6 flex-shrink-0">
      <header className="flex items-start justify-between">
        <div>
            <h1 className="text-xl font-bold text-yellow-400 whitespace-nowrap">
                <EnhanceIcon className="w-8 h-8 inline-block align-middle mr-2 text-yellow-300"/>
                Pixel AI Studio Pro
            </h1>
            <p className="text-sm text-gray-400">Nyukers (C)opyright, 2026</p>
        </div>
        <div className="flex items-center space-x-2">
          <button onClick={onOpenSettings} className="p-2 rounded-md hover:bg-gray-700 transition-colors" aria-label="Settings" title="Settings">
              <SettingsIcon className="w-6 h-6 text-gray-300"/>
          </button>
        </div>
      </header>

      <div className="flex-shrink-0">
          <div className="flex rounded-lg bg-gray-900 p-1">
              <button onClick={() => setAppMode('single')} title="Edit one image" className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${appMode === 'single' ? 'bg-yellow-400 text-gray-900' : 'text-gray-400 hover:bg-gray-700'}`}>Edit</button>
              <button onClick={() => setAppMode('analyze')} title="Batch Analysis" className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${appMode === 'analyze' ? 'bg-yellow-400 text-gray-900' : 'text-gray-400 hover:bg-gray-700'}`}>Analyzer</button>
          </div>
      </div>
      
      <div className="flex-grow flex flex-col space-y-6 overflow-y-auto pr-2 -mr-2">
        {appMode === 'single' && (
          <>
            {promptMode !== 'generate' && <ImageUploader onFilesSelected={onFilesSelected} currentImage={processingImageUrl} />}
            <div>
                <div className="grid grid-cols-2 gap-1 mb-4 p-1 bg-gray-900 rounded-lg">
                    <button onClick={() => setPromptMode('generate')} className={`w-full py-1.5 text-xs font-semibold rounded-md transition-colors ${promptMode === 'generate' ? 'bg-yellow-400 text-gray-900' : 'text-gray-400 hover:bg-gray-700'}`}>Generate</button>
                    <button onClick={() => setPromptMode('retouch')} className={`w-full py-1.5 text-xs font-semibold rounded-md transition-colors ${promptMode === 'retouch' ? 'bg-yellow-400 text-gray-900' : 'text-gray-400 hover:bg-gray-700'}`}>Retouch</button>
                    <button onClick={() => setPromptMode('imagination')} className={`w-full py-1.5 text-xs font-semibold rounded-md transition-colors ${promptMode === 'imagination' ? 'bg-yellow-400 text-gray-900' : 'text-gray-400 hover:bg-gray-700'}`}>Imagination</button>
                    <button onClick={() => setPromptMode('animation')} className={`w-full py-1.5 text-xs font-semibold rounded-md transition-colors ${promptMode === 'animation' ? 'bg-yellow-400 text-gray-900' : 'text-gray-400 hover:bg-gray-700'}`}>Animation</button>
                </div>
                {(promptMode === 'animation' || promptMode === 'generate') && (
                  <div className="mb-4 text-xs">
                    <label className="block text-sm font-medium text-gray-300 mb-2">Aspect Ratio</label>
                    <div className={`grid gap-2 ${promptMode === 'animation' ? 'grid-cols-2' : 'grid-cols-5'}`}>
                      {(promptMode === 'animation' ? animationAspectRatios : generationAspectRatios).map(ratio => (
                        <button key={ratio} onClick={() => promptMode === 'animation' ? setAnimationAspectRatio(ratio) : setGenerateAspectRatio(ratio)} className={`py-1.5 rounded-md font-semibold transition flex flex-col items-center justify-center gap-1 ${(promptMode === 'animation' ? animationAspectRatio : generateAspectRatio) === ratio ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>
                          <AspectRatioIcon ratio={ratio} className="w-5 h-5" />
                          <span>{ratio}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                {promptMode === 'generate' && (
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-300 mb-2">Number of Images ({numberOfImages})</label>
                        <input type="range" min="1" max="4" step="1" value={numberOfImages} onChange={e => setNumberOfImages(parseInt(e.target.value, 10))} disabled={isRandomMode} className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${isRandomMode ? 'bg-gray-600 cursor-not-allowed' : 'bg-gray-700 accent-yellow-400'}`} />
                    </div>
                )}
                <label className="block text-sm font-medium text-gray-300 mb-2">Prompt or Instruction</label>
                <div className="relative">
                    <textarea 
                        rows={4} 
                        className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 pr-10 text-gray-100 focus:ring-2 focus:ring-yellow-400" 
                        style={{ fontSize: `${promptFontSize}px` }}
                        value={prompt} 
                        onChange={(e) => { setPrompt(e.target.value); if (isRandomMode) setIsRandomMode(false); }} 
                        placeholder='e.g., "Colorize this photo"' 
                    />
                    <button onClick={handlePaste} disabled={isLoading} className="absolute top-2 right-10 p-1.5 text-gray-400 hover:text-yellow-400 bg-gray-800 rounded-md transition disabled:opacity-50" title="Paste & Replace"><PasteIcon className="h-5 w-5"/></button>
                    <button onClick={onTranslatePrompt} disabled={isLoading || !prompt.trim()} className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-yellow-400 bg-gray-800 rounded-md transition disabled:opacity-50" title="Translate"><TranslateIcon className="h-5 w-5"/></button>
                </div>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-300 mb-2">Ideas</h3>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={onGetCreativeIdeas} disabled={isLoading || !hasImage || promptMode === 'animation' || promptMode === 'generate'} className="flex items-center justify-center gap-2 text-xs p-2 rounded-md transition bg-gray-700 text-gray-100 hover:bg-gray-600 disabled:opacity-50"><LightbulbIcon className="h-5 w-5"/><span>Inspire Me</span></button>
                <button onClick={onAnalyzeImage} disabled={isLoading || !hasImage || promptMode === 'animation' || promptMode === 'generate'} className="flex items-center justify-center gap-2 text-xs p-2 rounded-md transition bg-gray-700 text-gray-100 hover:bg-gray-600 disabled:opacity-50"><WandIcon className="h-5 w-5"/><span>Analyze Image</span></button>
              </div>
            </div>
            <div>
                <div className="flex justify-between items-center mb-2">
                    <h3 className="text-sm font-medium text-gray-300 flex items-center"><WorkflowIcon className="w-5 h-5 mr-2" />Actions:</h3>
                    <button onClick={() => onOpenActionEditor(null)} disabled={isLoading} className="p-1.5 text-gray-400 hover:text-yellow-400 bg-gray-700 rounded-md transition disabled:opacity-50"><PlusIcon className="h-5 w-5"/></button>
                </div>
                <div className="space-y-2">
                  {actions.map(action => (
                      <div key={action.id} className="flex items-center space-x-1">
                          <button onClick={() => onRunAction(action)} disabled={isLoading || !hasImage} className="flex-grow text-xs text-left p-2 rounded-l-md transition truncate bg-gray-700 text-gray-100 hover:bg-gray-600 flex items-center space-x-2"><PlayIcon className="h-4 w-4 flex-shrink-0" /><span className="truncate">{action.name}</span></button>
                          <button onClick={() => onOpenActionEditor(action)} className="bg-gray-600 p-2 hover:bg-yellow-400 hover:text-gray-900 transition"><EditIcon className="h-4 w-4"/></button>
                          <button onClick={() => onDeleteAction(action.id)} className="bg-gray-600 p-2 rounded-r-md hover:bg-red-500 transition"><TrashIcon className="h-4 w-4"/></button>
                      </div>
                  ))}
                </div>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-300 mb-2">Presets:</h3>
              <div className="grid grid-cols-1 gap-2">
                {currentPresets.map((p) => (
                  <div key={p.id} className="flex items-center space-x-1">
                    <button onClick={() => handleSmartPresetClick(p)} className={`flex-grow text-xs text-left p-2 rounded-l-md transition truncate ${prompt === p.prompt ? 'bg-yellow-400 text-gray-900 font-semibold' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`} disabled={isLoading || (promptMode !== 'generate' && !hasImage)}>{getPromptDisplayName(p.id)}</button>
                    <button onClick={() => setPrompt(current => current ? `${current}, ${p.prompt}` : p.prompt)} className="bg-gray-600 p-2 rounded-r-md hover:bg-yellow-400 hover:text-gray-900 transition" disabled={isLoading}><PlusIcon className="h-4 w-4"/></button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {appMode === 'analyze' && (
          <div className="space-y-4">
            <input type="file" ref={analysisFileInputRef} onChange={handleAnalysisFilesSelected} className="hidden" multiple accept="image/*" />
            <button onClick={handleAnalysisUploadClick} className="w-full flex items-center justify-center bg-gray-700 text-gray-200 font-semibold py-3 px-4 rounded-lg hover:bg-gray-600 transition"><UploadIcon className="w-5 h-5 mr-2" />Upload Images</button>
            <div className="flex-grow flex flex-col space-y-4 overflow-y-auto max-h-[50vh]">
                <h2 className="text-base font-semibold text-gray-300 border-b border-gray-700 pb-2">Analysis Queue ({analysisItems.length})</h2>
                {analysisItems.map(item => (
                    <div key={item.id} onClick={() => onSelectAnalysisItem(item)} className={`flex items-center space-x-3 p-2 rounded-md transition-colors cursor-pointer ${selectedAnalysisItem?.id === item.id ? 'bg-yellow-400/20' : 'hover:bg-gray-700/50'}`}>
                        {getStatusIcon(item.status)}
                        <img src={item.originalDataUrl} alt={item.file.name} className="w-10 h-10 object-cover rounded" />
                        <p className="text-xs text-gray-100 truncate flex-grow" title={item.file.name}>{item.file.name}</p>
                        <button onClick={(e) => { e.stopPropagation(); onRemoveAnalysisItem(item.id); }} className="p-1 text-gray-400 hover:text-red-400"><XIcon className="w-4 h-4" /></button>
                    </div>
                ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-auto pt-6 flex-shrink-0">
          {appMode !== 'analyze' && (
              <>
                <button onClick={onRestore} disabled={isLoading || !prompt.trim() || (promptMode !== 'generate' && !hasImage) || isQuotaLimited || isEditing || isMasking} className="w-full flex items-center justify-center bg-yellow-400 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-yellow-300 disabled:opacity-40 transition">{isLoading ? <SpinnerIcon className="h-6 w-6 animate-spin" /> : <RestoreIcon className="h-6 w-6 mr-2" />}{getButtonText()}</button>
                <button onClick={onReset} disabled={isLoading || !hasImage || isProcessingOriginal || isEditing || isMasking} className="w-full mt-2 flex items-center justify-center bg-gray-700 text-gray-300 font-bold py-2 px-4 rounded-lg hover:bg-gray-600 disabled:opacity-40 transition"><ResetIcon className="h-5 w-5 mr-2" />Reset to Original</button>
              </>
          )}
          {appMode === 'analyze' && (
            <div className="space-y-2">
                <button onClick={onStartAnalysis} disabled={isBatchAnalyzing || analysisItems.filter(i => i.status === 'pending').length === 0 || isQuotaLimited} className="w-full flex items-center justify-center bg-yellow-400 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-yellow-300 disabled:opacity-40 transition">{runningAnalysisType === 'analysis' ? <SpinnerIcon className="h-6 w-6 animate-spin" /> : <RestoreIcon className="h-6 w-6 mr-2" />}{runningAnalysisType === 'analysis' ? getAnalysisButtonText() : 'Start Analysis'}</button>
                <button onClick={onStartAiDetection} disabled={isBatchAnalyzing || analysisItems.filter(i => i.status === 'pending').length === 0 || isQuotaLimited} className="w-full flex items-center justify-center bg-yellow-400 text-gray-900 font-bold py-3 px-4 rounded-lg hover:bg-yellow-300 disabled:opacity-40 transition">{runningAnalysisType === 'detection' ? <SpinnerIcon className="h-5 w-5 animate-spin mr-2" /> : <DetectIcon className="h-5 w-5 mr-2" />}{runningAnalysisType === 'detection' ? 'Processing...' : 'AI Detection'}</button>
                <button onClick={onExportAnalysisResults} disabled={isBatchAnalyzing || analysisItems.filter(i => i.status === 'completed' || i.status === 'error').length === 0} className="w-full flex items-center justify-center bg-gray-600 text-gray-200 font-semibold py-2 px-4 rounded-lg hover:bg-gray-500 disabled:opacity-40 transition"><DownloadIcon className="h-5 w-5 mr-2" />Export Results</button>
                 <button onClick={onClearAnalysis} disabled={isBatchAnalyzing || analysisItems.length === 0} className="w-full flex items-center justify-center bg-gray-700 text-gray-300 font-bold py-2 px-4 rounded-lg hover:bg-red-600 hover:text-white disabled:opacity-40 transition"><ClearIcon className="h-5 w-5 mr-2" />Clear All</button>
            </div>
          )}
      </div>
    </div>
  );
};
export default LeftPanel;
