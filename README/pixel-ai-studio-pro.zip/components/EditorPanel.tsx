import React, { useState, useRef, useEffect, useCallback } from 'react';
import { EditState, FilterType, CropBox } from '../types';
import { AI_FILTER_PRESETS } from '../constants';
import { SlidersIcon } from './icons/SlidersIcon';
import { FilterIcon } from './icons/FilterIcon';
import { RotateLeft90Icon } from './icons/RotateLeft90Icon';
import { RotateRight90Icon } from './icons/RotateRight90Icon';
import { FlipIcon } from './icons/FlipIcon';
import { StraightenIcon } from './icons/StraightenIcon';
import { ResetIcon } from './icons/ResetIcon';
import { CheckIcon } from './icons/CheckIcon';
import { XIcon } from './icons/XIcon';
import { WandIcon } from './icons/WandIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { CropIcon } from './icons/CropIcon';
import { ExpandIcon } from './icons/ExpandIcon';

interface EditorPanelProps {
  imageUrl: string;
  mimeType: string;
  onConfirm: (editedDataUrl: string) => void;
  onCancel: () => void;
  onApplyAiFilter: (base64Data: string, mimeType: string, filterId: string) => Promise<string | null>;
  onApplyOutpaint: (base64Data: string, mimeType: string) => Promise<string | null>;
}

const initialEditState: EditState = {
  rotation: 0,
  scaleX: 1,
  straightenAngle: 0,
  filter: { type: 'none', intensity: 100 },
  activeSubTool: 'none',
};

type ActiveTab = 'transform' | 'filters';

type DragHandle = 'tl' | 'tm' | 'tr' | 'ml' | 'mr' | 'bl' | 'bm' | 'br' | 'box';
type DragInfo = {
  handle: DragHandle;
  startX: number;
  startY: number;
  initialBox: CropBox;
};

const aiFilterDisplayNames: Record<string, string> = {
  ai_filter_watercolor: 'Watercolor',
  ai_filter_oil_painting: 'Oil Painting',
  ai_filter_pencil_sketch: 'Pencil Sketch',
  ai_filter_anime: 'Anime Style',
};


export const EditorPanel: React.FC<EditorPanelProps> = ({ imageUrl, mimeType, onConfirm, onCancel, onApplyAiFilter, onApplyOutpaint }) => {
  const [editState, setEditState] = useState<EditState>(initialEditState);
  const [activeTab, setActiveTab] = useState<ActiveTab>('transform');
  const [isAiFiltering, setIsAiFiltering] = useState(false);
  const [isOutpainting, setIsOutpainting] = useState(false);
  const [cropBox, setCropBox] = useState<CropBox | null>(null);
  const [dragInfo, setDragInfo] = useState<DragInfo | null>(null);
  const [padding, setPadding] = useState({ top: 0, right: 0, bottom: 0, left: 0 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(new Image());
  const containerRef = useRef<HTMLDivElement>(null);
  const HANDLE_SIZE = 10;
  
  const [currentImageUrl, setCurrentImageUrl] = useState(imageUrl);

  useEffect(() => {
    setCurrentImageUrl(imageUrl);
    setEditState(initialEditState);
  }, [imageUrl]);

  const getCanvasScale = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !canvas.width) return 1;
    return canvas.clientWidth / canvas.width;
  }, []);

  const drawCropUI = useCallback((ctx: CanvasRenderingContext2D, box: CropBox) => {
    const canvas = ctx.canvas;
    const scale = getCanvasScale();
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, canvas.width, box.y);
    ctx.fillRect(0, box.y + box.height, canvas.width, canvas.height - (box.y + box.height));
    ctx.fillRect(0, box.y, box.x, box.height);
    ctx.fillRect(box.x + box.width, box.y, canvas.width - (box.x + box.width), box.height);

    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 1 / scale;
    ctx.setLineDash([5 / scale, 3 / scale]);
    ctx.strokeRect(box.x, box.y, box.width, box.height);
    ctx.restore();
    
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 1 / scale;
    ctx.setLineDash([]); 

    ctx.beginPath();
    ctx.moveTo(box.x + box.width / 3, box.y);
    ctx.lineTo(box.x + box.width / 3, box.y + box.height);
    ctx.moveTo(box.x + (2 * box.width) / 3, box.y);
    ctx.lineTo(box.x + (2 * box.width) / 3, box.y + box.height);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(box.x, box.y + box.height / 3);
    ctx.lineTo(box.x + box.width, box.y + box.height / 3);
    ctx.moveTo(box.x, box.y + (2 * box.height) / 3);
    ctx.lineTo(box.x + box.width, box.y + (2 * box.height) / 3);
    ctx.stroke();
    ctx.restore();

    ctx.fillStyle = 'white';
    const handleSize = HANDLE_SIZE / scale;

    const handles = {
        tl: { x: box.x, y: box.y },
        tm: { x: box.x + box.width / 2, y: box.y },
        tr: { x: box.x + box.width, y: box.y },
        ml: { x: box.x, y: box.y + box.height / 2 },
        mr: { x: box.x + box.width, y: box.y + box.height / 2 },
        bl: { x: box.x, y: box.y + box.height },
        bm: { x: box.x + box.width / 2, y: box.y + box.height },
        br: { x: box.x + box.width, y: box.y + box.height },
    };

    Object.values(handles).forEach(pos => {
        ctx.fillRect(pos.x - handleSize / 2, pos.y - handleSize / 2, handleSize, handleSize);
    });
  }, [getCanvasScale]);

  const drawImage = useCallback(() => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image.src || image.naturalWidth === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const isOutpaintingMode = editState.activeSubTool === 'outpaint';
    const newWidth = image.naturalWidth + padding.left + padding.right;
    const newHeight = image.naturalHeight + padding.top + padding.bottom;
    
    canvas.width = isOutpaintingMode ? newWidth : image.naturalWidth;
    canvas.height = isOutpaintingMode ? newHeight : image.naturalHeight;

    ctx.save();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    let filterString = '';
    switch(editState.filter.type) {
        case 'sepia': filterString = `sepia(${editState.filter.intensity}%)`; break;
        case 'grayscale': filterString = `grayscale(${editState.filter.intensity}%)`; break;
        case 'vintage': filterString = `sepia(${editState.filter.intensity * 0.7}%) contrast(1.1) brightness(0.9)`; break;
    }
    ctx.filter = filterString;
    
    const drawX = isOutpaintingMode ? padding.left : 0;
    const drawY = isOutpaintingMode ? padding.top : 0;

    if (isOutpaintingMode) {
        ctx.drawImage(image, drawX, drawY);
    } else {
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((editState.rotation * Math.PI) / 180);
        ctx.rotate((editState.straightenAngle * Math.PI) / 180);
        ctx.scale(editState.scaleX, 1);
        ctx.drawImage(image, -image.naturalWidth / 2, -image.naturalHeight / 2);
    }


    ctx.restore();

    if (editState.activeSubTool === 'crop' && cropBox) {
        drawCropUI(ctx, cropBox);
    }
  }, [editState, cropBox, drawCropUI, padding]);

  useEffect(() => {
    const image = imageRef.current;
    image.crossOrigin = 'anonymous';
    image.onload = () => {
        drawImage();
    };
    image.src = currentImageUrl;
  }, [currentImageUrl, drawImage]);

  useEffect(() => {
    drawImage();
  }, [editState, padding, drawImage]);
  
  const handleReset = () => {
    setEditState(initialEditState);
    setCurrentImageUrl(imageUrl);
    setPadding({ top: 0, right: 0, bottom: 0, left: 0 });
  };

  const handleApplyAiFilter = async (filterId: string) => {
    const preset = AI_FILTER_PRESETS.find(p => p.id === filterId);
    if (!preset || !canvasRef.current) return;

    setIsAiFiltering(true);
    try {
        const currentCanvasData = canvasRef.current.toDataURL(mimeType);
        const base64Data = currentCanvasData.split(',')[1];
        
        const newImageDataUrl = await onApplyAiFilter(base64Data, mimeType, filterId);

        if (newImageDataUrl) {
            setEditState(initialEditState);
            setCurrentImageUrl(newImageDataUrl);
        }
    } catch (e) {
        console.error("Failed to apply AI filter", e);
    } finally {
        setIsAiFiltering(false);
    }
  };

  const handleGenerateOutpaint = async () => {
    if (!canvasRef.current) return;
    
    setIsOutpainting(true);
    try {
        const paddedCanvasData = canvasRef.current.toDataURL('image/png');
        const base64Data = paddedCanvasData.split(',')[1];
        
        const newImageDataUrl = await onApplyOutpaint(base64Data, 'image/png');
        
        if (newImageDataUrl) {
            setEditState(initialEditState);
            setPadding({ top: 0, right: 0, bottom: 0, left: 0 });
            setCurrentImageUrl(newImageDataUrl);
        }
    } catch (e) {
        console.error("Failed to apply outpainting", e);
    } finally {
        setIsOutpainting(false);
    }
  };
  
  const handleConfirm = () => {
    if(canvasRef.current) {
        onConfirm(canvasRef.current.toDataURL('image/png'));
    }
  };

  const startCropping = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setEditState(s => ({ ...s, activeSubTool: 'crop' }));
    const padding = 0.1;
    setCropBox({
        x: canvas.width * padding,
        y: canvas.height * padding,
        width: canvas.width * (1 - padding * 2),
        height: canvas.height * (1 - padding * 2),
    });
  };

  const startOutpainting = () => {
    setEditState(s => ({ ...s, activeSubTool: 'outpaint' }));
    setPadding({ top: 0, right: 0, bottom: 0, left: 0 });
  };

  const cancelOutpainting = () => {
    setEditState(s => ({ ...s, activeSubTool: 'none' }));
    setPadding({ top: 0, right: 0, bottom: 0, left: 0 });
  };

  const applyCrop = () => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !cropBox || image.naturalWidth === 0) return;

    const transformedCanvas = document.createElement('canvas');
    const transformedCtx = transformedCanvas.getContext('2d');
    if (!transformedCtx) return;

    transformedCanvas.width = image.naturalWidth;
    transformedCanvas.height = image.naturalHeight;

    let filterString = '';
    switch (editState.filter.type) {
        case 'sepia': filterString = `sepia(${editState.filter.intensity}%)`; break;
        case 'grayscale': filterString = `grayscale(${editState.filter.intensity}%)`; break;
        case 'vintage': filterString = `sepia(${editState.filter.intensity * 0.7}%) contrast(1.1) brightness(0.9)`; break;
    }
    transformedCtx.filter = filterString;
    transformedCtx.translate(transformedCanvas.width / 2, transformedCanvas.height / 2);
    transformedCtx.rotate((editState.rotation * Math.PI) / 180);
    transformedCtx.rotate((editState.straightenAngle * Math.PI) / 180);
    transformedCtx.scale(editState.scaleX, 1);
    transformedCtx.drawImage(image, -image.naturalWidth / 2, -image.naturalHeight / 2);

    const finalCanvas = document.createElement('canvas');
    const finalCtx = finalCanvas.getContext('2d');
    if (!finalCtx) return;

    finalCanvas.width = cropBox.width;
    finalCanvas.height = cropBox.height;

    finalCtx.drawImage(
        transformedCanvas,
        cropBox.x, cropBox.y, cropBox.width, cropBox.height,
        0, 0, cropBox.width, cropBox.height
    );

    const croppedDataUrl = finalCanvas.toDataURL('image/png');
    setEditState(initialEditState);
    setCropBox(null);
    setCurrentImageUrl(croppedDataUrl);
  };

  const cancelCrop = () => {
    setEditState(s => ({ ...s, activeSubTool: 'none' }));
    setCropBox(null);
  };

  const getHandleAtPos = (x: number, y: number, box: CropBox): DragHandle | null => {
    const scale = getCanvasScale();
    const handleRadius = (HANDLE_SIZE / scale) / 2;

    const handles: { [key in DragHandle]: { x: number, y: number } } = {
        tl: { x: box.x, y: box.y },
        tm: { x: box.x + box.width / 2, y: box.y },
        tr: { x: box.x + box.width, y: box.y },
        ml: { x: box.x, y: box.y + box.height / 2 },
        mr: { x: box.x + box.width, y: box.y + box.height / 2 },
        bl: { x: box.x, y: box.y + box.height },
        bm: { x: box.x + box.width / 2, y: box.y + box.height },
        br: { x: box.x + box.width, y: box.y + box.height },
        box: {x: 0, y: 0} 
    };
    
    for (const key in handles) {
        if(key === 'box') continue;
        const handle = handles[key as Exclude<DragHandle, 'box'>];
        if (x > handle.x - handleRadius && x < handle.x + handleRadius &&
            y > handle.y - handleRadius && y < handle.y + handleRadius) {
            return key as DragHandle;
        }
    }

    if (x > box.x && x < box.x + box.width && y > box.y && y < box.y + box.height) {
        return 'box';
    }

    return null;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (editState.activeSubTool !== 'crop' || !cropBox) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;
    
    const handle = getHandleAtPos(mouseX, mouseY, cropBox);
    if (handle) {
      setDragInfo({
          handle,
          startX: e.clientX,
          startY: e.clientY,
          initialBox: { ...cropBox },
      });
    }
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!dragInfo || !cropBox) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const dx = e.clientX - dragInfo.startX;
    const dy = e.clientY - dragInfo.startY;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    let newBox = { ...dragInfo.initialBox };
    const { x, y, width, height } = dragInfo.initialBox;
    const scaledDx = dx * scaleX;
    const scaledDy = dy * scaleY;

    switch (dragInfo.handle) {
        case 'tl':
            newBox.x = Math.min(x + scaledDx, x + width - HANDLE_SIZE);
            newBox.y = Math.min(y + scaledDy, y + height - HANDLE_SIZE);
            newBox.width = width - (newBox.x - x);
            newBox.height = height - (newBox.y - y);
            break;
        case 'tr':
            newBox.width = Math.max(HANDLE_SIZE, width + scaledDx);
            newBox.y = Math.min(y + scaledDy, y + height - HANDLE_SIZE);
            newBox.height = height - (newBox.y - y);
            break;
        case 'bl':
            newBox.x = Math.min(x + scaledDx, x + width - HANDLE_SIZE);
            newBox.width = width - (newBox.x - x);
            newBox.height = Math.max(HANDLE_SIZE, height + scaledDy);
            break;
        case 'br':
            newBox.width = Math.max(HANDLE_SIZE, width + scaledDx);
            newBox.height = Math.max(HANDLE_SIZE, height + scaledDy);
            break;
        case 'tm':
            newBox.y = Math.min(y + scaledDy, y + height - HANDLE_SIZE);
            newBox.height = height - (newBox.y - y);
            break;
        case 'bm':
            newBox.height = Math.max(HANDLE_SIZE, height + scaledDy);
            break;
        case 'ml':
            newBox.x = Math.min(x + scaledDx, x + width - HANDLE_SIZE);
            newBox.width = width - (newBox.x - x);
            break;
        case 'mr':
            newBox.width = Math.max(HANDLE_SIZE, width + scaledDx);
            break;
        case 'box':
            newBox.x = x + scaledDx;
            newBox.y = y + scaledDy;
            break;
    }
    
    newBox.x = Math.max(0, Math.min(newBox.x, canvas.width - newBox.width));
    newBox.y = Math.max(0, Math.min(newBox.y, canvas.height - newBox.height));
    
    setCropBox(newBox);
  }, [dragInfo, cropBox]);

  const handleMouseUp = useCallback(() => {
    setDragInfo(null);
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  const sideLabels: Record<string, string> = { 
    top: 'Top (px)', 
    bottom: 'Bottom (px)', 
    left: 'Left (px)', 
    right: 'Right (px)'
  };

  const TabButton: React.FC<{ tab: ActiveTab; label: string; icon: React.ReactNode; children?: React.ReactNode }> = ({ tab, label, icon }) => (
    <button
      onClick={() => setActiveTab(tab)}
      disabled={editState.activeSubTool !== 'none'}
      className={`flex-1 py-2 px-3 text-sm font-semibold rounded-md flex items-center justify-center gap-2 transition ${activeTab === tab ? 'bg-yellow-400 text-gray-900' : 'text-gray-300 bg-gray-700 hover:bg-gray-600'} disabled:opacity-50 disabled:cursor-not-allowed`}
    >
      {icon} {label}
    </button>
  );

  return (
    <div className="w-full h-full flex bg-gray-900">
      <aside className="w-80 bg-gray-800 p-4 flex flex-col space-y-4 border-r border-gray-700">
        <h2 className="text-lg font-bold text-gray-200">Editing Mode</h2>
        
        {editState.activeSubTool !== 'none' ? (
          <div className="flex-grow flex flex-col justify-center items-center text-center p-4 bg-gray-900/50 rounded-lg">
            {editState.activeSubTool === 'crop' && (
              <>
                <h3 className="text-lg font-semibold mb-2">Crop</h3>
                <div className="flex gap-2">
                    <button onClick={cancelCrop} className="bg-gray-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-gray-500 transition flex items-center gap-2"><XIcon className="w-5 h-5"/>Cancel</button>
                    <button onClick={applyCrop} className="bg-yellow-400 text-gray-900 px-4 py-2 rounded-md font-bold hover:bg-yellow-300 transition flex items-center gap-2"><CheckIcon className="w-5 h-5"/>Apply</button>
                </div>
              </>
            )}
             {editState.activeSubTool === 'outpaint' && (
                <div className="w-full space-y-3">
                  <h3 className="text-base font-semibold text-gray-300">Outpaint Controls</h3>
                  {(['top', 'bottom', 'left', 'right'] as const).map(side => (
                    <div key={side}>
                       <label htmlFor={`padding-${side}`} className="block text-sm font-medium text-gray-300 mb-1 capitalize">{sideLabels[side]}</label>
                       <input 
                         id={`padding-${side}`}
                         type="number" 
                         value={padding[side]} 
                         onChange={e => setPadding(p => ({...p, [side]: Math.max(0, parseInt(e.target.value) || 0)}))}
                         className="w-full bg-gray-900 border border-gray-600 rounded-md p-1.5 text-gray-100 focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition"
                       />
                    </div>
                  ))}
                  <button onClick={handleGenerateOutpaint} disabled={isOutpainting} className="w-full mt-2 bg-yellow-400 text-gray-900 px-4 py-2 rounded-md font-bold hover:bg-yellow-300 transition flex items-center justify-center gap-2 disabled:opacity-50">
                    {isOutpainting ? <SpinnerIcon className="w-5 h-5 animate-spin"/> : <WandIcon className="w-5 h-5"/>}
                    Generate Outpaint
                  </button>
                  <button onClick={cancelOutpainting} className="w-full bg-gray-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-gray-500 transition flex items-center justify-center gap-2"><XIcon className="w-5 h-5"/>Cancel</button>
                </div>
            )}
          </div>
        ) : (
        <div className="flex-grow flex flex-col space-y-4 overflow-y-auto">
            <div className="flex gap-2 p-1 bg-gray-900 rounded-lg">
                <TabButton tab="transform" label="Transform" icon={<SlidersIcon className="w-5 h-5"/>} />
                <TabButton tab="filters" label="Filters" icon={<FilterIcon className="w-5 h-5"/>} />
            </div>

            {activeTab === 'transform' && (
                <div className="space-y-4">
                    <h3 className="text-base font-semibold text-gray-300">Transform</h3>
                    <div className="grid grid-cols-2 gap-2">
                        <button onClick={startCropping} className="bg-gray-700 p-2 rounded-md flex items-center justify-center gap-2 hover:bg-gray-600 transition"><CropIcon className="w-5 h-5"/>Crop</button>
                        <button onClick={startOutpainting} className="bg-gray-700 p-2 rounded-md flex items-center justify-center gap-2 hover:bg-gray-600 transition"><ExpandIcon className="w-5 h-5"/>Outpaint</button>
                        <button onClick={() => setEditState(s => ({...s, rotation: (s.rotation - 90) % 360}))} className="bg-gray-700 p-2 rounded-md flex items-center justify-center gap-2 hover:bg-gray-600 transition"><RotateLeft90Icon className="w-5 h-5"/>Rotate Left</button>
                        <button onClick={() => setEditState(s => ({...s, rotation: (s.rotation + 90) % 360}))} className="bg-gray-700 p-2 rounded-md flex items-center justify-center gap-2 hover:bg-gray-600 transition"><RotateRight90Icon className="w-5 h-5"/>Rotate Right</button>
                        <button onClick={() => setEditState(s => ({...s, scaleX: s.scaleX * -1}))} className="bg-gray-700 p-2 rounded-md flex items-center justify-center gap-2 hover:bg-gray-600 transition"><FlipIcon className="w-5 h-5"/>Flip Horizontal</button>
                    </div>
                    <div>
                        <label htmlFor="straighten-slider" className="block text-sm font-medium text-gray-300 mb-2 flex items-center gap-2"><StraightenIcon className="w-5 h-5"/>Straighten ({editState.straightenAngle.toFixed(1)}°)</label>
                        <input id="straighten-slider" type="range" min="-20" max="20" step="0.1" value={editState.straightenAngle} onChange={e => setEditState(s => ({...s, straightenAngle: parseFloat(e.target.value)}))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-400"/>
                    </div>
                </div>
            )}

            {activeTab === 'filters' && (
                <div className="space-y-4">
                     <div className="space-y-3">
                        <h3 className="text-base font-semibold text-gray-300">Standard Filters</h3>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            {(['none', 'sepia', 'grayscale', 'vintage'] as FilterType[]).map(f => (
                                <button key={f} onClick={() => setEditState(s => ({...s, filter: {...s.filter, type: f}}))} className={`py-2 rounded-md font-semibold transition ${editState.filter.type === f ? 'bg-yellow-400 text-gray-900' : 'bg-gray-700 text-gray-100 hover:bg-gray-600'}`}>{f.charAt(0).toUpperCase() + f.slice(1)}</button>
                            ))}
                        </div>
                        {editState.filter.type !== 'none' && (
                             <div>
                                <label htmlFor="filter-intensity-slider" className="block text-sm font-medium text-gray-300 mb-2">Intensity ({editState.filter.intensity}%)</label>
                                <input id="filter-intensity-slider" type="range" min="0" max="100" value={editState.filter.intensity} onChange={e => setEditState(s => ({...s, filter: {...s.filter, intensity: parseInt(e.target.value, 10)}}))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-yellow-400"/>
                            </div>
                        )}
                    </div>
                    <div className="space-y-3">
                        <h3 className="text-base font-semibold text-gray-300 flex items-center gap-2"><WandIcon className="w-5 h-5 text-yellow-300"/>AI Artistic Filters</h3>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                            {AI_FILTER_PRESETS.map(preset => (
                                <button key={preset.id} onClick={() => handleApplyAiFilter(preset.id)} className="bg-gray-700 text-gray-100 p-2 rounded-md hover:bg-gray-600 transition disabled:opacity-50" disabled={isAiFiltering}>
                                    {isAiFiltering ? <SpinnerIcon className="w-4 h-4 animate-spin mx-auto"/> : aiFilterDisplayNames[preset.id] || preset.id}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
        )}

        <div className="mt-auto pt-4 border-t border-gray-700 space-y-2">
          <button onClick={handleReset} className="w-full flex items-center justify-center bg-gray-600 text-gray-200 font-semibold py-2 px-4 rounded-lg hover:bg-gray-500 transition"><ResetIcon className="w-5 h-5 mr-2"/>Reset All</button>
          <div className="flex gap-2">
            <button onClick={onCancel} className="flex-1 bg-gray-700 text-white px-4 py-2 rounded-md font-semibold hover:bg-gray-600 transition">Cancel</button>
            <button onClick={handleConfirm} className="flex-1 bg-yellow-400 text-gray-900 px-4 py-2 rounded-md font-bold hover:bg-yellow-300 transition">Confirm</button>
          </div>
        </div>
      </aside>
      <main ref={containerRef} className="flex-grow flex items-center justify-center p-4 bg-black/50 overflow-hidden relative" onMouseDown={handleMouseDown}>
        <canvas ref={canvasRef} className="max-w-full max-h-full object-contain"></canvas>
      </main>
    </div>
  );
};