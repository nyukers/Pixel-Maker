
import React, { useState } from 'react';
import { DetectionBox, ComparisonMode, ResultItem, PromptMode, AnalysisItem } from '../types';
import { ImageIcon } from './icons/ImageIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import BottomToolbar from './BottomToolbar';
import { SearchIcon } from './icons/SearchIcon';
import ComparisonSlider from './ComparisonSlider';

const DetectionOverlay: React.FC<{ boxes: DetectionBox[] }> = ({ boxes }) => {
  if (boxes.length === 0) return null;
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none z-40" viewBox="0 0 1000 1000" preserveAspectRatio="none">
      {boxes.map((box, i) => {
        const [ymin, xmin, ymax, xmax] = box.box_2d;
        return (
          <g key={i}>
            <rect x={xmin} y={ymin} width={xmax - xmin} height={ymax - ymin} fill="none" stroke="#fbbf24" strokeWidth="4" className="animate-pulse" />
            <rect x={xmin} y={ymin - 25} width={box.label.length * 10 + 20} height="25" fill="#fbbf24" />
            <text x={xmin + 5} y={ymin - 7} fill="#111827" fontSize="16" fontWeight="bold">{box.label}</text>
          </g>
        );
      })}
    </svg>
  );
};

interface CenterPanelProps {
  appMode: any; beforeImage: any; afterImage: any; comparisonMode: ComparisonMode; setComparisonMode: any;
  isLoading: boolean; loadingMessage: string; hasImage: boolean;
  isMasking: boolean; setIsMasking: any; isEditing: boolean; setIsEditing: any;
  onImageMasked: (mask: string) => void; isSpotting: boolean; setIsSpotting: any;
  detectedObjects: DetectionBox[]; onSpotRequest: (s: string) => void;
  selectedResult: ResultItem | null; promptMode: PromptMode;
  selectedAnalysisItem: AnalysisItem | null;
}

const CenterPanel: React.FC<CenterPanelProps> = ({
  appMode, beforeImage, afterImage, comparisonMode, setComparisonMode, isLoading, loadingMessage,
  hasImage, isMasking, setIsMasking, isEditing, setIsEditing, isSpotting, setIsSpotting,
  detectedObjects, onSpotRequest, selectedResult, promptMode, selectedAnalysisItem
}) => {
  const [spotQuery, setSpotQuery] = useState('');
  const [zoom, setZoom] = useState(1);

  const handleSetZoom = (z: number | 'fit' | 'fit-h') => {
      if (typeof z === 'number') {
          setZoom(z);
      } else {
          // Simplistic fit implementation for now. 
          // Ideally needs container/image dimensions calculation.
          setZoom(1); 
      }
  };

  return (
    <div className="flex-grow flex flex-col items-center justify-center bg-gray-900/50 relative overflow-hidden">
      {isLoading && (
        <div className="absolute inset-0 bg-black/70 z-50 flex flex-col items-center justify-center">
          <SpinnerIcon className="w-12 h-12 text-yellow-400 animate-spin" />
          <p className="mt-4 text-lg text-gray-200">{loadingMessage}</p>
        </div>
      )}
      
      {!hasImage ? (
        <div className="text-center text-gray-400">
          <ImageIcon className="w-16 h-16 mx-auto mb-4 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-300">Welcome to Pixel AI Studio</h2>
        </div>
      ) : (
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden p-8">
          {comparisonMode === 'slider' && beforeImage && afterImage ? (
            <ComparisonSlider before={beforeImage} after={afterImage} zoom={zoom} pan={{x:0, y:0}} beforeImageDimensions={null} afterImageDimensions={null} onPanMouseDown={()=>{}} isPanning={false} />
          ) : (
            <div 
                className="relative max-w-full max-h-full flex items-center justify-center shadow-2xl rounded-lg overflow-hidden group transition-transform duration-200 ease-out"
                style={{ transform: `scale(${zoom})` }}
            >
                {afterImage && <img src={afterImage} alt="Main Preview" className="max-w-full max-h-full object-contain" />}
                {isSpotting && <DetectionOverlay boxes={detectedObjects} />}
            </div>
          )}

          {isSpotting && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center bg-gray-800/95 p-2 rounded-xl border border-yellow-400/50 shadow-2xl backdrop-blur-md">
                <input 
                  autoFocus placeholder="Find what? (e.g. dogs)" 
                  className="bg-transparent border-none focus:ring-0 text-sm text-white w-48 px-3"
                  value={spotQuery} onChange={e => setSpotQuery(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && onSpotRequest?.(spotQuery)}
                />
                <button onClick={() => onSpotRequest?.(spotQuery)} className="bg-yellow-400 p-2 rounded-lg hover:bg-yellow-300 transition-colors ml-2">
                  <SearchIcon className="w-4 h-4 text-gray-900" />
                </button>
            </div>
          )}
        </div>
      )}

      <BottomToolbar
        isEditing={isEditing} setIsEditing={setIsEditing} isMasking={isMasking} setIsMasking={setIsMasking}
        zoom={zoom} handleSetZoom={handleSetZoom} hasImage={hasImage} selectedResult={selectedResult}
        isSpotting={isSpotting} setIsSpotting={setIsSpotting}
        comparisonMode={comparisonMode} setComparisonMode={setComparisonMode}
        beforeImage={beforeImage} promptMode={promptMode}
      />
    </div>
  );
};

export default CenterPanel;
