
import React from 'react';
import { ResultItem, AnalysisItem, AppMode } from '../types';
import { DownloadIcon } from './icons/DownloadIcon';
import { ClearIcon } from './icons/ClearIcon';
import { SendToBackIcon } from './icons/SendToBackIcon';
import { UpscaleIcon } from './icons/UpscaleIcon';
import { TrashIcon } from './icons/TrashIcon';
import { FrameIcon } from './icons/FrameIcon';
import { HighDefIcon } from './icons/HighDefIcon';
import { AnalysisIcon } from './icons/AnalysisIcon';
import { DetectIcon } from './icons/DetectIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface RightPanelProps {
  results: ResultItem[];
  selectedResultId: string | null;
  onSelectResult: (result: ResultItem) => void;
  onUseAsSource: (result: ResultItem) => void;
  onDownloadResult: (result: ResultItem) => void;
  onUpscaleResult: (result: ResultItem) => void;
  onUpscaleResult4K?: (result: ResultItem) => void;
  onDeleteResult: (result: ResultItem) => void;
  onClearAll: () => void;
  isLoading: boolean;
  onExportFrame: (result: ResultItem) => void;
  useProModel?: boolean;
  appMode: AppMode;
  selectedAnalysisItem: AnalysisItem | null;
}

const RightPanel: React.FC<RightPanelProps> = ({
  results,
  selectedResultId,
  onSelectResult,
  onUseAsSource,
  onDownloadResult,
  onUpscaleResult,
  onUpscaleResult4K,
  onDeleteResult,
  onClearAll,
  isLoading,
  onExportFrame,
  useProModel,
  appMode,
  selectedAnalysisItem
}) => {
  if (appMode === 'analyze') {
    return (
      <div className="w-1/4 max-w-xs flex flex-col bg-gray-800 p-5 border-l border-gray-700 flex-shrink-0 overflow-y-auto">
        <div className="flex items-center space-x-3 mb-6">
            <AnalysisIcon className="w-6 h-6 text-yellow-400" />
            <h2 className="text-xl font-bold text-gray-200">Analysis Report</h2>
        </div>

        {!selectedAnalysisItem ? (
          <div className="flex-grow flex flex-col items-center justify-center text-center p-4">
             <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mb-4 opacity-50">
                <AnalysisIcon className="w-8 h-8 text-gray-400" />
             </div>
             <p className="text-gray-400 text-sm italic">Select an image from the queue to view details.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Image Info Summary */}
            <div className="bg-gray-900/50 p-3 rounded-lg border border-gray-700">
                <p className="text-xs font-mono text-yellow-400 truncate mb-1" title={selectedAnalysisItem.file.name}>{selectedAnalysisItem.file.name}</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-tighter">{selectedAnalysisItem.mimeType} • {(selectedAnalysisItem.file.size / 1024 / 1024).toFixed(2)} MB</p>
            </div>

            {selectedAnalysisItem.analysisResult ? (
              <div className="space-y-5 animate-in fade-in slide-in-from-right-4 duration-300">
                <section>
                    <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2 border-b border-gray-700 pb-1">Core Subject</h3>
                    <p className="text-sm text-gray-100 leading-relaxed font-medium">{selectedAnalysisItem.analysisResult.subject}</p>
                </section>

                <section>
                    <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2 border-b border-gray-700 pb-1">Style & Aesthetics</h3>
                    <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Art Style:</span>
                            <span className="text-gray-200 text-right ml-2">{selectedAnalysisItem.analysisResult.style}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Composition:</span>
                            <span className="text-gray-200 text-right ml-2">{selectedAnalysisItem.analysisResult.composition}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                            <span className="text-gray-400">Mood:</span>
                            <span className="text-gray-200 text-right ml-2">{selectedAnalysisItem.analysisResult.mood}</span>
                        </div>
                    </div>
                </section>

                <section>
                    <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2 border-b border-gray-700 pb-1">Technical Spec</h3>
                    <div className="grid grid-cols-2 gap-2">
                        <div className="bg-gray-900/40 p-2 rounded">
                            <p className="text-[10px] text-gray-500 uppercase">Angle</p>
                            <p className="text-xs text-gray-200">{selectedAnalysisItem.analysisResult.camera?.angle || 'N/A'}</p>
                        </div>
                        <div className="bg-gray-900/40 p-2 rounded">
                            <p className="text-[10px] text-gray-500 uppercase">Framing</p>
                            <p className="text-xs text-gray-200">{selectedAnalysisItem.analysisResult.camera?.framing || 'N/A'}</p>
                        </div>
                    </div>
                </section>
              </div>
            ) : selectedAnalysisItem.status === 'processing' ? (
              <div className="flex flex-col items-center py-10">
                  <SpinnerIcon className="w-8 h-8 text-yellow-400 animate-spin mb-3" />
                  <p className="text-sm text-gray-400">Decoding visual data...</p>
              </div>
            ) : (
               <div className="p-4 bg-gray-900/30 rounded-lg text-center">
                  <p className="text-xs text-gray-500 italic">No analysis data. Click "Start Analysis" in the left panel.</p>
               </div>
            )}

            {selectedAnalysisItem.aiDetectionResult && (
              <div className="mt-8 pt-6 border-t border-gray-700 animate-in fade-in duration-500">
                <div className="flex items-center space-x-2 mb-4">
                    <DetectIcon className="w-5 h-5 text-red-400" />
                    <h3 className="text-xs font-black text-red-400 uppercase tracking-widest">AI Integrity Score</h3>
                </div>
                
                <div className="flex items-end justify-between mb-2">
                    <span className="text-3xl font-bold text-gray-100">{selectedAnalysisItem.aiDetectionResult.score}%</span>
                    <span className="text-[10px] text-gray-500 font-mono uppercase mb-1">Probability</span>
                </div>

                <div className="w-full h-2.5 bg-gray-700 rounded-full overflow-hidden mb-4 shadow-inner">
                    <div 
                        className={`h-full transition-all duration-1000 ease-out ${selectedAnalysisItem.aiDetectionResult.score > 50 ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]' : 'bg-green-500'}`} 
                        style={{ width: `${selectedAnalysisItem.aiDetectionResult.score}%` }}
                    ></div>
                </div>

                <p className="text-xs text-gray-300 italic mb-4 leading-relaxed bg-gray-900/50 p-3 rounded-lg border-l-2 border-red-500">
                    "{selectedAnalysisItem.aiDetectionResult.assessment}"
                </p>

                <div className="flex flex-wrap gap-1.5">
                    {selectedAnalysisItem.aiDetectionResult.indicators.map((ind, i) => (
                        <span key={i} className="text-[10px] font-semibold bg-gray-700 text-gray-300 px-2 py-1 rounded shadow-sm border border-gray-600">
                            {ind}
                        </span>
                    ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-1/4 max-w-xs flex flex-col bg-gray-800 p-4 border-l border-gray-700 flex-shrink-0">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-300 whitespace-nowrap">History</h2>
      </div>
      <div className="flex-grow overflow-y-auto space-y-3 pr-2 -mr-2">
        {results.length === 0 ? (
          <p className="text-gray-400 text-sm mt-4 text-center">Your generated images and edits will appear here.</p>
        ) : (
          results.map((result) => {
            const isVideo = !!result.videoUrl;
            const isUpscaled = !!result.isUpscaled;
            return (
              <div
                key={result.id}
                onClick={() => onSelectResult(result)}
                title="Click to view this result in the main panel"
                className={`relative group rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                  selectedResultId === result.id ? 'border-yellow-400 shadow-lg' : 'border-transparent hover:border-gray-600'
                }`}
              >
                <img 
                  src={result.imageUrl} 
                  alt="Restored image thumbnail" 
                  className="w-full h-auto object-cover" 
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                {result.width && result.height && (
                  <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 rounded px-1.5 py-0.5 text-[10px] text-gray-200 pointer-events-none font-mono">
                      {result.width} x {result.height}
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-2 backdrop-blur-sm">
                  <p className="text-xs text-gray-100 truncate" title={result.prompt}>
                      {result.prompt}
                  </p>
                </div>
                <div className="absolute top-2 right-2 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={(e) => { e.stopPropagation(); onUseAsSource(result); }} title="Use as Source" className="bg-gray-900/50 p-2 rounded-full text-gray-100 hover:bg-yellow-400 hover:text-gray-900 transition-all"><SendToBackIcon className="w-5 h-5" /></button>
                    <button onClick={(e) => { e.stopPropagation(); onUpscaleResult(result); }} title="AI Upscale 2x" disabled={isVideo || isUpscaled} className="bg-gray-900/50 p-2 rounded-full text-gray-100 hover:bg-yellow-400 hover:text-gray-900 transition-all disabled:opacity-30"><UpscaleIcon className="w-5 h-5" /></button>
                    <button onClick={(e) => { e.stopPropagation(); onDownloadResult(result); }} title="Download" className="bg-gray-900/50 p-2 rounded-full text-gray-100 hover:bg-yellow-400 hover:text-gray-900 transition-all"><DownloadIcon className="w-5 h-5" /></button>
                    <button onClick={(e) => { e.stopPropagation(); onDeleteResult(result); }} title="Delete" className="bg-gray-900/50 p-2 rounded-full text-gray-100 hover:bg-red-500 hover:text-white transition-all"><TrashIcon className="w-5 h-5" /></button>
                </div>
              </div>
            )
          })
        )}
      </div>
      <div className="mt-4 pt-4 border-t border-gray-700 space-y-3">
        <button
          onClick={onClearAll}
          disabled={results.length === 0}
          className="w-full flex items-center justify-center bg-gray-700 text-gray-300 font-bold py-2 px-4 rounded-lg hover:bg-red-600 hover:text-white transition"
        >
          <ClearIcon className="h-5 w-5 mr-2" />
          Clear All
        </button>
      </div>
    </div>
  );
};

export default RightPanel;
