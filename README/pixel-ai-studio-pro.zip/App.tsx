
import React, { useState, useCallback } from 'react';
import { ResultItem, ComparisonMode, PromptMode, AnalysisItem, AppMode, AspectRatio, DetectionBox, Action, LoadedPreset, PresetPrompt, CreativeIdea } from './types';
import { restorePhoto, animatePhoto, fillPhoto, generateImage, upscaleImage, applyAiFilter, outpaintImage, detectObjects, translateTextToEnglish, analyzeImage, detectAiImage, getCreativeIdeas } from './services/geminiService';
import { getImageDimensions, saveImage } from './utils/imageUtils';
import LeftPanel from './components/LeftPanel';
import CenterPanel from './components/CenterPanel';
import RightPanel from './components/RightPanel';
import SettingsModal from './components/SettingsModal';
import WelcomeModal from './components/WelcomeModal';
import ActionEditorModal from './components/ActionEditorModal';
import DownloadModal from './components/DownloadModal';
import { EditorPanel } from './components/EditorPanel';
import InspirationModal from './components/InspirationModal';
import { PRESET_PROMPT_DISPLAY_NAMES, PRESET_PROMPTS, IMAGINATION_PRESET_PROMPTS, ANIMATION_PRESET_PROMPTS, GENERATE_PRESET_PROMPTS } from './constants';

// Helper to convert File to Base64 string at runtime
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
};

const App: React.FC = () => {
  // --- Core States ---
  const [originalImage, setOriginalImage] = useState<{dataUrl: string, mimeType: string} | null>(null);
  const [processingImage, setProcessingImage] = useState<{dataUrl: string, mimeType: string} | null>(null);
  const [results, setResults] = useState<ResultItem[]>([]);
  const [selectedResult, setSelectedResult] = useState<ResultItem | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [prompt, setPrompt] = useState<string>('');
  const [appMode, setAppMode] = useState<AppMode>('single');
  const [promptMode, setPromptMode] = useState<PromptMode>('retouch');
  const [isEditing, setIsEditing] = useState(false);
  const [isMasking, setIsMasking] = useState(false);
  const [isSpotting, setIsSpotting] = useState(false);
  const [detectedObjects, setDetectedObjects] = useState<DetectionBox[]>([]);
  
  // --- Analyzer States ---
  const [analysisItems, setAnalysisItems] = useState<AnalysisItem[]>([]);
  const [selectedAnalysisItem, setSelectedAnalysisItem] = useState<AnalysisItem | null>(null);
  const [runningAnalysisType, setRunningAnalysisType] = useState<'analysis' | 'detection' | null>(null);
  
  // --- Modals States ---
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isWelcomeOpen, setIsWelcomeOpen] = useState(true);
  const [isInspirationOpen, setIsInspirationOpen] = useState(false);
  const [isActionEditorOpen, setIsActionEditorOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [itemToDownload, setItemToDownload] = useState<ResultItem | null>(null);
  const [editingAction, setEditingAction] = useState<Action | null>(null);
  const [creativeIdeas, setCreativeIdeas] = useState<CreativeIdea[]>([]);
  
  // --- Settings States ---
  const [systemInstruction, setSystemInstruction] = useState<string>('');
  const [stylesUrl, setStylesUrl] = useState<string>('');
  const [useProModel, setUseProModel] = useState(false);
  const [removeBgTolerance, setRemoveBgTolerance] = useState<number>(20);
  const [paintByNumbersColors, setPaintByNumbersColors] = useState<number>(32);
  const [animationAspectRatio, setAnimationAspectRatio] = useState<AspectRatio>('16:9');
  const [generateAspectRatio, setGenerateAspectRatio] = useState<AspectRatio>('1:1');
  const [numberOfImages, setNumberOfImages] = useState<number>(1);
  const [promptFontSize, setPromptFontSize] = useState<number>(12);

  // --- Actions State ---
  const [actions, setActions] = useState<Action[]>([
    {
        id: 'action_old_photo_restoration',
        name: 'Old Photo Restoration',
        steps: [
            'retouch_fix_damage',
            'retouch_remove_noise',
            'retouch_enhance_clarity',
            'retouch_sharpen',
            'retouch_colorize'
        ],
        isAtomic: true
    },
    {
        id: 'action_hdr_lighting',
        name: 'HDR Lighting',
        steps: [
            'retouch_lighting_balanced',
            'retouch_lighting_cinematic_moody'
        ],
        isAtomic: true
    }
  ]);

  const addResult = useCallback((item: { imageUrl: string; mimeType: string; prompt: string; videoUrl?: string; width?: number; height?: number }) => {
    // Generate a more unique ID to prevent key collision issues
    const uniqueId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    const res: ResultItem = { id: uniqueId, ...item };
    setResults(prev => [res, ...prev]);
    setSelectedResult(res);
  }, []);

  const handleFilesSelected = (files: File[]) => {
    if (appMode === 'single') {
        const reader = new FileReader();
        reader.onload = (e) => {
            const res = e.target?.result as string;
            getImageDimensions(res).then(dims => {
                setOriginalImage({ dataUrl: res, mimeType: files[0].type });
                setProcessingImage({ dataUrl: res, mimeType: files[0].type });
                const item = { id: 'orig', imageUrl: res, mimeType: files[0].type, prompt: 'Original Image', width: dims.width, height: dims.height };
                setResults([item]);
                setSelectedResult(item);
            }).catch(err => {
                console.error("Failed to get dims", err);
                setOriginalImage({ dataUrl: res, mimeType: files[0].type });
                setProcessingImage({ dataUrl: res, mimeType: files[0].type });
                const item = { id: 'orig', imageUrl: res, mimeType: files[0].type, prompt: 'Original Image' };
                setResults([item]);
                setSelectedResult(item);
            });
        };
        reader.readAsDataURL(files[0]);
    } else {
        const newItems: AnalysisItem[] = files.map(file => ({
            id: Math.random().toString(36).substr(2, 9),
            file,
            originalDataUrl: URL.createObjectURL(file), // Blob URL for local UI preview only
            mimeType: file.type,
            status: 'pending',
            analysisResult: null,
            aiDetectionResult: null
        }));
        setAnalysisItems(prev => [...prev, ...newItems]);
    }
  };

  const handleStartBatchProcess = async (type: 'analysis' | 'detection') => {
    if (isLoading || analysisItems.length === 0) return;
    setIsLoading(true);
    setRunningAnalysisType(type);
    const itemsToProcess = analysisItems.filter(i => i.status === 'pending');
    for (let i = 0; i < itemsToProcess.length; i++) {
        const item = itemsToProcess[i];
        setLoadingMessage(`Batch ${type}: ${i + 1}/${itemsToProcess.length}...`);
        try {
            setAnalysisItems(prev => prev.map(ai => ai.id === item.id ? { ...ai, status: 'processing' } : ai));
            const base64 = await fileToBase64(item.file);
            if (type === 'analysis') {
                const res = await analyzeImage(base64, item.mimeType);
                setAnalysisItems(prev => prev.map(ai => ai.id === item.id ? { ...ai, analysisResult: res, status: 'completed' } : ai));
                if (selectedAnalysisItem?.id === item.id) setSelectedAnalysisItem(prev => prev ? { ...prev, analysisResult: res, status: 'completed' } : null);
            } else {
                const res = await detectAiImage(base64, item.mimeType);
                setAnalysisItems(prev => prev.map(ai => ai.id === item.id ? { ...ai, aiDetectionResult: res, status: 'completed' } : ai));
                if (selectedAnalysisItem?.id === item.id) setSelectedAnalysisItem(prev => prev ? { ...prev, aiDetectionResult: res, status: 'completed' } : null);
            }
        } catch (e) {
            setAnalysisItems(prev => prev.map(ai => ai.id === item.id ? { ...ai, status: 'error', error: 'Failed' } : ai));
        }
    }
    setIsLoading(false);
    setRunningAnalysisType(null);
    setLoadingMessage('');
  };

  const handleGetCreativeIdeas = async () => {
    if (!processingImage) return;
    setIsLoading(true);
    setLoadingMessage('Brainstorming ideas...');
    try {
        const base64 = processingImage.dataUrl.split(',')[1];
        const ideas = await getCreativeIdeas(base64, processingImage.mimeType);
        if (ideas.length > 0) {
            setCreativeIdeas(ideas);
            setIsInspirationOpen(true);
        } else {
            alert('No creative ideas generated. Please try again.');
        }
    } catch (e) {
        console.error(e);
        alert('Failed to generate creative ideas.');
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleAnalyzeSingleImage = async () => {
    if (!processingImage) return;
    setIsLoading(true);
    setLoadingMessage('Analyzing image...');
    try {
      const base64 = processingImage.dataUrl.split(',')[1];
      const res = await analyzeImage(base64, processingImage.mimeType);
      if (res) {
          const analysisSummary = `${res.subject}, ${res.style}, ${res.mood}`;
          setPrompt(analysisSummary);
      }
    } catch (e) {
        console.error(e);
        alert('Analysis failed.');
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleRestore = async () => {
    if ((!processingImage && promptMode !== 'generate') || !prompt.trim() || isLoading) return;
    setIsLoading(true);
    setLoadingMessage('Processing...');
    try {
      const base64 = processingImage?.dataUrl.split(',')[1] || '';
      const mime = processingImage?.mimeType || 'image/jpeg';
      let res;
      if (promptMode === 'generate') {
        const generated = await generateImage(prompt, generateAspectRatio, numberOfImages);
        for (const img of generated) {
            try {
                const dims = await getImageDimensions(img.imageUrl);
                addResult({ ...img, prompt, width: dims.width, height: dims.height });
            } catch (e) {
                addResult({ ...img, prompt });
            }
        }
      } else if (promptMode === 'animation') {
        res = await animatePhoto(base64, mime, prompt, setLoadingMessage, animationAspectRatio);
        if (res) addResult({ imageUrl: processingImage!.dataUrl, videoUrl: res.videoUrl, mimeType: 'video/mp4', prompt });
      } else {
        res = await restorePhoto(base64, mime, prompt, systemInstruction, removeBgTolerance, undefined, useProModel);
        if (res) {
            try {
                const dims = await getImageDimensions(res.imageUrl);
                addResult({ ...res, prompt, width: dims.width, height: dims.height });
            } catch (e) {
                addResult({ ...res, prompt });
            }
        }
      }
    } catch (e) { alert(e); } finally { setIsLoading(false); }
  };

  const handleRunAction = async (action: Action) => {
    if (!processingImage || isLoading) return;
    setIsLoading(true);
    setLoadingMessage(`Starting action: ${action.name}...`);

    let currentImageBase64 = processingImage.dataUrl.split(',')[1];
    let currentMime = processingImage.mimeType;
    let lastResult = null;

    try {
        const allPresets = [...PRESET_PROMPTS, ...IMAGINATION_PRESET_PROMPTS, ...ANIMATION_PRESET_PROMPTS, ...GENERATE_PRESET_PROMPTS];
        
        for (const [index, stepId] of action.steps.entries()) {
            setLoadingMessage(`Step ${index + 1}/${action.steps.length}: ${PRESET_PROMPT_DISPLAY_NAMES[stepId] || stepId}...`);

            const preset = allPresets.find(p => p.id === stepId);
            const promptText = preset ? preset.prompt : stepId; 

            const res = await restorePhoto(
                currentImageBase64,
                currentMime,
                promptText,
                systemInstruction,
                removeBgTolerance,
                undefined, // dims
                useProModel
            );

            if (res) {
                currentImageBase64 = res.imageUrl.split(',')[1];
                currentMime = res.mimeType;
                lastResult = res;

                // If NOT atomic, add every step to history
                if (!action.isAtomic) {
                     const dims = await getImageDimensions(res.imageUrl);
                     addResult({ ...res, prompt: `[Step ${index+1}] ${promptText}`, width: dims.width, height: dims.height });
                }
            } else {
                throw new Error(`Step failed: ${stepId}`);
            }
        }

        // If atomic, add only the final result
        if (action.isAtomic && lastResult) {
             const dims = await getImageDimensions(lastResult.imageUrl);
             addResult({ ...lastResult, prompt: `Action: ${action.name}`, width: dims.width, height: dims.height });
        }

    } catch (e) {
        console.error(e);
        alert(`Action failed: ${e instanceof Error ? e.message : 'Unknown error'}`);
    } finally {
        setIsLoading(false);
        setLoadingMessage('');
    }
  };

  const handleSaveAction = (action: Action) => {
    setActions(prev => {
      const exists = prev.find(a => a.id === action.id);
      if (exists) {
        return prev.map(a => a.id === action.id ? action : a);
      }
      return [...prev, action];
    });
    setIsActionEditorOpen(false);
  };

  const handleDeleteAction = (actionId: string) => {
    if (confirm('Are you sure you want to delete this action?')) {
        setActions(prev => prev.filter(a => a.id !== actionId));
    }
  };

  const handleExportAnalysisResults = () => {
    if (analysisItems.length === 0) return;
    const content = analysisItems.map(item => {
        let text = `FILE: ${item.file.name}\n`;
        text += `DATE: ${new Date().toLocaleString()}\n`;
        if (item.analysisResult) text += `ANALYSIS: ${JSON.stringify(item.analysisResult, null, 2)}\n`;
        if (item.aiDetectionResult) text += `AI SCORE: ${item.aiDetectionResult.score}%\nASSESSMENT: ${item.aiDetectionResult.assessment}\n`;
        return text + "-".repeat(20) + "\n";
    }).join("\n");
    const blob = new Blob([content], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `pixel_analysis_${Date.now()}.txt`;
    a.click();
  };

  const handleDownloadConfirm = (format: 'png' | 'jpeg', quality: number, metadata: string) => {
    if (itemToDownload) {
        if (itemToDownload.videoUrl) {
            // Direct video download
            const a = document.createElement('a');
            a.href = itemToDownload.videoUrl;
            a.download = `pixel_video_${Date.now()}.mp4`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        } else {
            // Image download via saveImage helper
            saveImage(itemToDownload.imageUrl, `pixel_edit_${Date.now()}`, format, quality, metadata);
        }
    }
    setIsDownloadModalOpen(false);
  };

  // Prepare presets for Action Editor
  const allPresetsForEditor: LoadedPreset[] = [
      ...PRESET_PROMPTS.map(p => ({...p, displayName: PRESET_PROMPT_DISPLAY_NAMES[p.id] || p.id, category: 'retouch' as PromptMode})),
      ...IMAGINATION_PRESET_PROMPTS.map(p => ({...p, displayName: PRESET_PROMPT_DISPLAY_NAMES[p.id] || p.id, category: 'imagination' as PromptMode}))
  ];

  return (
    <div className="flex h-screen w-screen bg-gray-900 text-gray-100 overflow-hidden font-sans">
      {isEditing && processingImage ? (
        <EditorPanel
          imageUrl={processingImage.dataUrl} mimeType={processingImage.mimeType}
          onConfirm={(url) => { 
            getImageDimensions(url).then(dims => {
                addResult({ imageUrl: url, mimeType: 'image/png', prompt: 'Image Edited', width: dims.width, height: dims.height }); 
                setIsEditing(false); 
            }).catch(() => {
                addResult({ imageUrl: url, mimeType: 'image/png', prompt: 'Image Edited' }); 
                setIsEditing(false); 
            });
          }}
          onCancel={() => setIsEditing(false)}
          onApplyAiFilter={applyAiFilter} onApplyOutpaint={outpaintImage}
        />
      ) : (
        <>
          <LeftPanel
            onFilesSelected={handleFilesSelected} processingImageUrl={processingImage?.dataUrl || null}
            prompt={prompt} setPrompt={setPrompt} onRestore={handleRestore} isLoading={isLoading}
            hasImage={!!originalImage || (appMode === 'analyze' && analysisItems.length > 0)}
            onReset={() => originalImage && setProcessingImage(originalImage)}
            isProcessingOriginal={false}
            onTranslatePrompt={async () => { const t = await translateTextToEnglish(prompt); setPrompt(t); }}
            promptMode={promptMode} setPromptMode={setPromptMode} appMode={appMode} setAppMode={setAppMode}
            onOpenSettings={() => setIsSettingsOpen(true)}
            isEditing={isEditing} isMasking={isMasking} analysisItems={analysisItems}
            onStartAnalysis={() => handleStartBatchProcess('analysis')}
            onStartAiDetection={() => handleStartBatchProcess('detection')}
            onExportAnalysisResults={handleExportAnalysisResults}
            onClearAnalysis={() => setAnalysisItems([])}
            onRemoveAnalysisItem={(id) => setAnalysisItems(prev => prev.filter(i => i.id !== id))}
            onAnalyzeImage={handleAnalyzeSingleImage} onGetCreativeIdeas={handleGetCreativeIdeas}
            selectedAnalysisItem={selectedAnalysisItem} onSelectAnalysisItem={setSelectedAnalysisItem}
            runningAnalysisType={runningAnalysisType} isBatchAnalyzing={isLoading}
            onPresetClick={(p) => setPrompt(p.prompt)}
            animationAspectRatio={animationAspectRatio} setAnimationAspectRatio={setAnimationAspectRatio}
            generateAspectRatio={generateAspectRatio} setGenerateAspectRatio={setGenerateAspectRatio}
            numberOfImages={numberOfImages} setNumberOfImages={setNumberOfImages}
            removeBgTolerance={removeBgTolerance} setRemoveBgTolerance={setRemoveBgTolerance}
            paintByNumbersColors={paintByNumbersColors} setPaintByNumbersColors={setPaintByNumbersColors}
            isRandomMode={false} setIsRandomMode={() => {}} isQuotaLimited={false} quotaCooldownRemaining={0}
            totalLoadedPrompts={0} actions={actions} loadedPresets={{retouch:[], imagination:[], animation:[], generate:[]}}
            onRunAction={handleRunAction} 
            onOpenActionEditor={(action) => { setEditingAction(action); setIsActionEditorOpen(true); }} 
            onDeleteAction={handleDeleteAction} 
            onLoadStyles={() => {}}
            promptFontSize={promptFontSize}
          />
          <CenterPanel
            appMode={appMode} beforeImage={originalImage?.dataUrl} 
            afterImage={appMode === 'analyze' ? selectedAnalysisItem?.originalDataUrl || null : selectedResult?.imageUrl}
            comparisonMode="single" setComparisonMode={() => {}} isLoading={isLoading} loadingMessage={loadingMessage}
            hasImage={!!originalImage || (appMode === 'analyze' && analysisItems.length > 0)}
            isMasking={isMasking} setIsMasking={setIsMasking} isEditing={isEditing} setIsEditing={setIsEditing}
            onImageMasked={async (mask) => {
                if (!processingImage) return;
                setIsLoading(true);
                const res = await fillPhoto(processingImage.dataUrl.split(',')[1], processingImage.mimeType, prompt, mask);
                if (res) {
                    try {
                        const dims = await getImageDimensions(res.imageUrl);
                        addResult({ ...res, prompt: 'AI Fill', width: dims.width, height: dims.height });
                    } catch (e) {
                         addResult({ ...res, prompt: 'AI Fill' });
                    }
                }
                setIsLoading(false); setIsMasking(false);
            }}
            isSpotting={isSpotting} setIsSpotting={setIsSpotting}
            detectedObjects={appMode === 'analyze' ? selectedAnalysisItem?.detectedObjects || [] : detectedObjects}
            onSpotRequest={(s) => {}}
            selectedResult={selectedResult} promptMode={promptMode}
            selectedAnalysisItem={selectedAnalysisItem}
          />
          <RightPanel
            results={results} selectedResultId={selectedResult?.id || null}
            onSelectResult={setSelectedResult} onUseAsSource={(r) => setProcessingImage({ dataUrl: r.imageUrl, mimeType: r.mimeType })}
            onDownloadResult={(r) => { 
                setItemToDownload(r);
                setIsDownloadModalOpen(true);
            }}
            onUpscaleResult={async (r) => { 
                setIsLoading(true); 
                const up = await upscaleImage(r.imageUrl.split(',')[1], r.mimeType, undefined, useProModel, '2x'); 
                if (up) {
                    try {
                        const dims = await getImageDimensions(up.imageUrl);
                        addResult({ ...up, prompt: 'Upscaled', width: dims.width, height: dims.height }); 
                    } catch (e) {
                        addResult({ ...up, prompt: 'Upscaled' }); 
                    }
                }
                setIsLoading(false); 
            }}
            onDeleteResult={(r) => setResults(prev => prev.filter(i => i.id !== r.id))}
            onClearAll={() => setResults([])} isLoading={isLoading} onExportFrame={() => {}}
            appMode={appMode} selectedAnalysisItem={selectedAnalysisItem}
          />
        </>
      )}
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        useProModel={useProModel} 
        onUseProModelChange={setUseProModel} 
        systemInstruction={systemInstruction} 
        onSystemInstructionChange={setSystemInstruction} 
        stylesUrl={stylesUrl} 
        onStylesUrlChange={setStylesUrl} 
        onLoadPromptsFromFileContent={() => {}} 
        promptFontSize={promptFontSize}
        onPromptFontSizeChange={setPromptFontSize}
      />
      <WelcomeModal isOpen={isWelcomeOpen} onClose={() => setIsWelcomeOpen(false)} />
      <InspirationModal isOpen={isInspirationOpen} onClose={() => setIsInspirationOpen(false)} ideas={creativeIdeas} onApply={(p) => { setPrompt(p); setIsInspirationOpen(false); }} />
      <ActionEditorModal 
        isOpen={isActionEditorOpen} 
        onClose={() => setIsActionEditorOpen(false)} 
        onSave={handleSaveAction} 
        actionToEdit={editingAction} 
        availablePresets={allPresetsForEditor}
      />
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        result={itemToDownload}
        onConfirmDownload={handleDownloadConfirm}
      />
    </div>
  );
};

export default App;
