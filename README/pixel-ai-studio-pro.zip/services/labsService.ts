
import { GoogleGenAI, Type } from "@google/genai";

const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * ПІСОЧНИЦЯ ДЛЯ НОВИХ ІДЕЙ
 * Сюди ми додаємо функції, які можуть бути нестабільними.
 */

export async function experimentalFeatureTest(base64: string, prompt: string) {
    const ai = getAi();
    // Тут буде логіка нового експерименту
    console.log("Running Lab Experiment with prompt:", prompt);
    return null; 
}

export const CURRENT_EXPERIMENTS = [
    { 
        id: 'depth_pro_v1', 
        name: 'Super Depth Map', 
        description: 'Новий алгоритм вимірювання глибини для 3D ефектів.',
        icon: '🧪'
    },
    { 
        id: 'style_transfer_v2', 
        name: 'Neural Style', 
        description: 'Прямий перенос художнього стилю між двома фото.',
        icon: '🎨'
    }
];
