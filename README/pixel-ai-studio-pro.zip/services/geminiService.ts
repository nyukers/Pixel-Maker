
import { GoogleGenAI, Modality, Type } from "@google/genai";
import { upscaleImageOnClient, resizeImageOnClient } from "../utils/imageUtils";
import { DetectionBox, AnalysisResult, AiDetectionResult, CreativeIdea } from "../types";
import { AI_FILTER_PRESETS } from "../constants";

const MODEL_PRO = 'gemini-3-pro-preview';
const MODEL_IMAGE_FLASH = 'gemini-2.5-flash-image';
const MODEL_IMAGE_PRO = 'gemini-3-pro-image-preview';

// Guideline: Create instance right before making an API call
const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeImage(base64: string, mime: string): Promise<AnalysisResult | null> {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: MODEL_PRO,
      contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: "Provide a professional aesthetic and technical analysis of this image." }] },
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            composition: { type: Type.STRING },
            subject: { type: Type.STRING },
            background: { type: Type.STRING },
            style: { type: Type.STRING },
            mood: { type: Type.STRING },
            camera: {
              type: Type.OBJECT,
              properties: {
                angle: { type: Type.STRING },
                framing: { type: Type.STRING },
                model: { type: Type.STRING }
              },
              required: ["angle", "framing", "model"]
            }
          },
          required: ["composition", "subject", "background", "style", "mood", "camera"]
        }
      }
    });
    return JSON.parse(response.text || "null");
  } catch (e) {
    console.error("Analysis API Error:", e);
    throw e;
  }
}

export async function detectAiImage(base64: string, mime: string): Promise<AiDetectionResult | null> {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: MODEL_PRO,
      contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: "Is this image AI-generated? Look for artifacts, skin texture, and lighting patterns." }] },
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.INTEGER, description: "0-100 probability of AI generation" },
            assessment: { type: Type.STRING },
            indicators: { type: Type.ARRAY, items: { type: Type.STRING } },
            possibleTool: { type: Type.STRING }
          },
          required: ["score", "assessment", "indicators"]
        }
      }
    });
    return JSON.parse(response.text || "null");
  } catch (e) {
    console.error("Detection API Error:", e);
    throw e;
  }
}

export async function getCreativeIdeas(base64: string, mime: string): Promise<CreativeIdea[]> {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: MODEL_PRO,
      contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: "Give 3 unique artistic transformation ideas." }] },
      config: { 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              prompt: { type: Type.STRING }
            },
            required: ["title", "description", "prompt"]
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (e) { return []; }
}

export async function detectObjects(base64: string, mime: string, subject: string): Promise<DetectionBox[]> {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: MODEL_IMAGE_FLASH,
      contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: `Locate all "${subject}" in the image.` }] },
      config: { 
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING },
              box_2d: { type: Type.ARRAY, items: { type: Type.INTEGER } }
            },
            required: ["label", "box_2d"]
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (e) { return []; }
}

export async function restorePhoto(base64: string, mime: string, prompt: string, instr?: string, bgTol: number = 20, dims?: {width:number, height:number}, pro: boolean = false) {
  const ai = getAi();
  const model = pro ? MODEL_IMAGE_PRO : MODEL_IMAGE_FLASH;
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: prompt }] },
      config: { 
        systemInstruction: instr,
        responseModalities: [Modality.IMAGE, Modality.TEXT] 
      }
    });
    const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    if (part?.inlineData) {
        let url = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        if (dims) {
            url = await resizeImageOnClient(url, dims.width, dims.height);
        }
        return { imageUrl: url, mimeType: part.inlineData.mimeType };
    }
    return null;
  } catch (error) { throw error; }
}

export async function animatePhoto(base64: string, mime: string, prompt: string, setMsg: any, ratio: string) {
  const ai = getAi();
  let op = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    image: { imageBytes: base64, mimeType: mime },
    config: { numberOfVideos: 1, resolution: '720p', aspectRatio: ratio as any }
  });
  while (!op.done) {
    await new Promise(r => setTimeout(r, 10000));
    op = await ai.operations.getVideosOperation({ operation: op });
  }
  const uri = op.response?.generatedVideos?.[0]?.video?.uri;
  if (uri) {
    const res = await fetch(`${uri}&key=${process.env.API_KEY}`);
    const blob = await res.blob();
    return { videoUrl: URL.createObjectURL(blob), mimeType: 'video/mp4' };
  }
  return null;
}

export async function upscaleImage(base64: string, mime: string, instr?: string, pro: boolean = false, mode: '2x' | '4k' = '2x') {
    const ai = getAi();
    const m = pro || mode === '4k' ? MODEL_IMAGE_PRO : MODEL_IMAGE_FLASH;
    const response = await ai.models.generateContent({
      model: m,
      contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: "Upscale and enhance this image." }] },
      config: { imageConfig: mode === '4k' ? { imageSize: '4K' } : undefined }
    });
    const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    if (part?.inlineData) {
        let url = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        if (mode === '2x') {
            url = await upscaleImageOnClient(url, 2);
        }
        return { imageUrl: url, mimeType: part.inlineData.mimeType };
    }
    return null;
}

export async function generateImage(prompt: string, ratio: string, num: number) {
  const ai = getAi();
  const res = await ai.models.generateImages({
    model: 'imagen-4.0-generate-001',
    prompt,
    config: { numberOfImages: num, aspectRatio: ratio as any, outputMimeType: 'image/jpeg' }
  });
  return res.generatedImages.map(img => ({
    imageUrl: `data:image/jpeg;base64,${img.image.imageBytes}`,
    mimeType: 'image/jpeg'
  }));
}

export async function applyAiFilter(base64: string, mime: string, filterId: string): Promise<string | null> {
  const ai = getAi();
  const preset = AI_FILTER_PRESETS.find(p => p.id === filterId);
  const prompt = preset ? preset.prompt : `Filter: ${filterId}`;
  const response = await ai.models.generateContent({
    model: MODEL_IMAGE_FLASH,
    contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: prompt }] },
  });
  const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
  return part?.inlineData ? `data:${part.inlineData.mimeType};base64,${part.inlineData.data}` : null;
}

export async function outpaintImage(base64: string, mime: string): Promise<string | null> {
  const ai = getAi();
  const response = await ai.models.generateContent({
    model: MODEL_IMAGE_FLASH,
    contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: "Outpaint and extend background." }] },
  });
  const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
  return part?.inlineData ? `data:${part.inlineData.mimeType};base64,${part.inlineData.data}` : null;
}

export async function fillPhoto(base64: string, mime: string, prompt: string, maskBase64: string): Promise<{ imageUrl: string; mimeType: string } | null> {
  const ai = getAi();
  const response = await ai.models.generateContent({
    model: MODEL_IMAGE_FLASH,
    contents: {
      parts: [
        { inlineData: { data: base64, mimeType: mime } },
        { inlineData: { data: maskBase64.split(',')[1], mimeType: 'image/png' } },
        { text: prompt || "Inpaint mask area." }
      ]
    },
    config: { responseModalities: [Modality.IMAGE, Modality.TEXT] }
  });
  const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
  return part?.inlineData ? { imageUrl: `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`, mimeType: part.inlineData.mimeType } : null;
}

export async function translateTextToEnglish(text: string) {
  const ai = getAi();
  const res = await ai.models.generateContent({
    model: MODEL_PRO,
    contents: `Return ONLY the English translation: "${text}"`
  });
  return res.text?.trim() || text;
}
