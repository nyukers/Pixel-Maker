
import * as imageq from 'image-q';
import { upscaleImageOnClient } from './imageUtils';

interface PaletteItem {
  id: number;
  hex: string;
  rgb: { r: number; g: number; b: number };
}

interface Region {
  colorIndex: number;
  pixels: number[]; // Array of pixel indices (y * width + x)
  centroid: { x: number; y: number };
}

interface PbnResult {
  numberedImageUrl: string;
  legendImageUrl: string;
}

/**
 * Main function to process Paint by Numbers logic on the client side.
 * 1. Quantizes the original image to reduce colors.
 * 2. Finds connected regions (blobs) for each color.
 * 3. GENERATES A NEW LINEART based on region boundaries (Edge Detection).
 * 4. Upscales the lineart to 2x.
 * 5. Overlays numbers on this Hi-Res schematic with collision detection.
 * 6. Generates a matching Legend image.
 */
export async function processPaintByNumbers(
  originalImageUrl: string,
  targetColorCount: number
): Promise<PbnResult> {
  return new Promise(async (resolve, reject) => {
    try {
      // 1. Load Image
      const originalImg = await loadImage(originalImageUrl);

      // 2. Setup Context
      const width = originalImg.width;
      const height = originalImg.height;

      const calcCanvas = document.createElement('canvas');
      calcCanvas.width = width;
      calcCanvas.height = height;
      const calcCtx = calcCanvas.getContext('2d', { willReadFrequently: true });
      if (!calcCtx) throw new Error("Could not create calculation canvas");
      
      calcCtx.drawImage(originalImg, 0, 0, width, height);
      const imageData = calcCtx.getImageData(0, 0, width, height);

      // 3. Quantize Colors (image-q)
      const pointContainer = imageq.utils.PointContainer.fromUint8Array(
        imageData.data,
        width,
        height
      );
      // Increase colors slightly for quantization to allow for better region merging later
      const paletteResult = await imageq.buildPalette([pointContainer], {
        colors: targetColorCount,
      });
      const palettePoints = paletteResult.getPointContainer().getPointArray();

      // Map raw palette to our PaletteItem structure
      const palette: PaletteItem[] = palettePoints.map((p, index) => {
        const r = p.r, g = p.g, b = p.b;
        const hex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
        return { id: index + 1, hex, rgb: { r, g, b } };
      });

      // Apply palette to image to get a quantized buffer (index map)
      const quantizedData = await imageq.applyPalette(pointContainer, paletteResult);
      const quantizedBytes = quantizedData.toUint8Array(); // RGBRGB...

      // Create an raw index map: pixel_index -> palette_index
      const rawIndexMap = new Int32Array(width * height);
      
      // Helper to find closest palette index
      for (let i = 0; i < width * height; i++) {
        const r = quantizedBytes[i * 4];
        const g = quantizedBytes[i * 4 + 1];
        const b = quantizedBytes[i * 4 + 2];
        
        let bestIdx = 0;
        let minDist = Number.MAX_VALUE;
        
        for (let p = 0; p < palette.length; p++) {
           const pr = palette[p].rgb.r;
           const pg = palette[p].rgb.g;
           const pb = palette[p].rgb.b;
           const dist = (r-pr)*(r-pr) + (g-pg)*(g-pg) + (b-pb)*(b-pb);
           if (dist < minDist) {
             minDist = dist;
             bestIdx = p;
             if (dist === 0) break;
           }
        }
        rawIndexMap[i] = bestIdx;
      }

      // 4. Find Connected Regions (BFS / Flood Fill)
      // Adaptive threshold: Higher color count = allow smaller regions (more detail)
      let minRegionSize = 50;
      if (targetColorCount >= 64) minRegionSize = 10;
      else if (targetColorCount >= 32) minRegionSize = 25;

      const regions = findRegions(rawIndexMap, width, height, minRegionSize);

      // 5. CLEANUP: Create a "Clean Map"
      const cleanMap = new Int32Array(width * height).fill(-1);
      
      // Fill clean map with valid regions
      regions.forEach(region => {
        region.pixels.forEach(idx => {
          cleanMap[idx] = region.colorIndex;
        });
      });

      // Fill Gaps (Nearest Neighbor Interpolation) - 2 pass
      for (let i = 0; i < width * height; i++) {
        if (cleanMap[i] === -1) {
          if (i > 0 && cleanMap[i-1] !== -1) cleanMap[i] = cleanMap[i-1];
          else if (i >= width && cleanMap[i-width] !== -1) cleanMap[i] = cleanMap[i-width];
        }
      }
      for (let i = width * height - 1; i >= 0; i--) {
         if (cleanMap[i] === -1) {
           if (i < width * height - 1 && cleanMap[i+1] !== -1) cleanMap[i] = cleanMap[i+1];
           else if (i < width * height - width && cleanMap[i+width] !== -1) cleanMap[i] = cleanMap[i+width];
         }
      }

      // 6. Generate Schematic Lineart (1x)
      const schemaCanvas = document.createElement('canvas');
      schemaCanvas.width = width;
      schemaCanvas.height = height;
      const schemaCtx = schemaCanvas.getContext('2d');
      if (!schemaCtx) throw new Error("Could not create schema canvas");

      // Fill white background
      schemaCtx.fillStyle = '#FFFFFF';
      schemaCtx.fillRect(0, 0, width, height);

      const schemaImageData = schemaCtx.getImageData(0, 0, width, height);
      const data = schemaImageData.data;

      // Draw Lines based on CLEAN map
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
           const idx = y * width + x;
           const currentVal = cleanMap[idx];

           let isEdge = false;
           
           // Check Right
           if (x < width - 1) {
             const rightVal = cleanMap[idx + 1];
             if (currentVal !== rightVal) isEdge = true;
           }
           
           // Check Bottom
           if (!isEdge && y < height - 1) {
             const bottomVal = cleanMap[idx + width];
             if (currentVal !== bottomVal) isEdge = true;
           }

           if (isEdge) {
             const pos = idx * 4;
             // Dark Grey (#444444)
             data[pos] = 68;
             data[pos + 1] = 68; 
             data[pos + 2] = 68; 
             data[pos + 3] = 255; 
           }
        }
      }
      schemaCtx.putImageData(schemaImageData, 0, 0);
      
      const schema1xDataUrl = schemaCanvas.toDataURL('image/png');

      // 7. UPSCALE (2x)
      // We upscale the clean lineart first to get a high-res canvas
      const schema2xDataUrl = await upscaleImageOnClient(schema1xDataUrl, 2);
      const schema2xImg = await loadImage(schema2xDataUrl);
      
      const finalCanvas = document.createElement('canvas');
      finalCanvas.width = schema2xImg.width;
      finalCanvas.height = schema2xImg.height;
      const finalCtx = finalCanvas.getContext('2d');
      if (!finalCtx) throw new Error("Could not create final canvas");
      
      finalCtx.drawImage(schema2xImg, 0, 0);

      // 8. Draw Numbers on Hi-Res Schema with Collision Detection
      
      // Sort regions by size (descending) so largest regions get numbers first
      regions.sort((a, b) => b.pixels.length - a.pixels.length);

      // Adjust font size relative to the 2x canvas
      const fontSize = Math.max(12, Math.floor(Math.min(finalCanvas.width, finalCanvas.height) * 0.012));
      
      finalCtx.font = `bold ${fontSize}px sans-serif`;
      finalCtx.textAlign = 'center';
      finalCtx.textBaseline = 'middle';
      finalCtx.lineWidth = 3;
      finalCtx.strokeStyle = 'rgba(255, 255, 255, 0.9)'; // Strong white halo
      finalCtx.fillStyle = '#111111'; // Black text

      const placedBoxes: {x: number, y: number, w: number, h: number}[] = [];

      regions.forEach(region => {
         // Scale centroid to 2x
         const cx = region.centroid.x * 2;
         const cy = region.centroid.y * 2;
         
         const label = (region.colorIndex + 1).toString();
         
         // Measure text for collision box
         const metrics = finalCtx.measureText(label);
         const w = metrics.width;
         const h = fontSize; // approximate height
         const pad = 4; // padding around text
         
         const box = {
             x: cx - w/2 - pad,
             y: cy - h/2 - pad,
             w: w + pad*2,
             h: h + pad*2
         };
         
         // Check if box is within canvas bounds
         if (box.x < 0 || box.y < 0 || box.x + box.w > finalCanvas.width || box.y + box.h > finalCanvas.height) {
             return;
         }

         // Check collision with existing labels
         let overlap = false;
         for (const placed of placedBoxes) {
             if (box.x < placed.x + placed.w &&
                 box.x + box.w > placed.x &&
                 box.y < placed.y + placed.h &&
                 box.y + box.h > placed.y) {
                 overlap = true;
                 break;
             }
         }

         if (!overlap) {
            finalCtx.strokeText(label, cx, cy);
            finalCtx.fillText(label, cx, cy);
            placedBoxes.push(box);
         }
      });

      const numberedImageUrl = finalCanvas.toDataURL('image/png');

      // 9. Generate Legend Image
      const legendImageUrl = await generateLegendFromPalette(palette);

      resolve({
        numberedImageUrl,
        legendImageUrl
      });

    } catch (e) {
      reject(e);
    }
  });
}

// --- Helper Functions ---

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Failed to load image"));
    img.src = src;
  });
}

function findRegions(indexMap: Int32Array, width: number, height: number, minRegionSize: number): Region[] {
  const visited = new Uint8Array(width * height); // 0 = unvisited, 1 = visited
  const regions: Region[] = [];

  // Iterative scan
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      if (visited[idx] === 0) {
        const colorIndex = indexMap[idx];
        
        // BFS Flood Fill
        const pixels: number[] = [];
        const queue: number[] = [idx];
        visited[idx] = 1;
        
        let sumX = 0;
        let sumY = 0;
        
        // Safety brake for extremely large images
        let head = 0;
        while (head < queue.length) {
          const currIdx = queue[head++];
          pixels.push(currIdx);
          
          const cx = currIdx % width;
          const cy = Math.floor(currIdx / width);
          
          sumX += cx;
          sumY += cy;

          // Neighbors (4-connectivity)
          const neighbors = [
            currIdx - 1,       // Left
            currIdx + 1,       // Right
            currIdx - width,   // Up
            currIdx + width    // Down
          ];

          for (const nIdx of neighbors) {
             // Boundary checks
             if (nIdx < 0 || nIdx >= width * height) continue;
             // Wrap-around checks for left/right
             const nx = nIdx % width;
             if (Math.abs(nx - cx) > 1) continue; 

             if (visited[nIdx] === 0 && indexMap[nIdx] === colorIndex) {
                visited[nIdx] = 1;
                queue.push(nIdx);
             }
          }
        }

        // Region finished. Check size.
        if (pixels.length >= minRegionSize) {
          regions.push({
            colorIndex,
            pixels,
            centroid: {
              x: sumX / pixels.length,
              y: sumY / pixels.length
            }
          });
        }
      }
    }
  }
  return regions;
}

async function generateLegendFromPalette(palette: PaletteItem[]): Promise<string> {
    const legendCanvas = document.createElement('canvas');
    const ctx = legendCanvas.getContext('2d');
    if (!ctx) throw new Error("Could not create canvas for legend");

    const cols = 4; 
    const rows = Math.ceil(palette.length / cols);
    
    const swatchSize = 80;
    const gap = 20;
    const padding = 40;
    const textHeight = 60; // Added extra height for color name and hex
    const headerHeight = 80;
    
    const canvasWidth = (cols * swatchSize) + ((cols - 1) * gap) + (padding * 2);
    const canvasHeight = headerHeight + (rows * (swatchSize + textHeight)) + ((rows - 1) * gap) + padding;

    legendCanvas.width = canvasWidth;
    legendCanvas.height = canvasHeight;

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    // Title
    ctx.fillStyle = '#111827';
    ctx.font = 'bold 24px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('LEGEND OF COLORS', canvasWidth / 2, 50);
    
    ctx.font = '14px sans-serif';
    ctx.fillStyle = '#6b7280';
    ctx.fillText(`Total Colors: ${palette.length}`, canvasWidth / 2, 75);

    // Draw Grid
    palette.forEach((item, index) => {
        const col = index % cols;
        const row = Math.floor(index / cols);

        const x = padding + (col * (swatchSize + gap));
        const y = headerHeight + (row * (swatchSize + gap + textHeight));

        // Color Swatch
        ctx.fillStyle = item.hex;
        ctx.fillRect(x, y, swatchSize, swatchSize);
        
        // Border
        ctx.strokeStyle = '#e5e7eb';
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, swatchSize, swatchSize);

        // Number Badge
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fillRect(x, y, 24, 24);
        ctx.fillStyle = '#000000';
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(item.id.toString(), x + 12, y + 12);

        // Get Color Name
        const colorName = findClosestColorName(item.rgb.r, item.rgb.g, item.rgb.b);

        // Hex Text
        ctx.fillStyle = '#374151';
        ctx.textAlign = 'center';
        
        ctx.font = '12px monospace';
        ctx.textBaseline = 'top';
        ctx.fillText(item.hex, x + (swatchSize / 2), y + swatchSize + 8);

        // Color Name Text
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(colorName, x + (swatchSize / 2), y + swatchSize + 24);
    });

    return legendCanvas.toDataURL('image/png');
}

export async function generateLegendImage(originalImageUrl: string, targetColorCount: number): Promise<string> {
    const { legendImageUrl } = await processPaintByNumbers(originalImageUrl, targetColorCount);
    return legendImageUrl;
}

// --- Color Name Logic ---

const NAMED_COLORS = [
  { name: "Black", r: 0, g: 0, b: 0 },
  { name: "White", r: 255, g: 255, b: 255 },
  { name: "Red", r: 255, g: 0, b: 0 },
  { name: "Green", r: 0, g: 128, b: 0 },
  { name: "Blue", r: 0, g: 0, b: 255 },
  { name: "Yellow", r: 255, g: 255, b: 0 },
  { name: "Cyan", r: 0, g: 255, b: 255 },
  { name: "Magenta", r: 255, g: 0, b: 255 },
  { name: "Silver", r: 192, g: 192, b: 192 },
  { name: "Gray", r: 128, g: 128, b: 128 },
  { name: "Maroon", r: 128, g: 0, b: 0 },
  { name: "Olive", r: 128, g: 128, b: 0 },
  { name: "Purple", r: 128, g: 0, b: 128 },
  { name: "Teal", r: 0, g: 128, b: 128 },
  { name: "Navy", r: 0, g: 0, b: 128 },
  { name: "Orange", r: 255, g: 165, b: 0 },
  { name: "Gold", r: 255, g: 215, b: 0 },
  { name: "Pink", r: 255, g: 192, b: 203 },
  { name: "Brown", r: 165, g: 42, b: 42 },
  { name: "Beige", r: 245, g: 245, b: 220 },
  { name: "Turquoise", r: 64, g: 224, b: 208 },
  { name: "Lavender", r: 230, g: 230, b: 250 },
  { name: "Salmon", r: 250, g: 128, b: 114 },
  { name: "Coral", r: 255, g: 127, b: 80 },
  { name: "Khaki", r: 240, g: 230, b: 140 },
  { name: "Indigo", r: 75, g: 0, b: 130 },
  { name: "Violet", r: 238, g: 130, b: 238 },
  { name: "Plum", r: 221, g: 160, b: 221 },
  { name: "Crimson", r: 220, g: 20, b: 60 },
  { name: "Lime", r: 0, g: 255, b: 0 },
  { name: "Sky Blue", r: 135, g: 206, b: 235 },
  { name: "Royal Blue", r: 65, g: 105, b: 225 },
  { name: "Tan", r: 210, g: 180, b: 140 },
  { name: "Chocolate", r: 210, g: 105, b: 30 },
  { name: "Sienna", r: 160, g: 82, b: 45 },
  { name: "Slate Gray", r: 112, g: 128, b: 144 },
  { name: "Dark Green", r: 0, g: 100, b: 0 },
  { name: "Forest Green", r: 34, g: 139, b: 34 },
  { name: "Pale Green", r: 152, g: 251, b: 152 },
  { name: "Hot Pink", r: 255, g: 105, b: 180 },
  { name: "Deep Pink", r: 255, g: 20, b: 147 },
  { name: "Tomato", r: 255, g: 99, b: 71 },
  { name: "Dark Orange", r: 255, g: 140, b: 0 },
  { name: "Wheat", r: 245, g: 222, b: 179 },
  { name: "Azure", r: 240, g: 255, b: 255 },
  { name: "Mint", r: 189, g: 252, b: 201 },
  { name: "Rose", r: 255, g: 228, b: 225 },
  { name: "Ivory", r: 255, g: 255, b: 240 },
  { name: "Peach", r: 255, g: 218, b: 185 },
  { name: "Mustard", r: 255, g: 219, b: 88 },
  { name: "Ochre", r: 204, g: 119, b: 34 },
  { name: "Cream", r: 255, g: 253, b: 208 },
  { name: "Charcoal", r: 54, g: 69, b: 79 },
  { name: "Aquamarine", r: 127, g: 255, b: 212 },
  { name: "Midnight Blue", r: 25, g: 25, b: 112 },
  { name: "Sand", r: 194, g: 178, b: 128 },
  { name: "Rust", r: 183, g: 65, b: 14 },
  { name: "Bronze", r: 205, g: 127, b: 50 },
  { name: "Copper", r: 184, g: 115, b: 51 },
  { name: "Mauve", r: 224, g: 176, b: 255 },
  { name: "Lilac", r: 200, g: 162, b: 200 },
  { name: "Periwinkle", r: 204, g: 204, b: 255 },
  { name: "Seafoam", r: 147, g: 223, b: 184 },
  { name: "Burgundy", r: 128, g: 0, b: 32 },
  { name: "Emerald", r: 80, g: 200, b: 120 },
  { name: "Sapphire", r: 15, g: 82, b: 186 },
  { name: "Ruby", r: 224, g: 17, b: 95 },
  { name: "Amethyst", r: 153, g: 102, b: 204 },
  { name: "Topaz", r: 255, g: 200, b: 124 },
  { name: "Pearl", r: 234, g: 224, b: 200 },
  { name: "Obsidian", r: 50, g: 50, b: 50 },
  { name: "Onyx", r: 53, g: 56, b: 57 },
];

function findClosestColorName(r: number, g: number, b: number): string {
  let minDistance = Number.MAX_VALUE;
  let closestName = "Unknown";

  for (const color of NAMED_COLORS) {
    const dr = r - color.r;
    const dg = g - color.g;
    const db = b - color.b;
    const distance = dr * dr + dg * dg + db * db;

    if (distance < minDistance) {
      minDistance = distance;
      closestName = color.name;
      if (distance === 0) break; // Exact match
    }
  }
  return closestName;
}
