
/**
 * Generates a depth-of-field (Bokeh) effect.
 * It blurs the background while keeping the foreground sharp based on a depth map.
 * 
 * @param originalImageUrl - The base64 data URL of the color source image.
 * @param depthMapDataUrl - The base64 data URL of the grayscale depth map.
 * @returns A Promise that resolves to the base64 data URL of the processed image.
 */
export async function generateBokeh(originalImageUrl: string, depthMapDataUrl: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const originalImg = new Image();
        originalImg.crossOrigin = "Anonymous";
        const depthImg = new Image();
        depthImg.crossOrigin = "Anonymous";

        let loadedCount = 0;
        const checkLoaded = () => {
            loadedCount++;
            if (loadedCount === 2) process();
        };

        originalImg.onload = checkLoaded;
        depthImg.onload = checkLoaded;
        originalImg.onerror = () => reject(new Error("Failed to load original image"));
        depthImg.onerror = () => reject(new Error("Failed to load depth map"));

        originalImg.src = originalImageUrl;
        depthImg.src = depthMapDataUrl;

        function process() {
            try {
                const width = originalImg.width;
                const height = originalImg.height;
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error("No context");

                // 1. Create Blurred Version (Simulating lens blur)
                const blurCanvas = document.createElement('canvas');
                blurCanvas.width = width;
                blurCanvas.height = height;
                const blurCtx = blurCanvas.getContext('2d');
                if (!blurCtx) throw new Error("No blur context");

                // Adjust blur radius for the amount of 'bokeh'
                // Using 12px for a strong but realistic portrait look
                blurCtx.filter = 'blur(12px)'; 
                blurCtx.drawImage(originalImg, 0, 0, width, height);
                const blurredData = blurCtx.getImageData(0,0, width, height);

                // 2. Get Original and Depth Data
                ctx.drawImage(originalImg, 0, 0, width, height);
                const originalData = ctx.getImageData(0, 0, width, height);
                
                ctx.clearRect(0,0, width, height);
                ctx.drawImage(depthImg, 0, 0, width, height);
                const depthData = ctx.getImageData(0, 0, width, height);

                const outputData = ctx.createImageData(width, height);

                // 3. Normalize Depth Map
                // Find the range of depth values to ensure the closest object (brightest pixel)
                // is treated as fully "in focus".
                let minDepth = 255;
                let maxDepth = 0;
                for (let k = 0; k < depthData.data.length; k += 4) {
                    // Use Red channel for grayscale value
                    const val = depthData.data[k];
                    if (val < minDepth) minDepth = val;
                    if (val > maxDepth) maxDepth = val;
                }
                
                const depthRange = maxDepth - minDepth;
                // Scale factor to stretch contrast to 0-255
                const depthScale = depthRange > 0 ? 255.0 / depthRange : 0;

                // 4. Blend based on depth
                const data = outputData.data;
                const oPix = originalData.data;
                const bPix = blurredData.data;
                const dPix = depthData.data;

                for (let i = 0; i < data.length; i += 4) {
                    let rawDepth = dPix[i];
                    
                    // Apply normalization: Stretch the depth values so the subject becomes White (255)
                    if (depthScale > 0) {
                        rawDepth = (rawDepth - minDepth) * depthScale;
                    }

                    // Normalized depth (0.0 = far/background, 1.0 = close/foreground)
                    const depth = rawDepth / 255.0;
                    
                    // Calculate mix factor (Amount of Blur)
                    // 0.0 = No Blur (Original)
                    // 1.0 = Full Blur
                    
                    let mix = 0;

                    // Logic: Keep foreground (depth > threshold) sharp. Blur background.
                    // We use a "Focal Plane" logic.
                    const focusThreshold = 0.75; // Top 25% of depth (closest objects) remain sharp
                    
                    if (depth >= focusThreshold) {
                        mix = 0; // Fully sharp
                    } else {
                        // Smooth transition to blur for background
                        // Map 0.0 -> focusThreshold to 1.0 -> 0.0
                        mix = 1.0 - (depth / focusThreshold);
                        
                        // Ease-in function for smoother bokeh falloff
                        mix = mix * mix; 
                    }

                    // Clamp
                    if (mix < 0) mix = 0;
                    if (mix > 1) mix = 1;

                    data[i] = oPix[i] * (1 - mix) + bPix[i] * mix;
                    data[i+1] = oPix[i+1] * (1 - mix) + bPix[i+1] * mix;
                    data[i+2] = oPix[i+2] * (1 - mix) + bPix[i+2] * mix;
                    data[i+3] = 255;
                }

                ctx.putImageData(outputData, 0, 0);
                resolve(canvas.toDataURL('image/jpeg', 0.95));
            } catch (e: any) {
                reject(new Error("Bokeh generation failed: " + e.message));
            }
        }
    });
}
