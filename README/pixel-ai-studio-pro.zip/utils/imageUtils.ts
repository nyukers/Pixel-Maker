
/**
 * Takes an image data URL and a scale factor, and returns a new data URL for the upscaled image.
 * @param imageUrl The data URL of the image to upscale.
 * @param scale The factor by which to scale the image (e.g., 2 for 2x).
 * @returns A promise that resolves with the data URL of the upscaled image.
 */
export function upscaleImageOnClient(imageUrl: string, scale: number): Promise<string> {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                return reject(new Error('Could not get canvas context.'));
            }

            const newWidth = img.width * scale;
            const newHeight = img.height * scale;

            canvas.width = newWidth;
            canvas.height = newHeight;
            
            // Use image smoothing for a better quality upscale before AI enhancement
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            ctx.drawImage(img, 0, 0, newWidth, newHeight);

            resolve(canvas.toDataURL('image/png')); // Always export as PNG to avoid compression artifacts before AI step
        };
        img.onerror = (err) => {
            reject(new Error(`Failed to load image for client-side upscaling.`));
        };
        img.src = imageUrl;
    });
}

/**
 * Takes an image data URL, identifies the background color(s) (handles solid and checkerboard),
 * and returns a new data URL for a PNG with those colors made transparent.
 * @param imageUrl The data URL of the image to process.
 * @param tolerance A value from 0-255 to determine how close a color needs to be to the background color to be removed.
 * @returns A promise that resolves with the data URL of the processed image.
 */
export function makeBackgroundTransparent(imageUrl: string, tolerance: number = 20): Promise<string> {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                return reject(new Error('Could not get canvas context.'));
            }

            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);

            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imageData.data;

            // --- Color Identification ---
            const colorsToRemove: { r: number; g: number; b: number }[] = [];
            
            // 1. Get the top-left corner pixel color as the primary background color.
            const color1 = { r: data[0], g: data[1], b: data[2] };
            colorsToRemove.push(color1);

            // 2. Scan the top row to find a second, different color for checkerboard patterns.
            for (let i = 4; i < canvas.width * 4; i += 4) {
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                if (Math.abs(r - color1.r) > tolerance || Math.abs(g - color1.g) > tolerance || Math.abs(b - color1.b) > tolerance) {
                    const color2 = { r, g, b };
                    colorsToRemove.push(color2);
                    break; 
                }
            }

            // --- Pixel Processing ---
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];

                // Check if the current pixel matches any of the identified background colors.
                for (const color of colorsToRemove) {
                    const distance = Math.sqrt(
                        Math.pow(r - color.r, 2) +
                        Math.pow(g - color.g, 2) +
                        Math.pow(b - color.b, 2)
                    );

                    if (distance < tolerance) {
                        data[i + 3] = 0; // Set alpha to 0 (transparent)
                        break; // Move to the next pixel
                    }
                }
            }

            ctx.putImageData(imageData, 0, 0);
            resolve(canvas.toDataURL('image/png'));
        };
        img.onerror = (err) => {
            reject(new Error(`Failed to load image for transparency processing: ${err}`));
        };
        img.src = imageUrl;
    });
}

export const getImageDimensions = (dataUrl: string): Promise<{ width: number; height: number }> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.width, height: img.height });
      };
      img.onerror = (err) => {
          console.error("Failed to load image for dimension check", err);
          reject(new Error("Failed to get image dimensions."));
      }
      img.src = dataUrl;
    });
};

/**
 * Resizes an image to a specific width and height.
 * @param imageUrl The data URL of the image to resize.
 * @param width The target width.
 * @param height The target height.
 * @returns A promise that resolves with the data URL of the resized image as a PNG.
 */
export function resizeImageOnClient(imageUrl: string, width: number, height: number): Promise<string> {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                return reject(new Error('Could not get canvas context.'));
            }

            canvas.width = width;
            canvas.height = height;
            
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            ctx.drawImage(img, 0, 0, width, height);

            resolve(canvas.toDataURL('image/png'));
        };
        img.onerror = () => {
            reject(new Error(`Failed to load image for client-side resizing.`));
        };
        img.src = imageUrl;
    });
}

/**
 * Saves an image to the local file system with specified format and optional metadata.
 */
export function saveImage(dataUrl: string, filename: string, format: 'png' | 'jpeg', quality: number = 90, metaComment: string = '') {
    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if(!ctx) return;

        // Fill white background for JPEG transparency handling
        if (format === 'jpeg') {
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        
        ctx.drawImage(img, 0, 0);

        let finalDataUrl = canvas.toDataURL(`image/${format}`, quality / 100);

        // Inject EXIF Metadata for JPEG if present
        // Safely access global piexif object
        const piexif = (window as any).piexif;

        if (format === 'jpeg' && typeof piexif !== 'undefined') {
            try {
                const brandingText = "Powered by Pixel AI Studio, (C) Nyukers, 2026. https://nyukers.blogspot.com";
                const fullDescription = metaComment ? `${metaComment}. ${brandingText}` : brandingText;

                const zeroth: any = {};
                const exif: any = {};
                const gps: any = {};
                
                // ImageDescription (Code 270)
                zeroth[piexif.ImageIFD.ImageDescription] = fullDescription;
                // Software (Code 305)
                zeroth[piexif.ImageIFD.Software] = "Pixel AI Studio Pro";
                // Copyright (Code 33432)
                zeroth[piexif.ImageIFD.Copyright] = "(C) Nyukers, 2026";
                // Artist (Code 315)
                zeroth[piexif.ImageIFD.Artist] = "Nyukers";

                const exifObj = { "0th": zeroth, "Exif": exif, "GPS": gps };
                const exifBytes = piexif.dump(exifObj);
                finalDataUrl = piexif.insert(exifBytes, finalDataUrl);
            } catch (e) {
                console.error("Failed to insert EXIF metadata", e);
            }
        }

        const a = document.createElement('a');
        a.href = finalDataUrl;
        a.download = `${filename}.${format}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };
    img.src = dataUrl;
}
