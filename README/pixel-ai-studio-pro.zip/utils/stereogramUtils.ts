
/**
 * Generates a Random Dot Stereogram (Magic Eye) from a depth map.
 * Re-implemented to match the logic of a known working Python script.
 * 
 * @param depthMapDataUrl - The base64 data URL of the grayscale depth map.
 * @returns A Promise that resolves to the base64 data URL of the generated stereogram.
 */
export async function generateStereogram(depthMapDataUrl: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const depthImage = new Image();
        depthImage.crossOrigin = "Anonymous";
        depthImage.onload = () => {
            try {
                const width = depthImage.width;
                const height = depthImage.height;

                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    throw new Error("Could not create canvas context");
                }

                // 1. Draw Depth Map to get pixel data
                ctx.drawImage(depthImage, 0, 0);
                const depthData = ctx.getImageData(0, 0, width, height);
                const pixels = depthData.data; // RGBA

                // 2. Normalize Depth Map (Auto-Levels)
                // Ensures that z goes from 0 to 1 fully, regardless of the input contrast.
                let minDepth = 255;
                let maxDepth = 0;

                for (let i = 0; i < pixels.length; i += 4) {
                    const val = pixels[i]; // R channel
                    if (val < minDepth) minDepth = val;
                    if (val > maxDepth) maxDepth = val;
                }

                const depthRange = maxDepth - minDepth;
                const depthScale = depthRange > 0 ? 255 / depthRange : 0; 

                // 3. Configuration (Matched to Python Script)
                const patternWidth = 140; // "width" in python script texture generation
                const depthFactor = 0.3;  // "depth_factor" in python script

                // 4. Generate Texture (Random Noise)
                // Emulating: texture = np.random.randint(0, 256, (height, pattern_width, 3), dtype=np.uint8)
                const textureData = new Uint8ClampedArray(height * patternWidth * 4);
                for (let i = 0; i < textureData.length; i += 4) {
                    textureData[i] = Math.floor(Math.random() * 256);     // R
                    textureData[i + 1] = Math.floor(Math.random() * 256); // G
                    textureData[i + 2] = Math.floor(Math.random() * 256); // B
                    textureData[i + 3] = 255;                             // A
                }

                // 5. Generate Stereogram
                const resultImageData = ctx.createImageData(width, height);
                const rData = resultImageData.data;

                for (let y = 0; y < height; y++) {
                    for (let x = 0; x < width; x++) {
                        
                        // Get normalized depth (z) 0..1
                        const depthIdx = (y * width + x) * 4;
                        let rawDepth = pixels[depthIdx]; // Using Red channel
                        
                        if (depthScale > 0) {
                            rawDepth = (rawDepth - minDepth) * depthScale;
                        } else {
                            rawDepth = 0;
                        }
                        
                        const z = rawDepth / 255;

                        // Calculate shift
                        // Python: shift = int(pattern_width * (1 - depth_factor * z))
                        const shift = Math.floor(patternWidth * (1 - depthFactor * z));

                        let r, g, b;

                        if (x < shift) {
                            // Left edge: fill with texture
                            // Python: stereogram[y, x] = texture[y, x % pattern_width]
                            const texX = x % patternWidth;
                            const texIdx = (y * patternWidth + texX) * 4;
                            r = textureData[texIdx];
                            g = textureData[texIdx + 1];
                            b = textureData[texIdx + 2];
                        } else {
                            // Main part: copy shifted pixel
                            // Python: stereogram[y, x] = stereogram[y, x - shift]
                            const prevIdx = (y * width + (x - shift)) * 4;
                            r = rData[prevIdx];
                            g = rData[prevIdx + 1];
                            b = rData[prevIdx + 2];
                        }

                        const idx = (y * width + x) * 4;
                        rData[idx] = r;
                        rData[idx + 1] = g;
                        rData[idx + 2] = b;
                        rData[idx + 3] = 255;
                    }
                }

                ctx.putImageData(resultImageData, 0, 0);

                // 6. Draw Guide Dots (Optional but helpful helper)
                const midX = width / 2;
                const dotY = 30;
                const dotRadius = 6;

                ctx.save();
                ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.fillRect(midX - (patternWidth/2) - 40, 0, patternWidth + 80, 60);

                ctx.fillStyle = '#FFFF00'; 
                ctx.strokeStyle = 'red';
                ctx.lineWidth = 2;

                // Left Dot
                ctx.beginPath();
                ctx.arc(midX - patternWidth / 2, dotY, dotRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Right Dot
                ctx.beginPath();
                ctx.arc(midX + patternWidth / 2, dotY, dotRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();
                
                ctx.font = "14px sans-serif";
                ctx.fillStyle = "white";
                ctx.textAlign = "center";
                ctx.fillText("Focus until 2 dots become 3", midX, 52);
                ctx.restore();

                resolve(canvas.toDataURL('image/jpeg', 0.95));

            } catch (e: any) {
                reject(new Error("Stereogram generation failed: " + e.message));
            }
        };
        depthImage.onerror = () => reject(new Error("Failed to load depth map image"));
        depthImage.src = depthMapDataUrl;
    });
}
