
/**
 * Generates an "Atmospheric Fog" effect using a depth map.
 * Distant objects (darker in depth map) will be blended with a fog color.
 * Foreground objects (lighter in depth map) will remain clear.
 * 
 * @param originalImageUrl - The base64 data URL of the color source image.
 * @param depthMapDataUrl - The base64 data URL of the grayscale depth map.
 * @returns A Promise that resolves to the base64 data URL of the processed image.
 */
export async function generateFog(originalImageUrl: string, depthMapDataUrl: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const originalImg = new Image();
        originalImg.crossOrigin = "Anonymous";
        const depthImg = new Image();
        depthImg.crossOrigin = "Anonymous";

        let loadedCount = 0;
        const checkLoaded = () => {
            loadedCount++;
            if (loadedCount === 2) process();
        };

        originalImg.onload = checkLoaded;
        depthImg.onload = checkLoaded;
        originalImg.onerror = () => reject(new Error("Failed to load original image"));
        depthImg.onerror = () => reject(new Error("Failed to load depth map"));

        originalImg.src = originalImageUrl;
        depthImg.src = depthMapDataUrl;

        function process() {
            try {
                const width = originalImg.width;
                const height = originalImg.height;
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error("No context");

                // Draw original to get data
                ctx.drawImage(originalImg, 0, 0, width, height);
                const originalData = ctx.getImageData(0, 0, width, height);
                
                // Draw depth to get data
                ctx.clearRect(0, 0, width, height);
                ctx.drawImage(depthImg, 0, 0, width, height);
                const depthData = ctx.getImageData(0, 0, width, height);

                const outputData = ctx.createImageData(width, height);

                // Normalize depth map to ensure full range
                let minDepth = 255;
                let maxDepth = 0;
                for (let k = 0; k < depthData.data.length; k += 4) {
                    const val = depthData.data[k];
                    if (val < minDepth) minDepth = val;
                    if (val > maxDepth) maxDepth = val;
                }
                const depthRange = maxDepth - minDepth;
                const depthScale = depthRange > 0 ? 255.0 / depthRange : 0;

                // Fog Color (Cool Blue/Grey)
                const fogR = 210;
                const fogG = 220;
                const fogB = 235;
                
                const maxFogOpacity = 0.90; // Maximum fog density at the furthest point

                // Safe Zone Threshold (0.0 to 1.0)
                // Pixels with depth > this value will have ZERO fog.
                // 0.6 means the closest 40% of the scene is crystal clear.
                const fogStartThreshold = 0.6; 

                const data = outputData.data;
                const oPix = originalData.data;
                const dPix = depthData.data;

                for (let i = 0; i < data.length; i += 4) {
                    let rawDepth = dPix[i];
                    
                    if (depthScale > 0) {
                        rawDepth = (rawDepth - minDepth) * depthScale;
                    }

                    // Normalized depth: 1.0 = Close, 0.0 = Far
                    const depth = rawDepth / 255.0;
                    
                    let fogFactor = 0;

                    if (depth > fogStartThreshold) {
                        // Foreground Safe Zone - Crystal Clear
                        fogFactor = 0;
                    } else {
                        // Background - Apply Fog
                        // Normalize the remaining range (0 to threshold) to (0 to 1)
                        // So that fog starts gently right after the threshold
                        const rangePos = depth / fogStartThreshold; // 0.0 (Far) to 1.0 (Threshold boundary)
                        
                        // Invert: we want fog to be 1.0 at far, and 0.0 at boundary
                        let fogIntensity = 1.0 - rangePos;
                        
                        // Ease-out power curve for smoother transition
                        fogIntensity = Math.pow(fogIntensity, 1.2);
                        
                        fogFactor = fogIntensity * maxFogOpacity;
                    }

                    // Blend: Original * (1-fog) + FogColor * fog
                    data[i] = oPix[i] * (1 - fogFactor) + fogR * fogFactor;     // R
                    data[i+1] = oPix[i+1] * (1 - fogFactor) + fogG * fogFactor; // G
                    data[i+2] = oPix[i+2] * (1 - fogFactor) + fogB * fogFactor; // B
                    data[i+3] = 255; // Alpha
                }

                ctx.putImageData(outputData, 0, 0);
                resolve(canvas.toDataURL('image/jpeg', 0.95));
            } catch (e: any) {
                reject(new Error("Fog generation failed: " + e.message));
            }
        }
    });
}
