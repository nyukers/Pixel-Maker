
/**
 * Generates a "Wiggle 3D" video animation.
 * It takes a source image and a depth map, generates shifted frames to simulate
 * different viewing angles, and compiles them into a looped video using MediaRecorder.
 */
export async function generateWiggle3D(originalImageUrl: string, depthMapDataUrl: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const originalImg = new Image();
        originalImg.crossOrigin = "Anonymous";
        const depthImg = new Image();
        depthImg.crossOrigin = "Anonymous";

        let loadedCount = 0;
        const checkLoaded = () => {
            loadedCount++;
            if (loadedCount === 2) {
                process();
            }
        };

        originalImg.onload = checkLoaded;
        depthImg.onload = checkLoaded;
        originalImg.onerror = () => reject(new Error("Failed to load original image."));
        depthImg.onerror = () => reject(new Error("Failed to load depth map."));

        originalImg.src = originalImageUrl;
        depthImg.src = depthMapDataUrl;

        function process() {
            try {
                const width = originalImg.width;
                const height = originalImg.height;

                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error("Could not create canvas");

                // 1. Prepare Data Buffers
                ctx.drawImage(originalImg, 0, 0);
                const originalPixels = ctx.getImageData(0, 0, width, height).data;

                ctx.clearRect(0, 0, width, height);
                ctx.drawImage(depthImg, 0, 0, width, height);
                const depthPixels = ctx.getImageData(0, 0, width, height).data;

                // 2. Define Frames (Shifts)
                // We will create 3 distinct frames: Left (-shift), Center (0), Right (+shift)
                // Sequence: L -> C -> R -> C -> Loop
                const maxShift = Math.floor(width * 0.015); // 1.5% shift magnitude
                const shifts = [-maxShift, 0, maxShift, 0]; // The loop sequence
                
                // Pre-render frames to ImageBitmaps or ImageData for performance
                const frames: ImageData[] = [];

                for (const shift of shifts) {
                    const frameData = ctx.createImageData(width, height);
                    const framePixels = frameData.data;

                    for (let y = 0; y < height; y++) {
                        for (let x = 0; x < width; x++) {
                            const idx = (y * width + x) * 4;
                            
                            // Normalized depth 0..1 (255 is Close/White)
                            const depthVal = depthPixels[idx] / 255.0;
                            
                            // Logic: 
                            // Objects closer (high depth) shift MORE than background.
                            // Parallax: When camera moves LEFT, close objects move RIGHT relative to background.
                            // Here "shift" is the camera offset simulation.
                            // Let's simplify: We displace pixels based on depth.
                            
                            const pixelDisplacement = Math.floor(shift * depthVal);
                            
                            // Source pixel X
                            let srcX = x - pixelDisplacement;
                            
                            // Clamp/Wrap logic to avoid holes
                            if (srcX < 0) srcX = 0;
                            if (srcX >= width) srcX = width - 1;

                            const srcIdx = (y * width + srcX) * 4;

                            framePixels[idx] = originalPixels[srcIdx];         // R
                            framePixels[idx + 1] = originalPixels[srcIdx + 1]; // G
                            framePixels[idx + 2] = originalPixels[srcIdx + 2]; // B
                            framePixels[idx + 3] = 255;                        // A
                        }
                    }
                    frames.push(frameData);
                }

                // 3. Recording Setup
                // We draw to the canvas at a set FPS and record the stream
                const stream = canvas.captureStream(30); // 30 FPS stream
                const recorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9' });
                const chunks: Blob[] = [];

                recorder.ondataavailable = (e) => {
                    if (e.data.size > 0) chunks.push(e.data);
                };

                recorder.onstop = () => {
                    const blob = new Blob(chunks, { type: 'video/webm' });
                    const url = URL.createObjectURL(blob);
                    resolve(url);
                };

                recorder.start();

                // 4. Animation Loop for Recording
                let frameIndex = 0;
                const fps = 10; // Wiggle effect looks good at lower/choppy FPS (e.g., 10-12)
                const durationSeconds = 2; // 2 second loop is enough
                const totalFramesToRecord = fps * durationSeconds;
                let framesRecorded = 0;

                const interval = setInterval(() => {
                    // Draw current frame
                    ctx.putImageData(frames[frameIndex], 0, 0);
                    
                    // Advance frame index (looping through the shifts array)
                    frameIndex = (frameIndex + 1) % frames.length;
                    framesRecorded++;

                    if (framesRecorded >= totalFramesToRecord) {
                        clearInterval(interval);
                        recorder.stop();
                    }
                }, 1000 / fps);

            } catch (e: any) {
                reject(new Error("Wiggle 3D generation failed: " + e.message));
            }
        }
    });
}
