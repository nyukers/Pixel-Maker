
/**
 * Generates a Red/Cyan Anaglyph 3D image from an original image and a depth map.
 * 
 * @param originalImageUrl - The base64 data URL of the color source image.
 * @param depthMapDataUrl - The base64 data URL of the grayscale depth map.
 * @returns A Promise that resolves to the base64 data URL of the generated anaglyph image.
 */
export async function generateAnaglyph(originalImageUrl: string, depthMapDataUrl: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const originalImg = new Image();
        originalImg.crossOrigin = "Anonymous";
        
        const depthImg = new Image();
        depthImg.crossOrigin = "Anonymous";

        let loadedCount = 0;
        const checkLoaded = () => {
            loadedCount++;
            if (loadedCount === 2) {
                process();
            }
        };

        originalImg.onload = checkLoaded;
        depthImg.onload = checkLoaded;
        originalImg.onerror = () => reject(new Error("Failed to load original image for anaglyph."));
        depthImg.onerror = () => reject(new Error("Failed to load depth map for anaglyph."));

        originalImg.src = originalImageUrl;
        depthImg.src = depthMapDataUrl;

        function process() {
            try {
                const width = originalImg.width;
                const height = originalImg.height;

                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) throw new Error("Could not create canvas context");

                // Draw Original
                ctx.drawImage(originalImg, 0, 0, width, height);
                const originalData = ctx.getImageData(0, 0, width, height);
                
                // Draw Depth Map (resize to match original if needed)
                ctx.clearRect(0, 0, width, height);
                ctx.drawImage(depthImg, 0, 0, width, height);
                const depthData = ctx.getImageData(0, 0, width, height);

                // Create Output Buffer
                const outputData = ctx.createImageData(width, height);
                
                const originalPixels = originalData.data;
                const depthPixels = depthData.data;
                const outputPixels = outputData.data;

                // Parameters
                const strength = 0.02; // Shift multiplier relative to width
                const maxShift = Math.floor(width * strength);

                for (let y = 0; y < height; y++) {
                    for (let x = 0; x < width; x++) {
                        const idx = (y * width + x) * 4;
                        
                        // Get Depth (0..1)
                        // Brighter = Closer. 
                        // If depth is 255 (close), shift is max.
                        const depthVal = depthPixels[idx] / 255.0;
                        
                        // Calculate offset
                        const offset = Math.floor(maxShift * depthVal);

                        // RED CHANNEL (Left Eye)
                        // To make objects pop OUT (closer), the Left eye view should be shifted RIGHT relative to the Right eye view.
                        // Wait, standard logic:
                        // Screen plane = 0 shift.
                        // In front of screen = Crossed disparity (Left Image content is to the Right).
                        // Behind screen = Uncrossed disparity (Left Image content is to the Left).
                        
                        // Let's implement "Pop Out" (Crossed Disparity).
                        // Left Eye (Red) source pixel comes from the RIGHT of current x? 
                        // No, we are constructing the view at X.
                        // If the object is close, the Left Eye sees it further to the Right than the Cyclopean (Center) eye.
                        // So to fill pixel X for the Left Eye, we should look at the image content from the LEFT (x - offset).
                        // Let's verify: If we take content from X-offset and put it at X, we moved the content to the RIGHT. Correct.
                        
                        let r = 0;
                        const leftSrcX = x - offset;
                        if (leftSrcX >= 0 && leftSrcX < width) {
                            const leftIdx = (y * width + leftSrcX) * 4;
                            r = originalPixels[leftIdx];
                        }

                        // CYAN CHANNEL (Right Eye - Green + Blue)
                        // Right Eye sees object further to the Left.
                        // So we move content to the Left.
                        // To put content at X, we take source from RIGHT (x + offset).
                        let g = 0;
                        let b = 0;
                        const rightSrcX = x + offset;
                        if (rightSrcX >= 0 && rightSrcX < width) {
                            const rightIdx = (y * width + rightSrcX) * 4;
                            g = originalPixels[rightIdx + 1];
                            b = originalPixels[rightIdx + 2];
                        }

                        // Full Alpha
                        const a = 255;

                        outputPixels[idx] = r;
                        outputPixels[idx + 1] = g;
                        outputPixels[idx + 2] = b;
                        outputPixels[idx + 3] = a;
                    }
                }

                ctx.putImageData(outputData, 0, 0);
                resolve(canvas.toDataURL('image/jpeg', 0.95));

            } catch (e: any) {
                reject(new Error("Anaglyph generation failed: " + e.message));
            }
        }
    });
}
