
import React, { useEffect, useState } from 'react';
import * as imageq from 'image-q';

interface ColorLegendProps {
  originalImageUrl: string; // URL оригінального кольорового зображення
  targetColorCount: number; // Наприклад, 32
}

interface PaletteItem {
  id: number;
  hex: string;
  rgb: { r: number; g: number; b: number };
}

export const ColorLegendGenerator: React.FC<ColorLegendProps> = ({ 
  originalImageUrl, 
  targetColorCount 
}) => {
  const [palette, setPalette] = useState<PaletteItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const processImage = async () => {
      setIsProcessing(true);
      try {
        // 1. Завантажуємо зображення
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.src = originalImageUrl;
        
        await new Promise((resolve) => { img.onload = resolve; });

        // 2. Малюємо на Canvas, щоб отримати доступ до пікселів
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        
        // 3. КВАНТУВАННЯ (Магія image-q)
        // Перетворюємо Image data на PointContainer
        const pointContainer = imageq.utils.PointContainer.fromUint8Array(
          imageData.data, 
          canvas.width, 
          canvas.height
        );

        // Use buildPalette instead of direct class usage
        const generatedPalette = await imageq.buildPalette([pointContainer], {
           colors: targetColorCount
        });
        const pointArray = generatedPalette.getPointContainer().getPointArray();

        // 4. Формуємо чисту структуру даних для Легенди
        const cleanPalette: PaletteItem[] = pointArray.map((p, index) => {
          // Конвертація RGB в HEX
          const r = p.r, g = p.g, b = p.b;
          const hex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
          
          return {
            id: index + 1, // Номери від 1 до N
            hex: hex,
            rgb: { r, g, b }
          };
        });

        setPalette(cleanPalette);

      } catch (error) {
        console.error("Помилка обробки зображення:", error);
      } finally {
        setIsProcessing(false);
      }
    };

    if (originalImageUrl) {
      processImage();
    }
  }, [originalImageUrl, targetColorCount]);

  if (isProcessing) return <div>Generating Legend...</div>;

  return (
    <div className="p-4 border rounded shadow-sm bg-white">
      <h2 className="text-xl font-bold mb-4 text-center">LEGEND OF COLORS</h2>
      
      {/* Сітка легенди */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))', 
        gap: '10px' 
      }}>
        {palette.map((item) => (
          <div key={item.id} className="flex flex-col items-center">
            {/* Квадратик кольору */}
            <div 
              style={{ 
                backgroundColor: item.hex, 
                width: '50px', 
                height: '50px', 
                borderRadius: '8px',
                border: '1px solid #ccc',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }} 
            />
            {/* Номер */}
            <span className="mt-1 font-bold text-lg">{item.id}</span>
            <span className="text-xs text-gray-500">{item.hex}</span>
          </div>
        ))}
      </div>
    </div>
  );
};