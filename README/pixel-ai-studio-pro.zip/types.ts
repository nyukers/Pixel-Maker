
export interface ResultItem {
  id: string;
  imageUrl: string; 
  videoUrl?: string; 
  mimeType: string;
  prompt: string;
  sourceImageUrl?: string; 
  width?: number;
  height?: number;
  isUpscaled?: boolean;
}

export interface DetectionBox {
  label: string;
  box_2d: [number, number, number, number]; // [ymin, xmin, ymax, xmax] normalized 0-1000
}

export type ComparisonMode = 'side' | 'slider' | 'single';
export type PromptMode = 'retouch' | 'imagination' | 'animation' | 'generate';
export type AspectRatio = '16:9' | '9:16' | '1:1' | '4:3' | '3:4';
export type AppMode = 'single' | 'analyze';
export type AnalysisItemStatus = 'pending' | 'processing' | 'completed' | 'error';

export interface CameraAnalysis {
  angle: string;
  framing: string;
  model: string;
}

export interface AnalysisResult {
  composition: string;
  subject: string;
  background: string;
  style: string;
  artist?: string;
  mood: string;
  camera?: CameraAnalysis;
}

export interface CreativeIdea {
  title: string;
  description: string;
  prompt: string;
}

export interface AiDetectionResult {
  score: number;
  assessment: string;
  indicators: string[];
  possibleTool?: string;
}

export interface AnalysisItem {
  id: string;
  file: File;
  originalDataUrl: string;
  mimeType: string;
  analysisResult: AnalysisResult | null;
  aiDetectionResult: AiDetectionResult | null;
  status: AnalysisItemStatus;
  error?: string;
  exifData?: string | null;
  detectedObjects?: DetectionBox[];
}

export interface Pan { x: number; y: number; }
export interface PresetPrompt { 
  id: string; 
  prompt: string; 
  aspectRatio?: AspectRatio;
}
export interface LoadedPreset extends PresetPrompt { displayName: string; category: PromptMode; }
export type FilterType = 'none' | 'sepia' | 'grayscale' | 'vintage';
export interface FilterState { type: FilterType; intensity: number; }
export interface CropBox { x: number; y: number; width: number; height: number; }
export interface AiFilterState { type: string; intensity: number; }
export type EditSubTool = 'none' | 'straighten' | 'crop' | 'outpaint';
export interface EditState {
  rotation: number;
  scaleX: number;
  straightenAngle: number;
  filter: FilterState;
  activeSubTool: EditSubTool;
}
export interface Action {
  id: string;
  name: string;
  steps: string[];
  isAtomic?: boolean;
}
